/** Local, reversible application surfaces. Vehicle and journey state live elsewhere. */
let mounted = false, shellApi;
const el = id => document.getElementById(id);
export const SHELL_APPS = Object.freeze(['navigation', 'hawon', 'library', 'climate', 'media', 'phone', 'vehicle', 'radio']);
export function createShellState() {
  return { app: 'navigation', previous: 'navigation', driver: 23.5, passenger: 23.5, fan: 3, sync: true, ac: true, auto: true, front: false, rear: false, recirculate: false, driverSeat: 0, passengerSeat: 0, airflow: 0, track: 0, playing: false, radioPlaying: false, station: 0, volume: 45, phoneTab: 'favorites', digits: '', phonePreview: '', vehicleTab: 'status' };
}
export function reduceShell(state, action) {
  const s = { ...state };
  if (action.type === 'OPEN' && SHELL_APPS.includes(action.app)) {
    if (s.app === action.app && ['climate', 'library'].includes(action.app)) return { ...s, app: s.previous };
    if (s.app !== action.app) { s.previous = s.app; s.app = action.app; }
  } else if (action.type === 'BACK') {
    s.app = s.app === 'navigation' ? 'navigation' : s.previous;
    s.previous = 'navigation';
  } else if (action.type === 'TEMP' && ['driver', 'passenger'].includes(action.side)) {
    const value = Number(action.value);
    if (!Number.isFinite(value)) return state;
    s[action.side] = Math.round(Math.max(16, Math.min(30, value)) * 2) / 2;
    if (s.sync) s.driver = s.passenger = s[action.side];
  } else if (action.type === 'FAN' && Number.isFinite(Number(action.value))) {
    s.fan = Math.max(0, Math.min(8, Math.round(Number(action.value)))); s.auto = false;
  } else if (action.type === 'TOGGLE' && ['sync', 'ac', 'auto', 'front', 'rear', 'recirculate', 'playing', 'radioPlaying'].includes(action.key)) {
    s[action.key] = !s[action.key];
    if (action.key === 'sync' && s.sync) s.passenger = s.driver;
  } else if (action.type === 'SEAT' && ['driverSeat', 'passengerSeat'].includes(action.key)) s[action.key] = (s[action.key] + 1) % 4;
  else if (action.type === 'AIRFLOW') s.airflow = (s.airflow + 1) % 3;
  else if (action.type === 'TRACK') s.track = ((s.track + (Number(action.step) || 0)) % 3 + 3) % 3;
  else if (action.type === 'SELECT_TRACK' && Number.isInteger(action.index) && action.index >= 0 && action.index < 3) s.track = action.index;
  else if (action.type === 'STATION' && Number.isInteger(action.index) && action.index >= 0 && action.index < 3) s.station = action.index;
  else if (action.type === 'VOLUME' && Number.isFinite(Number(action.value))) s.volume = Math.round(Math.max(0, Math.min(100, Number(action.value))));
  else if (action.type === 'PHONE_TAB' && ['favorites', 'keypad'].includes(action.tab)) { s.phoneTab = action.tab; s.phonePreview = ''; }
  else if (action.type === 'DIGIT' && /^[0-9*#]$/.test(action.digit)) { s.digits = (s.digits + action.digit).slice(0, 20); s.phonePreview = ''; }
  else if (action.type === 'ERASE') { s.digits = s.digits.slice(0, -1); s.phonePreview = ''; }
  else if (action.type === 'PHONE_PREVIEW') s.phonePreview = action.name ? `${action.name} · 연락처 미리보기` : s.digits ? `${s.digits} · 번호 미리보기` : '번호를 입력해 주세요';
  else if (action.type === 'VEHICLE_TAB' && ['status', 'driving', 'display'].includes(action.tab)) s.vehicleTab = action.tab;
  return s;
}
export function openShellApp(id) { return shellApi?.open(id); }
const h = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text !== undefined) n.textContent = text; return n; };
const icons = { navigation: 'm12 3 8 18-8-5-8 5 8-18Z', media: 'M9 18V5l12-2v13M9 8l12-2M9 18a3 2 0 1 1-6 0 3 2 0 0 1 6 0Zm12-2a3 2 0 1 1-6 0 3 2 0 0 1 6 0Z', phone: 'm6 3-3 3c0 8 7 15 15 15l3-3-5-4-3 2-5-5 2-3-4-5Z', vehicle: 'm5 9 2-5h10l2 5 2 3v7H3v-7l2-3ZM5 9h14M5 15h3m8 0h3M5 19v2m14-2v2', climate: 'M12 10C3 1 2 12 10 12c-9 9 2 10 2 2 9 9 10-2 2-2 9-9-2-10-2-2Z', radio: 'M12 9v12m-3 0h6M7 6a7 7 0 0 0 0 9m10-9a7 7 0 0 1 0 9M4 3a11 11 0 0 0 0 15m16-15a11 11 0 0 1 0 15', library: 'M3 3h6v6H3ZM15 3h6v6h-6ZM3 15h6v6H3ZM15 15h6v6h-6Z', back: 'm14 5-7 7 7 7', close: 'm6 6 12 12M6 18 18 6' };
function icon(id) {
  if (id === 'hawon') return h('span', 'shell-hawon-mark', 'h');
  const n = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); n.setAttribute('viewBox', '0 0 24 24'); n.setAttribute('aria-hidden', 'true'); n.classList.add('shell-icon');
  const p = document.createElementNS(n.namespaceURI, 'path'); p.setAttribute('d', icons[id] || icons.climate); n.append(p); return n;
}
function button(label, click, cls = 'shell-button') { const n = h('button', cls, label); n.type = 'button'; n.addEventListener('click', click); return n; }
const APP_NAMES = { navigation: '내비게이션', hawon: '하원콜', library: '앱 라이브러리', climate: '공조', media: '미디어', phone: '전화', vehicle: '차량 설정', radio: '라디오' };
const TRACKS = [{ title: 'City Lights', artist: 'Pleos Drive · Demo collection', duration: '3:42', color: 'violet' }, { title: 'Afternoon Walk', artist: 'Pleos Drive · Demo collection', duration: '4:08', color: 'green' }, { title: 'On My Way', artist: 'Pleos Drive · Demo collection', duration: '3:18', color: 'blue' }];
const STATIONS = [{ name: 'Drive FM', frequency: '89.1' }, { name: 'City FM', frequency: '91.9' }, { name: 'Relax FM', frequency: '95.9' }];
export function mountPleosShell({ map, openBrief } = {}) {
  if (mounted) return;
  const shell = el('vehicleView'), surface = shell?.querySelector('.cockpit-surface');
  if (!surface) return;
  mounted = true;
  let state = createShellState(), perspective = true, lastFocus = null;
  const drawer = el('simulationDrawer'), drawerButton = el('drawerToggle');
  const host = h('section', 'shell-app-window'); host.id = 'shellAppWindow'; host.hidden = true; host.setAttribute('aria-label', '애플리케이션 창'); surface.append(host);
  function controls(open) { if (drawer) drawer.hidden = !open; drawerButton?.setAttribute('aria-expanded', String(open)); }
  function dispatch(action, redraw = true) { state = reduceShell(state, action); if (redraw) render(); else updateDock(); }
  function open(id) { if (!SHELL_APPS.includes(id)) return false; lastFocus = document.activeElement; dispatch({ type: 'OPEN', app: id }); return true; }
  function back() { dispatch({ type: 'BACK' }); if (host.hidden) lastFocus?.focus?.({ preventScroll: true }); }
  shellApi = { open, state: () => ({ ...state }) };
  const routeButtons = [];
  function route(selector, app, before) { const n = shell.querySelector(selector); if (!n) return; routeButtons.push([n, app]); n.dataset.shellApp = app; n.addEventListener('click', event => { event.preventDefault(); event.stopImmediatePropagation(); before?.(); open(app); }, true); }
  route('#navApp', 'navigation'); route('.dock-map', 'navigation'); route('#hawonApp', 'hawon'); route('#appLibrary', 'library'); route('#mediaApp', 'media'); route('.dock-phone', 'phone'); route('.dock-radio', 'radio'); route('.dock-climate', 'climate'); route('.climate-left > button:first-child', 'vehicle');
  route('.climate-left > .temperature', 'climate'); route('.climate-right > .temperature', 'climate');
  route('.climate-left > button:nth-child(3)', 'climate', () => dispatch({ type: 'TOGGLE', key: 'front' }, false));
  route('.rear-defrost', 'climate', () => dispatch({ type: 'TOGGLE', key: 'rear' }, false));
  route('.climate-left .seat-control', 'climate', () => dispatch({ type: 'SEAT', key: 'driverSeat' }, false));
  route('.climate-right .seat-control', 'climate', () => dispatch({ type: 'SEAT', key: 'passengerSeat' }, false));
  route('.fan-level', 'climate'); route('.airflow', 'climate', () => dispatch({ type: 'AIRFLOW' }, false)); route('.recirculate', 'climate', () => dispatch({ type: 'TOGGLE', key: 'recirculate' }, false));
  el('hawonExpand')?.addEventListener('click', () => open(state.app === 'hawon' ? 'navigation' : 'hawon'));
  drawerButton?.addEventListener('click', () => controls(drawer.hidden)); el('drawerClose')?.addEventListener('click', () => controls(false));
  el('perspectiveToggle')?.addEventListener('click', () => { perspective = !perspective; map?.setPerspective?.(perspective); el('perspectiveLabel').textContent = perspective ? '2D' : '3D'; el('perspectiveToggle').setAttribute('aria-pressed', String(perspective)); el('perspectiveToggle').setAttribute('aria-label', perspective ? '2D 지도로 전환' : '3D 지도로 전환'); });
  document.addEventListener('keydown', event => { if (event.key !== 'Escape' || document.querySelector('dialog[open]')) return; if (drawer && !drawer.hidden) controls(false); else if (state.app !== 'navigation') { event.preventDefault(); back(); } });
  document.addEventListener('pointerdown', event => { if (drawer && !drawer.hidden && !drawer.contains(event.target) && !drawerButton?.contains(event.target)) controls(false); });
  function updateDock() {
    for (const [n, app] of routeButtons) { const active = state.app === app; n.classList.toggle('active', active); n.setAttribute('aria-pressed', String(active)); }
    el('mediaApp')?.setAttribute('aria-label', '미디어'); el('hawonApp')?.setAttribute('aria-label', '하원콜');
    const temps = shell.querySelectorAll('.global-nav .temperature');
    temps.forEach((n, i) => { const side = i ? 'passenger' : 'driver', value = state[side]; const strong = n.querySelector('strong'); if (strong) { strong.textContent = value.toFixed(1); strong.append(h('sup', '', '°')); } n.setAttribute('aria-label', `${i ? '동승석' : '운전석'} 설정 온도 ${value.toFixed(1)}도 · 공조 열기`); });
    const fan = shell.querySelector('.fan-level span'); if (fan) { fan.textContent = String(state.fan); fan.append(h('small', '', state.auto ? 'AUTO' : 'MANUAL')); }
    shell.querySelector('.fan-level')?.setAttribute('aria-label', `풍량 ${state.fan} ${state.auto ? '자동' : '수동'} · 공조 열기`);
    for (const [selector, key] of [['.climate-left > button:nth-child(3)', 'front'], ['.rear-defrost', 'rear'], ['.recirculate', 'recirculate'], ['.climate-left .seat-control', 'driverSeat'], ['.climate-right .seat-control', 'passengerSeat']]) {
      const n = shell.querySelector(selector); n?.classList.toggle('control-on', Boolean(state[key])); if (n) n.setAttribute('aria-pressed', String(Boolean(state[key])));
    }
  }
  function header() {
    const head = h('header', 'shell-app-heading'); const b = button('', back, 'shell-back'); b.setAttribute('aria-label', '이전 화면'); b.append(icon('back')); head.append(b, h('h2', '', APP_NAMES[state.app]), h('span', 'shell-demo', '시연'));
    const close = button('', () => { dispatch({ type: 'OPEN', app: 'navigation' }); }, 'shell-close'); close.setAttribute('aria-label', '닫고 내비게이션으로'); close.append(icon('close')); head.append(close); host.append(head);
    const body = h('div', `shell-app-body shell-${state.app}`); host.append(body); return body;
  }
  function sectionTitle(target, text, detail) { const row = h('div', 'shell-section-title'); row.append(h('h3', '', text)); if (detail) row.append(h('span', '', detail)); target.append(row); }
  function appTile(id, label = APP_NAMES[id]) { const b = button('', () => open(id), 'shell-app-tile'); const pic = h('span', `shell-app-icon shell-${id}-icon`); pic.append(icon(id)); b.append(pic, h('span', '', label)); return b; }
  function library(body) {
    sectionTitle(body, '차량 제어'); const climate = h('div', 'shell-shortcuts');
    for (const [label, key] of [['앞 유리', 'front'], ['뒷 유리', 'rear'], ['운전석 시트', 'driverSeat'], ['동승석 시트', 'passengerSeat']]) { const b = button(label, () => { dispatch({ type: key.includes('Seat') ? 'SEAT' : 'TOGGLE', key }, false); open('climate'); }, 'shell-shortcut'); b.prepend(icon(key.includes('Seat') ? 'vehicle' : 'climate')); climate.append(b); }
    body.append(climate); sectionTitle(body, '모든 앱', '앱을 눌러 실행'); const grid = h('div', 'shell-library-grid'); for (const id of ['navigation', 'media', 'phone', 'radio', 'vehicle', 'climate', 'hawon']) grid.append(appTile(id)); body.append(grid);
  }
  function slider(label, value, min, max, step, changed) { const wrap = h('label', 'shell-slider'); const title = h('span', '', label); const out = h('output', '', String(value)); title.append(out); const input = h('input'); input.type = 'range'; input.min = min; input.max = max; input.step = step; input.value = value; input.setAttribute('aria-label', label); input.addEventListener('input', () => { changed(Number(input.value)); out.textContent = input.value; }); input.addEventListener('change', () => render()); wrap.append(title, input); return wrap; }
  function toggle(label, key, cls = '') { const b = button(label, () => dispatch({ type: 'TOGGLE', key }), `shell-toggle ${state[key] ? 'selected' : ''} ${cls}`); b.setAttribute('aria-pressed', String(state[key])); return b; }
  function climate(body) {
    const temps = h('div', 'shell-temp-zones');
    for (const [side, label] of [['driver', '운전석'], ['passenger', '동승석']]) { const zone = h('section', 'shell-temp-zone'); zone.append(h('h3', '', label)); const row = h('div', 'shell-temp-control'); const display = h('strong', '', `${state[side].toFixed(1)}°`); const down = button('−', () => dispatch({ type: 'TEMP', side, value: state[side] - .5 }), 'shell-temp-step'); down.setAttribute('aria-label', `${label} 온도 낮추기`); const up = button('+', () => dispatch({ type: 'TEMP', side, value: state[side] + .5 }), 'shell-temp-step'); up.setAttribute('aria-label', `${label} 온도 높이기`); row.append(down, display, up); zone.append(row); zone.append(slider(`${label} 온도`, state[side], 16, 30, .5, value => { dispatch({ type: 'TEMP', side, value }, false); temps.querySelectorAll('.shell-temp-control strong').forEach((n, i) => n.textContent = `${state[i ? 'passenger' : 'driver'].toFixed(1)}°`); })); temps.append(zone); }
    body.append(temps); const modes = h('div', 'shell-control-row'); for (const [name, key] of [['AUTO', 'auto'], ['A/C', 'ac'], ['SYNC', 'sync'], ['내기 순환', 'recirculate']]) modes.append(toggle(name, key)); body.append(modes);
    body.append(slider('풍량', state.fan, 0, 8, 1, value => dispatch({ type: 'FAN', value }, false)));
    const lower = h('div', 'shell-climate-lower'); const defrost = h('section', 'shell-control-group'); sectionTitle(defrost, '유리'); defrost.append(toggle('앞 유리 성에 제거', 'front'), toggle('뒷 유리 성에 제거', 'rear'));
    const seats = h('section', 'shell-control-group'); sectionTitle(seats, '시트'); for (const [label, key] of [['운전석', 'driverSeat'], ['동승석', 'passengerSeat']]) seats.append(button(`${label} 열선  ${state[key] ? `${state[key]}단계` : '꺼짐'}`, () => dispatch({ type: 'SEAT', key }), `shell-toggle ${state[key] ? 'selected' : ''}`));
    lower.append(defrost, seats); body.append(lower, button(`바람 방향  ·  ${['상체', '상체 + 발', '앞 유리 + 발'][state.airflow]}`, () => dispatch({ type: 'AIRFLOW' }), 'shell-wide-button'), h('p', 'shell-footnote', '이 화면의 설정은 시연에만 적용돼요.'));
  }
  function media(body) {
    const track = TRACKS[state.track], player = h('div', 'shell-music-player'), cover = h('div', `shell-album ${track.color}`); cover.append(h('span', 'shell-album-lines'), h('span', '', 'PLEOS\nDRIVE'), h('small', '', 'DEMO COLLECTION'));
    const info = h('div', 'shell-track-info'); info.append(h('span', 'shell-overline', 'MY MUSIC'), h('h3', '', track.title), h('p', '', track.artist)); const seek = h('div', 'shell-progress'); seek.append(h('i')); info.append(seek); const times = h('div', 'shell-track-time'); times.append(h('span', '', '0:00'), h('span', '', track.duration)); info.append(times);
    const controls = h('div', 'shell-player-controls'); const prev = button('Ⅰ◀', () => dispatch({ type: 'TRACK', step: -1 })); prev.setAttribute('aria-label', '이전 곡'); const play = button(state.playing ? 'Ⅱ' : '▶', () => dispatch({ type: 'TOGGLE', key: 'playing' }), 'shell-play'); play.setAttribute('aria-label', state.playing ? '미디어 일시 정지' : '미디어 재생 상태 체험'); play.setAttribute('aria-pressed', String(state.playing)); const next = button('▶Ⅰ', () => dispatch({ type: 'TRACK', step: 1 })); next.setAttribute('aria-label', '다음 곡'); controls.append(prev, play, next); info.append(controls, h('p', 'shell-footnote', state.playing ? '재생 화면 체험 중 · 음악 소리는 재생하지 않아요.' : '음원 없는 플레이어 시연')); player.append(cover, info); body.append(player);
    const list = h('div', 'shell-playlist'); sectionTitle(list, 'Drive playlist', '3곡'); TRACKS.forEach((t, index) => { const b = button('', () => dispatch({ type: 'SELECT_TRACK', index }), `shell-track ${index === state.track ? 'selected' : ''}`); b.append(h('span', 'shell-track-number', String(index + 1)), h('strong', '', t.title), h('span', '', t.duration)); b.setAttribute('aria-pressed', String(index === state.track)); list.append(b); }); body.append(list);
    const brief = button('오늘 일정 음성  ↗', () => { if (openBrief) openBrief(); else document.dispatchEvent(new CustomEvent('pleos:brief')); }, 'shell-brief-button'); body.append(brief);
  }
  function phone(body) {
    const tabs = h('div', 'shell-tabs'); for (const [id, title] of [['favorites', '즐겨찾기'], ['keypad', '키패드']]) { const b = button(title, () => dispatch({ type: 'PHONE_TAB', tab: id }), state.phoneTab === id ? 'selected' : ''); b.setAttribute('aria-pressed', String(state.phoneTab === id)); tabs.append(b); } body.append(tabs);
    if (state.phoneTab === 'favorites') { const contacts = h('div', 'shell-contacts'); for (const [initial, name, description] of [['가', '가족', '즐겨찾는 연락처'], ['학', '대치동 학원', '하원 장소'], ['보', '보호자', '긴급 연락처']]) { const b = button('', () => dispatch({ type: 'PHONE_PREVIEW', name }), 'shell-contact'); b.append(h('span', 'shell-contact-avatar', initial)); const text = h('span'); text.append(h('strong', '', name), h('small', '', description)); b.append(text, icon('phone')); contacts.append(b); } body.append(contacts); }
    else { const keypad = h('div', 'shell-keypad-wrap'); const number = h('output', 'shell-phone-number', state.digits || '전화번호 입력'); number.setAttribute('aria-label', '입력한 번호'); const erase = button('⌫', () => dispatch({ type: 'ERASE' }), 'shell-erase'); erase.setAttribute('aria-label', '마지막 번호 지우기'); const row = h('div', 'shell-number-row'); row.append(number, erase); keypad.append(row); const keys = h('div', 'shell-keypad'); for (const digit of '123456789*0#') keys.append(button(digit, () => dispatch({ type: 'DIGIT', digit }))); keypad.append(keys, button('연락처 미리보기', () => dispatch({ type: 'PHONE_PREVIEW' }), 'shell-phone-preview')); body.append(keypad); }
    const status = h('p', 'shell-phone-status', state.phonePreview || '연락처를 선택하면 이 화면에서 확인할 수 있어요.'); status.setAttribute('role', 'status'); body.append(status, h('p', 'shell-footnote', '가상 연락처예요. 실제 전화는 연결되지 않아요.'));
  }
  function carArtwork() {
    const box = h('div', 'shell-car-art'); const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('viewBox', '0 0 520 220'); svg.setAttribute('role', 'img'); svg.setAttribute('aria-label', '은색 가상 차량');
    for (const [tag, attrs] of [['ellipse', { cx: 264, cy: 180, rx: 205, ry: 18, fill: '#dfe3e6' }], ['path', { d: 'M53 142 78 107l80-20 57-52h118l68 53 56 17 25 35-10 28H64Z', fill: '#b9c2c8', stroke: '#89959e', 'stroke-width': 2 }], ['path', { d: 'm179 86 44-42h102l51 43Z', fill: '#34444f' }], ['path', { d: 'M276 45v43M165 96h230M149 107v49m131-58v58m119-50v50', stroke: '#87959f', fill: 'none', 'stroke-width': 2 }], ['path', { d: 'm64 127 48-7 4 11H60m353-15 45 12-2 11-44-8', fill: '#f1f6fa' }], ['path', { d: 'M78 155h376', stroke: '#e4eaed', 'stroke-width': 5 }], ['circle', { cx: 139, cy: 166, r: 34, fill: '#26323a' }], ['circle', { cx: 139, cy: 166, r: 19, fill: '#d4dce2', stroke: '#8c99a2', 'stroke-width': 5 }], ['circle', { cx: 397, cy: 166, r: 34, fill: '#26323a' }], ['circle', { cx: 397, cy: 166, r: 19, fill: '#d4dce2', stroke: '#8c99a2', 'stroke-width': 5 }]]) { const n = document.createElementNS(svg.namespaceURI, tag); for (const [key, value] of Object.entries(attrs)) n.setAttribute(key, value); svg.append(n); } box.append(svg); return box;
  }
  function vehicle(body) {
    const tabs = h('div', 'shell-tabs'); for (const [tab, name] of [['status', '차량 상태'], ['driving', '주행'], ['display', '디스플레이']]) tabs.append(button(name, () => dispatch({ type: 'VEHICLE_TAB', tab }), state.vehicleTab === tab ? 'selected' : '')); body.append(tabs);
    if (state.vehicleTab === 'status') { body.append(carArtwork()); const stats = h('div', 'shell-vehicle-stats'); for (const [v, title] of [['84%', '배터리'], [(el('topRange')?.textContent || '514') + ' km', '주행 가능 거리'], ['정상', '타이어 상태']]) { const item = h('div'); item.append(h('strong', '', v), h('span', '', title)); stats.append(item); } body.append(stats, h('p', 'shell-footnote', '차량 상태와 배터리는 가상 데이터예요.')); }
    else if (state.vehicleTab === 'driving') { sectionTitle(body, '드라이브 모드'); const card = h('div', 'shell-settings-card'); card.append(h('strong', '', 'ECO'), h('p', '', '부드러운 주행 화면을 체험하고 있어요.')); body.append(card, button('내비게이션으로 돌아가기', () => open('navigation'), 'shell-wide-button'), button('하원콜 열기', () => open('hawon'), 'shell-wide-button')); }
    else { sectionTitle(body, '화면 및 소리'); body.append(slider('미디어 음량', state.volume, 0, 100, 1, value => dispatch({ type: 'VOLUME', value }, false)), h('p', 'shell-footnote', '볼륨 표시를 조절해 보세요. 실제 소리는 바뀌지 않아요.'), button('앱 라이브러리', () => open('library'), 'shell-wide-button')); }
  }
  function radio(body) {
    const station = STATIONS[state.station]; const tuner = h('div', 'shell-radio-tuner'); tuner.append(h('span', 'shell-overline', 'FM RADIO'), h('strong', '', station.frequency), h('h3', '', station.name)); const frequency = h('div', 'shell-frequency-lines'); for (let i = 0; i < 29; i++) frequency.append(h('i')); tuner.append(frequency, button(state.radioPlaying ? 'Ⅱ  일시 정지' : '▶  재생 화면 체험', () => dispatch({ type: 'TOGGLE', key: 'radioPlaying' }), 'shell-radio-play')); body.append(tuner); sectionTitle(body, '즐겨찾는 방송'); const presets = h('div', 'shell-radio-presets'); STATIONS.forEach((s, index) => presets.append(button(`${s.frequency}  ${s.name}`, () => dispatch({ type: 'STATION', index }), `shell-toggle ${index === state.station ? 'selected' : ''}`))); body.append(presets, h('p', 'shell-footnote', '가상 방송국이에요. 방송 소리는 재생하지 않아요.'));
  }
  function render() {
    const contentApp = !['navigation', 'hawon'].includes(state.app); const wasHidden = host.hidden; const oldApp = host.dataset.app; const focusedIndex = [...host.querySelectorAll('button,input')].indexOf(document.activeElement);
    shell.classList.toggle('shell-app-open', contentApp); shell.classList.toggle('hawon-expanded', state.app === 'hawon'); shell.dataset.activeApp = state.app;
    el('hawonExpand')?.setAttribute('aria-expanded', String(state.app === 'hawon')); el('hawonExpand')?.setAttribute('aria-label', state.app === 'hawon' ? '하원콜 앱 접기' : '하원콜 앱 펼치기');
    host.hidden = !contentApp; updateDock();
    if (contentApp) { host.replaceChildren(); host.dataset.app = state.app; const body = header(); ({ library, climate, media, phone, vehicle, radio })[state.app](body); if (wasHidden || oldApp !== state.app) host.querySelector('.shell-back')?.focus({ preventScroll: true }); else if (focusedIndex >= 0) host.querySelectorAll('button,input')[focusedIndex]?.focus({ preventScroll: true }); }
    if (!contentApp) { if (!wasHidden && focusedIndex >= 0) shell.querySelector(state.app === 'hawon' ? '#hawonApp' : '#navApp')?.focus({ preventScroll: true }); setTimeout(() => map?.resize?.(), 220); }
  }
  render();
}
export function updatePleosShell(v) {
  if (!v) return;
  const shell = el('vehicleView'), speed = Math.max(0, Number(v.speedKph) || 0);
  shell?.classList.toggle('is-driving', v.gear === 'D'); shell?.classList.toggle('is-playing', Boolean(v.playing && speed > 0)); shell?.setAttribute('data-vehicle-gear', v.gear || 'P');
  const rpm = el('rpmValue'); if (rpm) rpm.textContent = v.gear === 'D' ? String(Math.round(800 + speed * 20)) : '0';
  const range = el('topRange'); if (range) range.textContent = String(514 - Math.round((Number(v.progress) || 0) * 2));
}
