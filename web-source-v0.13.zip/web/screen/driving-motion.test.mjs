import test from 'node:test';
import assert from 'node:assert/strict';
import {drivingMotionSnapshot, drivingLaneDash, drivingTrafficPose} from './pleos-shell.mjs';

const trip = {gear:'D', playing:true, speedKph:36, progress:.25, playbackRate:1, route:{totalMeters:2400}};
test('visual clock follows route distance and interpolates the real playback interval', () => {
  assert.equal(drivingMotionSnapshot(trip).travel, 600);
  assert.equal(drivingMotionSnapshot(trip, 300).travel, 603);
  assert.equal(drivingMotionSnapshot({...trip, playbackRate:3}, 300).travel, 609);
  assert.equal(drivingMotionSnapshot({...trip, playbackRate:6}, 300).travel, 618);
  // A suspended tab cannot cause an unbounded leap while its state is stale.
  assert.equal(drivingMotionSnapshot(trip, 50_000).travel, 603.3);
});
test('pause with a retained speedometer reading, P, and arrival all freeze the scene', () => {
  for (const patch of [{playing:false}, {gear:'P'}, {near:true}, {arrival:true}, {confirmed:true}, {speedKph:0}, {routeMismatch:true}]) {
    const v = {...trip, ...patch};
    assert.equal(drivingMotionSnapshot(v, 300).active, false);
    assert.equal(drivingMotionSnapshot(v, 300).travel, drivingMotionSnapshot(v).travel);
  }
});
test('road marks travel toward the viewer and grow with perspective', () => {
  for (const side of [-1,1]) {
    const before = drivingLaneDash(0, 4, side), after = drivingLaneDash(7, 4, side);
    assert.ok(after[1][1] > before[1][1], 'mark must flow down from horizon');
    assert.ok(after[1][1] - after[0][1] > before[1][1] - before[0][1], 'fixed road length grows toward viewer');
    assert.ok(Math.abs(after[1][0]-206) > Math.abs(before[1][0]-206), 'mark follows widening lane perspective');
    assert.deepEqual(drivingLaneDash(224,4,side), before, 'wrapping preserves the evenly spaced road');
  }
});
test('adjacent vehicles move relatively along their lanes and remain finite over repeated journeys', () => {
  for (const index of [0,1]) {
    const start = drivingTrafficPose(0,index), later = drivingTrafficPose(20,index);
    assert.ok(later.y > start.y); assert.ok(later.scale > start.scale);
    assert.ok(index ? later.x > start.x : later.x < start.x);
    for (let travel=0; travel<=2400; travel+=.7) {
      const p = drivingTrafficPose(travel,index);
      assert.ok(Object.values(p).every(Number.isFinite));
      assert.ok(p.opacity >= 0 && p.opacity <= 1);
      assert.ok(p.y >=110 && p.y <=580);
    }
  }
});

test('SVG bridge replaces static lane strokes, animates each frame, and cancels immediately on pause', async () => {
  const {updatePleosShell} = await import('./pleos-shell.mjs');
  class Node {
    constructor(tag) { this.tagName=tag; this.children=[]; this.attrs={}; this.dataset={}; this.namespaceURI='http://www.w3.org/2000/svg'; this.classList={toggle(){}}; }
    append(n) { n.parent=this; this.children.push(n); }
    setAttribute(k,v) { this.attrs[k]=v; }
    replaceWith(n) { n.parent=this.parent; this.parent.children.splice(this.parent.children.indexOf(this),1,n); }
    querySelector(selector) { return selector==='#egoCar'?ego:selector==='[stroke-dasharray]'?dash:selector==='.driving-scene'?scene:null; }
  }
  const scene=new Node('svg'), dash=new Node('path'), left=new Node('g'), right=new Node('g'), ego=new Node('g'), shell=new Node('section');
  for (const n of [dash,left,right,ego]) scene.append(n);
  const frames=new Map(); let frameId=0;
  const saved={document:globalThis.document,requestAnimationFrame:globalThis.requestAnimationFrame,cancelAnimationFrame:globalThis.cancelAnimationFrame};
  globalThis.document={hidden:false,getElementById:id=>id==='vehicleView'?shell:null,createElementNS:(_,tag)=>new Node(tag)};
  globalThis.requestAnimationFrame=callback=>{frames.set(++frameId,callback);return frameId;};
  globalThis.cancelAnimationFrame=id=>frames.delete(id);
  try {
    const at=performance.now(); updatePleosShell(trip);
    assert.equal(scene.children.includes(dash),false);
    const lane=scene.children[0], startMark=lane.children[4].attrs.points, startCar=left.attrs.transform;
    assert.equal(lane.children.length,32); assert.equal(frames.size,1);
    const callback=frames.values().next().value; frames.clear(); callback(at+200);
    assert.notEqual(lane.children[4].attrs.points,startMark); assert.notEqual(left.attrs.transform,startCar);
    assert.equal(frames.size,1);
    updatePleosShell({...trip,progress:.251,playing:false});
    const pausedCar=left.attrs.transform;
    assert.equal(scene.dataset.motion,'paused'); assert.equal(frames.size,0);
    updatePleosShell({...trip,progress:.251,playing:false});
    assert.equal(left.attrs.transform,pausedCar); assert.equal(frames.size,0);
  } finally {
    for (const [key,value] of Object.entries(saved)) { if(value===undefined)delete globalThis[key];else globalThis[key]=value; }
  }
});
