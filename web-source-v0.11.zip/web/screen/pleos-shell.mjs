/** Presentation-only Pleos layout. All journey decisions remain in model.mjs. */
let mounted = false;
let perspective = true;
const el = id => document.getElementById(id);

export function mountPleosShell({ map, toast = () => {} } = {}) {
  if (mounted) return;
  mounted = true;
  const shell = el('vehicleView');
  const drawer = el('simulationDrawer');
  const drawerButton = el('drawerToggle');
  function controls(open) {
    if (!drawer) return;
    drawer.hidden = !open;
    drawerButton?.setAttribute('aria-expanded', String(open));
  }
  function hawon(open) {
    shell?.classList.toggle('hawon-expanded', open);
    el('hawonExpand')?.setAttribute('aria-expanded', String(open));
    el('hawonExpand')?.setAttribute('aria-label', open ? '하원콜 앱 접기' : '하원콜 앱 펼치기');
    el('hawonApp')?.setAttribute('aria-pressed', String(open));
    el('hawonApp')?.classList.toggle('active', open);
    setTimeout(() => map?.resize?.(), 220);
  }
  drawerButton?.addEventListener('click', () => controls(drawer.hidden));
  el('drawerClose')?.addEventListener('click', () => controls(false));
  el('hawonExpand')?.addEventListener('click', () => hawon(!shell.classList.contains('hawon-expanded')));
  el('hawonApp')?.addEventListener('click', () => hawon(!shell.classList.contains('hawon-expanded')));
  el('navApp')?.addEventListener('click', () => hawon(false));
  el('appLibrary')?.addEventListener('click', () => {
    hawon(true);
    toast('하원콜 앱을 열었어요. 공조·전화·미디어는 화면 구성 재현이에요.');
  });
  el('perspectiveToggle')?.addEventListener('click', () => {
    perspective = !perspective;
    map?.setPerspective?.(perspective);
    el('perspectiveLabel').textContent = perspective ? '2D' : '3D';
    el('perspectiveToggle').setAttribute('aria-pressed', String(perspective));
    el('perspectiveToggle').setAttribute('aria-label', perspective ? '2D 지도로 전환' : '3D 지도로 전환');
  });
  document.querySelectorAll('.global-nav button:not([id])').forEach(button => {
    button.addEventListener('click', () => toast('화면 구성 재현이에요. 실제 차량 기능에는 연결되지 않아요.'));
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && drawer && !drawer.hidden) controls(false);
  });
  document.addEventListener('pointerdown', event => {
    if (drawer && !drawer.hidden && !drawer.contains(event.target) && !drawerButton.contains(event.target)) controls(false);
  });
}

export function updatePleosShell(v) {
  if (!v) return;
  const shell = el('vehicleView');
  const speed = Math.max(0, Number(v.speedKph) || 0);
  shell?.classList.toggle('is-driving', v.gear === 'D');
  shell?.classList.toggle('is-playing', Boolean(v.playing && speed > 0));
  shell?.setAttribute('data-vehicle-gear', v.gear || 'P');
  const rpm = el('rpmValue');
  if (rpm) rpm.textContent = v.gear === 'D' ? String(Math.round(800 + speed * 20)) : '0';
  const range = el('topRange');
  if (range) range.textContent = String(514 - Math.round((Number(v.progress) || 0) * 2));
}
