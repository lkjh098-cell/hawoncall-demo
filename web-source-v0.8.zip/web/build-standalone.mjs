import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {Script} from 'node:vm';
const base=new URL('./',import.meta.url),read=name=>readFile(new URL('screen/'+name,base),'utf8');
const [html,css,leafletCss,leafletJs,data,model,map,sync,app]=await Promise.all(['index.html','cockpit.css','vendor/leaflet.css','vendor/leaflet.js','route-data.mjs','model.mjs','real-map.mjs','sync.mjs','cockpit.js'].map(read));
const strip=s=>s.replace(/^import[^\n]*\n/gm,'').replace(/^export /gm,'');
const wrap=s=>{const names=[...s.matchAll(/^export (?:function|const|let|class) (\w+)/gm)].map(m=>m[1]);return `const {${names.join(',')}} = (()=>{\n${strip(s)}\nreturn {${names.join(',')}};})();`;};
const code=[wrap(data),wrap(model),wrap(map),wrap(sync),'(()=>{'+strip(app)+'})();'].join('\n');new Script(code,{filename:'hawoncall-browser-v08.js'});
// Leaflet's built-in marker/layer images are not used; remove those optional URLs for a genuinely single-file delivery.
const leafletStyle=leafletCss.replace(/url\(images\/[^)]+\)/g,'none');
const output=html.replace('<link rel="stylesheet" href="./vendor/leaflet.css">',()=>'<style>'+leafletStyle+'</style>').replace('<link rel="stylesheet" href="./cockpit.css">',()=>'<style>'+css+'</style>').replace('<script src="./vendor/leaflet.js"></script>',()=>'<script>'+leafletJs.replace(/<\/script/gi,'<\\/script')+'</script>').replace('<script type="module" src="./cockpit.js"></script>',()=>'<script type="module">\n'+code+'\n</script>');
await mkdir(new URL('dist/',base),{recursive:true});await writeFile(new URL('dist/index.html',base),output);await writeFile(new URL('실제지도_차량시연.html',base),output);console.log(`Built dist/index.html (${Buffer.byteLength(output)} bytes)`);
