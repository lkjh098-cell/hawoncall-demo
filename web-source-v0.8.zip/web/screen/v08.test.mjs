import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';
import {createInitialState,reduce,view} from './model.mjs';
import {packDemoState,restoreDemoState} from './sync.mjs';
import {REAL_ROUTE} from './route-data.mjs';
const init=(mode='pickup',institution='academy')=>createInitialState({now:1000,mode,institution,route:REAL_ROUTE});
const next=(s,type,rest={})=>reduce(s,{type,...rest});
const park=s=>next(next(s,'APPROACH'),'PARK');
test('all four institution kinds preserve saved route and reset only demo session',()=>{for(const institution of ['school','kindergarten','daycare','academy']){const s=next(init(),'SCENARIO',{institution});assert.equal(s.institution,institution);assert.equal(s.route.id,REAL_ROUTE.id);assert.equal(s.confirmed,false);assert.ok(view(s).institutionLabel);}});
test('pickup still needs a sensor candidate and explicit guardian boarding',()=>{let s=park(init());assert.equal(view(s).canConfirm,false);assert.equal(next(s,'CONFIRM').confirmed,false);s=next(s,'SENSOR');assert.equal(s.confirmed,false);s=next(s,'CONFIRM');assert.equal(s.confirmed,true);assert.equal(view(s).confirmationKind,'guardian-boarding');});
test('dropoff permits direct guardian handoff after fresh P without sensor prerequisite',()=>{let s=park(init('dropoff'));assert.equal(s.candidate,false);assert.equal(view(s).canConfirm,true);assert.equal(s.confirmed,false);s=next(s,'CONFIRM');assert.equal(s.confirmed,true);assert.equal(view(s).confirmationKind,'guardian-handoff');assert.equal(view(s).institutionEntryProven,false);});
test('dropoff D approach and distant P never enable handoff',()=>{for(const type of ['APPROACH','PARK']){const s=next(init('dropoff'),type);assert.equal(view(s).canConfirm,false);assert.equal(next(s,'CONFIRM').confirmed,false);}});
test('dropoff sensors never prove entry or automatically confirm handoff',()=>{const s=next(park(init('dropoff')),'SENSOR');assert.equal(s.confirmed,false);assert.equal(view(s).institutionEntryProven,false);assert.equal(view(s).canConfirm,true);});
test('dropoff stale, route mismatch, and non P close direct guardian gate',()=>{const s=park(init('dropoff'));const cases=[next(s,'TICK',{now:32001,dtMs:0}),next(s,'NAVIGATION',{snapshot:{routeId:'other',progress:1,timestamp:1000}}),next(s,'VEHICLE',{snapshot:{gear:'D',speedKph:0,timestamp:1000}})];for(const c of cases){assert.equal(view(c).canConfirm,false);assert.equal(next(c,'CONFIRM').confirmed,false);}});
test('reset retains mode and institution but clears explicit confirmation',()=>{const s=next(next(park(init('dropoff','daycare')),'CONFIRM'),'RESET');assert.equal(s.mode,'dropoff');assert.equal(s.institution,'daycare');assert.equal(s.confirmed,false);assert.equal(s.confirmedAt,null);});
test('sync envelope persists public demo state only and restores route from trusted local data',()=>{const s=next(park(init('dropoff','school')),'CONFIRM'),packet=packDemoState(s,'test',123);assert.equal('route' in packet.snapshot,false);assert.equal(JSON.stringify(packet).includes('coordinates'),false);const restored=restoreDemoState(packet,init());assert.equal(restored.mode,'dropoff');assert.equal(restored.institution,'school');assert.equal(restored.confirmed,true);assert.equal(restored.route.id,REAL_ROUTE.id);assert.equal(view(restored).institutionEntryProven,false);});
test('malformed and unknown sync envelopes fail closed without throwing',()=>{const packet=packDemoState(init(),'test',123);for(const p of [null,{},[],{...packet,version:7},{...packet,source:4},{...packet,revision:NaN},{...packet,snapshot:{...packet.snapshot,gear:'R'}},{...packet,snapshot:{...packet.snapshot,institution:'real-school'}},{...packet,snapshot:{...packet.snapshot,progress:2}},{...packet,snapshot:{...packet.snapshot,confirmed:true,confirmedAt:null}}])assert.equal(restoreDemoState(p,init()),null);});
test('single file delivery has inline Leaflet and app, accessible attribution, no unresolved local links or GPS',async()=>{const h=await readFile(new URL('../dist/index.html',import.meta.url),'utf8');assert.ok(h.includes('https://tile.openstreetmap.org/{z}/{x}/{y}.png'));assert.ok(h.includes('www.openstreetmap.org/copyright'));assert.ok(h.includes('브라우저 시연 · 차량 신호 가상'));assert.ok(h.includes('117개'));assert.ok(!/<(?:script|link)[^>]+(?:src|href)="\.\//.test(h));assert.ok(!h.includes('url(images/'));const app=await readFile(new URL('./cockpit.js',import.meta.url),'utf8');assert.ok(!app.includes('navigator.geolocation'));assert.ok(!app.includes('.locate('));});

test('guardian phone remains read only while vehicle confirmation is explicit',async()=>{const [app,html,css]=await Promise.all(['cockpit.js','index.html','cockpit.css'].map(name=>readFile(new URL('./'+name,import.meta.url),'utf8')));assert.ok(html.includes('id="guardianConfirm" class="primary-button" disabled'));assert.ok(app.includes("$('#guardianConfirm').disabled=true"));assert.ok(!app.includes("$('#guardianConfirm').onclick="));assert.ok(app.includes("$('#confirmGuardian').onclick="));assert.ok(css.includes('.guardian-only .scenario-bar'));assert.ok(css.includes('.guardian-only #clearData'));assert.ok(css.includes('.guardian-only .director{display:none}'));});

test('school scenario uses school travel wording in both directions',()=>{assert.ok(view(init('pickup','school')).title.includes('하교'));assert.ok(view(init('dropoff','school')).title.includes('등교'));assert.ok(view(init('pickup','academy')).title.includes('하원'));});

test('actual guardian handlers refuse mutation and confirmation even if invoked behind hidden controls',async()=>{
 const app=await readFile(new URL('./cockpit.js',import.meta.url),'utf8');
 const sendFn=app.slice(app.indexOf('function send('),app.indexOf('\nfunction switchView'));
 const confirmFn=app.slice(app.indexOf('function openConfirm('),app.indexOf('\nfunction reset'));
 const original=Object.freeze({confirmed:false,progress:0});
 const reject=()=>assert.fail('read-only guardian executed a mutating path');
 const context={guardianOnly:true,state:original,reduce:reject,render:reject,publish:reject,view:reject,toast:reject,$:reject};
 runInNewContext(sendFn+";send('CONFIRM');send('PLAY');send('SCENARIO',{mode:'dropoff'});",context);
 assert.equal(context.state,original);
 runInNewContext(confirmFn+';openConfirm();',context);
});
test('actual guardian keyboard handler ignores Space and arrows before touching presenter controls',async()=>{
 const app=await readFile(new URL('./cockpit.js',import.meta.url),'utf8');
 const keyboard=app.slice(app.indexOf("document.addEventListener('keydown'"),app.indexOf('\nnew ResizeObserver'));
 let handler;const reject=()=>assert.fail('guardian keyboard reached presenter controls');
 runInNewContext(keyboard,{guardianOnly:true,document:{addEventListener:(name,fn)=>{assert.equal(name,'keydown');handler=fn;}},$$:reject,$:reject,stageAction:reject});
 for(const key of ['ArrowLeft','ArrowRight',' '])handler({key,code:key===' '?'Space':key,preventDefault:reject});
});
