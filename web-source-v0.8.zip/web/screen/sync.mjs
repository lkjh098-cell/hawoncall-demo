// Only public, fabricated demo state is persisted. No route coordinates or user data.
export const DEMO_STORAGE_KEY = 'hawoncall.browser-demo.v08';
const scalarKeys=['progress','gear','speedKph','now','navAt','vehicleAt','playing','candidate','confirmed','confirmedAt','departed','mode','institution'];
export function packDemoState(state, source, revision=Date.now()) {
 const snapshot=Object.fromEntries(scalarKeys.map(k=>[k,state[k]]));
 return {version:8,source,revision,snapshot};
}
export function restoreDemoState(packet, initial) {
 if(!packet||packet.version!==8||typeof packet.source!=='string'||!Number.isFinite(packet.revision)||!packet.snapshot)return null;
 const s=packet.snapshot;
 if(!['pickup','dropoff'].includes(s.mode)||!['school','kindergarten','daycare','academy'].includes(s.institution)||!['D','P'].includes(s.gear))return null;
 if(!Number.isFinite(s.progress)||s.progress<0||s.progress>1||!Number.isFinite(s.speedKph)||s.speedKph<0||s.speedKph>200)return null;
 if(!['now','navAt','vehicleAt'].every(k=>Number.isFinite(s[k])&&s[k]>=0))return null;
 if(!['playing','candidate','confirmed','departed'].every(k=>typeof s[k]==='boolean'))return null;
 if(s.confirmed&&(!Number.isFinite(s.confirmedAt)||s.confirmedAt<0))return null;
 return {...initial,...Object.fromEntries(scalarKeys.map(k=>[k,s[k]])),route:initial.route,notice:''};
}
