/** Real road geometry helpers. Coordinates are GeoJSON [longitude, latitude].
 * This module neither accesses the DOM nor requests routing until createRoadMap is called.
 */
const R = 6371008.8;
const radians = n => n * Math.PI / 180;
const clamp = n => Math.min(1, Math.max(0, Number.isFinite(n) ? n : 0));
const geometryCache = new WeakMap();
const guidanceCache = new WeakMap();
export function metersBetween(a, b) {
  const dl = radians(b[0] - a[0]), dp = radians(b[1] - a[1]);
  const h = Math.sin(dp / 2) ** 2 + Math.cos(radians(a[1])) * Math.cos(radians(b[1])) * Math.sin(dl / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(Math.min(1, h)));
}
function geometry(coordinates) {
  if (!Array.isArray(coordinates) || coordinates.length < 2) throw new TypeError('Route requires at least two geographic coordinates.');
  if (geometryCache.has(coordinates)) return geometryCache.get(coordinates);
  const distances = [0];
  for (let i = 1; i < coordinates.length; i++) distances.push(distances[i - 1] + metersBetween(coordinates[i - 1], coordinates[i]));
  const result = {distances, total: distances.at(-1)};
  geometryCache.set(coordinates, result);
  return result;
}
/** Distance-based interpolation, not equally timed jumps between geometry vertices. */
export function pointAlongRoute(coordinates, progress = 0) {
  const {distances, total} = geometry(coordinates), target = clamp(progress) * total;
  let lo = 0, hi = coordinates.length - 1;
  while (lo + 1 < hi) { const mid = (lo + hi) >> 1; if (distances[mid] <= target) lo = mid; else hi = mid; }
  const a = coordinates[lo], b = coordinates[hi], segment = distances[hi] - distances[lo];
  const t = segment ? Math.min(1, (target - distances[lo]) / segment) : 0;
  const lon = a[0] + (b[0] - a[0]) * t, lat = a[1] + (b[1] - a[1]) * t;
  const dlon = radians(b[0] - a[0]), p1 = radians(a[1]), p2 = radians(b[1]);
  const heading = (Math.atan2(Math.sin(dlon) * Math.cos(p2), Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dlon)) * 180 / Math.PI + 360) % 360;
  return {lat, lon, heading, distanceMeters: target, segmentIndex: lo};
}
function projectOnRoute(coordinates, location, minimum = 0) {
  const {distances} = geometry(coordinates), cos = Math.cos(radians(location[1]));
  let best = {distance: Infinity, along: minimum};
  for (let i = 0; i < coordinates.length - 1; i++) {
    if (distances[i + 1] + 0.1 < minimum) continue;
    const a = coordinates[i], b = coordinates[i + 1];
    const ax = (a[0] - location[0]) * cos, ay = a[1] - location[1], dx = (b[0] - a[0]) * cos, dy = b[1] - a[1];
    const t = Math.max(0, Math.min(1, -(ax * dx + ay * dy) / (dx * dx + dy * dy || 1)));
    const along = distances[i] + (distances[i + 1] - distances[i]) * t;
    const d = (ax + dx * t) ** 2 + (ay + dy * t) ** 2;
    if (along + 0.1 >= minimum && d < best.distance) best = {distance: d, along};
  }
  return best.along;
}
function maneuvers(route) {
  if (guidanceCache.has(route)) return guidanceCache.get(route);
  let previous = 0;
  const result = (route.steps || []).filter(s => Array.isArray(s.maneuver?.location)).map(step => {
    previous = projectOnRoute(route.coordinates, step.maneuver.location, previous);
    return {...step, along: previous};
  });
  guidanceCache.set(route, result);return result;
}
export function guidanceForProgress(route, progress = 0) {
  const {total} = geometry(route.coordinates), traveled = clamp(progress) * total;
  const steps = maneuvers(route), nextIndex = steps.findIndex(step => step.maneuver.type !== 'depart' && step.along > traveled + 1);
  const next = nextIndex < 0 ? steps.at(-1) : steps[nextIndex];
  const following = nextIndex < 0 ? null : steps[nextIndex + 1] || null;
  const scale = Number.isFinite(route.totalMeters) && total ? route.totalMeters / total : 1;
  const describe = s => s ? {road: s.name || s.ref || '이름 없는 도로', modifier: s.maneuver.modifier || 'straight', type: s.maneuver.type, distanceMeters: Math.max(0, (s.along - traveled) * scale)} : null;
  return {...(describe(next) || {road: route.destination, modifier: 'straight', type: 'arrive', distanceMeters: 0}), following: describe(following)};
}
const carSVG = `<svg viewBox="0 0 72 96" aria-hidden="true"><defs><linearGradient id="mapCarBody" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#fff"/><stop offset=".45" stop-color="#e8f2ff"/><stop offset="1" stop-color="#93abc2"/></linearGradient><linearGradient id="mapCarGlass" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#18364f"/><stop offset="1" stop-color="#4a6e8b"/></linearGradient></defs><path d="M36 0 24 16h24Z" fill="#36b5ff"/><ellipse cx="36" cy="53" rx="30" ry="37" fill="#1678fc" opacity=".12"/><rect x="14" y="20" width="44" height="69" rx="16" fill="url(#mapCarBody)" stroke="white" stroke-width="2"/><path d="m22 36 5-10h18l5 10-3 17H25Z" fill="url(#mapCarGlass)"/><path d="M25 64h22l4 14H21Z" fill="#193b56"/><path d="M18 40v27m36-27v27" stroke="#8aa5bc" stroke-width="2"/><path d="M21 23h30" stroke="#48d9ff" stroke-width="3" stroke-linecap="round"/><path d="M22 84h28" stroke="#ff697a" stroke-width="2.5" stroke-linecap="round"/><path d="M13 46H8m51 0h5" stroke="#dbe9f4" stroke-width="4" stroke-linecap="round"/></svg>`;
/** Leaflet is vendored locally; only ordinary on-screen OSM tile requests occur. */
export function createRoadMap(container, {route, statusElement, leaflet = globalThis.L} = {}) {
  const status = (message, error = false) => {if (!statusElement) return; statusElement.textContent = message;statusElement.hidden = !message;statusElement.classList.toggle('is-error', error);};
  if (!leaflet) {status('지도를 불러오지 못했어요 · 인터넷 연결을 확인하세요', true);return {setProgress(){},fit(){},zoomIn(){},zoomOut(){},follow(){},setNight(){},resize(){}};}
  const L = leaflet, points = route.coordinates.map(([lon, lat]) => [lat, lon]);
  const map = L.map(container, {zoomControl: false, attributionControl: true, scrollWheelZoom: false, preferCanvas: false});
  map.attributionControl.setPrefix(false);
  const tilePane = map.createPane('roadTiles'); tilePane.style.zIndex = '200';
  const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {pane:'roadTiles', maxNativeZoom:19, maxZoom:20, attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors'});
  let tileErrors = 0, tileSuccess = 0;
  status('실제 지도를 불러오는 중…');
  tiles.on('loading', () => {tileErrors = 0;tileSuccess = 0;});
  tiles.on('tileerror', () => {tileErrors++;status('지도 연결 불안정 · 일부 배경 지도를 불러오지 못했어요', true);});
  tiles.on('tileload', () => {tileSuccess++;});
  tiles.on('load', () => {if (tileErrors || !tileSuccess) status('지도 연결 불안정 · 도로 경로만 표시될 수 있어요', true);else status('');});
  if (globalThis.location?.protocol === 'file:') status('지도는 로컬 서버에서 열어주세요 · README의 실행 방법을 확인하세요', true);
  else tiles.addTo(map);
  L.polyline(points, {color:'#fff',weight:12,opacity:.96,lineCap:'round',lineJoin:'round',interactive:false}).addTo(map);
  L.polyline(points, {color:'#286ff1',weight:7,opacity:1,lineCap:'round',lineJoin:'round',interactive:false}).addTo(map);
  L.circleMarker(points[0], {radius:5,color:'#fff',weight:3,fillColor:'#286ff1',fillOpacity:1}).bindTooltip('선릉 출발 지점(시연)',{direction:'top'}).addTo(map);
  const destinationIcon = L.divIcon({className:'real-destination',html:'<span>h</span>',iconSize:[32,40],iconAnchor:[16,40]});
  const destination = L.marker(points.at(-1),{icon:destinationIcon}).addTo(map);
  const label = document.createElement('span');label.textContent = route.destination;
  destination.bindTooltip(label,{permanent:true,direction:'top',offset:[0,-40],className:'pickup-map-label'});
  const popup = document.createElement('div');popup.textContent = `${route.destination} · 공개 도로 위 시연 지점이며 실제 교육기관과 무관해요.`;
  destination.bindPopup(popup);
  const car = L.marker(points[0], {icon:L.divIcon({className:'real-car-marker',html:`<div class="real-car-heading">${carSVG}</div>`,iconSize:[54,72],iconAnchor:[27,36]}),zIndexOffset:1000,keyboard:false}).addTo(map);
  let tracking = false, progress = 0, lastPan = 0;
  const bounds = L.latLngBounds(points);
  const fit = () => {tracking=false;map.fitBounds(bounds,{paddingTopLeft:[52,112],paddingBottomRight:[45,45],maxZoom:16,animate:false});};
  const setProgress = value => {progress=clamp(value);const p=pointAlongRoute(route.coordinates,progress);car.setLatLng([p.lat,p.lon]);const heading=car.getElement()?.querySelector('.real-car-heading');if(heading) heading.style.transform=`rotate(${p.heading}deg)`;if(tracking && performance.now()-lastPan>200){map.panTo([p.lat,p.lon],{animate:false});lastPan=performance.now();}};
  map.on('dragstart',()=>{tracking=false;});
  fit();setProgress(0);
  return {setProgress,fit,zoomIn:()=>map.zoomIn(),zoomOut:()=>map.zoomOut(),follow:enabled=>{tracking=enabled;if(enabled){const p=pointAlongRoute(route.coordinates,progress);map.setView([p.lat,p.lon],Math.max(map.getZoom(),16),{animate:false});}else fit();},setNight:enabled=>tilePane.classList.toggle('night-tiles',enabled),resize:()=>{map.invalidateSize({pan:false});if(!tracking)fit();},setDestination:name=>{label.textContent=name;popup.textContent=`${name} · 공개 도로 위 가상 기관 위치이며 실제 교육기관과 무관해요.`;},destroy:()=>map.remove()};
}
