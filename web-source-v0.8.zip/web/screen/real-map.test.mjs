import test from 'node:test';
import assert from 'node:assert/strict';
import {metersBetween,pointAlongRoute,guidanceForProgress} from './real-map.mjs';
import {REAL_ROUTE} from './route-data.mjs';
import {createInitialState,reduce,view} from './model.mjs';

test('recorded driving response has real Seoul road geometry and stable endpoints',()=>{
 assert.equal(REAL_ROUTE.coordinates.length,41);
 assert.deepEqual(REAL_ROUTE.coordinates[0],[127.049657,37.504591]);
 assert.deepEqual(REAL_ROUTE.coordinates.at(-1),[127.062978,37.494462]);
 for(const [lon,lat] of REAL_ROUTE.coordinates){assert.ok(lon>127&&lon<127.1);assert.ok(lat>37.4&&lat<37.6);}
 assert.ok(Object.isFrozen(REAL_ROUTE.coordinates));
 assert.ok(REAL_ROUTE.steps.some(s=>s.name==='테헤란로'));
 assert.ok(REAL_ROUTE.steps.some(s=>s.name==='삼성로'));
 assert.ok(REAL_ROUTE.steps.some(s=>s.name==='남부순환로'));
});
test('distance interpolation reaches both road endpoints and clamps progress',()=>{
 for(const p of [-1,0]){const x=pointAlongRoute(REAL_ROUTE.coordinates,p);assert.equal(x.lon,REAL_ROUTE.coordinates[0][0]);assert.equal(x.lat,REAL_ROUTE.coordinates[0][1]);}
 for(const p of [1,2]){const x=pointAlongRoute(REAL_ROUTE.coordinates,p);assert.equal(x.lon,REAL_ROUTE.coordinates.at(-1)[0]);assert.equal(x.lat,REAL_ROUTE.coordinates.at(-1)[1]);}
});
test('unevenly spaced vertices are traversed by distance rather than index',()=>{
 const x=pointAlongRoute([[0,0],[.001,0],[.011,0]],.5);
 assert.ok(Math.abs(x.lon-.0055)<1e-9);
 assert.equal(x.segmentIndex,1);
 assert.ok(Math.abs(x.heading-90)<1e-6);
});
test('heading uses geographic north rather than SVG screen coordinates',()=>{
 assert.ok(Math.abs(pointAlongRoute([[127,37],[127,37.01]],.4).heading)<1e-6);
 assert.ok(Math.abs(pointAlongRoute([[127,37],[127,36.99]],.4).heading-180)<1e-6);
});
test('maneuver comes from OSRM road data and advances after the actual turn',()=>{
 const start=guidanceForProgress(REAL_ROUTE,0);
 assert.equal(start.road,'삼성로');assert.equal(start.modifier,'right');
 assert.ok(Math.abs(start.distanceMeters-662.8)<2);
 const later=guidanceForProgress(REAL_ROUTE,.5);
 assert.equal(later.road,'남부순환로');assert.equal(later.modifier,'right');
 assert.ok(later.distanceMeters>1000&&later.distanceMeters<1100);
 const end=guidanceForProgress(REAL_ROUTE,1);assert.equal(end.type,'arrive');assert.equal(end.distanceMeters,0);
});
test('parked simulation location remains on the road within 35m of destination',()=>{
 const p=pointAlongRoute(REAL_ROUTE.coordinates,1-35/REAL_ROUTE.totalMeters);
 assert.ok(metersBetween([p.lon,p.lat],REAL_ROUTE.coordinates.at(-1))<=35.2);
 const a=REAL_ROUTE.coordinates[p.segmentIndex],b=REAL_ROUTE.coordinates[p.segmentIndex+1];
 const cross=(p.lon-a[0])*(b[1]-a[1])-(p.lat-a[1])*(b[0]-a[0]);
 assert.ok(Math.abs(cross)<1e-10);
});
test('displayed simulated ETA uses the recorded road duration, not live-traffic claims',()=>{
 let s=createInitialState({now:0,route:REAL_ROUTE});
 assert.equal(view(s).etaSeconds,Math.ceil(REAL_ROUTE.durationSeconds));
 s=reduce(s,{type:'DRIVE',now:1});
 assert.equal(view(s).etaSeconds,Math.ceil(REAL_ROUTE.durationSeconds*.72));
 assert.equal(REAL_ROUTE.traffic,'not-live');
});
test('real route identity survives approach parking and explicit guardian completion',()=>{
 let s=createInitialState({now:0,route:REAL_ROUTE});const route=s.route;
 for(const type of ['PLAY','APPROACH','PARK','SENSOR'])s=reduce(s,{type,now:1});
 assert.equal(s.confirmed,false);assert.equal(view(s).canConfirm,true);
 s=reduce(s,{type:'CONFIRM',now:2});assert.equal(s.confirmed,true);assert.equal(s.route,route);
 assert.equal(s.route.id,REAL_ROUTE.id);
});

test('playback advances the recorded route at explicit six-times demonstration speed',()=>{
 let s=createInitialState({now:0,route:REAL_ROUTE});s=reduce(s,{type:'PLAY',now:0});s=reduce(s,{type:'TICK',now:1000,dtMs:1000});
 assert.ok(Math.abs(s.progress-6/REAL_ROUTE.durationSeconds)<1e-9);
 assert.ok(Math.abs(s.speedKph-REAL_ROUTE.totalMeters/REAL_ROUTE.durationSeconds*3.6)<1e-9);
});
