import test from 'node:test';
import assert from 'node:assert/strict';
import {metersBetween,pointAlongRoute,guidanceForProgress} from './real-map.mjs';
import {REAL_ROUTE} from './route-data.mjs';
import {createInitialState,reduce,view} from './model.mjs';

test('recorded driving response has real Seoul road geometry and stable endpoints',()=>{
 assert.equal(REAL_ROUTE.coordinates.length,41);
 assert.deepEqual(REAL_ROUTE.coordinates[0],[127.049657,37.504591]);
 assert.deepEqual(REAL_ROUTE.coordinates.at(-1),[127.062978,37.494462]);
 for(const [lon,lat] of REAL_ROUTE.coordinates){assert.ok(lon>127&&lon<127.1);assert.ok(lat>37.4&&lat<37.6);}
 assert.ok(Object.isFrozen(REAL_ROUTE.coordinates));
 assert.ok(REAL_ROUTE.steps.some(s=>s.name==='테헤란로'));
 assert.ok(REAL_ROUTE.steps.some(s=>s.name==='삼성로'));
 assert.ok(REAL_ROUTE.steps.some(s=>s.name==='남부순환로'));
});
test('distance interpolation reaches both road endpoints and clamps progress',()=>{
 for(const p of [-1,0]){const x=pointAlongRoute(REAL_ROUTE.coordinates,p);assert.equal(x.lon,REAL_ROUTE.coordinates[0][0]);assert.equal(x.lat,REAL_ROUTE.coordinates[0][1]);}
 for(const p of [1,2]){const x=pointAlongRoute(REAL_ROUTE.coordinates,p);assert.equal(x.lon,REAL_ROUTE.coordinates.at(-1)[0]);assert.equal(x.lat,REAL_ROUTE.coordinates.at(-1)[1]);}
});
test('unevenly spaced vertices are traversed by distance rather than index',()=>{
 const x=pointAlongRoute([[0,0],[.001,0],[.011,0]],.5);
 assert.ok(Math.abs(x.lon-.0055)<1e-9);
 assert.equal(x.segmentIndex,1);
 assert.ok(Math.abs(x.heading-90)<1e-6);
});
test('heading uses geographic north rather than SVG screen coordinates',()=>{
 assert.ok(Math.abs(pointAlongRoute([[127,37],[127,37.01]],.4).heading)<1e-6);
 assert.ok(Math.abs(pointAlongRoute([[127,37],[127,36.99]],.4).heading-180)<1e-6);
});
test('maneuver comes from OSRM road data and advances after the actual turn',()=>{
 const start=guidanceForProgress(REAL_ROUTE,0);
 assert.equal(start.road,'삼성로');assert.equal(start.modifier,'right');
 assert.ok(Math.abs(start.distanceMeters-662.8)<2);
 const later=guidanceForProgress(REAL_ROUTE,.5);
 assert.equal(later.road,'남부순환로');assert.equal(later.modifier,'right');
 assert.ok(later.distanceMeters>1000&&later.distanceMeters<1100);
 const end=guidanceForProgress(REAL_ROUTE,1);assert.equal(end.type,'arrive');assert.equal(end.distanceMeters,0);
});
test('parked simulation location remains on the road within 35m of destination',()=>{
 const p=pointAlongRoute(REAL_ROUTE.coordinates,1-35/REAL_ROUTE.totalMeters);
 assert.ok(metersBetween([p.lon,p.lat],REAL_ROUTE.coordinates.at(-1))<=35.2);
 const a=REAL_ROUTE.coordinates[p.segmentIndex],b=REAL_ROUTE.coordinates[p.segmentIndex+1];
 const cross=(p.lon-a[0])*(b[1]-a[1])-(p.lat-a[1])*(b[0]-a[0]);
 assert.ok(Math.abs(cross)<1e-10);
});
test('displayed simulated ETA uses the recorded road duration, not live-traffic claims',()=>{
 let s=createInitialState({now:0,route:REAL_ROUTE});
 assert.equal(view(s).etaSeconds,Math.ceil(REAL_ROUTE.durationSeconds));
 s=reduce(s,{type:'DRIVE',now:1});
 assert.equal(view(s).etaSeconds,Math.ceil(REAL_ROUTE.durationSeconds*.72));
 assert.equal(REAL_ROUTE.traffic,'not-live');
});
test('real route identity survives approach parking and explicit guardian completion',()=>{
 let s=createInitialState({now:0,route:REAL_ROUTE});const route=s.route;
 for(const type of ['PLAY','APPROACH','PARK','SENSOR'])s=reduce(s,{type,now:1});
 assert.equal(s.confirmed,false);assert.equal(view(s).canConfirm,true);
 s=reduce(s,{type:'CONFIRM',now:2});assert.equal(s.confirmed,true);assert.equal(s.route,route);
 assert.equal(s.route.id,REAL_ROUTE.id);
});

test('playback advances the recorded route at explicit six-times demonstration speed',()=>{
 let s=createInitialState({now:0,route:REAL_ROUTE});s=reduce(s,{type:'PLAY',now:0});s=reduce(s,{type:'TICK',now:1000,dtMs:1000});
 assert.ok(Math.abs(s.progress-6/REAL_ROUTE.durationSeconds)<1e-9);
 assert.ok(Math.abs(s.speedKph-REAL_ROUTE.totalMeters/REAL_ROUTE.durationSeconds*3.6)<1e-9);
});

import {navigationMapStyle,createRoadMap} from './real-map.mjs';
test('navigation uses public vector basemap with real footprint extrusions and Korean labels',()=>{
 const style=navigationMapStyle();
 assert.equal(style.sources.openmaptiles.url,'https://tiles.openfreemap.org/planet');
 assert.ok(style.sources.openmaptiles.attribution.includes('OpenStreetMap'));
 const buildings=style.layers.find(x=>x.id==='navigation-buildings-3d');
 assert.equal(buildings['source-layer'],'building');assert.equal(buildings.type,'fill-extrusion');
 // The real-height input remains intact, with bounded relief so Seoul towers
 // cannot obscure the navigation route at the normal driving scale.
 assert.deepEqual(buildings.paint['fill-extrusion-height'],['min',24,['*',.28,['max',0,['coalesce',['get','render_height'],['get','height'],0]]]]);
 assert.equal(buildings.paint['fill-extrusion-vertical-gradient'],false);
 assert.ok(!style.layers.some(x=>/shield/.test(x.id)));
 const landmarks=style.layers.find(x=>x.id==='navigation-landmarks');
 assert.equal(landmarks['source-layer'],'poi');assert.equal(landmarks.layout['text-allow-overlap'],false);
 assert.deepEqual(landmarks.layout['text-field'][1],['get','name:ko']);
 assert.ok(JSON.stringify(landmarks.filter).includes('school'));
 assert.ok(!JSON.stringify(landmarks.filter).includes('shop'));
 const road=style.layers.find(x=>x.id==='highway-name-major');
 assert.deepEqual(road.layout['text-field'][1],['get','name:ko']);
 assert.equal(navigationMapStyle(false,false).layers.find(x=>x.id===buildings.id).layout.visibility,'none');
 assert.notEqual(navigationMapStyle(true).layers[0].paint['background-color'],style.layers[0].paint['background-color']);
});
test('unavailable map engine returns the complete no-op interface and a visible error',()=>{
 const status={hidden:true,classList:{toggle(){}}};
 const map=createRoadMap({}, {route:REAL_ROUTE,statusElement:status,maplibre:null});
 assert.equal(status.hidden,false);assert.match(status.textContent,/지도 엔진/);
 for(const method of ['setGuidanceActive','setRoute','setProgress','fit','zoomIn','zoomOut','follow','setNight','setPerspective','resize','setDestination','destroy']) assert.equal(typeof map[method],'function');
 assert.doesNotThrow(()=>map.setRoute(REAL_ROUTE));
});

import {navigationPoseForProgress} from './real-map.mjs';
function fakeNavigation({route=REAL_ROUTE,loadStyle=true}={}) {
 const listeners=new Map(), documentListeners=new Map(), markers=[], changes=[];
 let observer;
 const element=()=>({style:{},children:[],setAttribute(){},append(...children){this.children.push(...children);},classList:{toggle(){}}});
 const doc={hidden:false,createElement:element,addEventListener:(name,fn)=>documentListeners.set(name,fn),removeEventListener:name=>documentListeners.delete(name),defaultView:{ResizeObserver:class{constructor(fn){this.callback=fn;observer=this;}observe(){}disconnect(){this.disconnected=true;}}}};
 const container={clientWidth:800,clientHeight:600,ownerDocument:doc};
 class FakeMap {
  constructor(options){this.options=options;this.center=options.center;this.zoom=options.zoom;this.bearing=options.bearing;this.padding={top:0,bottom:0,left:0,right:0};this.jumps=[];this.sources=new Map();this.layers=new Map();FakeMap.instance=this;}
  on(name,fn){listeners.set(name,fn);}
  emit(name,event={}){listeners.get(name)?.(event);}
  addControl(){} getCanvas(){return {addEventListener(){}};}
  jumpTo(options){this.jumps.push(options);Object.assign(this,options);}
  // Simulated projection verifies the camera's geographic center and optical
  // center together. A detached marker-only update will fail the anchor check.
  project([lon,lat]){return {x:container.clientWidth/2+(lon-this.center[0])*1e6,y:(container.clientHeight+this.padding.top-this.padding.bottom)/2-(lat-this.center[1])*1e6};}
  getZoom(){return this.zoom;}getBearing(){return this.bearing;}stop(){this.stopped=true;}
  resize(){this.resizes=(this.resizes||0)+1;}
  fitBounds(bounds,options){this.fitted={bounds,options};this.zoom=options.maxZoom;}
  easeTo(options){this.eased=options;}
  zoomIn(){this.zoom++;}zoomOut(){this.zoom--;}
  getSource(id){return this.sources.get(id);}addSource(id,source){this.sources.set(id,{...source,setData(data){this.data=data;}});}
  addLayer(layer){this.layers.set(layer.id,layer);}getLayer(id){return this.layers.get(id);}setLayoutProperty(id,key,value){const layer=this.layers.get(id);if(layer){layer.layout??={};layer.layout[key]=value;}}
  setStyle(){this.sources.clear();this.layers.clear();this.emit('style.load');}
  isSourceLoaded(){return true;}areTilesLoaded(){return true;}remove(){this.removed=true;}
 }
 class Marker {constructor(options){this.options=options;markers.push(this);}setLngLat(value){this.position=value;return this;}setRotation(value){this.rotation=value;return this;}addTo(){return this;}remove(){this.removed=true;}}
 class Bounds {constructor(a,b){this.points=[a,b];}extend(p){this.points.push(p);return this;}}
 const api=createRoadMap(container,{route,onFollowChange:enabled=>changes.push(enabled),maplibre:{Map:FakeMap,Marker,LngLatBounds:Bounds,AttributionControl:class{}}});
 if(loadStyle)FakeMap.instance.emit('style.load');
 return {api,map:FakeMap.instance,marker:markers[0],destination:markers[1],markers,container,doc,documentListeners,observer,changes};
}
function assertNavigationAnchor(f) {
 const projected=f.map.project(f.marker.position);
 assert.ok(Math.abs(projected.x-f.container.clientWidth*.5)<1e-8);
 assert.ok(Math.abs(projected.y-f.container.clientHeight*.72)<1e-8);
 assert.deepEqual(f.map.center,f.marker.position);
}
test('playback translates road camera with vehicle anchored on every recorded-route frame',t=>{
 const f=fakeNavigation();t.after(()=>f.api.destroy());
 const roadPoint=REAL_ROUTE.coordinates[10], initialRoad=f.map.project(roadPoint);
 for(let frame=1;frame<=600;frame++){
  f.api.setProgress(frame/650);assertNavigationAnchor(f);
  assert.equal(f.map.bearing,f.marker.rotation);
  assert.equal(f.map.pitch,40);
 }
 const movedRoad=f.map.project(roadPoint);
 assert.ok(Math.hypot(movedRoad.x-initialRoad.x,movedRoad.y-initialRoad.y)>500);
 assert.ok(f.map.jumps.length>=602);
 assert.equal(f.map.eased,undefined);
 assert.equal(f.map.getSource('navigation-remaining').data.geometry.coordinates[0][0],f.marker.position[0]);
});
test('road tangent gives smooth shortest-path heading changes at route corners',()=>{
 let previous=navigationPoseForProgress(REAL_ROUTE.coordinates,0).heading,maxDelta=0;
 for(let frame=1;frame<=5000;frame++){
  const heading=navigationPoseForProgress(REAL_ROUTE.coordinates,frame/5000).heading;
  const delta=Math.abs(((heading-previous+540)%360)-180);maxDelta=Math.max(maxDelta,delta);previous=heading;
 }
 assert.ok(maxDelta<8,`heading step ${maxDelta} degrees`);
});
test('2D and follow zoom retain the same geographic vehicle anchor',t=>{
 const f=fakeNavigation();t.after(()=>f.api.destroy());
 f.api.setProgress(.4);f.api.setPerspective(false);assertNavigationAnchor(f);
 assert.equal(f.map.pitch,0);assert.equal(f.map.bearing,0);
 f.api.zoomOut();assert.ok(Math.abs(f.map.zoom-15.1)<1e-9);f.api.setProgress(.45);assert.ok(Math.abs(f.map.zoom-15.1)<1e-9);assertNavigationAnchor(f);
 f.api.setPerspective(true);assert.equal(f.map.pitch,40);assertNavigationAnchor(f);
});
test('overview and manual pan suspend follow; one return resumes at latest position',t=>{
 const f=fakeNavigation();t.after(()=>f.api.destroy());
 f.api.fit();assert.equal(f.api.isFollowing(),false);const before=f.map.jumps.length;
 f.api.setProgress(.3);assert.equal(f.map.jumps.length,before);
 f.api.follow(true);assert.equal(f.api.isFollowing(),true);assertNavigationAnchor(f);assert.equal(f.map.zoom,16.1);
 f.map.emit('dragstart',{originalEvent:{type:'pointermove'}});assert.equal(f.api.isFollowing(),false);
 f.api.setProgress(.7);const panCenter=[...f.map.center];f.api.resize();assert.deepEqual(f.map.center,panCenter);
 f.api.follow(true);assertNavigationAnchor(f);
 const beforeSuspend=f.map.jumps.length;f.api.follow(false);assert.equal(f.api.isFollowing(),false);assert.equal(f.map.jumps.length,beforeSuspend);
 assert.deepEqual(f.changes,[false,true,false,true,false]);
});
test('map-originated camera movement preserves follow while actual manual movement disables it',t=>{
 const f=fakeNavigation();t.after(()=>f.api.destroy());
 f.map.emit('movestart');assert.equal(f.api.isFollowing(),true);
 f.map.emit('movestart',{originalEvent:{type:'keydown'}});assert.equal(f.api.isFollowing(),false);
 f.api.follow(true);assertNavigationAnchor(f);
});
test('hidden map caches latest vehicle; resize and tab return restore exact current anchor',t=>{
 const f=fakeNavigation();t.after(()=>f.api.destroy());
 f.container.clientHeight=0;const before=f.map.jumps.length;
 f.api.setProgress(.6);f.api.resize();assert.equal(f.map.jumps.length,before);
 f.container.clientHeight=900;f.observer.callback();assertNavigationAnchor(f);
 f.container.clientWidth=1200;f.doc.hidden=false;f.documentListeners.get('visibilitychange')();assertNavigationAnchor(f);
 f.api.setNight(true);assertNavigationAnchor(f);
 f.api.destroy();assert.equal(f.observer.disconnected,true);assert.equal(f.documentListeners.has('visibilitychange'),false);const afterDestroy=f.map.jumps.length;f.api.setProgress(.9);f.observer.callback();assert.equal(f.map.jumps.length,afterDestroy);
});

const replacementRoute={destination:'새 목적지',totalMeters:2000,steps:[],coordinates:[[126.98,37.56],[126.99,37.56],[126.99,37.57]]};
test('route replacement resets playback and replaces markers, route geometry, and camera together',t=>{
 const f=fakeNavigation();t.after(()=>f.api.destroy());
 f.api.setProgress(.8);f.api.setDestination('이전 목적지 이름');
 f.api.setLiveTarget({lon:127.05,lat:37.5,accuracy:15});const oldLiveMarker=f.markers.at(-1);
 f.api.setMeetingRoute({coordinates:[[127.05,37.5],[127.06,37.51]]});
 assert.equal(f.api.isFollowing(),false);
 f.api.setRoute(replacementRoute);
 assert.equal(f.api.isFollowing(),true);assert.deepEqual(f.changes,[false,true]);
 assert.deepEqual(f.marker.position,replacementRoute.coordinates[0]);assertNavigationAnchor(f);
 assert.equal(f.marker.rotation,navigationPoseForProgress(replacementRoute.coordinates,0).heading);
 assert.deepEqual(f.destination.position,replacementRoute.coordinates.at(-1));
 assert.equal(f.destination.options.element.children[0].textContent,replacementRoute.destination);
 assert.deepEqual(f.map.getSource('navigation-route').data.geometry.coordinates,replacementRoute.coordinates);
 assert.deepEqual(f.map.getSource('navigation-remaining').data.geometry.coordinates,replacementRoute.coordinates);
 assert.equal(oldLiveMarker.removed,true);
 for(const id of ['meeting-road','child-accuracy'])assert.deepEqual(f.map.getSource(id).data,{type:'FeatureCollection',features:[]});
 const previousEase=f.map.eased;f.api.focusLiveTarget();assert.equal(f.map.eased,previousEase);
 f.api.setProgress(.5);
 const p=navigationPoseForProgress(replacementRoute.coordinates,.5);
 assert.deepEqual(f.marker.position,[p.lon,p.lat]);assertNavigationAnchor(f);
 assert.deepEqual(f.map.getSource('navigation-remaining').data.geometry.coordinates[0],f.marker.position);
 f.api.fit();assert.ok(f.map.fitted.bounds.points.every(point=>replacementRoute.coordinates.includes(point)));
});
test('route replacement before style load and subsequent style reload both use the newest route',t=>{
 const f=fakeNavigation({loadStyle:false});t.after(()=>f.api.destroy());
 f.api.setRoute(replacementRoute);f.api.setProgress(.3);
 assert.equal(f.map.getSource('navigation-route'),undefined);
 f.map.emit('style.load');
 assert.deepEqual(f.map.getSource('navigation-route').data.geometry.coordinates,replacementRoute.coordinates);
 assert.deepEqual(f.map.getSource('navigation-remaining').data.geometry.coordinates[0],f.marker.position);
 f.api.setNight(true);
 assert.deepEqual(f.map.getSource('navigation-route').data.geometry.coordinates,replacementRoute.coordinates);
 assert.deepEqual(f.map.getSource('navigation-remaining').data.geometry.coordinates[0],f.marker.position);
 assert.deepEqual(f.map.getSource('meeting-road').data,{type:'FeatureCollection',features:[]});
 assertNavigationAnchor(f);
});
test('invalid replacement preserves the active route and replacement after disposal is inert',t=>{
 const f=fakeNavigation();t.after(()=>f.api.destroy());
 f.api.setProgress(.4);const previous=[...f.marker.position];
 assert.throws(()=>f.api.setRoute({coordinates:[]}),/at least two/);
 assert.deepEqual(f.marker.position,previous);
 assert.deepEqual(f.map.getSource('navigation-route').data.geometry.coordinates,REAL_ROUTE.coordinates);
 f.api.destroy();const before=f.map.jumps.length;
 f.api.setRoute(replacementRoute);
 assert.equal(f.map.jumps.length,before);assert.deepEqual(f.marker.position,previous);
});

test('idle navigation hides guidance without discarding the real route; style reload respects the mode',t=>{const f=fakeNavigation();t.after(()=>f.api.destroy());f.api.setGuidanceActive(false);for(const id of ['navigation-route-halo','navigation-route-casing','navigation-route-traveled','navigation-route-active'])assert.equal(f.map.getLayer(id).layout.visibility,'none');assert.equal(f.destination.options.element.style.display,'none');assert.deepEqual(f.map.getSource('navigation-route').data.geometry.coordinates,REAL_ROUTE.coordinates);f.api.setNight(true);assert.equal(f.map.getLayer('navigation-route-active').layout.visibility,'none');f.api.setGuidanceActive(true);assert.equal(f.map.getLayer('navigation-route-active').layout.visibility,'visible');assert.equal(f.destination.options.element.style.display,'grid');});
