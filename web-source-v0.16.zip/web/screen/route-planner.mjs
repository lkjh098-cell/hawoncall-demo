import {REAL_ROUTE} from './route-data.mjs';
import {inMapScope} from './live-gps.mjs';

// Deployments may override these through mount options or
// window.HAWONCALL_ROUTE_PROVIDERS without changing this module.
export const PROVIDER_CONFIG = Object.freeze({search:'https://photon.komoot.io/api/',routing:'https://router.project-osrm.org/route/v1/driving/'});
export const PRESET_PLACES = Object.freeze([
  {id:'seolleung',name:'선릉역 인근',address:'서울 강남구 테헤란로 · 저장된 도로 기준점',coordinates:[127.049657,37.504591]},
  {id:'daechi',name:'대치동 픽업 기준점',address:'서울 강남구 남부순환로 · 저장된 도로 기준점',coordinates:[127.062978,37.494462]},
  {id:'cityhall',name:'서울시청 인근',address:'서울 중구 세종대로 · 지도 기준점',coordinates:[126.9780,37.5665]},
  {id:'jamsil',name:'잠실역 인근',address:'서울 송파구 올림픽로 · 지도 기준점',coordinates:[127.1002,37.5133]},
].map(p=>Object.freeze({...p,coordinates:Object.freeze(p.coordinates)})));
export const INSTITUTION_TYPES = Object.freeze({academy:'학원',school:'학교',kindergarten:'유치원',daycare:'어린이집'});
const MAX_POINTS=20000,MAX_STEPS=1500,MAX_DISTANCE=200000,MAX_DURATION=86400;
const clean=(v,max=200)=>typeof v==='string'?v.replace(/[\u0000-\u001f\u007f]/g,' ').trim().slice(0,max):'';
const routeId=()=> 'planned-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);
export function isSeoulCoordinate(p){return Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)&&inMapScope({lon:p[0],lat:p[1]});}
function distance(a,b){const r=Math.PI/180,h=Math.sin((b[1]-a[1])*r/2)**2+Math.cos(a[1]*r)*Math.cos(b[1]*r)*Math.sin((b[0]-a[0])*r/2)**2;return 12742017.6*Math.asin(Math.sqrt(Math.min(1,h)));}
export function validPlace(p){return !!p&&!!clean(p.name)&&!!clean(p.address,500)&&isSeoulCoordinate(p.coordinates);}
/** Only provider-returned names are shown: an unmatched query never becomes a place. */
export function parsePlaceResults(value){
  if(value?.type!=='FeatureCollection'||!Array.isArray(value.features))return [];
  const seen=new Set();return value.features.slice(0,100).flatMap(f=>{
    const p=f?.properties,c=f?.geometry?.coordinates;
    if(f?.type!=='Feature'||f.geometry?.type!=='Point'||!p||!isSeoulCoordinate(c))return [];
    if(p.countrycode&&String(p.countrycode).toUpperCase()!=='KR')return [];
    const street=[clean(p.street),clean(p.housenumber)].filter(Boolean).join(' '),name=clean(p.name)||street;
    if(!name)return [];
    const address=[clean(p.state),clean(p.city),clean(p.district),clean(p.locality),street].filter(Boolean).filter((v,i,a)=>a.indexOf(v)===i).join(' · ')||'서울 · 지도 좌표를 확인해 주세요';
    const key=c.join(',')+'|'+name;if(seen.has(key))return [];seen.add(key);
    return [{name,address,coordinates:[...c],source:'Photon / OpenStreetMap',sourceUrl:'https://www.openstreetmap.org/?mlat='+c[1]+'&mlon='+c[0]+'#map=18/'+c[1]+'/'+c[0]}];
  }).slice(0,6);
}
function validLine(c){return Array.isArray(c)&&c.length>=2&&c.length<=MAX_POINTS&&c.every(isSeoulCoordinate);}
function validSteps(steps,coordinates,totalMeters){
  if(!Array.isArray(steps)||steps.length<2||steps.length>MAX_STEPS)return false;
  let meters=0;
  for(const s of steps){
    if(!s||!Number.isFinite(s.distance)||s.distance<0||s.distance>MAX_DISTANCE||!Number.isFinite(s.duration)||s.duration<0||s.duration>MAX_DURATION||!clean(s.maneuver?.type,40)||!isSeoulCoordinate(s.maneuver?.location)||s.geometry?.type!=='LineString'||!validLine(s.geometry.coordinates)||typeof s.name!=='string'||s.name.length>500)return false;
    if(distance(s.maneuver.location,s.geometry.coordinates[0])>250)return false;
    meters+=s.distance;
  }
  if(steps[0].maneuver.type!=='depart'||steps.at(-1).maneuver.type!=='arrive'||distance(steps[0].maneuver.location,coordinates[0])>250||distance(steps.at(-1).maneuver.location,coordinates.at(-1))>250)return false;
  return Math.abs(meters-totalMeters)<=Math.max(50,totalMeters*.05);
}
/** Reject the entire route, preserving the active route, if any check fails. */
export function parseRouteResponse(value,origin,target){
  if(!validPlace(origin)||!validPlace(target)||value?.code!=='Ok')return null;
  const r=value.routes?.[0],c=r?.geometry?.coordinates;
  if(r?.geometry?.type!=='LineString'||!validLine(c)||!Number.isFinite(r.distance)||r.distance<=151||r.distance>MAX_DISTANCE||!Number.isFinite(r.duration)||r.duration<=0||r.duration>MAX_DURATION)return null;
  if(distance(origin.coordinates,c[0])>250||distance(target.coordinates,c.at(-1))>250)return null;
  let geometryMeters=0;for(let i=1;i<c.length;i++){const d=distance(c[i-1],c[i]);if(d>10000)return null;geometryMeters+=d;}
  if(geometryMeters<=151||Math.abs(geometryMeters-r.distance)>Math.max(150,r.distance*.2))return null;
  if(!Array.isArray(r.legs)||r.legs.length<1||r.legs.length>20||!r.legs.every(l=>Array.isArray(l?.steps)&&l.steps.length))return null;
  const steps=r.legs.flatMap(l=>l.steps);
  if(!validSteps(steps,c,r.distance))return null;
  return {coordinates:c.map(p=>[...p]),totalMeters:r.distance,durationSeconds:r.duration,steps:structuredClone(steps),traffic:'not-live'};
}
export function validPlannedRoute(r){
  if(!r||typeof r.id!=='string'||r.id.length>200||!r.id||!validPlace(r.origin)||!validPlace(r.target)||!clean(r.destination)||!clean(r.institution?.name,80)||!Object.hasOwn(INSTITUTION_TYPES,r.institution.type))return false;
  return !!parseRouteResponse({code:'Ok',routes:[{geometry:{type:'LineString',coordinates:r.coordinates},distance:r.totalMeters,duration:r.durationSeconds,legs:[{steps:r.steps}]}]},r.origin,r.target);
}
export function buildExampleRoute(institution={name:'대치 하원콜학원 · 예시',type:'academy'}){
  const i={name:clean(institution.name,80)||'대치 하원콜학원 · 예시',type:Object.hasOwn(INSTITUTION_TYPES,institution.type)?institution.type:'academy'};
  return {...structuredClone(REAL_ROUTE),id:routeId(),origin:structuredClone(PRESET_PLACES[0]),target:structuredClone(PRESET_PLACES[1]),destination:i.name,institution:i,source:'저장된 OSRM 도로 경로 / OpenStreetMap · 가상 기관 예시'};
}
function endpoint(value){try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.search&&!u.hash?u.href:null;}catch{return null;}}
export function searchUrl(query,base=PROVIDER_CONFIG.search){
  const q=clean(query,160),safe=endpoint(base);if(q.length<2||!safe)throw new Error('검색어는 2자 이상, 제공처는 HTTPS 주소가 필요해요.');
  const u=new URL(safe);u.search=new URLSearchParams({q,limit:'6',bbox:'126.76,37.42,127.19,37.71',lat:'37.5665',lon:'126.9780'});return u.href;
}
export function routeUrl(origin,target,base=PROVIDER_CONFIG.routing){
  const safe=endpoint(base);if(!validPlace(origin)||!validPlace(target)||!safe)throw new Error('서울 안의 출발지와 목적지를 선택해 주세요.');
  return safe.replace(/\/$/,'')+'/'+origin.coordinates.join(',')+';'+target.coordinates.join(',')+'?overview=full&steps=true&geometries=geojson';
}
const placeCache=new Map();let nextSearchAt=0,searchQueue=Promise.resolve();
function abortError(){return new DOMException('Cancelled','AbortError');}
function sleep(ms,signal){return new Promise((resolve,reject)=>{if(signal.aborted)return reject(abortError());const timer=setTimeout(()=>{signal.removeEventListener('abort',stop);resolve();},ms);function stop(){clearTimeout(timer);reject(abortError());}signal.addEventListener('abort',stop,{once:true});});}
async function fetchJson(url,signal){
  const controller=new AbortController(),stop=()=>controller.abort();signal.addEventListener('abort',stop,{once:true});const timer=setTimeout(stop,12000);
  try{if(signal.aborted)throw abortError();const r=await fetch(url,{signal:controller.signal,credentials:'omit',cache:'no-store'});if(!r.ok)throw new Error('Provider unavailable');const text=await r.text();if(text.length>6000000)throw new Error('Response too large');return JSON.parse(text);}finally{clearTimeout(timer);signal.removeEventListener('abort',stop);}
}
export function searchPlaces(query,{signal,base=PROVIDER_CONFIG.search}={}){
  signal??=new AbortController().signal;const url=searchUrl(query,base),hit=placeCache.get(url);if(hit&&Date.now()-hit.at<600000)return Promise.resolve(structuredClone(hit.places));
  const work=searchQueue.catch(()=>{}).then(async()=>{if(signal.aborted)throw abortError();await sleep(Math.max(0,nextSearchAt-Date.now()),signal);nextSearchAt=Date.now()+1100;const places=parsePlaceResults(await fetchJson(url,signal));placeCache.set(url,{at:Date.now(),places});if(placeCache.size>50)placeCache.delete(placeCache.keys().next().value);return structuredClone(places);});searchQueue=work.catch(()=>{});return work;
}

export function mountRoutePlanner({getRoute,getJourney,onApply,toast=()=>{},onOpen=()=>{},providers={}}){
  const provider={...PROVIDER_CONFIG,...globalThis.HAWONCALL_ROUTE_PROVIDERS,...providers};
  const trigger=document.createElement('button');trigger.id='routePlannerOpen';trigger.className='route-planner-open';trigger.textContent='경로·기관';trigger.setAttribute('aria-haspopup','dialog');document.querySelector('.navigation').append(trigger);
  const dialog=document.createElement('dialog');dialog.id='routePlannerDialog';dialog.className='route-planner-dialog';dialog.setAttribute('aria-labelledby','routePlannerTitle');
  dialog.innerHTML=`<div class="rp-heading"><div><span class="eyebrow">서울 · P 정차에서 설정</span><h2 id="routePlannerTitle">경로 설정</h2></div><button type="button" class="rp-close" aria-label="경로 설정 닫기">×</button></div><p class="rp-intro">출발지와 목적지를 선택하세요. 기관 이름은 선택한 도착지에 표시됩니다.</p><div class="rp-place-grid">${['origin','target'].map((key,i)=>`<section class="rp-place"><h3>${i?'도착지':'출발지'}</h3><form data-search="${key}" class="rp-search"><label for="rp-${key}-query">서울의 장소·도로명 주소</label><div class="rp-input-row"><input id="rp-${key}-query" maxlength="160" autocomplete="off" placeholder="예: ${i?'서울시청':'선릉역'}" required minlength="2"><button type="submit">검색</button></div></form><label class="rp-preset-label" for="rp-${key}-preset">빠른 선택</label><select id="rp-${key}-preset"><option value="">서울 장소 선택</option>${PRESET_PLACES.map(p=>`<option value="${p.id}">${p.name}</option>`).join('')}</select><div id="rp-${key}-results" class="rp-results" aria-label="${i?'도착지':'출발지'} 검색 결과"></div><p id="rp-${key}-selected" class="rp-selected"></p></section>`).join('')}</div><section class="rp-institution"><h3>이 도착지의 기관 이름</h3><div class="rp-institution-row"><label>종류<select id="rp-institution-type">${Object.entries(INSTITUTION_TYPES).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select></label><label>직접 정한 이름<input id="rp-institution-name" maxlength="80" placeholder="예: 우리 학원" autocomplete="off"></label></div><p>실제 제휴·기관 조회가 아니에요. 기관 이름을 바꿔도 도착 주소는 바뀌지 않아요.</p></section><div class="rp-example-row"><button type="button" id="rp-example">저장된 대치동 예시 불러오기</button><span>가상 학원 · 인터넷 없이 경로 확인</span></div><p id="rp-status" class="rp-status" role="status" aria-live="polite"></p><p id="rp-error" class="rp-error" role="alert"></p><div id="rp-preview" class="rp-preview" hidden></div><div class="rp-actions"><button type="button" id="rp-query-route" class="quiet-button">도로 경로 확인</button><button type="button" id="rp-apply" class="primary-button" disabled>이 경로로 시작</button></div><details class="rp-provider-info"><summary>검색·경로 제공과 개인정보</summary><p>검색 버튼 또는 Enter를 누를 때만 검색어를 Photon 공개 서비스에 보내요. 아이 이름·전화번호 등 개인정보와 비공개 정보는 검색어에 넣지 마세요. 기관 표시명은 검색 서비스에 보내지 않아요. 도로 경로 확인 시 선택한 두 좌표를 OSRM에 보내요. 무료 공개 서비스는 결과·가용성을 보장하지 않으며 실시간 교통은 반영하지 않아요.</p><p>검색이 안 되면 정확한 서울 도로명 주소로 다시 검색하거나 빠른 선택을 이용하세요. 검색하지 못한 기관 위치는 추측하지 않아요. 공개 장소·검색 결과의 진입로와 승하차 허용 여부는 직접 확인해 주세요.</p><p><a href="https://github.com/komoot/photon" target="_blank" rel="noopener">Photon</a> · <a href="https://project-osrm.org/" target="_blank" rel="noopener">OSRM</a> · © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap 기여자</a></p><p>이 경로로 시작을 누르면 선택한 장소·기관 이름과 경로를 이 브라우저에 저장해요. 같은 브라우저의 시연 탭 연결에 사용하며, 설정 → 시연 기록 지우고 처음부터에서 삭제할 수 있어요.</p></details>`;
  document.body.append(dialog);const el=id=>dialog.querySelector('#'+id);
  let selections={},draft=null,controller=null,version=0,busy=false;
  function cancel(){version++;controller?.abort();controller=null;busy=false;}
  function setStatus(s='',error=''){el('rp-status').textContent=s;el('rp-error').textContent=error;}
  function resetDraft(){draft=null;el('rp-preview').hidden=true;el('rp-apply').disabled=true;}
  function resetRequest(){cancel();resetDraft();setStatus();el('rp-query-route').disabled=false;}
  function selected(key,place,fill=true){resetRequest();selections[key]=structuredClone(place);if(fill)el('rp-'+key+'-query').value=place.name;el('rp-'+key+'-selected').textContent=place.name+' · '+place.address;el('rp-'+key+'-results').replaceChildren();}
  function institution(){const type=el('rp-institution-type').value;return {name:clean(el('rp-institution-name').value,80)||selections.target?.name||'',type};}
  function preview(route){draft=route;el('rp-preview').hidden=false;el('rp-preview').textContent=route.origin.name+' → '+route.destination+' · '+(route.totalMeters/1000).toFixed(1)+'km · 약 '+Math.max(1,Math.ceil(route.durationSeconds/60))+'분 (교통 미반영) · 도착 주소: '+route.target.address;el('rp-apply').disabled=false;setStatus('경로를 확인했어요. 도착지와 기관 이름을 확인한 뒤 시작하세요.');}
  function parked(){if(getJourney()?.gear==='P')return true;setStatus('','P 정차에서 경로를 설정해 주세요.');toast('P 정차에서 경로를 설정해 주세요.');return false;}
  function close(){cancel();if(dialog.open)dialog.close();}
  function fitVehicleWindow(){if(!dialog.open)return;const native=document.body.classList.contains('vehicle-runtime');dialog.classList.toggle('oem-native-route',native);if(!native)return;const rect=document.querySelector('.navigation').getBoundingClientRect();Object.assign(dialog.style,{left:rect.left+'px',top:rect.top+'px',width:rect.width+'px',height:rect.height+'px'});dialog.style.setProperty('--vehicle-unit',document.getElementById('vehicleView').getBoundingClientRect().width/100+'px');}
  new ResizeObserver(fitVehicleWindow).observe(document.querySelector('.navigation'));window.addEventListener('resize',fitVehicleWindow);
  function open(){if(!parked())return;onOpen();cancel();resetDraft();setStatus();selections={};for(const key of ['origin','target']){el('rp-'+key+'-query').value='';el('rp-'+key+'-preset').value='';el('rp-'+key+'-results').replaceChildren();el('rp-'+key+'-selected').textContent='장소를 선택해 주세요.';}const current=getRoute();if(validPlace(current?.origin))selected('origin',current.origin);else selected('origin',PRESET_PLACES[0]);if(validPlace(current?.target))selected('target',current.target);else selected('target',PRESET_PLACES[1]);el('rp-institution-name').value=current?.institution?.name||'대치 하원콜학원 · 예시';el('rp-institution-type').value=Object.hasOwn(INSTITUTION_TYPES,current?.institution?.type)?current.institution.type:'academy';el('rp-query-route').disabled=false;dialog.showModal();fitVehicleWindow();}
  trigger.onclick=open;dialog.querySelector('.rp-close').onclick=close;dialog.addEventListener('cancel',()=>cancel());dialog.addEventListener('close',()=>cancel());
  for(const key of ['origin','target']){
    el('rp-'+key+'-query').addEventListener('input',()=>{resetRequest();delete selections[key];el('rp-'+key+'-preset').value='';el('rp-'+key+'-selected').textContent='검색 결과 또는 빠른 선택에서 장소를 선택해 주세요.';el('rp-'+key+'-results').replaceChildren();});
    el('rp-'+key+'-preset').onchange=e=>{const p=PRESET_PLACES.find(p=>p.id===e.target.value);if(p)selected(key,p);};
    dialog.querySelector('[data-search="'+key+'"]').onsubmit=async e=>{
      e.preventDefault();if(!parked())return;resetRequest();const q=clean(el('rp-'+key+'-query').value,160);if(q.length<2){setStatus('','검색어를 2자 이상 입력해 주세요.');return;}delete selections[key];el('rp-'+key+'-selected').textContent='검색 결과에서 정확한 장소를 선택해 주세요.';el('rp-'+key+'-results').replaceChildren();controller=new AbortController();const request=version;setStatus('서울 안의 장소를 검색하고 있어요…');
      try{const places=await searchPlaces(q,{signal:controller.signal,base:provider.search});if(request!==version||!dialog.open)return;if(!places.length){setStatus('','서울 안에서 확인한 결과가 없어요. 도로명 주소로 다시 검색하거나 빠른 선택을 이용하세요.');return;}for(const place of places){const b=document.createElement('button');b.type='button';const strong=document.createElement('strong');strong.textContent=place.name;const address=document.createElement('span');address.textContent=place.address;b.append(strong,address);b.onclick=()=>selected(key,place);el('rp-'+key+'-results').append(b);}setStatus(places.length+'개 결과 · 주소를 확인하고 선택하세요.');}catch{if(request===version&&dialog.open)setStatus('','검색 서비스를 연결하지 못했어요. 기존 경로를 유지해요. 잠시 후 다시 검색하거나 빠른 선택을 이용하세요.');}
    };
  }
  for(const id of ['rp-institution-name','rp-institution-type'])el(id).addEventListener('input',()=>{cancel();el('rp-query-route').disabled=false;if(draft){const i=institution();preview({...draft,id:routeId(),institution:i,destination:i.name});}else setStatus();});
  el('rp-example').onclick=()=>{if(!parked())return;selected('origin',PRESET_PLACES[0]);selected('target',PRESET_PLACES[1]);el('rp-origin-preset').value='seolleung';el('rp-target-preset').value='daechi';el('rp-institution-name').value='대치 하원콜학원 · 예시';el('rp-institution-type').value='academy';preview(buildExampleRoute());};
  el('rp-query-route').onclick=async()=>{
    if(!parked()||busy)return;if(!validPlace(selections.origin)||!validPlace(selections.target)){setStatus('','출발지와 도착지를 검색 결과 또는 빠른 선택에서 선택해 주세요.');return;}resetRequest();controller=new AbortController();const request=version,origin=structuredClone(selections.origin),target=structuredClone(selections.target);busy=true;el('rp-query-route').disabled=true;setStatus('선택한 두 장소의 도로 경로를 확인하고 있어요…');
    try{const url=routeUrl(origin,target,provider.routing),data=await fetchJson(url,controller.signal);if(request!==version||!dialog.open)return;const route=parseRouteResponse(data,origin,target);if(!route)throw new Error('Invalid road route');const i=institution();preview({...route,id:routeId(),origin,target,institution:i,destination:i.name,source:'OSRM driving route / OpenStreetMap road data',sourceUrl:url,fetchedOn:new Date().toISOString().slice(0,10)});}catch{if(request===version&&dialog.open)setStatus('','서울 안의 도로 경로를 확인하지 못했어요. 기존 경로를 유지해요. 두 주소와 진입로를 확인하거나 저장된 예시를 이용하세요.');}finally{if(request===version){busy=false;el('rp-query-route').disabled=false;}}
  };
  el('rp-apply').onclick=()=>{if(!parked()||!draft)return;if(!validPlannedRoute(draft)){setStatus('','확인한 경로가 올바르지 않아요. 다시 조회해 주세요.');return;}const applied=structuredClone(draft);try{if(onApply(applied)===false){setStatus('','경로를 적용하지 못했어요. P 정차 상태를 다시 확인해 주세요.');return;}}catch{setStatus('','경로를 적용하지 못했어요. 기존 경로를 유지해요.');return;}close();};
  return {open,close,clear(){close();selections={};resetDraft();setStatus();el('rp-institution-name').value='';}};
}
