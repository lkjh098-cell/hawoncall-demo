#!/bin/zsh
set -e
cd "$(dirname "$0")/server"
if ! command -v node >/dev/null 2>&1; then
  echo 'Node.js 22.13 이상을 설치한 다음 다시 실행해 주세요.'
  read -r '?엔터를 누르면 닫힙니다.'
  exit 1
fi
node -e 'const [a,b]=process.versions.node.split(".").map(Number); if(a<22 || (a===22 && b<13)) { console.error("Node.js 22.13 이상이 필요합니다."); process.exit(1); }'
if [[ ! -d node_modules ]]; then npm ci; fi
npm run bootstrap
echo '\n브라우저 주소: http://127.0.0.1:3000\n종료하려면 Control+C를 누르세요.'
open 'http://127.0.0.1:3000'
npm start
