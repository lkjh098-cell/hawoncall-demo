# 하원콜 0.7 · 서울 등하교·등하원

이 GitHub 폴더는 v0.7 소스 배포본입니다. 아래 APK·AAR·검증 이미지·로그·아티팩트 해시는 별도로 전달된 로컬 v0.7 설치 패키지에 있으며 이 공개 저장소에는 포함하지 않습니다. 브라우저 시연과 실행 링크는 저장소 루트 README를 확인하세요.

순정 내비의 기존 경로를 유지하는 Pleos 차량용 앱과 Android 보호자 기능 모듈입니다. 서울을 범위로 학교·유치원·어린이집·학원을 구분하고, 등교·등원 인계와 하교·하원 픽업을 분리합니다. 차량의 접근, 정차, 보호자 탑승·인계 확인을 같은 서버를 통해 모바일에 전달합니다.

서울시 교통소통 도로 5,080개 구간, 좌표가 있는 공영주차장 참고 위치 117곳, 어린이보호구역 지정 시설 주소 1,630건을 포함합니다. 보호자 앱에서 장소 검색과 실제 도로 선형을 볼 수 있습니다. **117곳은 승하차 허용 지점이 아닙니다. 현장·허가 확인된 지점은 0곳이므로 현재 장소 선택은 비활성화됩니다.**

허용 근거를 갖춘 지점에 한해 실제 차량의 도착·완료 위치 관측과 P 체류시간을 학습하는 서버 기능을 구현했습니다. 같은 방향·기관 유형·요일·시간대의 표본 5건 이상에서 대기시간을 비교합니다. 학습으로 정차 허가를 만들어내지 않습니다. 현재 모바일 기본 조회는 기관 좌표를 보내지 않으므로 개인화 추천 순위는 아직 표시하지 않습니다.

**마이현대 공식 앱에 아직 추가되지 않았으며 실차 설치·주행 검증과 배포 승인은 남아 있습니다.** 현재 보호자 기능은 별도 네이티브 테스트 앱에서 실행합니다. 기존 브라우저 지도 시연은 이 버전의 실행 화면이 아닙니다.

## 파일

- `apk/hawoncall-guardian-debug.apk`: Android 보호자 테스트 앱.
- `apk/hawoncall-pleos-debug.apk`: Pleos 전용 SDK 연동 개발 빌드. 지원 기기와 설치·SDK 권한 필요.
- `apk/hawoncall-car-demo-debug.apk`: 일반 Android에서 가상 차량 신호로 실행하는 차량 앱 테스트 빌드.
- `lib/guardian-feature-release.aar`: 보호자 기능 라이브러리. 호스트 통합 및 의존성 설정은 `guardian-feature/README.md` 참조.
- `docs/SEOUL_V07.md`: 서울 자료 출처·범위, 허용 지점 검증과 학습 조건.
- `docs/VERIFICATION_V07.md`: 이번 버전의 빌드·테스트 결과와 실제 네이티브 확인 범위.
- `docs/artifacts-v07.json`: 설치 파일 및 AAR SHA-256.
- `docs/INTEGRATION_V06.md`: 이전 버전의 연결·호스트 통합 안내. 현재 동작은 V07 문서와 소스를 우선합니다.

## 서버 실행

Node.js 22.13 이상에서 다음 순서로 실행합니다. `bootstrap`은 실재하지 않는 시험 기관 4종과 임의의 관리자 비밀번호를 생성합니다. 등록 코드는 학원 `HAWON01`, 학교 `SEOULSCH`, 유치원 `SEOULKID`, 어린이집 `SEOULDAY`입니다. 기존 코드가 있으면 계정을 보존합니다. 관리 웹은 `http://127.0.0.1:3000`이며 기존 학원 중심 웹은 서울 네이티브 화면의 대체물이 아닙니다.

```sh
cd server
npm ci
npm run bootstrap
npm start
```

Android 에뮬레이터에서 서버 주소는 `http://10.0.2.2:3000`입니다. 실제 휴대폰·차량은 접근 가능한 **HTTPS 운영/스테이징 서버**가 필요합니다. debug의 HTTP 허용 대상은 localhost·127.0.0.1·10.0.2.2뿐입니다. 이 패키지는 클라우드에 서버를 배포하지 않습니다.

보호자 앱에서 기관 유형·등원/하원 방향을 정해 등록한 후 8자리 코드를 발급하고 차량 앱의 연결 설정에 입력합니다. 새로운 차량 연결은 기존 기관 목적지 바인딩을 초기화하므로, 정차 상태에서 순정 내비의 목적지를 다시 확인합니다. 접근만으로 도착·탑승·인계 완료가 되지 않습니다. 최종 보호자 확인은 차량 화면에서 처리합니다. 현재 호스트는 한 연결·한 방향·한 일정으로 동작하며 여러 아이·복수 일정 편집은 구현하지 않았습니다.

## 빌드

JDK 17, Android SDK 35 / Build Tools 35.0.0, Gradle 8.10.2를 사용합니다. SDK 위치는 `local.properties` 또는 `ANDROID_HOME`으로 지정하세요.

```sh
./gradlew :core:test :car-app:testDemoDebugUnitTest :guardian-feature:testDebugUnitTest
./gradlew :car-app:assembleDemoDebug :car-app:assemblePleosDebug :guardian-app:assembleDebug :guardian-feature:assembleRelease
cd server && npm test
```

Debug APK는 개발용 서명입니다. 앱마켓 배포용 서명 키와 주행 중 표시 승인 설정을 확정한 후 release를 서명해야 합니다. 키·비밀번호·테스트 데이터베이스는 배포본에 포함하지 않습니다.

## 재사용 구성

`guardian-feature`의 UI와 API 계층을 `guardian-app` 실행 호스트와 분리했습니다. 공식 마이현대 확장 SDK가 확인된 것은 아니며, 실제 편입 시 현대차 계정·동의·세션·알림 및 기술 스택에 맞춰 통합해야 합니다. iOS 구현과 백그라운드 푸시는 이번 범위에 포함하지 않습니다.

차량은 공식 Pleos Vehicle 2.3.2 / NaviHelper 3.0.5 / FusedLocation 1.1.3을 연결합니다. 지도·속도계·공조를 앱 안에 복제하지 않고 Pleos OS의 앱 창으로 실행합니다. 차량 창 위치와 순정 내비 옆 배치는 OS에서 결정합니다.
