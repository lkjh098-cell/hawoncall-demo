import { openStore, createAcademy, opaque } from '../src/store.js';
const db = openStore();
try {
  const code = process.env.ACADEMY_CODE || 'HAWON01';
  const existing = db.prepare('SELECT code FROM academies WHERE code=?').get(code);
  if (existing) console.log(`기존 학원 ${code}을 유지합니다. 비밀번호는 바꾸지 않았습니다.`);
  else {
    const password = process.env.ACADEMY_PASSWORD || opaque();
    createAcademy(db, { code, name: process.env.ACADEMY_NAME || '서울 서비스 시연 학원 (실재 기관 아님)', password, institutionType: process.env.INSTITUTION_TYPE || 'ACADEMY', serviceArea: 'SEOUL', isDemo: true });
    console.log(`시연 학원: ${code}\n관리자 비밀번호 (이 화면에서만 표시): ${password}`);
  }
  for (const [code,institutionType,label] of [['SEOULSCH','SCHOOL','학교'],['SEOULKID','KINDERGARTEN','유치원'],['SEOULDAY','DAYCARE','어린이집']]) {
    if (db.prepare('SELECT 1 FROM academies WHERE code=?').get(code)) continue;
    const password=process.env.ACADEMY_PASSWORD || opaque();
    createAcademy(db,{code,institutionType,name:`서울 서비스 시연 ${label} (실재 기관 아님)`,password,isDemo:true});
    console.log(`시연 ${label}: ${code}\n관리자 비밀번호 (이 화면에서만 표시): ${password}`);
  }
} finally { db.close(); }
