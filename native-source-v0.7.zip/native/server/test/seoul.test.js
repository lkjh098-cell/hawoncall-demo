import { test } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import { createApplication } from '../src/app.js';
import { createAcademy, openStore, prune } from '../src/store.js';
import { createSpotService, insideSeoul, kstScope } from '../src/seoul-spots.js';

// Synthetic geometry and authority proofs are isolated fixtures, never delivered as a permission dataset.
const fixture = () => {
  const point=(id,coordinates=[127,37.5],state='UNVERIFIED')=>({type:'Feature',id,geometry:{type:'Point',coordinates},properties:{name:`Test ${id}`,state,sourceId:'TEST_ONLY'}});
  const now=Date.now();
  const proof=(spotId,delta={})=>({id:`audit-${spotId}`,spotId,state:'VERIFIED',authorityName:'TEST ONLY',permissionDocumentRef:'fixture-permission',operatorAuditorId:'fixture-auditor',auditDocumentRef:'fixture-audit',auditedAt:new Date(now-1000).toISOString(),roadRestrictionsReviewed:true,safeAccessReviewed:true,schoolZoneRestrictionsReviewed:true,signRulesReviewed:true,maxDwellSeconds:600,calendarDates:[kstScope(now).date],allowedWeekdaysKST:[1,2,3,4,5,6,7],timeWindowsKST:[{start:'00:00',end:'24:00'}],validFrom:new Date(now-60000).toISOString(),validUntil:new Date(now+3600000).toISOString(),serviceArea:'SEOUL',journeyTypes:['PICKUP','DROPOFF'],vehicleTypes:['PASSENGER_CAR'],institutionTypes:['SCHOOL','KINDERGARTEN','DAYCARE','ACADEMY'],...delta});
  return {boundary:{type:'Polygon',coordinates:[[[126.7,37.3],[127.2,37.3],[127.2,37.8],[126.7,37.8],[126.7,37.3]]]},references:{type:'FeatureCollection',features:[point('eligible'),point('reference'),point('expired'),point('pickup-only'),point('bus-only'),point('outside',[129,35]),point('fake-property',[127,37.5],'VERIFIED'),point('blocked',[127,37.5],'BLOCKED')]},permissions:[proof('eligible'),proof('expired',{validUntil:new Date(now-1).toISOString()}),proof('pickup-only',{journeyTypes:['PICKUP']}),proof('bus-only',{vehicleTypes:['BUS']}),proof('outside'),proof('blocked')]};
};
const headers=token=>({Authorization:`Bearer ${token}`});
const registration=(delta={})=>({academyCode:'SEOUL01',childName:'서울 테스트',weekday:[1],pickupTime:'08:00',guardianConsent:true,...delta});
async function setup(delta={},customCatalog) {
  const catalog=customCatalog??fixture(),ctx=createApplication({databasePath:':memory:',rateLimit:false,spotCatalog:catalog});
  createAcademy(ctx.db,{code:'SEOUL01',name:'서울 범위 시연기관',password:'fixture-password-long'});
  const body=(await request(ctx.app).post('/api/guardian/links').send(registration(delta)).expect(201)).body;
  const code=(await request(ctx.app).post('/api/guardian/pairing').set(headers(body.guardianToken)).send({}).expect(200)).body.code;
  const car=(await request(ctx.app).post('/api/car/pairing').send({code}).expect(200)).body.carToken;
  return {...ctx,catalog,guardian:body.guardianToken,link:body.link,car};
}
const start=ctx=>request(ctx.app).post('/api/trips').set(headers(ctx.car)).send({linkId:ctx.link.id,clientTripId:crypto.randomUUID()});
const event=(ctx,trip,type,extra={})=>request(ctx.app).post(`/api/trips/${trip.id}/events`).set(headers(ctx.car)).send({eventId:crypto.randomUUID(),type,at:new Date().toISOString(),...(['BOARDED','HANDED_OVER'].includes(type)?{confirmation:'GUARDIAN'}:{}),...extra});
const arrivalProof=(delta={})=>({spotId:'eligible',observedAt:new Date().toISOString(),distanceMeters:12,accuracyMeters:5,source:'PLEOS_FUSED_LOCATION',parkedWaitSeconds:0,...delta});
const choose=(ctx,spotId,extra={})=>request(ctx.app).post('/api/guardian/pickup-spot').set(headers(ctx.guardian)).send({spotId,...extra});

test('Seoul scope, declared institution type and legacy defaults are validated',async()=>{
  const ctx=await setup();
  try {
    assert.equal(ctx.link.institutionType,'ACADEMY');assert.equal(ctx.link.journeyType,'PICKUP');assert.equal(ctx.link.serviceArea,'SEOUL');
    for (const delta of [{serviceArea:'BUSAN'},{institutionType:'SCHOOL'},{institutionType:'OTHER'},{journeyType:'OTHER'}]) await request(ctx.app).post('/api/guardian/links').send(registration(delta)).expect(400);
    for (const institutionType of ['SCHOOL','KINDERGARTEN','DAYCARE']) {
      const code=`TYPE_${institutionType}`;
      createAcademy(ctx.db,{code,name:'시연 기관',password:'fixture-password-long',institutionType});
      const r=await request(ctx.app).post('/api/guardian/links').send(registration({academyCode:code,institutionType,journeyType:'DROPOFF'})).expect(201);
      assert.equal(r.body.link.institutionType,institutionType);assert.equal(r.body.link.journeyType,'DROPOFF');
    }
  } finally {await ctx.close();}
});

test('catalog queries are ephemeral, Seoul-scoped and cannot self-approve a point',async()=>{
  const ctx=await setup();
  try {
    const before=ctx.db.prepare('SELECT * FROM links WHERE id=?').get(ctx.link.id);
    const r=await request(ctx.app).get('/api/guardian/pickup-spots?lat=37.5&lon=127').set(headers(ctx.guardian)).expect(200);
    assert.equal(r.body.serviceArea,'SEOUL');assert.equal(r.body.selectionAllowed,true);
    assert.deepEqual(r.body.spots.filter(s=>s.eligible).map(s=>s.id).sort(),['eligible','pickup-only']);
    assert.equal(r.body.spots.find(s=>s.id==='fake-property').eligible,false);
    assert.equal(r.body.spots.find(s=>s.id==='outside').state,'BLOCKED');
    for (const query of ['lat=35&lon=129','lat=37.5','lat=&lon=127','lat=NaN&lon=127','lat=37.5&lon=127&state=VERIFIED']) await request(ctx.app).get(`/api/guardian/pickup-spots?${query}`).set(headers(ctx.guardian)).expect(400);
    await request(ctx.app).get('/api/guardian/pickup-spots').set(headers(ctx.car)).expect(401);
    await choose(ctx,'eligible',{state:'VERIFIED'}).expect(400);
    for (const id of ['reference','expired','bus-only','outside','fake-property','blocked']) await choose(ctx,id).expect(409);
    await choose(ctx,'unknown').expect(404);
    assert.deepEqual(ctx.db.prepare('SELECT * FROM links WHERE id=?').get(ctx.link.id),before);
    const chosen=(await choose(ctx,'eligible').expect(200)).body.link.pickupSpot;
    assert.equal(chosen.id,'eligible');assert.equal(chosen.estimatedWaitSeconds,null);
    assert.equal((await request(ctx.app).get('/api/car/config').set(headers(ctx.car)).expect(200)).body.link.pickupSpot.id,'eligible');
    ctx.catalog.permissions[0].validUntil=new Date(Date.now()-1).toISOString();
    assert.equal((await request(ctx.app).get('/api/car/config').set(headers(ctx.car)).expect(200)).body.link.pickupSpot,null);
    await choose(ctx,'eligible').expect(409);
  } finally {await ctx.close();}
});

test('dropoff completes only after arrival with guardian handover and immutable direction',async()=>{
  const ctx=await setup({journeyType:'DROPOFF'});
  try {
    await choose(ctx,'pickup-only').expect(409);await choose(ctx,'eligible').expect(200);
    await request(ctx.app).post('/api/trips').set(headers(ctx.car)).send({linkId:ctx.link.id,clientTripId:'stale',journeyType:'PICKUP'}).expect(409);
    const trip=(await start(ctx).expect(201)).body.trip;assert.equal(trip.journeyType,'DROPOFF');
    ctx.db.prepare("UPDATE links SET journey_type='PICKUP' WHERE id=?").run(ctx.link.id);
    await event(ctx,trip,'HANDED_OVER').expect(409);
    await event(ctx,trip,'ARRIVED',{arrivalSpotEvidence:arrivalProof()}).expect(200);
    await event(ctx,trip,'BOARDED').expect(409);
    await event(ctx,trip,'HANDED_OVER',{confirmation:'SENSOR'}).expect(400);
    const e={eventId:'handover',type:'HANDED_OVER',at:new Date().toISOString(),confirmation:'GUARDIAN',arrivalSpotEvidence:arrivalProof()};
    const send=()=>request(ctx.app).post(`/api/trips/${trip.id}/events`).set(headers(ctx.car)).send(e);
    const done=(await send().expect(200)).body.trip;assert.equal(done.status,'HANDED_OVER');assert(done.handedOverAt);assert.equal(done.journeyType,'DROPOFF');assert.equal(done.boardedAt,null);
    assert.equal((await send().expect(200)).body.idempotent,true);
    assert.equal(ctx.db.prepare('SELECT count(*) n FROM spot_wait_samples WHERE trip_id=?').get(trip.id).n,1);
    await event(ctx,trip,'CANCEL').expect(409);
    await start(ctx).expect(201);
  } finally {await ctx.close();}
});

test('learning needs eligible immutable evidence and final guardian action, once per trip; threshold and expiry recheck',async()=>{
  const ctx=await setup();
  try {
    await choose(ctx,'eligible').expect(200);
    const fetch=async()=>(await request(ctx.app).get('/api/guardian/pickup-spots').set(headers(ctx.guardian)).expect(200)).body.spots.find(s=>s.id==='eligible');
    for (let i=0;i<5;i++) {
      const trip=(await start(ctx).expect(201)).body.trip;
      await event(ctx,trip,'ARRIVED',{arrivalSpotEvidence:arrivalProof()}).expect(200);
      assert.equal(ctx.db.prepare('SELECT count(*) n FROM spot_wait_samples').get().n,i);
      ctx.db.prepare('UPDATE trips SET spot_arrival_received_at=? WHERE id=?').run(new Date(Date.now()-60000).toISOString(),trip.id);
      await event(ctx,trip,'BOARDED',{arrivalSpotEvidence:arrivalProof({parkedWaitSeconds:60})}).expect(200);
      assert.equal(ctx.db.prepare('SELECT count(*) n FROM spot_wait_samples').get().n,i+1);
      if (i<4) assert.equal((await fetch()).estimatedWaitSeconds,null);
    }
    const recommended=(await request(ctx.app).get('/api/guardian/pickup-spots?lat=37.5&lon=127').set(headers(ctx.guardian)).expect(200)).body;assert.equal(recommended.recommendedSpotId,'eligible');assert.equal(recommended.recommendationBasis,'NEARBY_CONFIRMED_PARKED_WAIT');
    const learned=await fetch();assert.equal(learned.waitSampleCount,5);assert.equal(learned.estimatedWaitSeconds,60);
    const trip=(await start(ctx).expect(201)).body.trip;
    await event(ctx,trip,'ARRIVED',{arrivalSpotEvidence:arrivalProof()}).expect(200);
    ctx.catalog.permissions[0].validUntil=new Date(Date.now()-1).toISOString();
    await event(ctx,trip,'BOARDED',{arrivalSpotEvidence:arrivalProof()}).expect(200);
    assert.equal(ctx.db.prepare('SELECT count(*) n FROM spot_wait_samples').get().n,5);
    const expired=await fetch();assert.equal(expired.eligible,false);assert.equal(expired.estimatedWaitSeconds,null);assert.equal(expired.waitSampleCount,0);
    ctx.db.prepare('UPDATE trips SET created_at=?').run(new Date(Date.now()-91*86400000).toISOString());prune(ctx.db);
    assert.equal(ctx.db.prepare('SELECT count(*) n FROM spot_wait_samples').get().n,0);
  } finally {await ctx.close();}
});

test('missing boundary, incomplete operator audit and polygon holes fail closed',()=>{
  const catalog=fixture(),db=openStore(':memory:');
  try {
    const link={journey_type:'PICKUP',institution_type:'ACADEMY',service_area:'SEOUL'};
    catalog.boundary=null;assert.equal(createSpotService(db,catalog).eligibility('eligible',link).eligible,false);
    const incomplete=fixture();delete incomplete.permissions[0].auditDocumentRef;
    assert.equal(createSpotService(db,incomplete).eligibility('eligible',link).eligible,false);
    const withHole=fixture().boundary;withHole.coordinates.push([[126.9,37.4],[127.1,37.4],[127.1,37.6],[126.9,37.6],[126.9,37.4]]);
    assert.equal(insideSeoul([127,37.5],withHole),false);assert.equal(insideSeoul([126.8,37.5],withHole),true);
  } finally {db.close();}
});

test('road context uses nearby actual line geometry, bounded response and guardian authentication',async()=>{
  const ctx=await setup();
  try {
    ctx.catalog.roads={type:'FeatureCollection',source:{id:'TEST_ONLY'},features:[
      {type:'Feature',id:'near',geometry:{type:'LineString',coordinates:[[126.999,37.5],[127.001,37.5]]},properties:{name:'fixture'}},
      {type:'Feature',id:'far',geometry:{type:'LineString',coordinates:[[128,36],[128.01,36]]},properties:{name:'fixture'}}
    ]};
    const result=(await request(ctx.app).get('/api/guardian/road-context?lat=37.5&lon=127').set(headers(ctx.guardian)).expect(200)).body;
    assert.deepEqual(result.featureCollection.features.map(f=>f.id),['near']);assert.equal(result.permissionInferenceAllowed,false);assert.equal(result.radiusMeters,2000);
    assert.equal((await request(ctx.app).get('/api/guardian/road-context').set(headers(ctx.guardian)).expect(200)).body.requiresCoordinates,true);
    await request(ctx.app).get('/api/guardian/road-context?lat=35&lon=129').set(headers(ctx.guardian)).expect(400);
    await request(ctx.app).get('/api/guardian/road-context?lat=37.5&lon=127').set(headers(ctx.car)).expect(401);
  } finally {await ctx.close();}
});

test('generic arrival cannot train and point evidence rejects stale, distant, wrong-source and mismatched observations',async()=>{
  const ctx=await setup();
  try {
    await choose(ctx,'eligible').expect(200);
    const generic=(await start(ctx).expect(201)).body.trip;
    await event(ctx,generic,'ARRIVED').expect(200);await event(ctx,generic,'BOARDED').expect(200);
    assert.equal(ctx.db.prepare('SELECT count(*) n FROM spot_wait_samples').get().n,0);
    const noTerminalProof=(await start(ctx).expect(201)).body.trip;
    await event(ctx,noTerminalProof,'ARRIVED',{arrivalSpotEvidence:arrivalProof()}).expect(200);await event(ctx,noTerminalProof,'BOARDED').expect(200);assert.equal(ctx.db.prepare('SELECT count(*) n FROM spot_wait_samples').get().n,0);
    const trip=(await start(ctx).expect(201)).body.trip;
    for(const delta of [{spotId:'reference'},{observedAt:new Date(Date.now()-31000).toISOString()},{observedAt:new Date(Date.now()+6000).toISOString()},{distanceMeters:31},{distanceMeters:-1},{accuracyMeters:21}]) { const r=await event(ctx,trip,'ARRIVED',{arrivalSpotEvidence:arrivalProof(delta)}).expect(200);assert.equal(r.body.arrivalEvidenceAccepted,false); }
    await event(ctx,trip,'ARRIVED',{arrivalSpotEvidence:arrivalProof({source:'DEMO'})}).expect(400);
    await event(ctx,trip,'ARRIVED',{arrivalSpotEvidence:{...arrivalProof(),latitude:37.5}}).expect(400);
    await event(ctx,trip,'CALL',{arrivalSpotEvidence:arrivalProof()}).expect(400);
    await request(ctx.app).post(`/api/trips/${trip.id}/events`).set(headers(ctx.guardian)).send({eventId:'forged',type:'ARRIVED',at:new Date().toISOString(),arrivalSpotEvidence:arrivalProof()}).expect(401);
    const proofEvent={eventId:'point-proof',type:'ARRIVED',at:new Date().toISOString(),arrivalSpotEvidence:arrivalProof()};
    await request(ctx.app).post(`/api/trips/${trip.id}/events`).set(headers(ctx.car)).send(proofEvent).expect(200);
    ctx.db.prepare('UPDATE trips SET spot_arrival_received_at=? WHERE id=?').run(new Date(Date.now()-601000).toISOString(),trip.id);
    await event(ctx,trip,'BOARDED',{arrivalSpotEvidence:arrivalProof()}).expect(200);
    assert.equal(ctx.db.prepare('SELECT count(*) n FROM spot_wait_samples').get().n,0);
    const replay=await request(ctx.app).post(`/api/trips/${trip.id}/events`).set(headers(ctx.car)).send(proofEvent).expect(200);assert.equal(replay.body.idempotent,true);
  } finally {await ctx.close();}
});

test('permit calendar, Korean weekday, time-window and maximum stay are explicit and fail closed',()=>{
  const db=openStore(':memory:'),link={journey_type:'PICKUP',institution_type:'ACADEMY',service_area:'SEOUL'};
  try {
    for(const delta of [{calendarDates:[]},{allowedWeekdaysKST:[]},{timeWindowsKST:[]},{maxDwellSeconds:undefined},{schoolZoneRestrictionsReviewed:false},{signRulesReviewed:false}]) {
      const catalog=fixture();Object.assign(catalog.permissions[0],delta);assert.equal(createSpotService(db,catalog).eligibility('eligible',link).eligible,false);
    }
  } finally {db.close();}
});

test('catalog query searches the full collection before bounded results',async()=>{
  const ctx=await setup();
  try {
    const catalog=fixture();for(let i=0;i<250;i++) catalog.references.features.push({type:'Feature',id:`extra-${i}`,geometry:{type:'Point',coordinates:[127,37.5]},properties:{name:`검색 ${i}`}});
    const service=createSpotService(ctx.db,catalog),link={journey_type:'PICKUP',institution_type:'ACADEMY',service_area:'SEOUL'};
    assert.equal(service.list(link,null,'검색 249')[0].id,'extra-249');
    const r=(await request(ctx.app).get('/api/guardian/pickup-spots?q=reference').set(headers(ctx.guardian)).expect(200)).body;assert.deepEqual(r.spots.map(p=>p.id),['reference']);assert.equal(r.total,1);assert.equal(r.truncated,false);
  } finally {await ctx.close();}
});

test('protection facility search exposes sourced address context without inferring hazard polygons or permission',async()=>{
  const ctx=await setup();
  try {
    ctx.catalog.protectionFacilities={sourceId:'TEST_ONLY',referenceDate:'2026-06-30',records:Array.from({length:110},(_,i)=>({name:`학교 ${i}`,address:'참고 주소',district:'종로구'}))};
    const all=(await request(ctx.app).get('/api/guardian/protection-facilities').set(headers(ctx.guardian)).expect(200)).body;
    assert.equal(all.records.length,100);assert.equal(all.total,110);assert.equal(all.truncated,true);assert.equal(all.protectionAreaGeometryAvailable,false);assert.equal(all.completeHazardMap,false);assert.equal(all.permissionInferenceAllowed,false);
    const named=(await request(ctx.app).get('/api/guardian/protection-facilities?q='+encodeURIComponent('학교 109')).set(headers(ctx.guardian)).expect(200)).body;assert.equal(named.total,1);assert.equal(named.records[0].name,'학교 109');
    await request(ctx.app).get('/api/guardian/protection-facilities').set(headers(ctx.car)).expect(401);
  } finally {await ctx.close();}
});

test('cached permission expires at the matching Korean time-window end',()=>{
  const db=openStore(':memory:'),catalog=fixture(),link={journey_type:'PICKUP',institution_type:'ACADEMY',service_area:'SEOUL'},now=Date.now(),scope=kstScope(now);
  try {
    const endMinute=scope.minute+1,end=`${String(Math.floor(endMinute/60)).padStart(2,'0')}:${String(endMinute%60).padStart(2,'0')}`;
    catalog.permissions[0].timeWindowsKST=[{start:'00:00',end}];
    const service=createSpotService(db,catalog),check=service.eligibility('eligible',link,now);assert.equal(check.eligible,true);
    const until=Date.parse(check.permissionExpiresAt);assert(until>now && until<=now+60000);
    assert.equal(service.eligibility('eligible',link,until).eligible,false);
    assert.equal(service.detail('eligible',link,now).permissionExpiresAt,check.permissionExpiresAt);
  } finally {db.close();}
});

test('recommendations rank only nearby currently eligible points with five matching-context samples',async()=>{
  const catalog=fixture();
  for(const [id,lon] of [['near-slow',127.001],['near-fast',127.002],['far-fast',127.1],['border-fast',127],['revoked-fast',127.003],['expired-fast',127.004],['few-fast',127.005]]) {
    catalog.references.features.push({type:'Feature',id,geometry:{type:'Point',coordinates:[lon,37.5]},properties:{name:id}});
    catalog.permissions.push({...structuredClone(catalog.permissions[0]),id:`audit-${id}`,spotId:id});
  }
  catalog.references.features.find(f=>f.id==='border-fast').geometry.coordinates=[127,37.5+1000.4/111320];
  const ctx=await setup({},catalog);
  try {
    const service=createSpotService(ctx.db,catalog),link={journey_type:'PICKUP',institution_type:'ACADEMY',service_area:'SEOUL'},scope=kstScope();
    for(const [spotId,seconds,count] of [['near-slow',120,5],['near-fast',20,5],['far-fast',1,5],['border-fast',0,5],['revoked-fast',2,5],['expired-fast',3,5],['few-fast',4,4]]) {
      const check=service.eligibility(spotId,link);assert.equal(check.eligible,true);
      for(let i=0;i<count;i++) {
        const id=`sample-${spotId}-${i}`,now=new Date().toISOString();
        ctx.db.prepare("INSERT INTO trips(id,link_id,client_trip_id,status,created_at,updated_at,journey_type) VALUES(?,?,?,'BOARDED',?,?,'PICKUP')").run(id,ctx.link.id,id,now,now);
        ctx.db.prepare('INSERT INTO spot_wait_samples(trip_id,spot_id,journey_type,wait_seconds,completed_at,evidence_id,institution_type,kst_weekday,kst_hour) VALUES(?,?,?,?,?,?,?,?,?)').run(id,spotId,'PICKUP',seconds,now,check.evidenceDigest,'ACADEMY',scope.weekday,scope.hour);
      }
    }
    catalog.permissions.find(e=>e.spotId==='revoked-fast').state='BLOCKED';
    catalog.permissions.find(e=>e.spotId==='expired-fast').validUntil=new Date(Date.now()-1).toISOString();
    const nearby=(await request(ctx.app).get('/api/guardian/pickup-spots?lat=37.5&lon=127').set(headers(ctx.guardian)).expect(200)).body;
    assert.equal(nearby.recommendedSpotId,'near-fast');assert.equal(nearby.spots[0].id,'near-fast');assert.equal(nearby.spots[1].id,'near-slow');
    assert.equal(nearby.spots[0].recommendationRank,1);assert.equal(nearby.spots[1].recommendationRank,2);assert.equal(nearby.spots[0].recommendationConfidence,'LIMITED_OBSERVATIONS');
    for(const id of ['far-fast','border-fast','revoked-fast','expired-fast','few-fast','reference']) assert.equal(nearby.spots.find(s=>s.id===id).recommendationRank,null);
    const noLocation=(await request(ctx.app).get('/api/guardian/pickup-spots').set(headers(ctx.guardian)).expect(200)).body;
    assert.equal(noLocation.recommendedSpotId,null);assert.equal(noLocation.recommendationBasis,null);assert(noLocation.spots.every(s=>s.recommendationRank===null));
    assert.equal(noLocation.spots.find(s=>s.id==='near-fast').estimatedWaitSeconds,20);
    // The matching-context threshold also excludes a different institution type or hour.
    ctx.db.prepare("UPDATE spot_wait_samples SET institution_type='SCHOOL' WHERE spot_id='near-fast'").run();
    const different=(await request(ctx.app).get('/api/guardian/pickup-spots?lat=37.5&lon=127').set(headers(ctx.guardian)).expect(200)).body;assert.equal(different.recommendedSpotId,'near-slow');
  } finally {await ctx.close();}
});
