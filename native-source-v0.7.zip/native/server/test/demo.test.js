import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createContext, runInContext } from 'node:vm';

function demoContext() {
  const nodes=new Map();
  const node=selector=>{
    if(!nodes.has(selector))nodes.set(selector,{innerHTML:'',textContent:'',disabled:false,querySelector:()=>node(`${selector} button`)});
    return nodes.get(selector);
  };
  const context=createContext({document:{querySelector:node,querySelectorAll:()=>[]},location:{pathname:'/test'},sessionStorage:{getItem:()=>null},crypto:globalThis.crypto,console,
    setTimeout:callback=>{callback();return 0;},clearTimeout:()=>{},setInterval:()=>0,clearInterval:()=>{}});
  const source=readFileSync(new URL('../public/app.js',import.meta.url),'utf8').replace(/^if\(page==='home'\).*$/m,'');
  runInContext(source,context);
  runInContext(`carLink={id:'link',childName:'지우',academyName:'학원',baseLeadSeconds:300};trip={id:'trip',status:'ARRIVED'};
    const sent=[];log=()=>{};api=async(path,method,body)=>{sent.push(body);return {trip:{id:'trip',status:body.type==='BOARDED'?'BOARDED':body.type==='ARRIVED'?'ARRIVED':'EN_ROUTE',confirmation:body.confirmation??null}};};`,context);
  return {context,node,read:code=>runInContext(code,context)};
}

test('web sensor simulation records a candidate without transmitting boarding or confirmation',()=>{
  const c=demoContext();c.read('detectBoarding()');
  assert.equal(c.read('boardingDetected'),true);assert.equal(c.read('trip.status'),'ARRIVED');assert.equal(c.read('sent.length'),0);
  assert.match(c.node('#car-display').innerHTML,/탑승 신호를 감지/);
  assert.match(c.node('#car-display').innerHTML,/보호자가 실제 탑승을 확인/);
  assert.equal(c.node('#confirm-boarding').disabled,false);
});

test('web automatic playback stops at detection and never supplies guardian confirmation',async()=>{
  const c=demoContext();c.read(`startTrip=async()=>{trip={id:'trip',status:'EN_ROUTE'};boardingDetected=false;};`);
  await c.read('runAuto()');
  assert.equal(c.read('trip.status'),'ARRIVED');assert.equal(c.read('boardingDetected'),true);
  assert.equal(c.read('JSON.stringify(sent.map(x=>x.type))'),JSON.stringify(['ETA','CALL','ARRIVED']));
  assert.equal(c.read('sent.some(x=>x.confirmation!==undefined)'),false);
  assert.equal(c.node('#confirm-boarding').disabled,false);
});

test('only explicit web guardian action transmits BOARDED and marker',async()=>{
  const c=demoContext();
  await assert.rejects(c.read("event('BOARDED')"),/명시적인 탑승 확인/);
  assert.equal(c.read('sent.length'),0);
  await c.read('guardianConfirm()');
  assert.equal(c.read('trip.status'),'BOARDED');assert.equal(c.read('sent.length'),1);
  assert.equal(c.read('sent[0].confirmation'),'GUARDIAN');
  assert.match(c.node('#car-display').innerHTML,/명시적인 보호자 탑승 확인을 기록/);
  await c.read('guardianConfirm()');assert.equal(c.read('sent.length'),1);
});

test('web guardian action cannot confirm before parked arrival',async()=>{
  const c=demoContext();c.read("trip.status='EN_ROUTE'");await c.read('guardianConfirm()');
  assert.equal(c.read('sent.length'),0);
  c.read('detectBoarding()');assert.equal(c.read('boardingDetected'),false);
});

test('academy display distinguishes explicit confirmation from legacy boarding record',()=>{
  const c=demoContext();c.read(`filter='all';academyTrips=[{id:'1',childName:'지우',status:'BOARDED',confirmation:'GUARDIAN',createdAt:new Date().toISOString()},{id:'2',childName:'민서',status:'BOARDED',confirmation:null,createdAt:new Date().toISOString()}];renderTrips();`);
  assert.match(c.node('#trip-list').innerHTML,/보호자 확인 탑승/);
  assert.match(c.node('#trip-list').innerHTML,/탑승 기록 · 확인 기록 없음/);
});
