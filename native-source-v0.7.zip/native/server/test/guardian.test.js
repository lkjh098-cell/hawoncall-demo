import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import WebSocket from 'ws';
import { createApplication } from '../src/app.js';
import { createAcademy, digest, prune } from '../src/store.js';

const password='a-long-private-test-password';
const auth=token=>({Authorization:`Bearer ${token}`});
const registration={academyCode:'NATIVE01',childName:'지우',weekday:[1,3,5],pickupTime:'18:00',baseLeadSeconds:300,guardianConsent:true};
const event=type=>({eventId:crypto.randomUUID(),type,at:new Date().toISOString(),...(type==='BOARDED'?{confirmation:'GUARDIAN'}:{})});
let ctx,base,guardian,guardianB,link,linkB,car,academy;
const issue=token=>request(ctx.app).post('/api/guardian/pairing').set(auth(token)).send({});
const claim=code=>request(ctx.app).post('/api/car/pairing').send({code});
const start=(token=car,ownedLink=link)=>request(ctx.app).post('/api/trips').set(auth(token)).send({linkId:ownedLink.id,clientTripId:crypto.randomUUID()});
const send=(trip,type,token=car)=>request(ctx.app).post(`/api/trips/${trip.id}/events`).set(auth(token)).send(event(type));
before(async()=>{
  ctx=createApplication({databasePath:':memory:',rateLimit:false});
  createAcademy(ctx.db,{code:'NATIVE01',name:'같은학원',password});
  await new Promise((resolve,reject)=>{ctx.server.once('error',reject);ctx.server.listen(0,'127.0.0.1',resolve);});
  base=`ws://127.0.0.1:${ctx.server.address().port}`;
  const first=(await request(ctx.app).post('/api/guardian/links').send(registration).expect(201)).body;
  assert.deepEqual(Object.keys(first).sort(),['guardianToken','link']);
  guardian=first.guardianToken;link=first.link;
  const second=(await request(ctx.app).post('/api/guardian/links').send({...registration,childName:'민서'}).expect(201)).body;
  guardianB=second.guardianToken;linkB=second.link;
  academy=(await request(ctx.app).post('/api/academy/session').send({code:'NATIVE01',password}).expect(200)).body.token;
});
after(async()=>{await ctx.close();});

test('guardian registration shares legacy validation and stores only hashed credentials',async()=>{
  for(const delta of [{guardianConsent:false},{latitude:37},{weekday:[1,1]},{childName:'<script>'},{pickupTime:'24:00'}]) {
    await request(ctx.app).post('/api/guardian/links').send({...registration,...delta}).expect(400);
  }
  const saved=ctx.db.prepare('SELECT * FROM guardian_tokens WHERE link_id=?').get(link.id);
  assert.equal(saved.token_hash,digest(guardian));assert(!JSON.stringify(saved).includes(guardian));
  assert.equal(ctx.db.prepare('SELECT car_token_hash FROM links WHERE id=?').get(link.id).car_token_hash.length,64);
  const r=await request(ctx.app).get('/api/guardian/config').set(auth(guardian)).expect(200);
  assert.equal(r.body.link.id,link.id);assert.deepEqual(Object.keys(r.body),['link']);
});

test('pairing codes are random, unambiguous, hash-only, replaced on issue and one-use on claim',async()=>{
  const first=(await issue(guardian).expect(200)).body;
  const second=(await issue(guardian).expect(200)).body;
  assert.match(second.code,/^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{8}$/);
  assert.notEqual(first.code,second.code);
  assert(Math.abs(Date.parse(second.expiresAt)-Date.now()-300000)<3000);
  const saved=ctx.db.prepare('SELECT * FROM pairing_codes WHERE link_id=?').get(link.id);
  assert.equal(saved.code_hash,digest(second.code));assert(!JSON.stringify(saved).includes(second.code));
  await claim(first.code).expect(400);
  const result=(await claim(second.code).expect(200)).body;
  assert.deepEqual(Object.keys(result).sort(),['carToken','link']);assert.equal(result.link.id,link.id);car=result.carToken;
  assert.equal(ctx.db.prepare('SELECT car_token_hash FROM links WHERE id=?').get(link.id).car_token_hash,digest(car));
  await claim(second.code).expect(400);
  assert.equal(ctx.db.prepare('SELECT count(*) n FROM pairing_codes WHERE link_id=?').get(link.id).n,0);
});

test('guardian, vehicle and academy roles cannot use each other credentials or mutate guardian history',async()=>{
  const trip=(await start().expect(201)).body.trip;
  for(const token of [car,academy]) {
    await request(ctx.app).get('/api/guardian/config').set(auth(token)).expect(401);
    await request(ctx.app).get('/api/guardian/trips').set(auth(token)).expect(401);
    await issue(token).expect(401);
  }
  await request(ctx.app).get('/api/guardian/config').expect(401);
  await request(ctx.app).get('/api/guardian/trips').expect(401);
  await request(ctx.app).get('/api/car/config').set(auth(guardian)).expect(401);
  await request(ctx.app).get('/api/academy/trips').set(auth(guardian)).expect(401);
  await start(guardian).expect(401);
  await request(ctx.app).get(`/api/trips/${trip.id}`).set(auth(guardian)).expect(401);
  for(const type of ['ETA','CALL','ARRIVED','BOARDED','CANCEL']) {
    const payload={...event(type),...(type==='ETA'?{etaMin:3}:{})};
    await request(ctx.app).post(`/api/trips/${trip.id}/events`).set(auth(guardian)).send(payload).expect(401);
  }
  await request(ctx.app).post(`/api/trips/${trip.id}/released`).set(auth(guardian)).send({}).expect(401);
  assert.equal(ctx.db.prepare('SELECT status FROM trips WHERE id=?').get(trip.id).status,'PLANNED');
  await send(trip,'CANCEL').expect(200);
});

test('guardian history returns newest first for its link, including complete status fields',async()=>{
  const pairing=(await issue(guardianB).expect(200)).body;
  const otherCar=(await claim(pairing.code).expect(200)).body.carToken;
  const hidden=(await start(otherCar,linkB).expect(201)).body.trip;
  const older=(await start().expect(201)).body.trip;await send(older,'CANCEL').expect(200);
  const latest=(await start().expect(201)).body.trip;
  await send(latest,'ARRIVED').expect(200);
  await request(ctx.app).post(`/api/trips/${latest.id}/released`).set(auth(academy)).send({}).expect(200);
  await send(latest,'BOARDED').expect(200);
  ctx.db.prepare('UPDATE trips SET created_at=? WHERE id=?').run(new Date(Date.now()-60000).toISOString(),older.id);
  ctx.db.prepare('UPDATE trips SET created_at=? WHERE id=?').run(new Date(Date.now()+1000).toISOString(),latest.id);
  const result=(await request(ctx.app).get('/api/guardian/trips').set(auth(guardian)).expect(200)).body;
  assert.equal(result.trips[0].id,latest.id);
  assert(result.trips.findIndex(t=>t.id===older.id)>0);
  assert(result.trips.every(t=>t.linkId===link.id));assert(!result.trips.some(t=>t.id===hidden.id));
  const t=result.trips[0];assert.equal(t.status,'BOARDED');assert.equal(t.confirmation,'GUARDIAN');assert(t.releasedAt);assert(t.arrivedAt);assert(t.boardedAt);
  const other=(await request(ctx.app).get('/api/guardian/trips').set(auth(guardianB)).expect(200)).body;
  assert.deepEqual(other.trips.map(t=>t.id),[hidden.id]);
  for(const secret of ['guardianToken','carToken','token_hash','latitude','longitude']) assert(!JSON.stringify(result).includes(secret));
  await send(hidden,'CANCEL',otherCar).expect(200);
});

test('active-trip rotation is refused without consuming code or revoking current vehicle',async()=>{
  const trip=(await start().expect(201)).body.trip,code=(await issue(guardian).expect(200)).body.code;
  await claim(code).expect(409);
  await request(ctx.app).get('/api/car/config').set(auth(car)).expect(200);
  assert(ctx.db.prepare('SELECT 1 FROM pairing_codes WHERE code_hash=?').get(digest(code)));
  await send(trip,'CANCEL').expect(200);
  const oldCar=car;car=(await claim(code).expect(200)).body.carToken;
  await request(ctx.app).get('/api/car/config').set(auth(oldCar)).expect(401);
  await request(ctx.app).get(`/api/trips/${trip.id}`).set(auth(oldCar)).expect(401);
  await send(trip,'CALL',oldCar).expect(401);
  await start(oldCar).expect(401);
  await claim(code).expect(400);
  await request(ctx.app).get('/api/guardian/config').set(auth(guardian)).expect(200);
});

test('expired codes cannot be claimed and cleanup removes expired hashes',async()=>{
  const code=(await issue(guardian).expect(200)).body.code;
  ctx.db.prepare('UPDATE pairing_codes SET expires_at=? WHERE code_hash=?').run(new Date(Date.now()-1).toISOString(),digest(code));
  await claim(code).expect(400);
  await request(ctx.app).get('/api/car/config').set(auth(car)).expect(200);
  prune(ctx.db);assert(!ctx.db.prepare('SELECT 1 FROM pairing_codes WHERE code_hash=?').get(digest(code)));
  for(const bad of ['O0I1AAAA','ABC','abcdefgh','ABCDEFGH0',null,12345678]) await claim(bad).expect(400);
  await issue(guardian).send({latitude:37}).expect(400);
  await request(ctx.app).post('/api/car/pairing').send({code:'ABCDEFGH',latitude:37}).expect(400);
});

test('successful rotation closes every authenticated socket of the old vehicle',async()=>{
  const trip=(await start().expect(201)).body.trip;
  await send(trip,'CANCEL').expect(200);
  const ws=new WebSocket(`${base}/ws/car/${trip.id}`);
  await new Promise((resolve,reject)=>{ws.once('open',resolve);ws.once('error',reject);});
  const initial=new Promise(resolve=>ws.once('message',resolve));ws.send(JSON.stringify({type:'AUTH',token:car}));await initial;
  const closed=new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('revocation did not close socket')),2000);ws.once('close',code=>{clearTimeout(timer);resolve(code);});});
  const code=(await issue(guardian).expect(200)).body.code;
  const old=car;car=(await claim(code).expect(200)).body.carToken;
  assert.equal(await closed,4401);
  const denied=new WebSocket(`${base}/ws/car/${trip.id}`);
  await new Promise(resolve=>denied.once('open',resolve));
  const rejection=new Promise(resolve=>denied.once('close',resolve));denied.send(JSON.stringify({type:'AUTH',token:old}));assert.equal(await rejection,4403);
});

test('pairing claims are rate limited including failed guesses',async()=>{
  const limited=createApplication({databasePath:':memory:'});
  try {
    for(let i=0;i<20;i++) await request(limited.app).post('/api/car/pairing').send({code:'ABCDEFGH'}).expect(400);
    const r=await request(limited.app).post('/api/car/pairing').send({code:'ABCDEFGH'}).expect(429);
    assert(Number(r.headers['retry-after'])>0);
  } finally {await limited.close();}
});
