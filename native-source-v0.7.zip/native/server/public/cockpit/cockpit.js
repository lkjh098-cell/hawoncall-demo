import {createInitialState, reduce, view, scenarioPosition} from './model.mjs';

const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const svgNS='http://www.w3.org/2000/svg';
let state=createInitialState({now:Date.now(),route:{destination:'푸른별학원',name:'한빛동 하원 경로'}});
let zoom=1,follow=false,north=true,toastTimer,sensorTimer,autoMode=false,lastFrame=performance.now(),lastPaint=0;
let returnFocus=null;
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtDistance=n=>n>=1000?`${(n/1000).toFixed(1)}km`:`${Math.max(0,Math.round(n/10)*10)}m`;
function turnAt(index){
  if(index>=route.length-2)return {arrow:'↑',label:'직진'};
  const a=route[index],b=route[index+1],c=route[index+2];
  const dx=b.x-a.x,dy=b.y-a.y,nx=c.x-b.x,ny=c.y-b.y;
  const cross=dx*ny-dy*nx,dot=dx*nx+dy*ny;
  if(Math.abs(cross)<.001)return dot<0?{arrow:'↶',label:'유턴'}:{arrow:'↑',label:'직진'};
  return cross<0?{arrow:'↰',label:'좌회전'}:{arrow:'↱',label:'우회전'};
}
const route=state.route.points.map(p=>({x:p.x*1000,y:p.y*650}));
const routeD=route.map((p,i)=>`${i?'L':'M'}${p.x} ${p.y}`).join(' ');

function makeMap(){
  // The streets and buildings are authored, fictional geometry, never remote tiles.
  const roadOuter=$('.road-outer'),roadInner=$('.road-inner'),roadCenters=$('.road-centers');
  for(const [group] of [[roadOuter],[roadInner],[roadCenters]]){const path=document.createElementNS(svgNS,'path');path.setAttribute('d',routeD);group.append(path);}
  $('#routeBase').setAttribute('d',routeD);$('#routePath').setAttribute('d',routeD);
  $('.route-arrows').innerHTML='<path d="m156 508 8 5-8 5Zm309-228 5-8 5 8Zm178-90 8 5-8 5Zm156-91 8 5-8 5Z"/>';
  $('#destination').setAttribute('transform','translate(880 104)');$('.destination-label').setAttribute('transform','translate(880 47)');
  const buildings=[];
  const nearLine=(x,y)=>route.some((p,i)=>i<route.length-1&&((Math.abs(p.y-route[i+1].y)<1&&Math.abs(y-p.y)<35&&x>Math.min(p.x,route[i+1].x)-30&&x<Math.max(p.x,route[i+1].x)+30)||(Math.abs(p.x-route[i+1].x)<1&&Math.abs(x-p.x)<35&&y>Math.min(p.y,route[i+1].y)-30&&y<Math.max(p.y,route[i+1].y)+30)));
  for(let row=-2;row<8;row++)for(let col=-2;col<10;col++){
    const x=col*140+18,y=row*130+19;
    for(let k=0;k<4;k++){
      const bx=x+(k%2)*51+(row%2)*4,by=y+Math.floor(k/2)*42,w=31+((col*7+row*3+k+100)%14),h=22+((row*5+col*2+k+100)%12);
      if(nearLine(bx+w/2,by+h/2)||[44,355,485,616].some(n=>Math.abs(by+h/2-n)<33)||[298,580,858].some(n=>Math.abs(bx+w/2-n)<34)||(bx>590&&bx<820&&by>60&&by<250))continue;
      buildings.push(`<rect class="building" x="${bx}" y="${by}" width="${w}" height="${h}" rx="2"/><path class="building-roof" d="M${bx+5} ${by+5}h${w-10}v${h-10}"/>`);
    }
  }
  $('#buildings').innerHTML=buildings.join('');
  const trees=[];for(let i=0;i<22;i++){const x=618+(i*41%173),y=91+(i*57%137);if(Math.hypot(x-752,y-190)<39)continue;trees.push(`<circle class="tree" cx="${x}" cy="${y}" r="${5+i%4}"/>`);}$('#trees').innerHTML=trees.join('');
  $('#carHeading').setAttribute('transform','rotate(90) scale(1.32)');
}
function toast(message){$('#toast').textContent=message;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),3200);}
function send(type,extra={}){state=reduce(state,{type,now:Date.now(),...extra});render();}
function reset(){clearTimeout(sensorTimer);autoMode=false;closeDialog('guardian');send('RESET');zoom=1;follow=false;camera();}
function camera(){
  const el=$('.navigation'),ratio=el.clientWidth/Math.max(1,el.clientHeight),width=1160/zoom,height=width/ratio;
  const p=scenarioPosition(view(state).progress),cx=follow?Math.max(width*.3,Math.min(1000-width*.3,p.x*1000)):520,cy=follow?p.y*650:325;
  $('#streetMap').setAttribute('viewBox',`${cx-width/2} ${cy-height/2} ${width} ${height}`);
  $('#streetMap').setAttribute('preserveAspectRatio','xMidYMid meet');
}
function paintCar(){const v=view(state),p=scenarioPosition(v.progress);$('#carPosition').setAttribute('transform',`translate(${p.x*1000} ${p.y*650})`);$('#carHeading').setAttribute('transform',`rotate(${p.heading+90}) scale(1.32)`);if(follow)camera();}
function openDialog(name){returnFocus=document.activeElement;$('#'+name+'Backdrop').hidden=false;document.body.style.overflow='hidden';setTimeout(()=>$('#'+name+'Backdrop').querySelector('button').focus(),0);}
function closeDialog(name){$('#'+name+'Backdrop').hidden=true;document.body.style.overflow='';returnFocus?.focus?.();}
function showGuardian(){if(!view(state).canConfirm){toast('P 주차 후 탑승 신호를 확인해 주세요.');return;}openDialog('guardian');}
function render(){
  const v=view(state),mins=Math.max(1,Math.ceil(v.etaSeconds/60)),hasArrived=v.arrival||v.confirmed,approach=['approach','arrived','candidate','confirmed'].includes(v.stage);
  const now=new Date();$('#clock').textContent=now.toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit',hour12:false});
  $('#speed').textContent=Math.round(v.speedKph);$('#gear').textContent=v.gear;$('#clusterSpeed').textContent=Math.round(v.speedKph);
  $('.cluster-gear').innerHTML=(['P','R','N','D'].includes(v.gear)?'':'<b id="clusterGear">—</b>')+['P','R','N','D'].map(g=>g===v.gear?`<b id="clusterGear">${g}</b>`:`<span>${g}</span>`).join('');
  $('#vehicleStatus').textContent=v.confirmed?'보호자 확인 완료':v.gear==='P'?'안전하게 주차 중':'내비게이션 안내 중';
  const eta=new Date(now.getTime()+v.etaSeconds*1000);$('#arrivalTime').textContent=hasArrived?'도착':eta.toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit',hour12:false});
  $('#etaText').innerHTML=hasArrived?'<span>픽업 장소</span>':`${mins}분 <i>·</i> ${fmtDistance(v.remainingMeters)}`;
  const segment=Math.min(6,Math.floor(v.progress*7)),next=route[segment+1],turnM=Math.round((1-(v.progress*7)%1)*v.route.totalMeters/7);
  const turn=turnAt(segment),nextTurn=turnAt(segment+1);const roadNames=['새솔로','한빛로','배움길','한빛로','중앙공원로','중앙대로','푸른별학원'];
  $('#turnDistance').innerHTML=approach?'목적지 <small>근처</small>':`${Math.max(20,Math.round(turnM/10)*10)} <small>m</small>`;
  $('#turnArrow').textContent=approach?'⚑':turn.arrow;$('#turnArrow').style.transform='none';
  $('#turnRoad').textContent=approach?(hasArrived?'푸른별학원 픽업 구역':'전방에서 안전하게 정차하세요'):`${roadNames[segment]} 방면 ${turn.label}`;
  $('.lane-indicator').innerHTML=`↑ <b>${turn.arrow}</b>`;$('.next-turn b').textContent=nextTurn.arrow;$('.next-turn').style.display=approach||segment===6?'none':'flex';$('.next-turn span:last-child').textContent=`${Math.round(v.route.totalMeters/7/10)*10}m`;
  const copy={
    ready:['하원 픽업 준비','지우를 만날 시간,<br>미리 준비해요','도착 시간에 맞춰 학원에<br>하원 준비를 알려드려요.','↗','준비 요청을 기다려요','주행을 시작하면 도착 시간을 전해요.'],
    driving:['학원으로 이동 중','지우를 만날 시간,<br>미리 준비해요','학원에 도착 예정 시간을 전했어요.<br>안전하게 이동하세요.','↗',`도착 ${mins}분 전 · 학원에 알림`,'지우가 하원 준비를 하고 있어요.'],
    approach:['학원 근처에 도착','만나기 전에,<br>안전하게 주차해요','픽업 구역에 가까워졌어요.<br>정차한 뒤 P로 전환해 주세요.','P','주차를 기다리고 있어요','주행 중에는 탑승을 확인할 수 없어요.'],
    arrived:['픽업 장소에 주차 완료','지우가 나올 때까지<br>잠시 기다려요','학원 근처에서 P를 확인했어요.<br>아이의 탑승을 기다려 주세요.','P','P 주차 · 도착 확인','문·착석 신호가 오면 안내해 드려요.'],
    candidate:['보호자 확인이 필요해요','지우가 탔는지<br>한 번 더 확인해요','문·착석 신호가 감지됐어요.<br>아이의 실제 탑승을 확인해 주세요.','✓','탑승 신호 감지 · 아직 미확인','센서 신호만으로 탑승을 확정하지 않아요.'],
    confirmed:['오늘의 픽업 완료','지우야,<br>오늘도 수고했어','보호자의 탑승 확인을 기록했어요.<br>안전하게 출발하세요.','✓','보호자 탑승 확인 완료','오늘도 안심하고 만났어요.'],
    stale:['차량 정보 확인 중','새로운 차량 정보를<br>기다리고 있어요','최근 내비·차량 정보가 필요해요.<br>시연 단계를 선택해 갱신하세요.','·','정보 수신 대기','최근 신호가 없으면 탑승 확인을 멈춰요.'],
    'route-changed':['픽업 경로 확인 중','경로가 바뀌어<br>확인을 멈췄어요','현재 내비 경로를 확인한 뒤<br>픽업을 다시 시작해 주세요.','↗','픽업 경로 변경','새 경로를 확인할 때까지 기다려요.'],
    departed:['차량이 출발했어요','안전한 귀갓길을<br>함께해요','현재 픽업 구역을 떠나는 중이에요.<br>시연을 다시 시작할 수 있어요.','↗','차량 출발','처음부터 버튼으로 다시 체험해 보세요.']
  }[v.stage];
  const [eyebrow,title,description,symbol,status,detail]=copy||[];
  $('#pickupEyebrow').textContent=eyebrow;$('#pickupTitle').innerHTML=title;$('#pickupDescription').innerHTML=description;$('#statusSymbol').textContent=symbol;$('#statusTitle').textContent=status;$('#statusDetail').textContent=detail;
  $$('.progress-step').forEach((el,i)=>el.classList.toggle('active',i===0||i===1&&approach||i===2&&v.confirmed));
  const action=$('#pickupActionArea');if(v.canConfirm&&!$('#guardianAction')){action.innerHTML='<button class="pickup-action" id="guardianAction">보호자 탑승 확인</button>';$('#guardianAction').addEventListener('click',showGuardian);}else if(!v.canConfirm&&$('#guardianAction'))action.innerHTML='';
  const activeStage=v.confirmed?'guardian':v.candidate?'sensor':v.arrival?'park':v.near?'approach':'driving';
  $$('[data-stage]').forEach(b=>{b.classList.toggle('active',b.dataset.stage===activeStage);b.setAttribute('aria-pressed',String(b.dataset.stage===activeStage));b.disabled=b.dataset.stage==='park'?(!v.near||v.confirmed):b.dataset.stage==='sensor'?(!v.canSensor||v.candidate):b.dataset.stage==='guardian'?!v.canConfirm:false;});
  $('#playIcon').textContent=v.playing?'Ⅱ':'▶';$('#playText').textContent=v.playing?'일시 정지':v.confirmed?'시연 완료':v.candidate?'보호자 확인 대기':v.arrival?'P 주차 중':v.near?'주차를 선택하세요':'시연 재생';$('#playPause').disabled=v.near||v.confirmed||v.stage==='route-changed';
  $('#directorHint').textContent=v.stage==='approach'?'P 주차를 선택하세요. 탑승 완료는 보호자가 직접 확인해요.':v.candidate?'센서 감지는 후보예요. 보호자 확인을 눌러 실제 탑승을 확인해요.':v.confirmed?'보호자가 명시적으로 확인했어요. 처음부터 다시 체험할 수 있어요.':v.arrival?'주차를 확인했어요. 탑승 신호 단계로 이어갈 수 있어요.':'재생하면 차량이 학원 근처까지 이동해요. 주차는 직접 선택해요.';
  $('#eventMessage').textContent=v.notice||(v.stage==='approach'?'학원 150m 전 · 자동 재생 정지 · 운전자가 P 주차를 선택하세요.':v.candidate?'문·착석 감지는 탑승 후보예요. 보호자 확인 전에는 완료되지 않아요.':v.confirmed?'보호자가 아이의 실제 탑승을 직접 확인했어요.':'모든 지도·위치·차량 신호는 브라우저 시연 데이터예요.');
  if(!v.canConfirm&&!$('#guardianBackdrop').hidden)closeDialog('guardian');
  paintCar();
}

$('#playPause').onclick=()=>{const v=view(state);if(v.playing){autoMode=false;send('PAUSE');}else{autoMode=true;send('PLAY');}};
$('#restart').onclick=reset;
$$('[data-stage]').forEach(b=>b.onclick=()=>{
  const type=b.dataset.stage;
  if(type==='driving'){reset();send('DRIVE');}
  if(type==='approach'){clearTimeout(sensorTimer);autoMode=false;send('APPROACH');}
  if(type==='park'){
    send('PARK');
    if(autoMode&&view(state).canSensor){toast('P 주차를 확인했어요. 잠시 후 가상 탑승 신호를 보여드려요.');sensorTimer=setTimeout(()=>{if(view(state).canSensor)send('SENSOR');autoMode=false;},1800);}
  }
  if(type==='sensor'){clearTimeout(sensorTimer);autoMode=false;send('SENSOR');}
  if(type==='guardian')showGuardian();
});
$('#confirmGuardian').onclick=()=>{state=reduce(state,{type:'TICK',now:Date.now(),dtMs:0});if(!view(state).canConfirm){closeDialog('guardian');render();toast('최근 차량 정보가 필요해요. 탑승 신호를 다시 확인해 주세요.');return;}closeDialog('guardian');send('CONFIRM');toast('보호자의 탑승 확인을 기록했어요.');};
$('#openConnection').onclick=()=>openDialog('connection');
$$('[data-close]').forEach(b=>b.onclick=()=>closeDialog(b.dataset.close));
$$('.dialog-backdrop').forEach(b=>b.addEventListener('click',e=>{if(e.target===b)closeDialog(b.id.replace('Backdrop',''));}));
document.addEventListener('keydown',e=>{const backdrop=$$('.dialog-backdrop').find(b=>!b.hidden);if(!backdrop)return;if(e.key==='Escape')closeDialog(backdrop.id.replace('Backdrop',''));if(e.key==='Tab'){const focusable=[...backdrop.querySelectorAll('button:not(:disabled),a[href]')],first=focusable[0],last=focusable.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}});
$('#zoomIn').onclick=()=>{zoom=Math.min(2.4,zoom+.25);camera();toast(`지도 ${Math.round(zoom*100)}%`);};
$('#zoomOut').onclick=()=>{zoom=Math.max(.75,zoom-.25);camera();toast(`지도 ${Math.round(zoom*100)}%`);};
$('#overview').onclick=()=>{zoom=1;follow=false;camera();toast('전체 픽업 경로를 보여드려요.');};
$('#orientation').onclick=()=>{follow=!follow;$('#compassLetter').textContent=follow?'차량':'N';camera();toast(follow?'차량을 중심으로 지도를 따라가요.':'전체 경로를 북쪽 기준으로 보여드려요.');};
document.body.classList.add('night');
$('#themeToggle').onclick=()=>{const night=document.body.classList.toggle('night');$('#themeToggle').textContent=night?'☀':'☾';$('#themeToggle').setAttribute('aria-label',night?'주간 지도로 전환':'야간 지도로 전환');toast(night?'야간 지도':'주간 지도');};
$('#themeToggle').textContent='☀';$('#themeToggle').setAttribute('aria-label','주간 지도로 전환');
$('#fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();setTimeout(camera,150);}catch{toast('이 브라우저에서는 전체 화면을 사용할 수 없어요.');}};
document.addEventListener('fullscreenchange',()=>setTimeout(camera,150));
$('#homeButton').onclick=()=>{zoom=1;follow=false;camera();toast('하원콜 차량 시연 홈이에요.');};
$('#navButton').onclick=()=>{zoom=1;follow=false;camera();toast('푸른별학원까지의 가상 경로예요.');};
$('#mediaButton').onclick=()=>toast('미디어는 이 시연에서 연결하지 않았어요.');
$('#climateButton').onclick=()=>toast('실내 온도 22.0° · 공조 정보는 화면 시연이에요.');
let muted=false;$('#volumeButton').onclick=()=>{muted=!muted;$('#volumeButton').innerHTML=muted?'◖ ×':'◖<span>))</span>';$('#volumeButton').setAttribute('aria-label',muted?'음소거 해제':'음소거');toast(muted?'안내 음소거':'안내 음소거 해제');};
new ResizeObserver(camera).observe($('.navigation'));
makeMap();camera();render();
setInterval(()=>send('HEARTBEAT'),5000);
function frame(t){const dt=t-lastFrame;lastFrame=t;state=reduce(state,{type:'TICK',dtMs:dt,now:Date.now()});paintCar();if(t-lastPaint>200){render();lastPaint=t;}requestAnimationFrame(frame);}
requestAnimationFrame(frame);
