// Browser-only cockpit demonstration. No native adapter or server commands are sent.
// This browser contract requires both navigation and vehicle observations within 30s.
// It does not replace the native adapter's more specific freshness policies.
const FRESH_MS = 30_000;
const APPROACH_METERS = 150;
const ARRIVAL_METERS = 100;
const clamp = (n, low, high) => Math.min(high, Math.max(low, n));
const number = (n, fallback) => Number.isFinite(n) ? n : fallback;
const defaultRoute = { id: 'demo-hawon-route', name: '하원 픽업 경로', destination: '한빛학원', totalMeters: 2400 };
const routePoints = Object.freeze([
  [0.08, 0.79], [0.23, 0.79], [0.23, 0.58], [0.47, 0.58],
  [0.47, 0.30], [0.74, 0.30], [0.74, 0.16], [0.88, 0.16],
].map(([x, y]) => Object.freeze({ x, y })));

/** A fixed map path, normalized to 0..1 so the UI can size its own SVG. */
export function scenarioPosition(progress = 0) {
  const p = clamp(number(progress, 0), 0, 1) * (routePoints.length - 1);
  const i = Math.min(Math.floor(p), routePoints.length - 2);
  const t = p - i;
  const from = routePoints[i], to = routePoints[i + 1];
  return { x: from.x + (to.x - from.x) * t, y: from.y + (to.y - from.y) * t,
    heading: Math.atan2(to.y - from.y, to.x - from.x) * 180 / Math.PI };
}

export function createInitialState(options = {}) {
  const now = number(options.now, Date.now());
  const source = { ...defaultRoute, ...options.route };
  const route = Object.freeze({ ...source, totalMeters: Math.max(151, number(source.totalMeters, 2400)), points: routePoints });
  return {
    route, progress: 0, gear: 'P', speedKph: 0, now,
    navAt: now, vehicleAt: now, navSource: 'simulation', vehicleSource: 'simulation',
    navValid: true, vehicleValid: true, routeMismatch: false, playing: false, candidate: false, confirmed: false,
    confirmedAt: null, departed: false, observedEtaSeconds: null, notice: '',
  };
}

const rawDistance = s => Math.max(0, s.route.totalMeters * (1 - s.progress));
const distance = s => Math.round(rawDistance(s));
const isNear = s => rawDistance(s) <= APPROACH_METERS + 1e-6;
const fresh = s => s.navValid && s.vehicleValid && [s.navAt, s.vehicleAt].every(at => Number.isFinite(at) && s.now >= at && s.now - at <= FRESH_MS);
const eligible = s => s.gear === 'P' && rawDistance(s) <= ARRIVAL_METERS + 1e-6 && fresh(s) && !s.routeMismatch;
const refresh = (s, now) => ({ ...s, navAt: now, vehicleAt: now, navSource: 'simulation', vehicleSource: 'simulation', navValid: true, vehicleValid: true, observedEtaSeconds: null });
const invalidate = s => (!eligible(s) && s.candidate) ? { ...s, candidate: false } : s;

/** Events change this simulation only. External snapshots never cause guardian confirmation. */
export function reduce(state, event = {}) {
  const now = number(event.now, state.now);
  let s = { ...state, now: Math.max(state.now, now), notice: '' };
  const approach = 1 - APPROACH_METERS / s.route.totalMeters;
  switch (event.type) {
    case 'PLAY':
      if (s.confirmed || s.routeMismatch) return s;
      s = refresh({ ...s, playing: s.progress < approach, gear: 'D', speedKph: s.progress < approach ? 36 : 0, candidate: false, departed: false }, s.now);
      break;
    case 'PAUSE': s.playing = false; break;
    case 'HEARTBEAT':
      if (s.navSource === 'simulation' && s.vehicleSource === 'simulation' && !s.routeMismatch) {
        s = { ...s, navAt: s.now, vehicleAt: s.now };
      }
      return s;
    case 'TICK': {
      if (s.playing) {
        const dt = clamp(number(event.dtMs, s.now - state.now), 0, 5_000);
        const progress = Math.min(approach, s.progress + dt / 25_000);
        s = refresh({ ...s, progress, gear: 'D', speedKph: progress >= approach ? 0 : 36, playing: progress < approach }, s.now);
      }
      break;
    }
    case 'DRIVE':
      s = refresh({ ...s, gear: 'D', speedKph: 36, progress: Math.min(approach, Math.max(s.progress, 0.28)), playing: false, candidate: false, departed: false }, s.now);
      break;
    case 'APPROACH':
      s = refresh({ ...s, progress: approach, gear: 'D', speedKph: 0, playing: false, candidate: false, departed: false }, s.now);
      break;
    case 'PARK':
      s = refresh({ ...s, progress: isNear(s) ? Math.max(s.progress, 1 - 35 / s.route.totalMeters) : s.progress, gear: 'P', speedKph: 0, playing: false }, s.now);
      if (!eligible(s)) s.notice = s.routeMismatch ? '경로 변경으로 픽업 확인을 중지했어요.' : '학원 100m 이내에서 도착을 확인해요.';
      break;
    case 'SENSOR':
      if (eligible(s) && !s.confirmed) s.candidate = true;
      else s.notice = '신선한 도착 정보와 P 기어가 필요해요.';
      break;
    case 'CONFIRM':
      if (s.confirmed) return invalidate(s);
      if (eligible(s) && s.candidate) s = { ...s, confirmed: true, confirmedAt: s.now, candidate: false, playing: false };
      else s.notice = '도착 후 P에서 탑승 신호를 확인하고 보호자가 직접 확정해 주세요.';
      break;
    case 'DEPART':
      s = refresh({ ...s, gear: 'D', speedKph: 15, candidate: false, departed: true, playing: false }, s.now);
      break;
    case 'RESET':
      return { ...createInitialState({ now: s.now }), route: state.route };
    case 'NAVIGATION': {
      const n = event.snapshot || {};
      const at = number(n.timestamp, null);
      if (s.navSource === 'external' && Number.isFinite(at) && Number.isFinite(s.navAt) && at < s.navAt) return invalidate(s);
      const routeId = n.routeId ?? n.route?.id;
      const mismatch = routeId !== undefined && routeId !== s.route.id;
      const navValid = routeId === s.route.id && (Number.isFinite(n.progress) || Number.isFinite(n.remainingMeters));
      let progress = s.progress;
      if (!mismatch) {
        if (Number.isFinite(n.progress)) progress = clamp(n.progress, 0, 1);
        else if (Number.isFinite(n.remainingMeters)) progress = clamp(1 - n.remainingMeters / s.route.totalMeters, 0, 1);
      }
      s = { ...s, navAt: at, navSource: 'external', navValid, progress, routeMismatch: mismatch, playing: false,
        observedEtaSeconds: !mismatch && Number.isFinite(n.etaSeconds) ? Math.max(0, n.etaSeconds) : null };
      if (mismatch) s = { ...s, candidate: false, notice: '내비 경로가 변경되어 픽업 확인을 중지했어요.' };
      break;
    }
    case 'VEHICLE': {
      const v = event.snapshot || {};
      const at = number(v.timestamp, null);
      if (s.vehicleSource === 'external' && Number.isFinite(at) && Number.isFinite(s.vehicleAt) && at < s.vehicleAt) return invalidate(s);
      const gear = v.gear === 'P' || v.gear === 'D' ? v.gear : 'UNKNOWN';
      s = { ...s, vehicleAt: at, vehicleSource: 'external', vehicleValid: gear !== 'UNKNOWN', gear, speedKph: gear === 'P' ? 0 : Math.max(0, number(v.speedKph, s.speedKph)), playing: false };
      break;
    }
    default: break;
  }
  return invalidate(s);
}

export function view(state) {
  const remainingMeters = distance(state);
  const isFresh = fresh(state);
  const near = isNear(state);
  const arrival = eligible(state);
  const candidate = arrival && state.candidate && !state.confirmed;
  const canConfirm = candidate && !state.confirmed;
  let stage = 'ready', title = '하원 픽업을 시작해요', subtitle = '고정된 내비 경로를 따라 학원으로 이동해요.';
  if (state.confirmed && state.departed) { stage = 'departed'; title = '탑승을 확인하고 출발했어요'; subtitle = '보호자가 직접 탑승을 확인한 기록이에요.'; }
  else if (state.confirmed) { stage = 'confirmed'; title = '보호자가 탑승을 확인했어요'; subtitle = '탑승 완료 · 보호자 확인 기록을 유지해요.'; }
  else if (state.routeMismatch) { stage = 'route-changed'; title = '경로가 변경되었어요'; subtitle = '픽업 확인이 중지됐어요. 내비 경로를 확인해 주세요.'; }
  else if (!isFresh) { stage = 'stale'; title = '차량 정보를 기다려요'; subtitle = '30초 이내의 유효한 내비·차량 정보가 필요해요.'; }
  else if (state.departed) { stage = 'departed'; title = '차량이 출발했어요'; subtitle = '탑승 확인 없이 픽업 구역을 벗어나는 중이에요.'; }
  else if (candidate) { stage = 'candidate'; title = '탑승 신호가 감지됐어요'; subtitle = '센서 신호는 후보예요. 아이를 확인한 뒤 직접 확정해 주세요.'; }
  else if (arrival) { stage = 'arrived'; title = '학원에 도착했어요'; subtitle = 'P 기어를 확인했어요. 아이의 탑승을 기다려요.'; }
  else if (near) { stage = 'approach'; title = '학원 근처에 도착했어요'; subtitle = '안전하게 정차하고 P로 전환해 주세요.'; }
  else if (state.gear === 'D' || state.progress > 0) { stage = 'driving'; title = '학원으로 이동하고 있어요'; subtitle = '내비 경로와 도착 예정 정보를 확인해요.'; }
  return { ...state, stage, title, subtitle, remainingMeters,
    etaSeconds: state.observedEtaSeconds ?? Math.ceil(remainingMeters / (36 / 3.6)), isFresh, near, arrival,
    candidate, canConfirm, arrivalRadiusMeters: ARRIVAL_METERS, approachRadiusMeters: APPROACH_METERS, canSensor: arrival && !state.confirmed,
    position: scenarioPosition(state.progress), route: state.route,
    freshnessSeconds: Number.isFinite(state.navAt) && Number.isFinite(state.vehicleAt) ? Math.max(0, Math.floor((state.now - Math.min(state.navAt, state.vehicleAt)) / 1000)) : null,
  };
}
