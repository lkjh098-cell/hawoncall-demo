import { createApplication } from './app.js';
const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || '127.0.0.1';
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT를 확인하세요.');
const service = createApplication();
service.server.listen(port, host, () => console.log(`하원콜 서버: http://${host}:${port}`));
service.server.on('error', error => { console.error(error.message); process.exitCode = 1; });
for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, async () => {
  await service.close(); process.exit(0);
});
