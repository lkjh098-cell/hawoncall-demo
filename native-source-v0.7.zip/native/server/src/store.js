import { DatabaseSync } from 'node:sqlite';
import { randomBytes, randomInt, scryptSync, timingSafeEqual, createHash } from 'node:crypto';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

export const opaque = () => randomBytes(32).toString('base64url');
// O/0 and I/1 are excluded so a short code is easy to enter on a vehicle screen.
const pairingAlphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export const pairingCode = () => Array.from({length:8}, () => pairingAlphabet[randomInt(pairingAlphabet.length)]).join('');
export const digest = (value) => createHash('sha256').update(value).digest('hex');
export function passwordHash(password) {
  const salt = randomBytes(16).toString('hex');
  return `${salt}:${scryptSync(password, salt, 64).toString('hex')}`;
}
export function verifyPassword(password, value) {
  const [salt, hash] = value.split(':');
  const actual = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, 'hex');
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
export function openStore(path = process.env.DATABASE_PATH || './data/hawoncall.sqlite') {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
  const db = new DatabaseSync(path);
  db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;
    CREATE TABLE IF NOT EXISTS academies (
      id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY, academy_id TEXT NOT NULL REFERENCES academies(id), expires_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS links (
      id TEXT PRIMARY KEY, academy_id TEXT NOT NULL REFERENCES academies(id), child_name TEXT NOT NULL,
      weekday TEXT NOT NULL, pickup_time TEXT NOT NULL, base_lead_seconds INTEGER NOT NULL,
      car_token_hash TEXT UNIQUE NOT NULL, consent_at TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS guardian_tokens (
      token_hash TEXT PRIMARY KEY, link_id TEXT UNIQUE NOT NULL REFERENCES links(id) ON DELETE CASCADE, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS pairing_codes (
      code_hash TEXT PRIMARY KEY, link_id TEXT UNIQUE NOT NULL REFERENCES links(id) ON DELETE CASCADE, expires_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS trips (
      id TEXT PRIMARY KEY, link_id TEXT NOT NULL REFERENCES links(id), client_trip_id TEXT NOT NULL,
      status TEXT NOT NULL, eta_min INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
      called_at TEXT, arrived_at TEXT, boarded_at TEXT, cancelled_at TEXT, released_at TEXT,
      last_event_at TEXT, UNIQUE(link_id,client_trip_id));
    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY, trip_id TEXT NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
      event_id TEXT NOT NULL, type TEXT NOT NULL, at TEXT NOT NULL, received_at TEXT NOT NULL,
      payload TEXT NOT NULL, UNIQUE(trip_id,event_id));
    CREATE INDEX IF NOT EXISTS trips_created ON trips(created_at);
    CREATE INDEX IF NOT EXISTS links_academy ON links(academy_id);`);
  // Legacy BOARDED rows intentionally remain null: old sensor events are not guardian confirmations.
  if (!db.prepare('PRAGMA table_info(trips)').all().some(column => column.name === 'boarding_confirmation')) {
    db.exec('ALTER TABLE trips ADD COLUMN boarding_confirmation TEXT');
  }
  const add = (table, name, type) => {
    if (!db.prepare(`PRAGMA table_info(${table})`).all().some(column => column.name === name)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${type}`);
  };
  add('academies','institution_type',"TEXT NOT NULL DEFAULT 'ACADEMY'");
  add('academies','is_demo','INTEGER NOT NULL DEFAULT 0');
  add('academies','service_area',"TEXT NOT NULL DEFAULT 'SEOUL'");
  add('links','institution_type',"TEXT NOT NULL DEFAULT 'ACADEMY'");
  add('links','journey_type',"TEXT NOT NULL DEFAULT 'PICKUP'");
  add('links','service_area',"TEXT NOT NULL DEFAULT 'SEOUL'");
  add('links','selected_spot_id','TEXT');
  add('trips','journey_type',"TEXT NOT NULL DEFAULT 'PICKUP'");
  add('trips','handed_over_at','TEXT');
  add('trips','pickup_spot_snapshot','TEXT');
  add('trips','arrival_received_at','TEXT');
  add('trips','spot_arrival_received_at','TEXT');
  add('trips','spot_arrival_evidence','TEXT');
  db.exec(`CREATE TABLE IF NOT EXISTS spot_wait_samples (
    trip_id TEXT PRIMARY KEY REFERENCES trips(id) ON DELETE CASCADE,
    spot_id TEXT NOT NULL, journey_type TEXT NOT NULL, wait_seconds INTEGER NOT NULL,
    completed_at TEXT NOT NULL, evidence_id TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS spot_wait_scope ON spot_wait_samples(spot_id,journey_type);`);
  add('spot_wait_samples','institution_type',"TEXT NOT NULL DEFAULT 'ACADEMY'");
  add('spot_wait_samples','kst_weekday','INTEGER');
  add('spot_wait_samples','kst_hour','INTEGER');
  return db;
}
export function prune(db, now = Date.now()) {
  const cutoff = new Date(now - 90 * 86400000).toISOString();
  db.prepare('DELETE FROM trips WHERE created_at < ?').run(cutoff);
  db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(new Date(now).toISOString());
  db.prepare('DELETE FROM pairing_codes WHERE expires_at <= ?').run(new Date(now).toISOString());
}
export const institutionTypes = ['SCHOOL','KINDERGARTEN','DAYCARE','ACADEMY'];
export function createAcademy(db, { code, name, password, institutionType = 'ACADEMY', serviceArea = 'SEOUL', isDemo = false }) {
  if (!/^[A-Z0-9_-]{4,24}$/.test(code)) throw new Error('학원 코드는 영문 대문자·숫자 4~24자입니다.');
  if (typeof name !== 'string' || !name.trim() || name.trim().length > 60) throw new Error('학원 이름을 확인하세요.');
  if (typeof password !== 'string' || password.length < 12 || password.length > 128) throw new Error('비밀번호는 12~128자입니다.');
  if (!institutionTypes.includes(institutionType) || serviceArea !== 'SEOUL') throw new Error('서울 서비스 기관 유형을 확인하세요.');
  const id = `ac_${opaque().slice(0,20)}`;
  db.prepare('INSERT INTO academies(id,code,name,password_hash,created_at,institution_type,service_area,is_demo) VALUES(?,?,?,?,?,?,?,?)').run(id, code, name.trim(), passwordHash(password), new Date().toISOString(), institutionType, serviceArea, isDemo?1:0);
  return { id, code, name: name.trim(), institutionType, serviceArea };
}
