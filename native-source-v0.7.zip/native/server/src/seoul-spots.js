import { readFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { digest } from './store.js';

const dataPath = name => fileURLToPath(new URL(`../data/${name}`, import.meta.url));
const read = (path, fallback) => existsSync(path) ? JSON.parse(readFileSync(path, 'utf8')) : fallback;
const validCoordinates = c => Array.isArray(c) && c.length >= 2 && Number.isFinite(c[0]) && Number.isFinite(c[1]) && Math.abs(c[0]) <= 180 && Math.abs(c[1]) <= 90;
function inRing(point, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const a = ring[i], b = ring[j];
    if (!validCoordinates(a) || !validCoordinates(b)) return false;
    const cross = (point[1]-a[1])*(b[0]-a[0])-(point[0]-a[0])*(b[1]-a[1]);
    if (Math.abs(cross) < 1e-10 && point[0] >= Math.min(a[0],b[0]) && point[0] <= Math.max(a[0],b[0]) && point[1] >= Math.min(a[1],b[1]) && point[1] <= Math.max(a[1],b[1])) return true;
    if ((a[1] > point[1]) !== (b[1] > point[1]) && point[0] < (b[0]-a[0])*(point[1]-a[1])/(b[1]-a[1])+a[0]) inside = !inside;
  }
  return inside;
}
export function insideSeoul(coordinates, boundary) {
  if (!validCoordinates(coordinates) || !boundary) return false;
  if (boundary.type === 'FeatureCollection') return boundary.features.some(f => insideSeoul(coordinates,f));
  const geometry = boundary.type === 'Feature' ? boundary.geometry : boundary;
  const polygons = geometry?.type === 'MultiPolygon' ? geometry.coordinates : geometry?.type === 'Polygon' ? [geometry.coordinates] : [];
  return polygons.some(rings => rings.length && inRing(coordinates,rings[0]) && !rings.slice(1).some(ring => inRing(coordinates,ring)));
}
export function loadSeoulCatalog() {
  return {
    references: read(dataPath('seoul-reference.geojson'), {type:'FeatureCollection',features:[]}),
    boundary: read(dataPath('seoul-boundary.geojson'), null),
    roads: read(dataPath('seoul-roads.geojson'), {type:'FeatureCollection',features:[]}),
    protectionFacilities: read(dataPath('seoul-protection-zones.json'), {records:[]}),
    // Permission evidence is operator-managed, never supplied by the guardian API.
    permissions: read(dataPath('spot-permissions.json'), {permissions:[]}).permissions ?? []
  };
}
export const kstScope = (now=Date.now()) => { const d=new Date(now+9*3600000);return {date:d.toISOString().slice(0,10),weekday:d.getUTCDay()||7,hour:d.getUTCHours(),minute:d.getUTCHours()*60+d.getUTCMinutes()}; };
const completeText = value => typeof value === 'string' && value.trim().length > 0;
export function createSpotService(db, catalog = loadSeoulCatalog()) {
  const features = catalog.references?.features ?? [];
  const byId = new Map();
  for (const feature of features) {
    const id = feature.id ?? feature.properties?.id;
    if (typeof id !== 'string' || !id || byId.has(id) || feature.geometry?.type !== 'Point' || !validCoordinates(feature.geometry.coordinates)) throw new Error('Invalid or duplicate Seoul spot reference');
    byId.set(id, feature);
  }
  const evidenceFor = id => (catalog.permissions ?? []).filter(e => e && e.spotId === id);
  const eligibility = (id, link, now = Date.now()) => {
    const feature = byId.get(id);
    if (!feature) return {eligible:false,state:'UNVERIFIED',reason:'UNKNOWN_SPOT'};
    if (!insideSeoul(feature.geometry.coordinates,catalog.boundary)) return {eligible:false,state:'BLOCKED',reason:'OUTSIDE_SEOUL_OR_BOUNDARY_UNAVAILABLE'};
    if (feature.properties?.state === 'BLOCKED') return {eligible:false,state:'BLOCKED',reason:'OPERATOR_BLOCKED'};
    const proofs = evidenceFor(id);
    if (proofs.some(e => e.state === 'BLOCKED')) return {eligible:false,state:'BLOCKED',reason:'OPERATOR_BLOCKED'};
    for (const e of proofs) {
      if (e.state !== 'VERIFIED' || !completeText(e.id) || !completeText(e.authorityName) || !completeText(e.permissionDocumentRef) || !completeText(e.operatorAuditorId) || !completeText(e.auditDocumentRef) || !Number.isFinite(Date.parse(e.auditedAt)) || Date.parse(e.auditedAt) > now || e.roadRestrictionsReviewed !== true || e.safeAccessReviewed !== true) continue;
      const starts=Date.parse(e.validFrom), ends=Date.parse(e.validUntil);
      if (!Number.isFinite(starts) || !Number.isFinite(ends) || starts > now || ends <= now || ends <= starts) continue;
      const scope=kstScope(now), validMinute=(value,end=false)=>typeof value==='string' && (end && value==='24:00' || /^([01]\d|2[0-3]):[0-5]\d$/.test(value));
      if (!Array.isArray(e.calendarDates) || !e.calendarDates.includes(scope.date) || !Array.isArray(e.allowedWeekdaysKST) || !e.allowedWeekdaysKST.includes(scope.weekday) || !Number.isInteger(e.maxDwellSeconds) || e.maxDwellSeconds<1 || e.maxDwellSeconds>3600 || e.schoolZoneRestrictionsReviewed!==true || e.signRulesReviewed!==true) continue;
      const matchingWindows=Array.isArray(e.timeWindowsKST)?e.timeWindowsKST.filter(w=>w && validMinute(w.start) && validMinute(w.end,true) && scope.minute >= Number(w.start.slice(0,2))*60+Number(w.start.slice(3)) && scope.minute < Number(w.end.slice(0,2))*60+Number(w.end.slice(3))):[];
      if (!matchingWindows.length) continue;
      const dayStart=Date.parse(`${scope.date}T00:00:00Z`)-9*3600000;
      const permissionExpiresAt=new Date(Math.min(ends,Math.max(...matchingWindows.map(w=>dayStart+(Number(w.end.slice(0,2))*60+Number(w.end.slice(3)))*60000)))).toISOString();
      if (e.serviceArea !== 'SEOUL' || link.service_area !== 'SEOUL' || !Array.isArray(e.journeyTypes) || !e.journeyTypes.includes(link.journey_type) || !Array.isArray(e.vehicleTypes) || !e.vehicleTypes.includes('PASSENGER_CAR') || !Array.isArray(e.institutionTypes) || !e.institutionTypes.includes(link.institution_type)) continue;
      return {eligible:true,state:'VERIFIED',reason:null,evidence:e,permissionExpiresAt,evidenceDigest:digest(JSON.stringify(e))};
    }
    return {eligible:false,state:'UNVERIFIED',reason:proofs.length?'PERMISSION_NOT_CURRENT_OR_SCOPE_MISMATCH':'NO_OPERATOR_PERMISSION_EVIDENCE'};
  };
  const detail = (id,link,now=Date.now()) => {
    const feature=byId.get(id); if (!feature) return null;
    const check=eligibility(id,link,now);
    const scope=kstScope(now);
    const stats=check.eligible ? db.prepare('SELECT count(*) count,avg(wait_seconds) mean FROM spot_wait_samples WHERE spot_id=? AND journey_type=? AND evidence_id=? AND institution_type=? AND kst_weekday=? AND kst_hour=?').get(id,link.journey_type,check.evidenceDigest,link.institution_type,scope.weekday,scope.hour) : {count:0};
    return {id,name:feature.properties?.name ?? feature.properties?.nameKo ?? id,latitude:feature.geometry.coordinates[1],longitude:feature.geometry.coordinates[0],serviceArea:'SEOUL',state:check.state,eligible:check.eligible,reason:check.reason,permissionExpiresAt:check.permissionExpiresAt ?? null,maxDwellSeconds:check.evidence?.maxDwellSeconds ?? null,waitSampleCount:stats.count,estimatedWaitSeconds:stats.count>=5?Math.round(stats.mean):null,address:feature.properties?.address ?? null,sourceName:feature.properties?.sourceName ?? null,sourceUrl:feature.properties?.sourceUrl ?? null,sourceId:feature.properties?.sourceId ?? null};
  };
  return {
    eligibility, detail,
    selected(link) { return link.selected_spot_id && eligibility(link.selected_spot_id,link).eligible ? detail(link.selected_spot_id,link) : null; },
    list(link,coordinates,query='') {
      const spots=[...byId.keys()].map(id=>detail(id,link)).filter(s=>!query || `${s.name} ${s.address??''}`.toLocaleLowerCase('ko').includes(query.toLocaleLowerCase('ko')));
      const distances=new Map();
      if (coordinates) for (const spot of spots) { const distance=Math.hypot((spot.longitude-coordinates[0])*Math.cos(coordinates[1]*Math.PI/180)*111320,(spot.latitude-coordinates[1])*111320);distances.set(spot.id,distance);spot.distanceMeters=Math.round(distance); }
      const qualified=coordinates?spots.filter(s=>s.eligible && distances.get(s.id)<=1000 && s.waitSampleCount>=5 && s.estimatedWaitSeconds!==null).sort((a,b)=>a.estimatedWaitSeconds-b.estimatedWaitSeconds || a.distanceMeters-b.distanceMeters):[];
      const ranks=new Map(qualified.map((s,i)=>[s.id,i+1]));
      for(const spot of spots) { spot.recommendationRank=ranks.get(spot.id)??null;spot.recommendationConfidence=ranks.has(spot.id)?'LIMITED_OBSERVATIONS':null; }
      return spots.sort((a,b)=>(a.recommendationRank??Infinity)-(b.recommendationRank??Infinity) || Number(b.eligible)-Number(a.eligible) || (a.distanceMeters??0)-(b.distanceMeters??0) || a.name.localeCompare(b.name,'ko')); 
    },
    snapshot(link) {
      if (!link.selected_spot_id) return null;
      const check=eligibility(link.selected_spot_id,link);
      return check.eligible?JSON.stringify({spotId:link.selected_spot_id,journeyType:link.journey_type,institutionType:link.institution_type,evidenceDigest:check.evidenceDigest,geometryDigest:digest(JSON.stringify(byId.get(link.selected_spot_id).geometry)),permissionExpiresAt:check.permissionExpiresAt,vehicleType:'PASSENGER_CAR'}):null;
    },
    validArrivalShape(evidence) {
      return evidence && !Array.isArray(evidence) && typeof evidence==='object' && !Object.keys(evidence).some(k=>!['spotId','observedAt','distanceMeters','accuracyMeters','source','parkedWaitSeconds'].includes(k)) && typeof evidence.spotId==='string' && evidence.spotId.length<=160 && typeof evidence.observedAt==='string' && evidence.observedAt.length<=40 && Number.isFinite(evidence.distanceMeters) && (evidence.accuracyMeters===undefined || Number.isFinite(evidence.accuracyMeters)) && evidence.source==='PLEOS_FUSED_LOCATION' && (evidence.parkedWaitSeconds===undefined || Number.isInteger(evidence.parkedWaitSeconds) && evidence.parkedWaitSeconds>=0 && evidence.parkedWaitSeconds<=3600);
    },
    validateArrival(trip,evidence,now=Date.now()) {
      if (!evidence || Array.isArray(evidence) || typeof evidence!=='object' || Object.keys(evidence).some(k=>!['spotId','observedAt','distanceMeters','accuracyMeters','source','parkedWaitSeconds'].includes(k)) || evidence.source!=='PLEOS_FUSED_LOCATION' || typeof evidence.spotId!=='string' || typeof evidence.observedAt!=='string' || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,9})?Z$/.test(evidence.observedAt) || !Number.isFinite(Date.parse(evidence.observedAt)) || Date.parse(evidence.observedAt)<now-30000 || Date.parse(evidence.observedAt)>now+5000 || !Number.isFinite(evidence.distanceMeters) || evidence.distanceMeters<0 || evidence.distanceMeters>30 || evidence.accuracyMeters!==undefined && (!Number.isFinite(evidence.accuracyMeters) || evidence.accuracyMeters<0 || evidence.accuracyMeters>20)) return false;
      if (!trip.pickup_spot_snapshot) return false;
      const snap=JSON.parse(trip.pickup_spot_snapshot), check=eligibility(snap.spotId,{journey_type:snap.journeyType,institution_type:snap.institutionType,service_area:'SEOUL'},now);
      return evidence.spotId===snap.spotId && Date.parse(snap.permissionExpiresAt)>now && check.eligible && check.evidenceDigest===snap.evidenceDigest && digest(JSON.stringify(byId.get(snap.spotId).geometry))===snap.geometryDigest;
    },
    learn(trip, now,completionEvidence) {
      if (!this.validateArrival(trip,completionEvidence,Date.parse(now))) return false;
      if (!trip.pickup_spot_snapshot || !trip.spot_arrival_received_at || !trip.spot_arrival_evidence || trip.boarding_confirmation !== 'GUARDIAN' || !['BOARDED','HANDED_OVER'].includes(trip.status)) return false;
      const snap=JSON.parse(trip.pickup_spot_snapshot);
      const check=eligibility(snap.spotId,{journey_type:snap.journeyType,institution_type:snap.institutionType,service_area:'SEOUL'},Date.parse(now));
      if (!check.eligible || check.evidenceDigest !== snap.evidenceDigest || snap.journeyType!==trip.journey_type) return false;
      const elapsed=Math.round((Date.parse(now)-Date.parse(trip.spot_arrival_received_at))/1000);
      const seconds=completionEvidence.parkedWaitSeconds;
      if (!Number.isInteger(seconds) || seconds<0 || seconds>Math.min(3600,check.evidence.maxDwellSeconds) || elapsed<0 || elapsed>Math.min(3600,check.evidence.maxDwellSeconds) || seconds>elapsed+30) return false;
      const scope=kstScope(Date.parse(trip.spot_arrival_received_at));
      return db.prepare('INSERT OR IGNORE INTO spot_wait_samples(trip_id,spot_id,journey_type,wait_seconds,completed_at,evidence_id,institution_type,kst_weekday,kst_hour) VALUES(?,?,?,?,?,?,?,?,?)').run(trip.id,snap.spotId,snap.journeyType,seconds,now,snap.evidenceDigest,snap.institutionType,scope.weekday,scope.hour).changes===1;
    }
  };
}

// Geographical context only: road geometry never establishes a stopping permission or a route.
export function nearbyRoadContext(roads, coordinates, radiusMeters = 2000, limit = 500) {
  if (!coordinates) return {type:'FeatureCollection',features:[],requiresCoordinates:true,truncated:false};
  const xScale=Math.cos(coordinates[1]*Math.PI/180)*111320;
  const project=c=>[(c[0]-coordinates[0])*xScale,(c[1]-coordinates[1])*111320];
  const closeToSegment=(a,b)=>{
    if (!validCoordinates(a) || !validCoordinates(b)) return false;
    const p=project(a),q=project(b),dx=q[0]-p[0],dy=q[1]-p[1];
    const length=dx*dx+dy*dy,t=length?Math.max(0,Math.min(1,-(p[0]*dx+p[1]*dy)/length)):0;
    return Math.hypot(p[0]+t*dx,p[1]+t*dy)<=radiusMeters;
  };
  const nearby=(roads?.features??[]).filter(f=>{
    const lines=f.geometry?.type==='LineString'?[f.geometry.coordinates]:f.geometry?.type==='MultiLineString'?f.geometry.coordinates:[];
    return lines.some(line=>line.slice(1).some((c,i)=>closeToSegment(line[i],c)));
  });
  return {type:'FeatureCollection',features:nearby.slice(0,limit),requiresCoordinates:false,truncated:nearby.length>limit};
}
