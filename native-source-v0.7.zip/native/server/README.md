# 하원콜 서버 0.7 · 서울 기관 / 보호자 연동

Express + WebSocket + SQLite로 동작하는 서버입니다. 외부 클라우드·문자·전화 서비스 없이 로컬 실행하며, 포함된 서울 도로·주차 참고 데이터를 제공합니다. 기관 목록, 보호자 등록, 차량 상태 전달을 같은 API로 연결합니다. 아래 기존 웹 안내는 학원 픽업 중심이며 v0.7의 학교·유치원·어린이집과 양방향 UI는 네이티브 앱에서 확인합니다.

## 실행

Node.js **22.13 이상**이 필요합니다. `node:sqlite` 내장 모듈을 사용해 별도 네이티브 SQLite 빌드가 필요하지 않습니다. 개발 지시서의 Node 20 / better-sqlite3 조합 대신 이 구성을 선택했습니다. 검증 환경은 macOS, **Node 26.7.0**입니다.

```sh
npm ci
npm run bootstrap
npm start
```

`bootstrap`을 호출하면 실재하지 않는 시연 학원 `HAWON01`, 학교 `SEOULSCH`, 유치원 `SEOULKID`, 어린이집 `SEOULDAY`를 생성합니다. 실행 결과에 무작위 관리자 비밀번호가 한 번 표시됩니다. 이미 존재하면 비밀번호를 바꾸지 않습니다. 비밀번호를 직접 정하려면 최초 생성 시 `ACADEMY_PASSWORD='12자-이상-고유한-비밀번호' npm run bootstrap`을 사용하세요. 학원 기본 계정은 `ACADEMY_CODE`, `ACADEMY_NAME`, `INSTITUTION_TYPE`도 설정할 수 있습니다. 원문 비밀번호는 DB에 저장하지 않습니다.

- 홈: <http://127.0.0.1:3000/>
- 학원 화면: <http://127.0.0.1:3000/academy/HAWON01>
- 보호자 등록: <http://127.0.0.1:3000/setup>
- **모든 차량 신호가 가상인 웹 시뮬레이터**: <http://127.0.0.1:3000/demo>

학원 화면에 로그인한 뒤 새 창에서 보호자 등록 → 토큰 보관 → 웹 시뮬레이터의 ‘전체 흐름’을 실행하세요. ‘학원에 하원 호출’이 보이면 학원 화면에서 ‘내려보냄’을 누르세요. 가상 차량 화면에도 확인 상태가 전달됩니다. 이 웹 시연은 Android 앱이나 Pleos 차량 신호의 실기 검증을 대신하지 않습니다.

Android Emulator가 접근할 때는 `HOST=0.0.0.0 npm start`로 실행하고 차량 앱에 `http://10.0.2.2:3000`을 입력하세요. 다른 기기에서는 맥의 같은 네트워크 주소를 사용합니다. 기본 바인딩은 `127.0.0.1`이며 이 로컬 서버를 인터넷에 공개하는 설정은 포함하지 않습니다. 실제 배포에는 HTTPS/WSS가 필요합니다.

## 설정과 데이터

환경 변수는 실행하는 셸에서 설정합니다. `.env.example`은 예시이며 `.env`를 자동으로 읽지 않습니다.

- `PORT`: 기본 3000
- `HOST`: 기본 127.0.0.1
- `DATABASE_PATH`: 기본 `./data/hawoncall.sqlite`
- `ACADEMY_CODE` / `ACADEMY_NAME` / `ACADEMY_PASSWORD`: 최초 계정 생성에만 사용

비밀번호는 무작위 salt + scrypt 해시, 차량 토큰과 학원 세션은 SHA-256 해시로 저장합니다. 차량 토큰은 연결 생성 시 한 번 발급하는 256비트 난수입니다. 학원 세션은 12시간 뒤 만료됩니다. 브라우저 인증 정보는 현재 탭의 sessionStorage만 사용합니다. 자동 공개 관리자 계정, 하드코딩 비밀번호, 위치 수집은 없습니다.

픽업과 이벤트 로그는 생성 후 90일이 지나면 시작 시·매시간 삭제합니다. 아이 호칭·일정·보호자 동의 시각 및 연결 정보는 연결 사용을 위해 유지됩니다. 이 로컬 버전의 연결 해제·개인정보 삭제는 운영자가 서버 중지 후 DB에서 해당 연결과 관련 픽업을 지워 처리해야 합니다. 학원 목록은 최근 90일 안의 최대 200건을 조회합니다.

## API 계약

모든 오류는 `{ "error": "...", "message": "한국어 설명" }` 형식이며 설정 불일치 등의 기계 판별 사유에는 선택적 `code`가 붙습니다. 차량 생성 설정 불일치의 409 코드는 `LINK_CONFIGURATION_CHANGED`입니다. 인증 헤더는 `Authorization: Bearer <token>`입니다. 입력의 알 수 없는 필드는 거절합니다. 특히 위치 좌표는 저장하거나 학원에 전달하지 않습니다.

- `POST /api/academy/session` `{code,password}` → `{token,expiresAt,academy:{id,code,name}}`
- `DELETE /api/academy/session` 학원 인증 → 204
- `POST /api/links` `{academyCode,childName,weekday:[1,2,3,4,5],pickupTime:"21:50",baseLeadSeconds:300,guardianConsent:true}` → `{link,carToken}`
- `GET /api/car/config` 차량 인증 → `{link}`
- `POST /api/trips` 차량 인증 `{linkId,clientTripId}` → `{trip}`. 동일 clientTripId는 같은 픽업 반환. 연결별 동시 진행 픽업은 1건.
- `GET /api/trips/:id` 차량 인증 → `{trip}`
- `POST /api/trips/:id/events` 차량 인증 `{eventId,type,at,etaMin?,confirmation?}` → `{trip}`
- `GET /api/academy/trips` 학원 인증 → `{trips}`
- `POST /api/trips/:id/released` 학원 인증, 빈 JSON 객체 → `{trip}`
- `GET /api/health` → 연결 상태·보관 정책

link 필드: `id, childName, academyName, academyCode, weekday, pickupTime, baseLeadSeconds, guardianConsent`. 요일은 월요일 1 ~ 일요일 7, 준비 시간은 60~1200초입니다. 학원 좌표·POI 연결은 차량 내부에서 설정합니다. 순정 내비 경로와 다음 목적지는 앱이 변경하지 않습니다.

trip 필드: `id, linkId, clientTripId, childName, academyName, status, etaMin, createdAt, updatedAt, calledAt, arrivedAt, boardedAt, cancelledAt, releasedAt, confirmation`. 초기 상태는 `PLANNED`, 이후 `EN_ROUTE`, `CALLED`, `ARRIVED`, `BOARDED`(PICKUP), `HANDED_OVER`(DROPOFF) 또는 `CANCELLED`입니다. `DONE`은 차량 내 상태이며 서버에서는 방향별 완료 상태로 종료합니다.

이벤트 종류는 `ETA | CALL | ARRIVED | BOARDED | HANDED_OVER | CANCEL`. `at`은 UTC ISO 문자열입니다. ETA는 0~1440의 정수 분만 허용합니다. eventId는 픽업별 유일한 1~100자 영숫자·대시·밑줄입니다. 같은 eventId와 같은 내용의 재시도는 현재 trip과 `idempotent:true`를 반환합니다. 같은 ID의 내용 변경은 409입니다. 이미 종료된 픽업에는 새 이벤트를 적용하지 않습니다. ARRIVED가 먼저 오면 호출 시각도 설정하고, 나중의 CALL은 ARRIVED를 이전 상태로 돌리지 않습니다. 탑승·인계는 ARRIVED에서만 허용합니다. 학원 내려보냄은 CALLED/ARRIVED에서 허용하며 재시도해도 최초 확인 시각을 유지합니다.

WebSocket은 `/ws/academy/:code`, `/ws/car/:tripId`에 연결한 직후 첫 메시지로 `{type:"AUTH",token:"..."}`을 보내야 합니다. URL에 토큰을 넣지 않습니다. 성공 시 즉시 초기 스냅샷을 받으며 변경 시 학원에는 `{type:"TRIPS",trips}`, 차량에는 `{type:"TRIP",trip}`이 옵니다. 인증 전 5초 timeout, 4KB 메시지 제한, 동일 origin 브라우저 검사, 느린 소비자 제한, ping/pong가 적용됩니다. 네이티브 클라이언트는 Origin을 생략할 수 있습니다. 웹은 연결 단절 시 재연결하고 10초 간격 REST polling을 병행합니다.

## 검증

```sh
npm test
```

`node:test` + supertest + ws로 REST 정상 흐름, 동의·입력 검증, 인증과 학원/차량 간 접근 격리, 중복 이벤트/픽업 재시도, 종료 상태 보호, 빠른 도착, 내려보냄, WebSocket 초기/갱신·인증 timeout, 위치/비밀 미전달, 90일 삭제, SQLite 재시작 지속성을 검사합니다. 웹 브라우저에서 실제 화면과 흐름을 별도로 확인해야 합니다.


## 0.3 인계 확인 계약

차량의 접근(APPROACHING)과 센서 후보(BOARDING_DETECTED)는 차량 내 상태입니다. 서버 ARRIVED는 기어 P와 최근 근접 위치를 함께 확인한 최초 도착 기록이며, 이후에도 현재 차량의 P 상태가 계속 유지된다고 보장하는 실시간 신호가 아닙니다. 기어 P는 합법·안전한 정차 장소의 증명이 아니므로 보호자가 안전한 주차 여부를 확인합니다.

BOARDED 이벤트는 `confirmation: "GUARDIAN"`가 필수이며, 서버는 이 필드를 차량 UI에서 명시 확인했다는 기록으로 저장합니다. 보호자 신원이나 아이 본인을 서버가 독립적으로 식별·인증했다는 의미는 아닙니다. 기존 BOARDED 데이터의 확인 필드는 null로 유지합니다. 웹 자동 시연은 센서 감지에서 멈추며 별도 보호자 확인을 눌러야 완료합니다.

## v0.7 서울 등하원 범위와 승하차 참고 지점

서비스 설정 범위는 `SEOUL`이다. 이것은 기존 기관의 실제 주소를 확인했다는 뜻이 아니다. 운영자가 등록한 기관 유형은 `SCHOOL`, `KINDERGARTEN`, `DAYCARE`, `ACADEMY`이며 기존 기관/연결은 `ACADEMY`, `PICKUP`으로 이전된다. 기존 `academyCode`, `academyName`, `pickupTime` 필드는 호환성을 유지한다. 링크 응답에는 `institutionType`, `institutionCode`, `institutionName`, `journeyType`, `serviceArea`, `isDemoInstitution`, `pickupSpot`이 추가된다. bootstrap이 만드는 기관은 실재 기관이 아닌 시연용이며 응답에 명시한다. 기관 코드와 입력 유형이 일치해야 한다.

보호자 등록은 `institutionType`(생략하면 코드에 등록된 유형), `journeyType`(`PICKUP` 또는 `DROPOFF`, 기본 `PICKUP`), `serviceArea`(기본 `SEOUL`)를 받는다. 서울 외 서비스 값은 거절한다. 차량의 `POST /api/trips`에는 위 세 값을 선택적으로 보내 저장된 설정과의 일치를 검사할 수 있다. trip의 `journeyType`은 생성 시 고정된다. 이후 링크 설정이 바뀌어도 해당 trip의 방향은 바뀌지 않는다. `BOARDED`는 하원 픽업, `HANDED_OVER`는 등원 인계에만 허용하며 둘 다 선행 `ARRIVED`와 `confirmation: "GUARDIAN"`이 필요하다. 두 완료 상태와 `CANCELLED`는 종료 상태다. 등원 완료에는 `handedOverAt`이 반환된다.

### 참고 지점 조회·선택

- `GET /api/guardian/pickup-spots`는 보호자 bearer로 서울 참고 목록을 조회한다. 선택적으로 `?lat=37.5&lon=127.0`을 함께 보낼 수 있다. `q`(80자 이하)는 전체 원자료의 지점 이름·주소를 검색하고 결과를 최대 200개로 제한한다. 응답 `total/truncated`는 검색 전체 건수·잘림 여부다. 좌표는 서울 서비스 경계 안에 있어야 하며 거리순 조회에만 사용하고 저장하지 않는다. 목록 조회는 선택 지점이나 내비게이션 경로를 바꾸지 않는다.
- 응답은 `{ serviceArea, spots, selectionAllowed, recommendedSpotId, recommendationBasis }`이다. spot에는 `id`, `name`, `latitude`, `longitude`, `state`, `eligible`, `reason`, `permissionExpiresAt`, `maxDwellSeconds`, `waitSampleCount`, `estimatedWaitSeconds`, `sourceId`, `sourceName`, `sourceUrl`, `address`가 있다. 좌표 조회 시 `distanceMeters`가 추가된다.
- `POST /api/guardian/pickup-spot`의 본문은 `{ "spotId": "..." }`만 받는다. 확인된 현재 허가가 유효하고 방향·기관 유형·승용차 범위와 일치하는 지점만 선택한다. 불명 ID는 404, 미확인·차단·만료·범위 불일치는 409다. 성공 응답은 `{ link }`이다.
- 보호자·차량 config의 `link.pickupSpot`은 현재도 자격이 유효할 때만 반환한다. 만료·차단된 선택은 `null`로 닫힌다. 클라이언트도 이미 수신한 `permissionExpiresAt`을 확인해야 한다. 이 값은 전체 허가 만료와 현재 일일 시간 창의 끝 중 빠른 시각이다.
- `GET /api/guardian/road-context?lat=&lon=`는 동일한 서울 좌표 검증 후 반경 2km, 최대 500개의 실제 도로 선형 참고자료를 반환한다. 응답의 `featureCollection`은 GeoJSON이며 `truncated`로 잘림을 표시한다. 좌표 생략 시 빈 목록과 `requiresCoordinates: true`다. 도로 선형은 주행 경로·정차 허가를 뜻하지 않는다.

- `GET /api/guardian/protection-facilities?q=`는 보호자 인증으로 어린이보호구역 지정 시설의 이름·주소·자치구를 검색한다. 최대 100개와 `total/truncated/source`를 반환한다. `protectionAreaGeometryAvailable: false`, `completeHazardMap: false`를 명시하며 주소 목록으로 도로 규제 경계·승하차 허가를 추론하지 않는다.

### 운영자 허가 자료와 학습 제한

`server/data/seoul-reference.geojson`은 string `id`, Point geometry, `properties.name/sourceId/sourceName/sourceUrl/address`를 가진 FeatureCollection이다. `seoul-boundary.geojson`은 출처를 명시한 서울 서비스 경계 Polygon 또는 MultiPolygon(Feature/FeatureCollection도 지원)이다. 경계가 없으면 자격은 열리지 않는다. 제공된 공식 도로·주차·보호구역 자료는 **문맥 참고자료**이며 해당 자료만으로 승하차 허가가 성립하지 않는다. reference 속성의 `VERIFIED` 표시는 승인으로 취급하지 않는다. 보호자는 허가나 상태를 자체 승인할 수 없다.

실제 운영 전에 별도의 운영자 관리 `spot-permissions.json`에 `{ "permissions": [...] }`를 구축해야 한다. 각 기록은 `id`, `spotId`, `state: "VERIFIED"`, `authorityName`, `permissionDocumentRef`, `operatorAuditorId`, `auditDocumentRef`, `auditedAt`, `roadRestrictionsReviewed: true`, `safeAccessReviewed: true`, `schoolZoneRestrictionsReviewed: true`, `signRulesReviewed: true`, `calendarDates: ["YYYY-MM-DD"]`, `allowedWeekdaysKST: [1,2,3,4,5]`(월=1, 일=7), `timeWindowsKST: [{"start":"08:00","end":"09:00"}]`, `maxDwellSeconds`(1~3600 정수), `validFrom`, `validUntil`, `serviceArea: "SEOUL"`, `journeyTypes`, `vehicleTypes: ["PASSENGER_CAR"]`, `institutionTypes`를 요구한다. `calendarDates`에는 공휴일·휴교일·임시 규제를 검토한 실제 감사 대상 날짜만 명시한다. 한국 시간 요일과 시간 창도 모두 일치해야 한다(`end: "24:00"` 허용, 자정 넘는 창은 날짜별로 나눔). `validFrom/validUntil`은 실제 허용 시간의 연속 구간이어야 한다. 시간대별 제한이 있으면 각 허용 구간으로 발급해야 하며 종일 허가로 넓혀 적지 않는다. 운영자 문서의 진위와 권한은 파일 반영 전에 별도 감사해야 한다. 공개 HTTP 승인 API는 없다. 배포 자료에는 검증된 실제 허가 지점을 가장한 테스트 fixture를 넣지 않는다. 허가 자료를 교체하면 서버를 재시작해야 한다.

대기시간 학습은 현재 허가가 있는 선택 지점을 trip 생성 때 고정한 뒤 실제 지점 도착과 완료 양쪽에 위치 관측 증거가 있을 때만 실행한다. `ARRIVED`, `BOARDED`, `HANDED_OVER`는 선택적 `arrivalSpotEvidence: {spotId, observedAt, distanceMeters, accuracyMeters?, source: "PLEOS_FUSED_LOCATION", parkedWaitSeconds?}`를 받는다. 점유 위치 좌표 자체는 전송·저장하지 않는다. 관측은 서버 수신 시 30초 이내(미래 시계 오차 최대 5초), 같은 고정 지점에서 30m 이내, 정확도 값이 있으면 20m 이내여야 한다. point ID·허가 증거·참고 좌표 형상을 모두 비교한다. 이는 인증된 차량 앱의 실제 위치 어댑터를 신뢰하는 경계이며 서버가 GPS를 암호학적으로 증명하는 것은 아니다.

일반 기관 목적지의 `ARRIVED`만으로는 지점 학습을 하지 않는다. 나중에 별도의 유효한 지점 관측 `ARRIVED`가 오면 그 서버 수신 시각부터 지점 체류 구간을 연다. 완료도 현재 위치 증거와 명시 보호자 확인이 모두 있어야 학습한다. 앱은 실제 위치가 선택 지점 근처이고 P 상태인 구간의 `parkedWaitSeconds` 정수를 완료 증거에 제공한다. 서버는 지점 도착~완료 수신 간격과 P 체류 시간이 모두 0~`maxDwellSeconds`(최대 3600초)인지, P 체류가 수신 간격보다 30초 이상 길지 않은지 확인한다. 원격 서버는 기어 연속성을 직접 관측하지 않으므로 실제 차량 어댑터의 P·위치 신선도 통합 검증이 필요하다. 선택 지점과 OEM 목적지는 서로 다를 수 있으며 지점 선택이 내비 경로를 바꾸지 않는다.

오프라인 대기열에서 관측이 만료되거나 현재 지점·허가와 맞지 않으면 구조가 유효한 도착·완료 이벤트는 수용하고 `arrivalEvidenceAccepted: false`로 학습만 배제한다. 좌표 등 금지된 키를 포함하거나 출처·자료형이 잘못된 증거는 거절한다. 이로써 만료된 부가 관측 때문에 안전한 여정 완료 대기열이 막히지 않는다. 허가가 변경·만료되면 학습하지 않는다. `trip_id` 유일 키로 반복 전송은 한 번만 반영한다. 취소·ETA·방문 횟수·임의 평점은 학습하지 않는다.

같은 지점·방향·기관 유형·동일 허가 증거·한국 시간 요일·시간대(1시간)의 완료 표본이 5건 이상일 때만 P 체류 평균을 표시한다. 조회 좌표를 함께 보낸 경우에만 그 좌표에서 1km 이내이고 같은 문맥의 표본이 5건 이상인 현재 유효한 지점들을 평균 P 체류시간이 짧은 순서, 이어 거리순으로 배치한다. 이 지점들에만 `recommendationRank`(1부터)와 `recommendationConfidence: "LIMITED_OBSERVATIONS"`를 붙이고 1위를 `recommendedSpotId`로 제시한다. 먼 지점·미확인·차단·만료 지점·5건 미만 지점은 학습 추천에 올리지 않는다. 좌표가 없으면 평균 관측값은 보여도 추천 순위·개인화 추천은 반환하지 않는다. 이는 관측된 체류시간의 비교이며 안전성·적법성 점수가 아니다. 추천 시에도 현재 허가를 다시 검사하고 지점 선택·경로 변경은 자동 실행하지 않는다. 표본은 trip과 함께 90일 뒤 삭제된다. 현재 보호자 UI는 조회 좌표를 기본 전송하지 않으므로 위치를 반영한 추천은 향후 기관 좌표 연결에서 사용할 API 기능이다. 자료 출처와 기준일은 `server/data/sources.json`을 확인한다. 배포 기본 자료에는 운영자가 현장·허가를 확인한 지점이 없으므로 선택 가능 지점·실제 학습 표본은 0건이다.
