package ai.hawoncall.guardian

import kotlinx.coroutines.runBlocking
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class GuardianDataTest {
    private val token="g".repeat(48)
    private val link="""{"id":"lk_1","childName":"하늘","academyName":"하늘학원","academyCode":"SKY01","weekday":[1,3,5],"pickupTime":"16:30"}"""
    private fun trip(id:String,created:String,status:String="EN_ROUTE",eta:String="null",confirmation:String="null")=
        """{"id":"$id","status":"$status","etaMin":$eta,"createdAt":"$created","updatedAt":"$created","calledAt":null,"arrivedAt":null,"boardedAt":null,"releasedAt":null,"confirmation":$confirmation}"""

    @Test fun productionRejectsEveryHttpHost() {
        listOf("localhost","127.0.0.1","10.0.2.2","example.com").forEach { host ->
            assertThrows(IllegalArgumentException::class.java) { GuardianServerPolicy.validate("http://$host:3000",false) }
        }
        assertTrue(GuardianServerPolicy.validate("https://pickup.example.com",false).isHttps)
    }
    @Test fun debugAllowsOnlyExplicitLocalHostsWithoutCredentialsOrPaths() {
        listOf("localhost","127.0.0.1","10.0.2.2").forEach { assertEquals(it,GuardianServerPolicy.validate("http://$it:3000",true).host) }
        listOf("http://192.168.0.2:3000","http://localhost.evil.test","http://localhost@evil.test", "https://user:pass@example.com",
            "https://example.com/api", "https://example.com/?token=secret", "https://example.com/#secret").forEach { raw ->
            assertThrows(IllegalArgumentException::class.java) { GuardianServerPolicy.validate(raw,true) }
        }
    }
    @Test fun latestTripUsesCreationTimeAndDoesNotInventZeroEta() {
        val old=trip("old","2026-10-24T00:00:00Z","ARRIVED","0")
        val fresh=trip("fresh","2026-10-25T00:00:00Z")
        val latest=GuardianJson.latest(JSONObject("""{"trips":[$fresh,$old]}"""))!!
        assertEquals("fresh",latest.id); assertNull(latest.etaMin)
        assertNull(GuardianJson.latest(JSONObject("""{"trips":[]}""")))
    }
    @Test fun persistedSnapshotRoundTripsWithoutLosingGuardianConfirmation() {
        val t=GuardianJson.trip(JSONObject(trip("tr_1","2026-10-25T00:00:00Z","BOARDED","0","\"GUARDIAN\"")))
        val session=GuardianSession("https://example.com/",token,GuardianJson.link(JSONObject(link)),t,1234L)
        assertEquals(session,GuardianJson.decode(GuardianJson.encode(session)))
    }
    @Test fun registrationUsesGuardianEndpointAndNeverLegacyCarToken()=runBlocking {
        val server=MockWebServer()
        try {
            server.enqueue(MockResponse().setResponseCode(201).setBody("""{"link":$link,"guardianToken":"$token","carToken":"must-ignore"}"""))
            server.start()
            val s=GuardianApi(true).register(server.url("/").toString(),GuardianRegistration("SKY01","하늘",listOf(1,3,5),"16:30"))
            val req=server.takeRequest()
            assertEquals("/api/guardian/links",req.path); assertEquals("POST",req.method)
            assertNull(req.getHeader("Authorization")); assertEquals(token,s.token)
            val body=JSONObject(req.body.readUtf8())
            assertEquals(9,body.length()); assertEquals(true,body.getBoolean("guardianConsent")); assertEquals(300,body.getInt("baseLeadSeconds"))
            assertEquals("ACADEMY",body.getString("institutionType")); assertEquals("PICKUP",body.getString("journeyType"))
            assertEquals("SEOUL",body.getString("serviceArea")); assertFalse(body.has("carToken"))
        } finally { server.shutdown() }
    }
    @Test fun refreshUsesBearerOnBothScopedEndpoints()=runBlocking {
        val server=MockWebServer()
        try {
            server.enqueue(MockResponse().setBody("""{"link":$link}"""))
            server.enqueue(MockResponse().setBody("""{"trips":[${trip("latest","2026-10-25T00:00:00Z","CALLED","4")}]}"""))
            server.start()
            val session=GuardianSession(server.url("/").toString(),token,GuardianJson.link(JSONObject(link)))
            val result=GuardianApi(true).refresh(session)
            assertEquals("/api/guardian/config",server.takeRequest().let { assertEquals("Bearer $token",it.getHeader("Authorization"));it.path })
            assertEquals("/api/guardian/trips",server.takeRequest().let { assertEquals("Bearer $token",it.getHeader("Authorization"));it.path })
            assertEquals(4,result.latestTrip?.etaMin); assertTrue(result.fetchedAt>0)
        } finally { server.shutdown() }
    }
    @Test fun redirectDoesNotForwardGuardianBearerToAnotherEndpoint()=runBlocking {
        val server=MockWebServer()
        try {
            server.start()
            server.enqueue(MockResponse().setResponseCode(302).addHeader("Location",server.url("/unexpected")))
            val session=GuardianSession(server.url("/").toString(),token,GuardianJson.link(JSONObject(link)))
            try { GuardianApi(true).pairing(session); fail("Redirect must fail closed") } catch(e:GuardianApiException) { assertEquals(302,e.code) }
            assertEquals(1,server.requestCount)
        } finally { server.shutdown() }
    }
    @Test fun pairingRejectsMalformedCode()=runBlocking {
        val server=MockWebServer()
        try {
            server.enqueue(MockResponse().setBody("""{"code":"bad-code","expiresAt":"2026-10-25T00:05:00Z"}"""))
            server.start()
            val session=GuardianSession(server.url("/").toString(),token,GuardianJson.link(JSONObject(link)))
            try { GuardianApi(true).pairing(session); fail("Malformed code accepted") } catch(_:IllegalArgumentException) { }
            val req=server.takeRequest()
            assertEquals("POST",req.method); assertEquals("/api/guardian/pairing",req.path);assertEquals("{}",req.body.readUtf8())
        } finally { server.shutdown() }
    }
    @Test fun legacyLinksDefaultToSeoulAcademyPickupAndNewLinksKeepDirection() {
        val legacy=GuardianJson.link(JSONObject(link))
        assertEquals(InstitutionType.ACADEMY,legacy.institutionType)
        assertEquals(JourneyType.PICKUP,legacy.journeyType); assertEquals("SEOUL",legacy.serviceArea)
        val school=GuardianJson.link(JSONObject(link).put("institutionType","SCHOOL").put("journeyType","DROPOFF").put("serviceArea","SEOUL"))
        assertEquals("등교",school.journeyLabel)
        assertEquals("하교",school.copy(journeyType=JourneyType.PICKUP).journeyLabel)
        assertEquals("등원",school.copy(institutionType=InstitutionType.DAYCARE).journeyLabel)
        val session=GuardianSession("https://example.com/",token,school)
        assertEquals(session,GuardianJson.decode(GuardianJson.encode(session)))
    }
    @Test fun handoverAndBoardingCompletionRequireMatchingDirectionAndGuardian() {
        val pickup=GuardianJson.link(JSONObject(link))
        val dropoff=pickup.copy(institutionType=InstitutionType.SCHOOL,journeyType=JourneyType.DROPOFF)
        val handed=GuardianJson.trip(JSONObject(trip("tr_2","2026-10-25T00:00:00Z","HANDED_OVER","null","\"GUARDIAN\""))
            .put("handedOverAt","2026-10-25T00:05:00Z").put("journeyType","DROPOFF"))
        assertEquals("보호자가 기관 인계를 확인했어요",statusTitle(handed,dropoff))
        assertEquals("인계 확인 기록을 확인하세요",statusTitle(handed,pickup))
        assertEquals("인계 확인 기록을 확인하세요",statusTitle(handed.copy(confirmation=null),dropoff))
        val boarded=handed.copy(status="BOARDED",boardedAt=handed.handedOverAt,journeyType=JourneyType.PICKUP)
        assertEquals("차량에서 탑승을 확인했어요",statusTitle(boarded,pickup))
        assertEquals("이동 확인 기록을 확인하세요",statusTitle(boarded,dropoff))
        assertTrue(statusDetail(handed,dropoff).contains("직접 확인"))
        val session=GuardianSession("https://example.com/",token,dropoff,handed)
        assertEquals(session,GuardianJson.decode(GuardianJson.encode(session)))
    }
    @Test fun spotSelectionRequiresBothVerifiedAndEligible() {
        fun spot(state:String,eligible:Boolean)=JSONObject("""{"id":"s1","name":"서울 참고 장소","state":"$state","eligible":$eligible,"reason":null,"permissionExpiresAt":null,"waitSampleCount":0,"estimatedWaitSeconds":null,"sourceId":"seoul"}""")
        assertFalse(GuardianJson.spot(spot("UNVERIFIED",true)).selectable)
        assertFalse(GuardianJson.spot(spot("BLOCKED",true)).selectable)
        assertFalse(GuardianJson.spot(spot("VERIFIED",false)).selectable)
        assertTrue(GuardianJson.spot(spot("VERIFIED",true)).selectable)
        val selected=GuardianJson.link(JSONObject(link).put("pickupSpot",spot("VERIFIED",true)))
        val session=GuardianSession("https://example.com/",token,selected)
        assertEquals(session,GuardianJson.decode(GuardianJson.encode(session)))
    }
    @Test fun catalogAndSelectionUseGuardianScopedEndpoints()=runBlocking {
        val server=MockWebServer()
        try {
            val spot="""{"id":"s1","name":"서울 참고 장소","state":"VERIFIED","eligible":true,"reason":null,"permissionExpiresAt":"2026-11-01T00:00:00Z","waitSampleCount":0,"estimatedWaitSeconds":null,"sourceId":"seoul"}"""
            server.enqueue(MockResponse().setBody("""{"serviceArea":"SEOUL","spots":[$spot],"selectionAllowed":true}"""))
            server.enqueue(MockResponse().setBody(JSONObject().put("link",JSONObject(link).put("pickupSpot",JSONObject(spot))).toString()))
            server.start()
            val api=GuardianApi(true)
            val session=GuardianSession(server.url("/").toString(),token,GuardianJson.link(JSONObject(link)))
            val catalog=api.pickupSpots(session)
            assertTrue(catalog.selectionAllowed); assertEquals(1,catalog.spots.size)
            val get=server.takeRequest()
            assertEquals("/api/guardian/pickup-spots",get.path); assertEquals("Bearer $token",get.getHeader("Authorization"))
            val selected=api.selectPickupSpot(session,"s1")
            assertEquals("s1",selected.link.pickupSpot?.id)
            val post=server.takeRequest()
            assertEquals("/api/guardian/pickup-spot",post.path); assertEquals("POST",post.method)
            assertEquals("Bearer $token",post.getHeader("Authorization")); assertEquals("s1",JSONObject(post.body.readUtf8()).getString("spotId"))
        } finally { server.shutdown() }
    }

    @Test fun roadContextParsesActualLineAndMultiLineGeometry() {
        val roads=GuardianJson.roads(JSONObject("""{"serviceArea":"SEOUL","requiresCoordinates":false,"radiusMeters":2000,"truncated":true,"source":{"name":"서울 도로 참고자료","year":2024,"url":"https://example.com/roads"},"featureCollection":{"features":[{"geometry":{"type":"LineString","coordinates":[[126.97,37.56],[126.98,37.57]]}},{"geometry":{"type":"MultiLineString","coordinates":[[[126.96,37.55],[126.97,37.56]],[[126.99,37.58],[127.0,37.59]]]}}]}}"""))
        assertEquals(3,roads.lines.size); assertEquals(2000,roads.radiusMeters); assertTrue(roads.truncated)
        assertEquals("2024",roads.sourceYear); assertEquals(126.97,roads.lines.first().first().longitude,0.000001)
        assertThrows(IllegalArgumentException::class.java) { GuardianJson.roads(JSONObject("""{"serviceArea":"SEOUL","requiresCoordinates":true}""")) }
    }
    @Test fun roadQueryUsesOnlyTappedCatalogCoordinatesAndGuardianBearer()=runBlocking {
        val server=MockWebServer()
        try {
            server.enqueue(MockResponse().setBody("""{"serviceArea":"SEOUL","requiresCoordinates":false,"radiusMeters":2000,"featureCollection":{"features":[]},"source":null}"""))
            server.start()
            val session=GuardianSession(server.url("/").toString(),token,GuardianJson.link(JSONObject(link)))
            val spot=GuardianPickupSpot("s1","서울 참고 장소","UNVERIFIED",false,null,null,0,null,null,latitude=37.56,longitude=126.97)
            assertTrue(GuardianApi(true).roadContext(session,spot).lines.isEmpty())
            val request=server.takeRequest()
            assertEquals("/api/guardian/road-context",request.requestUrl?.encodedPath)
            assertEquals("37.56",request.requestUrl?.queryParameter("lat")); assertEquals("126.97",request.requestUrl?.queryParameter("lon"))
            assertEquals("Bearer $token",request.getHeader("Authorization"))
        } finally { server.shutdown() }
    }

    @Test fun catalogSearchSendsQueryBeforeServerLimitAndKeepsTotal()=runBlocking {
        val server=MockWebServer()
        try {
            server.enqueue(MockResponse().setBody("""{"serviceArea":"SEOUL","spots":[],"selectionAllowed":false,"total":2180,"truncated":true}"""))
            server.start()
            val session=GuardianSession(server.url("/").toString(),token,GuardianJson.link(JSONObject(link)))
            val result=GuardianApi(true).pickupSpots(session,"종로")
            assertEquals(2180,result.total); assertTrue(result.truncated)
            val request=server.takeRequest()
            assertEquals("종로",request.requestUrl?.queryParameter("q"))
            assertEquals("Bearer $token",request.getHeader("Authorization"))
        } finally { server.shutdown() }
    }

    @Test fun snapshotWritesIgnoreFetchClockButRetryUnstoredChanges() {
        val cached=GuardianSession("https://example.com/",token,GuardianJson.link(JSONObject(link)),fetchedAt=1000L)
        val refreshed=cached.copy(fetchedAt=4000L)
        assertFalse(requiresSnapshotWrite(cached,refreshed))
        assertTrue(requiresSnapshotWrite(null,refreshed))
        val trip=GuardianJson.trip(JSONObject(trip("updated","2026-10-25T00:00:00Z","CALLED","3")))
        val changed=refreshed.copy(latestTrip=trip)
        assertTrue(requiresSnapshotWrite(cached,changed))
        // A failed save retains the prior successful cache, so the next poll retries it.
        assertTrue(requiresSnapshotWrite(cached,changed.copy(fetchedAt=7000L)))
        assertFalse(requiresSnapshotWrite(changed,changed.copy(fetchedAt=10000L)))
        assertTrue(requiresSnapshotWrite(changed,changed.copy(link=changed.link.copy(pickupTime="17:00"))))
        assertTrue(requiresSnapshotWrite(changed,changed.copy(token="h".repeat(48))))
    }

}
