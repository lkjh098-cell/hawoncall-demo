package ai.hawoncall.guardian

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Test-host credential owner. Private, AES-GCM encrypted; the host must exclude all backup/transfer. */
class KeystoreGuardianSessionStore(context: Context) : GuardianSessionStore {
    private val prefs=context.applicationContext.getSharedPreferences("hawoncall_guardian_private",Context.MODE_PRIVATE)
    private val alias="hawoncall_guardian_session_v1"
    @Synchronized private fun key(): SecretKey {
        val store=KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias,null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    @Synchronized override fun load(): GuardianSession? {
        val encrypted=prefs.getString("session",null) ?: return null
        val iv=prefs.getString("iv",null) ?: throw IllegalStateException("저장된 인증 정보를 읽을 수 없습니다. 다시 연결하세요.")
        return Cipher.getInstance("AES/GCM/NoPadding").run {
            init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)))
            GuardianJson.decode(String(doFinal(Base64.decode(encrypted,Base64.NO_WRAP)),Charsets.UTF_8))
        }
    }
    @Synchronized override fun save(session: GuardianSession) {
        val cipher=Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE,key()) }
        val encrypted=cipher.doFinal(GuardianJson.encode(session).toByteArray(Charsets.UTF_8))
        check(prefs.edit().putString("session",Base64.encodeToString(encrypted,Base64.NO_WRAP))
            .putString("iv",Base64.encodeToString(cipher.iv,Base64.NO_WRAP)).commit()) { "인증 정보를 저장하지 못했습니다." }
    }
    @Synchronized override fun clear() {
        check(prefs.edit().clear().commit()) { "연결 정보를 삭제하지 못했습니다." }
    }
}
