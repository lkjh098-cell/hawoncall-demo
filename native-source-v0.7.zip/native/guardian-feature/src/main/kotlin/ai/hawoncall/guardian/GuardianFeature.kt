package ai.hawoncall.guardian

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val Navy=Color(0xFF11263F)
private val Ink=Color(0xFF152D47)
private val Muted=Color(0xFF52687D)
private val Cyan=Color(0xFF76E3EC)
private val Paper=Color(0xFFF4F7FA)
private val Line=Color(0xFFE1E8EF)
private val Error=Color(0xFF9B3131)
private val DayLabels=listOf("월","화","수","목","금","토","일")

/** Native embeddable feature. Host owns session storage, foreground lifecycle and transport policy. */
@Composable
fun GuardianFeature(
    sessionStore: GuardianSessionStore,
    allowLocalDevelopment: Boolean = false,
    initialServerUrl: String = "",
    modifier: Modifier = Modifier
) {
    val factory=remember(sessionStore,allowLocalDevelopment) { object: ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T: ViewModel> create(modelClass: Class<T>): T = GuardianViewModel(sessionStore,allowLocalDevelopment) as T
    } }
    val vm: GuardianViewModel=viewModel(key="hawoncall-guardian-feature",factory=factory)
    val state by vm.state.collectAsStateWithLifecycle()
    val owner=LocalLifecycleOwner.current
    val scrollState=rememberScrollState()
    LaunchedEffect(state.session?.link?.id) {
        scrollState.scrollTo(0)
        if(state.session!=null) vm.loadPickupSpots()
    }
    DisposableEffect(owner,vm) {
        val observer=LifecycleEventObserver { _,_ -> vm.setForeground(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) }
        owner.lifecycle.addObserver(observer)
        vm.setForeground(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))
        onDispose { owner.lifecycle.removeObserver(observer); vm.setForeground(false) }
    }
    MaterialTheme(colorScheme=lightColorScheme(primary=Navy,onPrimary=Color.White,secondary=Color(0xFF00747E),
        secondaryContainer=Color(0xFFE0F2F3),onSecondaryContainer=Navy,background=Paper,surface=Color.White,onSurface=Ink,onSurfaceVariant=Muted,outline=Color(0xFF8293A4),error=Error)) {
        var confirmReset by rememberSaveable { mutableStateOf(false) }
        Box(modifier.fillMaxSize().background(Paper).statusBarsPadding().navigationBarsPadding().imePadding()) {
            Column(Modifier.align(Alignment.TopCenter).widthIn(max=600.dp).fillMaxWidth()
                .verticalScroll(scrollState).padding(horizontal=24.dp).padding(top=22.dp,bottom=32.dp),
                verticalArrangement=Arrangement.spacedBy(22.dp)) {
                BrandHeader()
                if(state.restoring) {
                    SurfaceCard {
                        CircularProgressIndicator(Modifier.size(26.dp),strokeWidth=2.dp)
                        Spacer(Modifier.height(14.dp)); Text("보호자 연결을 불러오고 있어요",color=Muted)
                    }
                } else if(state.session==null) {
                    SetupForm(initialServerUrl,allowLocalDevelopment,state.busy,state.error,vm::register)
                    if(state.error?.contains("초기화")==true) TextButton(onClick={confirmReset=true}) { Text("기기 연결 정보 초기화") }
                } else Dashboard(state,vm::createPairing,vm::retry,vm::loadPickupSpots,vm::selectPickupSpot,vm::showRoadContext) { confirmReset=true }
                Text("독립 통합 테스트 모듈 · 공식 앱 연동 미적용",fontSize=11.sp,color=Muted,
                    modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
            }
        }
        if(confirmReset) AlertDialog(onDismissRequest={confirmReset=false},title={Text("이 기기 연결을 해제할까요?")},
            text={Text("이 기기의 보호자 인증과 표시 기록을 지웁니다. 서버의 연결과 차량 권한은 유지됩니다. 다시 이용하려면 새로 연결해야 합니다.")},
            confirmButton={TextButton(onClick={confirmReset=false;vm.reset()}) { Text("기기 연결 해제",color=Error) }},
            dismissButton={TextButton(onClick={confirmReset=false}) { Text("돌아가기") }})
    }
}

@Composable private fun BrandHeader() {
    Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()) {
        Box(Modifier.size(46.dp).background(Navy,RoundedCornerShape(15.dp)),contentAlignment=Alignment.Center) {
            Text("콜",color=Cyan,fontSize=23.sp,fontWeight=FontWeight.Black)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("하원콜",fontSize=24.sp,fontWeight=FontWeight.Bold,color=Navy,letterSpacing=(-0.8).sp)
            Text("보호자 · 서울",fontSize=11.sp,color=Muted,letterSpacing=0.5.sp)
        }
        Spacer(Modifier.weight(1f))
        Box(Modifier.background(Color(0xFFE0F2F3),RoundedCornerShape(30.dp)).padding(horizontal=10.dp,vertical=6.dp)) {
            Text("서울",fontSize=9.sp,color=Color(0xFF006773),fontWeight=FontWeight.Bold,letterSpacing=1.sp)
        }
    }
}

@Composable private fun SurfaceCard(content: @Composable ColumnScope.()->Unit) {
    Surface(shape=RoundedCornerShape(24.dp),color=Color.White,modifier=Modifier.fillMaxWidth(),tonalElevation=0.dp) {
        Column(Modifier.padding(22.dp),content=content)
    }
}

@Composable private fun SetupForm(initialUrl: String,allowLocal: Boolean,busy: Boolean,error: String?,
    submit:(String,GuardianRegistration,Boolean)->Unit) {
    var server by rememberSaveable { mutableStateOf(initialUrl) }
    var code by rememberSaveable { mutableStateOf("") }
    var child by rememberSaveable { mutableStateOf("") }
    var pickup by rememberSaveable { mutableStateOf("16:30") }
    var days by rememberSaveable { mutableStateOf("12345") }
    var consent by remember { mutableStateOf(false) }
    var institution by rememberSaveable { mutableStateOf(InstitutionType.ACADEMY.name) }
    var journey by rememberSaveable { mutableStateOf(JourneyType.PICKUP.name) }
    val institutionType=InstitutionType.valueOf(institution)
    val journeyType=JourneyType.valueOf(journey)
    val direction=journeyLabel(institutionType,journeyType)
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("아이의 하루를 잇는\n등하원 소식",fontSize=32.sp,lineHeight=41.sp,fontWeight=FontWeight.Bold,color=Navy,letterSpacing=(-1).sp,
            modifier=Modifier.semantics { heading() })
        Text("서울의 학교·유치원·어린이집·학원 이동을 함께 확인하세요.",fontSize=14.sp,lineHeight=22.sp,color=Muted)
    }
    SurfaceCard {
        Text("01  보호자 연결",fontWeight=FontWeight.Bold,fontSize=17.sp,color=Navy)
        Text("서울에서 이용할 수 있어요",fontSize=12.sp,color=Muted,modifier=Modifier.padding(top=8.dp,bottom=16.dp))
        Text("이용 기관",fontSize=13.sp,fontWeight=FontWeight.SemiBold)
        InstitutionType.entries.chunked(2).forEach { row ->
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { row.forEach { type ->
                FilterChip(selected=institutionType==type,onClick={institution=type.name},enabled=!busy,
                    label={Text(type.label)},modifier=Modifier.heightIn(min=48.dp))
            } }
        }
        Text("이동 방향",fontSize=13.sp,fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(top=10.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            JourneyType.entries.forEach { type -> FilterChip(selected=journeyType==type,onClick={journey=type.name},enabled=!busy,
                label={Text(journeyLabel(institutionType,type))},modifier=Modifier.heightIn(min=48.dp)) }
        }
        Text("기관과 방향별로 연결됩니다. 다른 이동은 별도 연결이 필요해요.",fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=4.dp,bottom=14.dp))
        OutlinedTextField(server,{server=it},label={Text("연결 서버 주소")},placeholder={Text("https://pickup.example.com")},
            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Uri),singleLine=true,enabled=!busy,modifier=Modifier.fillMaxWidth())
        Text(if(allowLocal) "테스트: 로컬 주소만 HTTP 허용 · 운영은 HTTPS" else "운영 서버의 HTTPS 주소를 입력하세요.",
            fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=6.dp,bottom=12.dp))
        OutlinedTextField(code,{code=it.uppercase().take(24)},label={Text("기관 연결 코드")},placeholder={Text("기관에서 받은 코드")},
            keyboardOptions=KeyboardOptions(capitalization=KeyboardCapitalization.Characters),singleLine=true,enabled=!busy,modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(child,{child=it.take(30)},label={Text("아이 호칭")},placeholder={Text("예: 하늘")},
            singleLine=true,enabled=!busy,modifier=Modifier.fillMaxWidth())
        Text("기관과 차량 화면에 표시할 호칭을 사용하세요.",fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=6.dp,bottom=16.dp))
        Text("이용 요일",fontSize=13.sp,fontWeight=FontWeight.SemiBold,color=Ink)
        Spacer(Modifier.height(8.dp))
        // Two rows keep all 48dp touch targets usable on narrow phones and with larger system text.
        listOf((1..4).toList(),(5..7).toList()).forEach { row ->
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                row.forEach { day ->
                    val selected=days.contains(day.toString())
                    FilterChip(selected=selected,onClick={days=if(selected) days.replace(day.toString(),"") else (days+day).toCharArray().sorted().joinToString("")},
                        enabled=!busy,label={Text(DayLabels[day-1])},modifier=Modifier.heightIn(min=48.dp).semantics {
                            contentDescription="${DayLabels[day-1]}요일"
                        })
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(pickup,{pickup=it.take(5)},label={Text("예정 $direction 시각")},supportingText={Text("24시간 형식 · 예: 16:30")},
            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Ascii),singleLine=true,enabled=!busy,modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth().background(Paper,RoundedCornerShape(14.dp))
            .toggleable(consent,enabled=!busy,role=Role.Checkbox,onValueChange={consent=it}).padding(10.dp),verticalAlignment=Alignment.Top) {
            Checkbox(checked=consent,onCheckedChange=null,enabled=!busy)
            Column(Modifier.padding(start=8.dp,top=8.dp)) {
                Text("법정대리인으로서 연결에 동의합니다",fontSize=13.sp,fontWeight=FontWeight.SemiBold)
                Text("아이 호칭·기관·이동 방향·일정·상태를 연결 서버와 공유합니다. 휴대폰의 현재 위치를 수집하지 않습니다.",
                    fontSize=12.sp,lineHeight=19.sp,color=Muted,modifier=Modifier.padding(top=4.dp,bottom=8.dp))
            }
        }
        error?.let { ErrorMessage(it) }
        Spacer(Modifier.height(20.dp))
        Button(onClick={submit(server,GuardianRegistration(code.trim(),child.trim(),days.map { it.digitToInt() },pickup.trim(),institutionType,journeyType),consent)},
            enabled=!busy && consent,shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth().heightIn(min=54.dp)) {
            if(busy) { CircularProgressIndicator(Modifier.size(20.dp),strokeWidth=2.dp,color=Color.White); Spacer(Modifier.width(10.dp)) }
            Text(if(busy) "연결하고 있어요" else "기관과 연결하기",fontWeight=FontWeight.Bold,fontSize=15.sp)
        }
    }
}

@Composable private fun Dashboard(state: GuardianUiState,onPair:()->Unit,onRetry:()->Unit,onLoadSpots:(String)->Unit,onSelectSpot:(String)->Unit,onRoad:(GuardianPickupSpot)->Unit,onReset:()->Unit) {
    val s=state.session ?: return
    val trip=s.latestTrip
    val dropoff=s.link.journeyType==JourneyType.DROPOFF
    val direction=s.link.journeyLabel
    val institution=s.link.institutionType.label
    val stale=state.refreshFailed || s.fetchedAt==0L || state.now-s.fetchedAt>10000L || state.needsReconnect
    Column(verticalArrangement=Arrangement.spacedBy(6.dp)) {
        Text("${s.link.childName}의 $direction",fontSize=30.sp,fontWeight=FontWeight.Bold,color=Navy,letterSpacing=(-0.8).sp,
            modifier=Modifier.semantics { heading() })
        Text("서울 · $institution · ${s.link.academyName}  ·  ${s.link.pickupTime}",fontSize=14.sp,color=Muted)
    }
    Surface(shape=RoundedCornerShape(26.dp),color=Navy,modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(if(stale) Color(0xFFFFCC83) else Cyan,CircleShape))
                Text(if(stale) "  연결 확인 필요" else "  $direction 상태 연결됨",fontSize=11.sp,color=if(stale) Color(0xFFFFCC83) else Cyan)
                Spacer(Modifier.weight(1f))
                if(state.refreshing) CircularProgressIndicator(Modifier.size(14.dp),strokeWidth=1.5.dp,color=Cyan)
            }
            Text(statusTitle(trip,s.link),fontSize=26.sp,lineHeight=34.sp,color=Color.White,fontWeight=FontWeight.Bold,
                modifier=Modifier.semantics { liveRegion=LiveRegionMode.Polite })
            if(trip!=null && trip.status in listOf("EN_ROUTE","CALLED") && trip.etaMin!=null) {
                Row(verticalAlignment=Alignment.Bottom) {
                    Text("${trip.etaMin}",fontSize=53.sp,fontWeight=FontWeight.Bold,color=Cyan,letterSpacing=(-2).sp)
                    Text(" 분 후 도착 예상",fontSize=14.sp,color=Color.White,modifier=Modifier.padding(bottom=10.dp))
                }
            }
            Text(statusDetail(trip,s.link),fontSize=13.sp,lineHeight=21.sp,color=Color(0xFFC8D7E5))
            HorizontalDivider(color=Color(0xFF34475D))
            Text(if(s.fetchedAt==0L) "아직 서버 상태를 확인하지 못했습니다" else "마지막 확인 ${time(s.fetchedAt)}${if(stale) " · 이전 기록" else " · 3초마다 확인"}",
                fontSize=11.sp,color=Color(0xFFC8D7E5))
        }
    }
    state.error?.let { error ->
        SurfaceCard {
            ErrorMessage(error)
            TextButton(onClick=onRetry,modifier=Modifier.align(Alignment.End)) { Text("연결 다시 확인") }
        }
    }
    state.cacheWarning?.let { warning ->
        SurfaceCard { Text(warning,fontSize=12.sp,lineHeight=20.sp,color=Muted,modifier=Modifier.semantics { liveRegion=LiveRegionMode.Polite }) }
    }
    if(trip!=null) SurfaceCard {
        Text("최근 $direction 기록",fontSize=16.sp,fontWeight=FontWeight.Bold,color=Navy)
        Text("${date(trip.createdAt)} 시작",fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=4.dp,bottom=20.dp))
        TimelineRow("01",if(dropoff) "기관에 도착 안내" else "$institution 호출",trip.calledAt,"아직 안내 전이에요")
        TimelineRow("02","차량 도착",trip.arrivedAt,"주차 도착을 기다려요")
        TimelineRow("03",if(dropoff) "보호자 인계 확인" else "보호자 탑승 확인",
            (if(dropoff) trip.handedOverAt else trip.boardedAt).takeIf { trip.confirmation=="GUARDIAN" && trip.journeyType==s.link.journeyType },
            if(dropoff) "기관에 아이를 인계한 뒤 차량에서 확인해 주세요" else "차량 화면에서 아이를 확인해 주세요",last=true)
        trip.releasedAt?.takeIf { !dropoff }?.let { Text("$institution 내려보내기 처리 ${isoTime(it)}",fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=12.dp)) }
    }
    PickupSpotsPanel(state,onLoadSpots,onSelectSpot,onRoad)
    SurfaceCard {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text("차량과 연결",fontSize=17.sp,fontWeight=FontWeight.Bold,color=Navy)
            Spacer(Modifier.weight(1f))
            Text("일회용 코드",fontSize=10.sp,color=Muted)
        }
        Spacer(Modifier.height(8.dp))
        Text("차량 앱의 ‘보호자 코드로 연결’에 입력하세요. 코드는 5분 동안 한 번만 사용할 수 있습니다.",fontSize=13.sp,lineHeight=21.sp,color=Muted)
        val pair=state.pairing
        if(pair!=null) {
            val remaining=((pair.expiresAt-state.now)/1000).coerceAtLeast(0)
            Spacer(Modifier.height(18.dp))
            Box(Modifier.fillMaxWidth().background(Paper,RoundedCornerShape(16.dp)).padding(vertical=20.dp),contentAlignment=Alignment.Center) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Text(if(remaining>0) pair.code.chunked(4).joinToString("  ") else "코드 만료",fontSize=28.sp,fontWeight=FontWeight.Bold,
                        color=if(remaining>0) Navy else Muted,letterSpacing=2.sp,modifier=Modifier.semantics {
                            contentDescription=if(remaining>0) "차량 연결 코드 ${pair.code.toCharArray().joinToString(" ")}" else "차량 연결 코드 만료"
                        })
                    Text(if(remaining>0) "${remaining/60}:${(remaining%60).toString().padStart(2,'0')} 남음 · 차량에서 한 번만 사용" else "새 코드를 발급해 주세요",fontSize=10.sp,color=Muted,
                        modifier=Modifier.padding(top=8.dp))
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick=onPair,enabled=!state.busy && !state.needsReconnect,shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth().heightIn(min=50.dp)) {
            if(state.busy) { CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp); Spacer(Modifier.width(8.dp)) }
            Text(if(state.busy) "코드 발급 중" else if(pair==null) "차량 연결 코드 발급" else "새 코드 발급",fontWeight=FontWeight.SemiBold)
        }
    }
    SurfaceCard {
        Text(if(dropoff) "인계 확인은 차량에서" else "탑승 확인은 차량에서",fontSize=15.sp,fontWeight=FontWeight.Bold,color=Navy)
        Text(if(dropoff) "보호자가 기관에 아이를 직접 인계한 뒤 차량에서 확인합니다. 차량 도착이나 센서만으로 입실을 확인하지 않아요." else "실제 아이의 탑승을 확인한 보호자가 차량 화면에서 확인합니다. 휴대폰에서는 이동 소식을 확인할 수 있어요.",fontSize=13.sp,lineHeight=21.sp,color=Muted,
            modifier=Modifier.padding(top=8.dp))
        HorizontalDivider(Modifier.padding(vertical=18.dp),color=Line)
        Text("$direction 일정  ${s.link.weekday.sorted().joinToString("·") { DayLabels.getOrElse(it-1) { "?" } }}  ${s.link.pickupTime}",fontSize=12.sp,color=Muted)
        TextButton(onClick=onReset,modifier=Modifier.align(Alignment.End)) { Text("이 기기 연결 해제",fontSize=12.sp,color=Muted) }
    }
}

@Composable private fun PickupSpotsPanel(state: GuardianUiState,onLoad:(String)->Unit,onSelect:(String)->Unit,onRoad:(GuardianPickupSpot)->Unit) {
    val selected=state.session?.link?.pickupSpot
    val uriHandler=LocalUriHandler.current
    var search by rememberSaveable { mutableStateOf("") }
    SurfaceCard {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text("서울 승하차 장소",fontSize=17.sp,fontWeight=FontWeight.Bold,color=Navy)
            Spacer(Modifier.weight(1f))
            Text("서울",fontSize=11.sp,color=Muted)
        }
        Text("공개자료의 장소를 먼저 확인하세요. 현장 이용 조건과 운영 승인이 확인된 장소만 선택할 수 있어요.",
            fontSize=12.sp,lineHeight=20.sp,color=Muted,modifier=Modifier.padding(top=8.dp))
        Text("휴대폰의 현재 위치를 사용하지 않고 서울 목록을 보여드려요.",fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=6.dp))
        selected?.let {
            Surface(color=Color(0xFFE0F2F3),shape=RoundedCornerShape(14.dp),modifier=Modifier.padding(top=14.dp).fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text("선택한 장소",fontSize=11.sp,color=Muted)
                    Text(it.name,fontWeight=FontWeight.Bold,color=Navy,modifier=Modifier.padding(top=4.dp))
                    Text(if(it.selectable) "이용 조건 확인됨 · 출발 전 현장을 다시 확인하세요" else "현장·운영 확인 필요 · 다시 확인해 주세요",fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=4.dp))
                }
            }
        }
        val catalog=state.spots
        if(state.spotsLoading) {
            Row(Modifier.padding(top=18.dp),verticalAlignment=Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp)
                Text("  장소를 확인하고 있어요",fontSize=12.sp,color=Muted)
            }
        } else if(catalog!=null) {
            OutlinedTextField(search,{search=it.take(80)},label={Text("장소 이름·주소로 찾기")},singleLine=true,
                modifier=Modifier.fillMaxWidth().padding(top=14.dp))
            OutlinedButton(onClick={onLoad(search)},enabled=!state.spotsLoading && !state.selectingSpot && !state.needsReconnect,
                modifier=Modifier.fillMaxWidth().padding(top=8.dp).heightIn(min=48.dp)) { Text("서울 전체에서 검색",fontSize=12.sp) }
            val filtered=catalog.spots
            Text("${if(state.spotQuery.isBlank()) "서울 전체" else "‘${state.spotQuery}’ 검색"} ${catalog.total}곳 · 최대 20곳 표시",fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=10.dp,bottom=4.dp))
            if(filtered.isEmpty()) Text("검색 결과가 없습니다. 다른 이름이나 주소로 찾아보세요.",fontSize=12.sp,color=Muted,modifier=Modifier.padding(top=12.dp))
            if(catalog.spots.isEmpty()) Text("표시할 장소가 없습니다. 기관에 승하차 장소를 확인해 주세요.",fontSize=12.sp,color=Muted,modifier=Modifier.padding(top=12.dp))
            filtered.take(20).forEach { spot ->
                HorizontalDivider(Modifier.padding(vertical=14.dp),color=Line)
                Text(spot.name,fontSize=14.sp,fontWeight=FontWeight.SemiBold,color=Ink)
                spot.address?.takeIf { it.isNotBlank() }?.let { Text(it,fontSize=11.sp,lineHeight=18.sp,color=Muted,modifier=Modifier.padding(top=4.dp)) }
                Text(when { spot.selectable -> "이용 조건 확인됨"; spot.state=="BLOCKED" -> "이용 제한 · 선택할 수 없어요"; else -> "현장·운영 확인 필요" },
                    fontSize=12.sp,fontWeight=FontWeight.SemiBold,color=if(spot.selectable) Color(0xFF00717B) else Muted,modifier=Modifier.padding(top=8.dp))
                spot.reason?.takeIf { it.isNotBlank() }?.let { Text(spotReason(it),fontSize=11.sp,lineHeight=18.sp,color=Muted,modifier=Modifier.padding(top=4.dp)) }
                if(spot.waitSampleCount>0) Text(if(spot.estimatedWaitSeconds!=null) "최근 대기 참고 ${spot.estimatedWaitSeconds/60}분 ${spot.estimatedWaitSeconds%60}초 · ${spot.waitSampleCount}건 기준" else "대기 기록 ${spot.waitSampleCount}건 · 예상 대기시간 확인 중",fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=6.dp))
                if(spot.waitSampleCount==0) Text("대기 기록이 아직 충분하지 않아요",fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=6.dp))
                spot.sourceName?.let { Text("자료: $it",fontSize=10.sp,color=Muted,modifier=Modifier.padding(top=6.dp)) }
                spot.sourceUrl?.takeIf { it.startsWith("https://") }?.let { url ->
                    TextButton(onClick={runCatching { uriHandler.openUri(url) }},contentPadding=PaddingValues(0.dp)) { Text("공개자료 확인",fontSize=11.sp) }
                }
                if(spot.selectable) spot.permissionExpiresAt?.let { Text("확인 유효 시각 ${date(it)}",fontSize=10.sp,color=Muted,modifier=Modifier.padding(top=4.dp)) }
                if(spot.latitude!=null && spot.longitude!=null) TextButton(onClick={onRoad(spot)},enabled=!state.needsReconnect) { Text("주변 도로 보기",fontSize=12.sp) }
                if(state.roadSpot?.id==spot.id) RoadContextPanel(state,onRoad)
                OutlinedButton(onClick={onSelect(spot.id)},enabled=spot.selectable && catalog.selectionAllowed && !state.selectingSpot && !state.needsReconnect && selected?.id!=spot.id,
                    modifier=Modifier.fillMaxWidth().padding(top=8.dp).heightIn(min=48.dp),shape=RoundedCornerShape(14.dp)) {
                    Text(when { selected?.id==spot.id -> "선택한 장소"; !spot.selectable -> "확인 후 선택 가능"; state.selectingSpot -> "선택 중"; else -> "이 장소 선택" },fontSize=12.sp)
                }
            }
        }
        state.spotError?.let { ErrorMessage(it) }
        TextButton(onClick={onLoad(state.spotQuery)},enabled=!state.spotsLoading && !state.selectingSpot && !state.needsReconnect,modifier=Modifier.align(Alignment.End).padding(top=8.dp)) {
            Text("장소 다시 확인",fontSize=12.sp)
        }
    }
}

private fun spotReason(reason: String): String = when(reason) {
    "NO_OPERATOR_PERMISSION_EVIDENCE" -> "현장 이용 조건과 운영 확인 자료가 아직 등록되지 않았어요."
    "PERMISSION_NOT_CURRENT_OR_SCOPE_MISMATCH" -> "현재 이동 조건에 맞는 유효한 운영 확인이 필요해요."
    "OUTSIDE_SEOUL_OR_BOUNDARY_UNAVAILABLE" -> "서울 서비스 범위와 장소 위치를 다시 확인해야 해요."
    "OPERATOR_BLOCKED" -> "운영자가 이용을 제한한 장소예요."
    else -> "현장 이용 조건을 기관과 운영자에게 확인해 주세요."
}
@Composable private fun RoadContextPanel(state: GuardianUiState,onRoad:(GuardianPickupSpot)->Unit) {
    val spot=state.roadSpot ?: return
    val context=state.roads
    HorizontalDivider(Modifier.padding(vertical=18.dp),color=Line)
    Text("주변 도로 · 승하차 허용은 별도 확인",fontSize=14.sp,fontWeight=FontWeight.Bold,color=Navy)
    Text(spot.name,fontSize=13.sp,fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(top=10.dp))
    spot.address?.let { Text(it,fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=4.dp)) }
    if(state.roadsLoading) Row(Modifier.padding(top=18.dp),verticalAlignment=Alignment.CenterVertically) {
        CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp); Text("  주변 도로를 불러오고 있어요",fontSize=12.sp,color=Muted)
    }
    state.roadError?.let { ErrorMessage(it); TextButton(onClick={onRoad(spot)}) { Text("도로 다시 확인") } }
    if(context!=null) {
        if(context.lines.isEmpty()) Text("이 위치 주변의 도로 자료가 없습니다.",fontSize=12.sp,color=Muted,modifier=Modifier.padding(top=14.dp))
        else {
            val latitude=spot.latitude ?: return
            val longitude=spot.longitude ?: return
            Box(Modifier.fillMaxWidth().padding(top=14.dp).aspectRatio(1.1f).clip(RoundedCornerShape(16.dp)).background(Paper)) {
                Canvas(Modifier.fillMaxSize()) {
                    val metersPerPixel=(context.radiusMeters*2.0/size.minDimension)
                    val longitudeScale=kotlin.math.cos(Math.toRadians(latitude))*111320.0
                    fun project(p: GuardianRoadPoint)=Offset((size.width/2+(p.longitude-longitude)*longitudeScale/metersPerPixel).toFloat(),
                        (size.height/2-(p.latitude-latitude)*111320.0/metersPerPixel).toFloat())
                    context.lines.forEach { line ->
                        val path=Path()
                        line.forEachIndexed { i,p -> val point=project(p); if(i==0) path.moveTo(point.x,point.y) else path.lineTo(point.x,point.y) }
                        drawPath(path,Color(0xFF6C8298),style=Stroke(width=2.dp.toPx(),cap=StrokeCap.Round))
                    }
                    drawCircle(Color.White,radius=9.dp.toPx(),center=center)
                    drawCircle(Navy,radius=6.dp.toPx(),center=center)
                    val scaleStart=Offset(16.dp.toPx(),size.height-18.dp.toPx())
                    val scaleEnd=Offset(scaleStart.x+(1000.0/metersPerPixel).toFloat(),scaleStart.y)
                    drawLine(Ink,scaleStart,scaleEnd,2.dp.toPx())
                    drawLine(Ink,Offset(scaleStart.x,scaleStart.y-4.dp.toPx()),Offset(scaleStart.x,scaleStart.y+4.dp.toPx()),2.dp.toPx())
                    drawLine(Ink,Offset(scaleEnd.x,scaleEnd.y-4.dp.toPx()),Offset(scaleEnd.x,scaleEnd.y+4.dp.toPx()),2.dp.toPx())
                }
                Text("북 ↑",fontSize=10.sp,fontWeight=FontWeight.Bold,color=Navy,modifier=Modifier.align(Alignment.TopEnd).padding(12.dp))
                Text("1 km",fontSize=9.sp,color=Navy,modifier=Modifier.align(Alignment.BottomStart).padding(start=16.dp,bottom=24.dp))
            }
            Text("● 장소 위치 · 반경 ${context.radiusMeters/1000} km 도로 자료${if(context.truncated) " 중 일부 표시" else ""}",fontSize=10.sp,color=Muted,modifier=Modifier.padding(top=7.dp))
        }
        Text("자료: ${context.sourceName ?: "출처 확인 필요"}${context.sourceYear?.let { " · $it" } ?: " · 기준연도 확인 필요"}",fontSize=10.sp,lineHeight=17.sp,color=Muted,modifier=Modifier.padding(top=8.dp))
        Text("실제 도로 자료를 참고해 표시했어요. 이동 경로와 현장의 최신 통행·정차 조건은 별도로 확인해 주세요.",fontSize=11.sp,lineHeight=18.sp,color=Muted,modifier=Modifier.padding(top=6.dp))
    }
}

@Composable private fun TimelineRow(number: String,title: String,at: String?,pending: String,last: Boolean=false) {
    Row(Modifier.fillMaxWidth().padding(bottom=if(last) 0.dp else 18.dp),verticalAlignment=Alignment.Top) {
        Box(Modifier.size(32.dp).background(if(at!=null) Color(0xFFDDF5F5) else Paper,CircleShape),contentAlignment=Alignment.Center) {
            Text(number,fontSize=10.sp,fontWeight=FontWeight.Bold,color=if(at!=null) Color(0xFF00717B) else Muted)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title,fontSize=14.sp,fontWeight=FontWeight.SemiBold,color=Ink)
            Text(if(at!=null) "${isoTime(at)} 기록됨" else pending,fontSize=12.sp,color=Muted,modifier=Modifier.padding(top=3.dp))
        }
    }
}
@Composable private fun ErrorMessage(message: String) {
    Text(message,fontSize=12.sp,lineHeight=19.sp,color=Error,modifier=Modifier.padding(top=12.dp).semantics { liveRegion=LiveRegionMode.Polite })
}
internal fun statusTitle(t: GuardianTrip?,link: GuardianLink): String {
    val direction=link.journeyLabel
    val institution=link.institutionType.label
    return when(t?.status) {
        null -> "첫 $direction 소식을 기다려요"
        "PLANNED" -> "$direction 이동이 예정되어 있어요"
        "EN_ROUTE" -> "차량이 $institution${if(link.institutionType==InstitutionType.SCHOOL) "로" else "으로"} 가고 있어요"
        "CALLED" -> if(link.journeyType==JourneyType.DROPOFF) "기관에 도착을 안내했어요" else "${institution}에 $direction 준비를 요청했어요"
        "ARRIVED" -> "차량이 도착했어요"
        "BOARDED" -> if(link.journeyType==JourneyType.PICKUP && t.journeyType==JourneyType.PICKUP && t.confirmation=="GUARDIAN") "차량에서 탑승을 확인했어요" else "이동 확인 기록을 확인하세요"
        "HANDED_OVER" -> if(link.journeyType==JourneyType.DROPOFF && t.journeyType==JourneyType.DROPOFF && t.confirmation=="GUARDIAN") "보호자가 기관 인계를 확인했어요" else "인계 확인 기록을 확인하세요"
        "CANCELLED" -> "$direction 이동이 취소되었어요"
        else -> "이동 상태를 확인하고 있어요"
    }
}
internal fun statusDetail(t: GuardianTrip?,link: GuardianLink): String = when(t?.status) {
    null -> "차량에서 이동을 시작하면 이곳에 소식이 표시됩니다."
    "PLANNED" -> "차량의 경로와 도착 예상 시간이 연결되면 알려드려요."
    "EN_ROUTE" -> "차량에서 전해진 도착 예상 시간입니다. 교통 상황에 따라 달라질 수 있어요."
    "CALLED" -> if(link.journeyType==JourneyType.DROPOFF) "기관에 도착 안내가 기록되었어요. 실제 아이 인계는 보호자가 직접 확인합니다." else "기관 호출이 기록되었어요. 아이의 내려보내기 여부는 기관에서 확인합니다."
    "ARRIVED" -> if(link.journeyType==JourneyType.DROPOFF) "차량의 주차 도착 기록입니다. 기관에 아이를 직접 인계한 뒤 차량에서 확인해 주세요. 입실 확인을 뜻하지 않아요." else "차량의 주차 도착 기록입니다. 아이가 탑승하면 차량에서 직접 확인해 주세요."
    "BOARDED" -> if(link.journeyType==JourneyType.PICKUP && t.journeyType==JourneyType.PICKUP && t.confirmation=="GUARDIAN") "차량에서 보호자가 직접 확인한 탑승 기록입니다." else "이 이동 방향의 보호자 탑승 확인 기록이 없습니다. 차량에서 상태를 확인하세요."
    "HANDED_OVER" -> if(link.journeyType==JourneyType.DROPOFF && t.journeyType==JourneyType.DROPOFF && t.confirmation=="GUARDIAN") "보호자가 직접 확인한 기관 인계 기록입니다. 센서나 위치만으로 입실을 확인한 기록이 아닙니다." else "이 이동 방향의 보호자 인계 확인 기록이 없습니다. 차량에서 상태를 확인하세요."
    "CANCELLED" -> "이 기록은 종료되었어요. 다음 이동이 시작되면 새 소식이 표시됩니다."
    else -> "아직 표시할 수 없는 상태입니다. 차량에서 확인해 주세요."
}
private val clockFormat=DateTimeFormatter.ofPattern("HH:mm:ss").withZone(ZoneId.systemDefault())
private val dateFormat=DateTimeFormatter.ofPattern("M월 d일 HH:mm").withZone(ZoneId.systemDefault())
private fun time(millis: Long)=clockFormat.format(Instant.ofEpochMilli(millis))
private fun isoTime(raw: String)=runCatching { clockFormat.format(Instant.parse(raw)) }.getOrDefault("시각 미확인")
private fun date(raw: String)=runCatching { dateFormat.format(Instant.parse(raw)) }.getOrDefault("시각 미확인")
