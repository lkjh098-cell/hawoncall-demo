# 하원콜 보호자 기능 모듈 · V0.7

`guardian-feature`는 Android Compose 라이브러리입니다. `guardian-app`은 이 기능을 실행하는 별도의 얇은 Android 통합 테스트 호스트이며 웹뷰를 사용하지 않습니다. 실제 공식 마이현대 앱에 합쳐진 결과물이 아닙니다. 공식 마이현대 임베딩 SDK·인증 계약은 확인되지 않았으므로, 향후 협의와 실제 호스트 검증이 필요한 독립 연동 후보입니다. 현대 로고나 공식 로그인 화면은 포함하지 않습니다.

## 삽입 진입점

```kotlin
GuardianFeature(
    sessionStore = hostGuardianSessionStore,
    allowLocalDevelopment = BuildConfig.DEBUG,
    initialServerUrl = if (BuildConfig.DEBUG) "http://10.0.2.2:3000" else ""
)
```

공개 진입점은 `ai.hawoncall.guardian.GuardianFeature`입니다. 호스트는 Compose `ViewModelStoreOwner`와 LifecycleOwner를 제공해야 합니다(일반 ComponentActivity 또는 Navigation 목적지). 동일 소유자에 하나의 기능 인스턴스를 넣으십시오. 정책을 바꾸려면 기존 기능 소유자를 폐기하고 새로 생성하십시오. 호스트 `BuildConfig.DEBUG`에서 개발 허용 여부를 주입하며 라이브러리 자체의 debug 여부로 운영 정책을 결정하지 않습니다.

## 인증 및 수명주기 소유권

- `GuardianSessionStore`의 `load/save/clear`를 호스트가 구현할 수 있습니다. 호출은 직렬화된 IO 작업에서 수행됩니다. 향후 정식 앱과 합의한 인증·세션 저장소를 연결할 자리입니다. 현재 서버의 보호자 범위 bearer만 사용하며 차량 토큰을 받거나 저장하지 않습니다.
- 테스트 호스트의 기본 구현 `KeystoreGuardianSessionStore`는 Android Keystore AES-GCM으로 세션(토큰, 서버 주소, 연결 정보, 최근 픽업 스냅샷)을 암호화하고 MODE_PRIVATE 저장소에 기록합니다. 복원 실패는 사용자에게 알리며 연결 초기화 동작을 제공합니다. 실제 통합 호스트도 클라우드 백업과 기기 전송에서 해당 저장소를 제외해야 합니다. 테스트 호스트는 allowBackup=false 및 명시적인 data extraction 제외 규칙을 설정합니다.
- 기능이 STARTED 이상이고 화면에 존재할 때만 3초 간격으로 상태를 조회합니다. 화면 이탈/백그라운드에서는 조회와 시계를 중단하고 복귀 즉시 갱신합니다. 네트워크는 비동기 OkHttp, 저장은 IO에서 수행합니다. 요청 취소를 실제 네트워크 호출로 전파합니다.
- 기기 연결 해제는 진행 중인 등록/코드 발급/조회 취소, 세대 번호 변경, 직렬화된 저장소 삭제를 수행합니다. 이전 응답이 새 세션을 덮어쓰지 못하도록 차단합니다. 이 동작은 서버 연결 삭제나 차량 토큰 폐기를 뜻하지 않습니다. 대화상자에도 이 범위를 명시합니다.
- 서버 조회가 성공하면 암호화 저장을 기다리지 않고 최신 기록과 확인 시각을 먼저 표시합니다. 마지막으로 저장한 연결·이동 기록이 달라졌을 때만 암호화 저장하며, 조회 시각만 바뀐 3초 주기 응답은 다시 저장하지 않습니다. 저장 실패는 별도 안내로 표시하고 네트워크 갱신 실패로 처리하지 않으며 다음 조회에서 저장을 재시도합니다.
- 마지막 서버 확인 시각과 서버가 기록한 이벤트 시각을 구분합니다. 캐시 복원·조회 실패·10초 이상 미갱신은 이전 기록으로 표시합니다. 알 수 없는 ETA를 0으로 표시하지 않으며 최근 픽업은 생성 시각으로 선택합니다. 401은 자동 조회를 중단하고 재확인/기기 재연결을 안내합니다.

## 서버 계약

- `POST /api/guardian/links`: `{academyCode,childName,weekday,pickupTime,institutionType,journeyType,serviceArea:"SEOUL",baseLeadSeconds:300,guardianConsent:true}` → `{link,guardianToken}`. 명시적 법정대리인 동의 없이는 요청하지 않습니다.
- `GET /api/guardian/config`, `GET /api/guardian/trips`: 보호자 bearer로 자신의 연결과 픽업만 조회합니다.
- `POST /api/guardian/pairing` 빈 JSON `{}`: 보호자 bearer로 8자리 대문자 영숫자 코드와 `expiresAt`을 받습니다. UI는 만료 시간을 표시하고 만료 후 코드를 숨깁니다. 5분·1회 사용의 최종 권한 검증은 서버가 수행합니다.
- 기관은 `SCHOOL`, `KINDERGARTEN`, `DAYCARE`, `ACADEMY`, 방향은 `PICKUP`, `DROPOFF`를 명시합니다. 학교는 등교/하교, 그 외 기관은 등원/하원으로 표시합니다. 기존 링크·암호화 스냅샷에 새 필드가 없으면 `ACADEMY`/`PICKUP`/`SEOUL`을 사용합니다. 기존 `academyCode`, `academyName`, `pickupTime` JSON 이름은 호환을 위해 유지합니다.
- `GET /api/guardian/pickup-spots`는 보호자 bearer로 서울 공개자료 목록을 조회합니다. 휴대폰 위치를 요청하거나 전송하지 않습니다. `{serviceArea:"SEOUL",spots:[...],selectionAllowed}`를 받고 이름, 주소, 확인 상태·이유, 출처, 유효기간과 서버가 제공한 대기 참고값을 표시합니다. 출처 링크는 HTTPS만 엽니다. 기관 이름·주소 검색어를 `q`로 보내 서울 전체 자료에서 검색합니다. 서버는 전체 자료를 검색한 뒤 200곳으로 응답을 제한하며 `total`과 `truncated`를 제공합니다. 화면에는 검색 결과 건수와 첫 20곳만 표시합니다.
- `GET /api/guardian/road-context?lat=&lon=`은 누른 참고 장소의 좌표만 보내 반경 2km 도로 자료를 조회합니다. 휴대폰 현재 위치를 사용하지 않습니다. 실제 `LineString`/`MultiLineString`을 Canvas에 그리고 장소 점, 북쪽, 1km 축척과 자료 출처·연도를 표시합니다. 이동 경로를 만들거나 도로 자료만으로 승하차 허용 여부를 추론하지 않습니다. 장소를 연달아 누르면 이전 요청을 취소하고 별도 세대 번호로 오래된 도로 응답을 차단합니다. 목록·도로 응답만 최대 4MiB로 제한하며 일반 인증·상태 응답은 기존 256KiB 제한을 유지합니다.
- `POST /api/guardian/pickup-spot`에 `{spotId}`를 보내고 반환된 `{link}`의 `pickupSpot`을 암호화 저장합니다. `selectionAllowed`이며 해당 장소가 `state:VERIFIED`와 `eligible:true`를 모두 만족할 때만 선택 버튼을 켭니다. `UNVERIFIED`는 ‘현장·운영 확인 필요’로 표시합니다. 공개자료에 존재한다는 사실만으로 정차나 운영 승인이 확인되었다고 표시하지 않습니다. 최종 권한·유효기간 검증은 서버가 수행합니다.
- 보호자 휴대폰 앱에는 탑승·인계 완료 이벤트를 보내는 경로나 버튼이 없습니다. 차량에서 실제 아이를 확인한 뒤 차량 UI의 명시적 보호자 확인을 거친 `confirmation: GUARDIAN` 기록만 완료로 표시합니다. 하교/하원 `PICKUP`은 `BOARDED`/`boardedAt`, 등교/등원 `DROPOFF`는 `HANDED_OVER`/`handedOverAt`을 구분합니다. 차량 도착·센서만으로 기관 입실을 확인했다고 표시하지 않습니다.
- 장소 선택 중에는 상태 조회를 취소하고 선택 완료 후 다시 시작하여 이전 조회가 선택한 장소를 덮어쓰지 않도록 합니다. 장소 조회/선택에도 401 재연결 및 초기화 세대 검증을 적용합니다.

운영은 HTTPS만 허용하며 URL 사용자정보·경로·쿼리·fragment를 거부합니다. HTTP는 개발 허용이 명시된 호스트에서 `localhost`, `127.0.0.1`, `10.0.2.2`만 가능합니다. Android Network Security Config도 같은 범위만 허용합니다. 리디렉션을 따라가지 않으므로 토큰이 새 호스트로 전달되지 않습니다. 위치·백그라운드·알림·카메라 권한은 요청하지 않습니다.

## 빌드 및 검증

```sh
./gradlew :guardian-app:assembleDebug :guardian-feature:testDebugUnitTest
```

단위 검증은 운영/개발 URL 경계, URL에 비밀정보 포함 금지, 최근 픽업 선택 및 null ETA, 세션 직렬화, 보호자 전용 등록·조회 헤더, 리디렉션 차단, 잘못된 연결 코드 거부, 기존/신규 링크 파싱, 방향별 보호자 완료 표시, 장소 선택 조건·세션 직렬화, 장소 조회/선택의 보호자 인증을 다룹니다. 실제 공식 앱 호스트, 인증 계약, 운영 배포 서버 검증은 별도입니다. 디버그 앱 ID는 `ai.hawoncall.guardian.debug`, 운영 기본 ID는 `ai.hawoncall.guardian`입니다.

## AAR 배포

`lib/guardian-feature-release.aar`는 이 모듈의 코드·리소스만 포함하며 의존 라이브러리를 묶은 fat AAR가 아닙니다. 가장 안전한 통합은 제공된 소스 모듈을 프로젝트에 포함하는 방식입니다. AAR를 직접 사용하는 호스트는 이 모듈의 `build.gradle.kts`에 명시된 Compose BOM/Material3/activity-compose/lifecycle/coroutines/OkHttp 의존성을 함께 선언해야 합니다. Android minimum API 28, Java 17 기준입니다. 서버 주소와 보호자 토큰 계약도 별도이며, 현대차 계정 토큰을 그대로 전달하면 동작하지 않습니다.
