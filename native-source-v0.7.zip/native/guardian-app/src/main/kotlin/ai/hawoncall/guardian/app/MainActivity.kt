package ai.hawoncall.guardian.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import ai.hawoncall.guardian.GuardianFeature
import ai.hawoncall.guardian.KeystoreGuardianSessionStore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sessions = KeystoreGuardianSessionStore(applicationContext)
        setContent {
            GuardianFeature(
                sessionStore = sessions,
                allowLocalDevelopment = BuildConfig.DEBUG,
                initialServerUrl = if (BuildConfig.DEBUG) "http://10.0.2.2:3000" else ""
            )
        }
    }
}
