# Pure JVM core API — V0.3

Package: `ai.hawoncall.core`. Serialize all calls on one owning thread. Inject a monotonic `Clock`; the engine clamps backwards observations. Transport adapters supply wall-clock timestamps if needed and discard stale SDK callbacks before passing observations. `PickupPlan.initialLeadSeconds` is initial preparation duration D; call lead is D + 30 seconds. Weekday is ISO 1–7; learning child identity is `linkId`.

`PickupEngine(plan, clock, learning = InMemoryLearningStore(), sampleId = UUID…)` exposes `state`, `snapshot`, `start()`, `updateEta(seconds)`, `arrive()`, `destinationArrived()`, `proximityEntered()`, `locationDistanceUpdated(meters)`, `destinationChanged(isAcademy)`, `gearChanged(Gear)`, `doorChanged(RearSide, open)`, `occupancyChanged(RearSide, occupied)`, `beltChanged(RearSide, buckled)`, `confirmBoarding()`, `cancel(reason)`, `completeDeparture()`, `tick()`, and `setCapabilities(occupancy, belt)`.

`start()` enters PLANNED. It never requests or replaces a route. `destinationChanged(true)` adopts an already selected academy destination and starts an idle pickup without requesting a route. Gear DRIVE or the first valid active-route ETA enters EN_ROUTE. The first ETA ≤ D + 30 seconds queues one CALL. CALL produces no success speech: transport acknowledgment, not local queue acceptance, must govern any “sent” message. `destinationChanged(false)` cancels an active unconfirmed pickup; it does not cancel BOARDED or DONE.

Pickup states: IDLE, PLANNED, EN_ROUTE, CALLED, **APPROACHING**, **ARRIVED**, **BOARDING_DETECTED**, **BOARDED**, DONE, CANCELLED.

- APPROACHING means nearby, without a confirmed pickup parking stop. `proximityEntered()` and compatibility alias `arrive()` only establish approach, even when the gear is PARK. Location ≤150 m also establishes approach. These inputs never independently establish ARRIVED.
- ARRIVED means PARK plus fresh actual near evidence: a location ≤100 m or an explicit OEM `destinationArrived()` observation no more than 30 seconds old. The signals may arrive in either order. The constants are `APPROACH_RADIUS_METERS = 150.0`, `PARKED_RADIUS_METERS = 100.0`, and `NEAR_EVIDENCE_MAX_AGE_MILLIS = 30_000`. An observed location beyond 100 m invalidates earlier near evidence, ends a parked interval, and returns a parked pickup to APPROACHING. Invalid, negative, NaN, and infinite distances are ignored. ARRIVED is emitted to the server at most once per trip.
- BOARDING_DETECTED is a fresh sensor candidate, never child identity or completed boarding. Detection emits no BOARDED server event, learning sample, route change, or completion greeting.
- **Only an explicit `confirmBoarding()` call can enter BOARDED**, queue one BOARDED server event and one learning sample. The UI should label this as guardian confirmation of the named child. Gear DRIVE after BOARDED enters DONE. The engine never navigates automatically to a next destination.

`RequestRoute(ACADEMY/NEXT)` remains a source-compatible effect type. **The V0.3 engine never emits it**, including start, route adoption, sensor detection, guardian confirmation, or departure. OEM navigation stays authoritative; any user-requested route operation belongs to a separate explicit UI action.

Leaving PARK before guardian confirmation invalidates every door/sensor attempt, returns ARRIVED or BOARDING_DETECTED to APPROACHING, and pauses waiting time. Returning to PARK requires fresh near evidence to enter ARRIVED again. A stale near observation cannot authorize a new stop. `arrivalAtMillis` remains the first confirmed parked-arrival timestamp for compatibility; `waitingSeconds` is accumulated accepted parked dwell, excluding every driving or other non-PARK interval. It freezes on confirmation or cancellation. Learning uses that same accumulated parked dwell. The once-per-trip waiting alert occurs at ≥300 accumulated parked seconds.

`snapshot` preserves `state`, `etaSeconds`, `arrivalAtMillis`, `boardedAtMillis`, `waitingSeconds`, `learnedDurationSeconds`, `callLeadSeconds`, `canConfirmBoarding`, and `gear`. `canConfirmBoarding` requires ARRIVED or BOARDING_DETECTED, PARK, and near evidence fresh within 30 seconds at read time. Guardian confirmation is available for every occupancy/belt capability combination, including unknown/unsupported sensors, and does not require a sensor cycle. The vehicle UI must additionally require that the current platform UX restrictions permit this interaction. Read access does not advance state. Tick every 100–250 ms for sensor-close debounce, candidate expiration, and waiting alert. Keep delivering fresh navigation/location observations while parked so the confirmation gate can remain current.

For sensor candidates, provide baselines before boarding. Only an observed Empty→Occupied or unbuckled→buckled edge is fresh; an initial `true` snapshot or repeated `true` never counts. A rear-door cycle must begin after ARRIVED while PARK remains uninterrupted. The same rear side must be open ≥1 second then closed ≥1 second; a fresh occupancy or belt edge on that side must be within 60 seconds before/after close. The closed cycle must still be ≤60 seconds old. A door-open observation from before ARRIVED cannot begin the cycle. Reopening, an empty-seat observation, or leaving PARK invalidates a detected candidate; capability refresh cannot promote old observations. Unknown sensors remain a guardian-confirmation fallback, not a completed boarding event.

Drain `List<PickupEffect>` with `drainEffects()` after each input/tick:

- `ServerEvent(type, atMillis, etaMin = null, reason = null)`, types ETA/CALL/ARRIVED/BOARDED/CANCEL. ETA is rounded up and throttled to ≥60 seconds between events. The client creates a trip on PLANNED and durably queues events until it has a trip ID.
- `StateChanged(from, to, atMillis)` for the transition log.
- `Speak(text)`: one approach/parking prompt, one confirmed-child greeting, and the once-per-trip wait alert. No unacknowledged CALL success speech or invented ETA.
- `LearningUpdated(key, previousSeconds, durationSeconds, waitSeconds)` after guardian confirmation only.
- `WaitingAlert(waitSeconds)` once after five accumulated parked minutes.
- `RequestRoute(destination)` is retained but never emitted.

Enums: `Gear.PARK/DRIVE/REVERSE/NEUTRAL/UNKNOWN`, `RearSide.LEFT/RIGHT`. DONE and CANCELLED are terminal; create a new engine per trip and reuse a learning store with a distinct sample ID. `LearningStore` is injectable. The supplied synchronized store is memory-only and deduplicates by learning key plus sample ID; a production durable store must persist values and sample IDs atomically. No monthly savings are inferred without real observations.

도착 이력이 생긴 뒤 ETA는 차량 표시만 갱신하며 서버 ETA를 추가하지 않습니다. 구버전의 늦은 ETA는 서버가 도착 상태·ETA0을 유지한 채 수락하여 뒤의 보호자 확인을 막지 않습니다.


## v0.7 Seoul institution journeys

`PickupPlan` keeps prior positional parameters and defaults, then accepts `institutionType`, `journeyType`, `serviceArea` (SEOUL) and optional informational `pickupSpot`. Plan values are immutable for the life of the engine. `PickupSnapshot.journeyType` identifies the frozen journey.

PICKUP preserves the guardian boarding flow. DROPOFF ignores boarding sensor candidates and `confirmBoarding()`. Only `confirmHandoff()` while PARK with fresh nearby destination evidence emits `HANDED_OVER` and enters terminal `HANDED_OVER`; it never emits BOARDED or trains pickup preparation time. Vehicle UI also requires UX permission and explicit guardian confirmation. Sensors do not prove institution entry.

Authorized pickup spot context does not modify the OEM destination, route identity, distance binding or arrival evidence. No point is generated when no eligible permission record is supplied.

The vehicle network adapter optionally attaches `arrivalSpotEvidence` to ARRIVED and guardian BOARDED/HANDED_OVER. It is calculated only from real Pleos Fused coordinates in memory, matched to the immutable selected point, within 30m and 30 seconds while P; coordinates are never queued or sent. Meter accuracy is capped at 20 when available. Pleos FusedLocation 1.1.3 provides confidence rather than meter accuracy, so this adapter omits accuracy instead of converting confidence. Demo inputs cannot provide point evidence.

Point wait samples require point evidence at both arrival and terminal confirmation. Native `parkedWaitSeconds` counts only point proximity observed while P after the first point arrival, pausing on movement, outside-point observations and stale location gaps. Invalid or unavailable proof leaves ordinary trip completion available without a learning sample. This is authenticated app telemetry, not independent proof of a legal stopping place.

A CREATE 409 with code `LINK_CONFIGURATION_CHANGED` pauses the durable outbox without dropping or relabeling commands. PARK + UX permission exposes an explicit archive-and-repair action. Other 409s retain the existing retry behavior; an active trip conflict never silently archives records.
