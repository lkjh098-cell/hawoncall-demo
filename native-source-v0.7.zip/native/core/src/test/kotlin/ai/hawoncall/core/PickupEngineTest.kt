package ai.hawoncall.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class PickupEngineTest {
    private class FakeClock(var millis: Long = 1_000_000) : Clock {
        override fun nowMillis() = millis
        fun advance(seconds: Long) { millis += seconds * 1_000 }
    }
    private class Fixture(capable: Boolean = true) {
        val clock = FakeClock()
        val store = InMemoryLearningStore()
        val plan = PickupPlan("link", "민지", "수학", "academy", 1)
        val engine = PickupEngine(plan, clock, store, "trip")
        init {
            engine.setCapabilities(capable, capable)
            engine.occupancyChanged(RearSide.RIGHT, false)
            engine.beltChanged(RearSide.RIGHT, false)
        }
        fun arrive() {
            engine.start()
            engine.gearChanged(Gear.PARK)
            engine.locationDistanceUpdated(50.0)
            engine.drainEffects()
        }
        fun door(side: RearSide = RearSide.RIGHT) {
            engine.doorChanged(side, true)
            clock.advance(1)
            engine.doorChanged(side, false)
        }
        fun debounce() { clock.advance(1); engine.tick() }
        fun candidate() {
            door(); engine.occupancyChanged(RearSide.RIGHT, true); debounce()
        }
        fun serverTypes() = engine.drainEffects().filterIsInstance<PickupEffect.ServerEvent>().map { it.type }
    }

    @Test fun startAndAdoptionPreserveExistingOemRoute() {
        for (adopt in listOf(false, true)) {
            val f = Fixture()
            if (adopt) f.engine.destinationChanged(true) else f.engine.start()
            assertEquals(PickupState.PLANNED, f.engine.state)
            assertTrue(f.engine.drainEffects().none { it is PickupEffect.RequestRoute })
        }
    }

    @Test fun normalFlowRequiresGuardianThenDeparture() {
        val f = Fixture()
        f.engine.start(); f.engine.gearChanged(Gear.DRIVE); f.engine.updateEta(330)
        assertEquals(PickupState.CALLED, f.engine.state)
        f.engine.destinationArrived()
        assertEquals(PickupState.APPROACHING, f.engine.state)
        f.engine.gearChanged(Gear.PARK)
        assertEquals(PickupState.ARRIVED, f.engine.state)
        f.candidate()
        assertEquals(PickupState.BOARDING_DETECTED, f.engine.state)
        f.engine.confirmBoarding()
        assertEquals(PickupState.BOARDED, f.engine.state)
        f.engine.gearChanged(Gear.DRIVE)
        assertEquals(PickupState.DONE, f.engine.state)
        assertTrue(f.engine.drainEffects().none { it is PickupEffect.RequestRoute })
    }

    @Test fun driveByEvenWithArrivalAndSensorsCannotBoard() {
        val f = Fixture()
        f.engine.start(); f.engine.gearChanged(Gear.DRIVE)
        f.engine.locationDistanceUpdated(1.0); f.engine.destinationArrived()
        f.candidate(); f.engine.confirmBoarding()
        assertEquals(PickupState.APPROACHING, f.engine.state)
        assertFalse(f.engine.snapshot.canConfirmBoarding)
        assertTrue(f.serverTypes().none { it == EventType.ARRIVED || it == EventType.BOARDED })
        assertEquals(0L, f.engine.snapshot.waitingSeconds)
    }

    @Test fun parkWithoutNearEvidenceCannotArriveOrConfirm() {
        val f = Fixture()
        f.engine.start(); f.engine.gearChanged(Gear.PARK)
        f.engine.confirmBoarding()
        assertEquals(PickupState.PLANNED, f.engine.state)
        assertFalse(f.engine.snapshot.canConfirmBoarding)
    }

    @Test fun geofenceAndLegacyArriveOnlyApproachEvenWhileParked() {
        for (legacy in listOf(false, true)) {
            val f = Fixture()
            f.engine.start(); f.engine.gearChanged(Gear.PARK)
            if (legacy) f.engine.arrive() else f.engine.proximityEntered()
            f.engine.confirmBoarding()
            assertEquals(PickupState.APPROACHING, f.engine.state)
            assertFalse(f.engine.snapshot.canConfirmBoarding)
            assertEquals(listOf(EventType.CALL), f.serverTypes())
        }
    }

    @Test fun navigationArrivalCanEstablishNearEvidenceWithParkInEitherOrder() {
        for (parkFirst in listOf(false, true)) {
            val f = Fixture()
            f.engine.start()
            if (parkFirst) f.engine.gearChanged(Gear.PARK)
            f.engine.destinationArrived()
            if (!parkFirst) f.engine.gearChanged(Gear.PARK)
            assertEquals(PickupState.ARRIVED, f.engine.state)
            assertEquals(listOf(EventType.CALL, EventType.ARRIVED), f.serverTypes())
        }
    }

    @Test fun approachAndParkedRadiusAreSeparateAndInclusive() {
        val f = Fixture()
        f.engine.start(); f.engine.gearChanged(Gear.PARK)
        f.engine.locationDistanceUpdated(150.1)
        assertEquals(PickupState.PLANNED, f.engine.state)
        f.engine.locationDistanceUpdated(150.0)
        assertEquals(PickupState.APPROACHING, f.engine.state)
        f.engine.locationDistanceUpdated(100.1)
        assertFalse(f.engine.snapshot.canConfirmBoarding)
        f.engine.locationDistanceUpdated(100.0)
        assertEquals(PickupState.ARRIVED, f.engine.state)
        assertTrue(f.engine.snapshot.canConfirmBoarding)
    }

    @Test fun staleNearEvidenceDoesNotQualifyOnPark() {
        val f = Fixture()
        f.engine.start(); f.engine.locationDistanceUpdated(10.0)
        f.clock.millis += 30_001
        f.engine.gearChanged(Gear.PARK)
        assertEquals(PickupState.APPROACHING, f.engine.state)
        assertFalse(f.engine.snapshot.canConfirmBoarding)
        f.engine.locationDistanceUpdated(100.0)
        assertEquals(PickupState.ARRIVED, f.engine.state)
    }

    @Test fun freshEvidenceBoundaryAndRefreshForConfirmation() {
        val f = Fixture(false)
        f.arrive(); f.clock.advance(30)
        assertTrue(f.engine.snapshot.canConfirmBoarding)
        f.clock.millis += 1
        assertFalse(f.engine.snapshot.canConfirmBoarding)
        f.engine.confirmBoarding()
        assertEquals(PickupState.ARRIVED, f.engine.state)
        f.engine.locationDistanceUpdated(20.0); f.engine.confirmBoarding()
        assertEquals(PickupState.BOARDED, f.engine.state)
    }

    @Test fun newOutsideLocationInvalidatesOlderNavigationNearEvidence() {
        val f = Fixture()
        f.engine.start(); f.engine.destinationArrived(); f.engine.locationDistanceUpdated(500.0)
        f.engine.gearChanged(Gear.PARK)
        assertEquals(PickupState.APPROACHING, f.engine.state)
        assertFalse(f.engine.snapshot.canConfirmBoarding)
    }

    @Test fun invalidDistancesAreIgnored() {
        val f = Fixture()
        f.engine.start(); f.engine.gearChanged(Gear.PARK)
        listOf(-1.0, Double.NaN, Double.POSITIVE_INFINITY).forEach(f.engine::locationDistanceUpdated)
        assertEquals(PickupState.PLANNED, f.engine.state)
        assertTrue(f.engine.drainEffects().none { it is PickupEffect.ServerEvent })
    }

    @Test fun repeatedInputsDoNotDuplicateCallArrivalOrSpeech() {
        val f = Fixture()
        f.engine.start(); f.engine.gearChanged(Gear.PARK)
        repeat(5) { f.engine.destinationArrived(); f.engine.proximityEntered(); f.engine.start() }
        val effects = f.engine.drainEffects()
        assertEquals(1, effects.filterIsInstance<PickupEffect.ServerEvent>().count { it.type == EventType.CALL })
        assertEquals(1, effects.filterIsInstance<PickupEffect.ServerEvent>().count { it.type == EventType.ARRIVED })
        assertEquals(1, effects.filterIsInstance<PickupEffect.Speak>().size)
    }

    @Test fun guardianFallbackIsAvailableForEveryCapabilityCombinationWithoutSensorCycle() {
        for (occupancy in listOf(false, true)) for (belt in listOf(false, true)) {
            val f = Fixture()
            f.engine.setCapabilities(occupancy, belt); f.arrive()
            assertTrue(f.engine.snapshot.canConfirmBoarding)
            f.engine.confirmBoarding()
            assertEquals(PickupState.BOARDED, f.engine.state)
            assertEquals(listOf(EventType.BOARDED), f.serverTypes())
        }
    }

    @Test fun sensorCandidateNeverEmitsBoardedOrLearningBeforeGuardian() {
        val f = Fixture()
        f.arrive(); f.candidate(); f.engine.tick()
        val effects = f.engine.drainEffects()
        assertEquals(PickupState.BOARDING_DETECTED, f.engine.state)
        assertTrue(effects.none { it is PickupEffect.LearningUpdated || it is PickupEffect.RequestRoute })
        assertTrue(effects.filterIsInstance<PickupEffect.ServerEvent>().none { it.type == EventType.BOARDED })
        assertEquals(null, f.engine.snapshot.boardedAtMillis)
        assertEquals(300L, f.engine.snapshot.learnedDurationSeconds)
    }

    @Test fun duplicateGuardianConfirmationHasExactlyOneEventAndSample() {
        val f = Fixture()
        f.arrive(); f.candidate(); f.engine.confirmBoarding(); f.engine.confirmBoarding(); f.engine.tick()
        val effects = f.engine.drainEffects()
        assertEquals(1, effects.count { it is PickupEffect.LearningUpdated })
        assertEquals(1, effects.filterIsInstance<PickupEffect.ServerEvent>().count { it.type == EventType.BOARDED })
        assertTrue(effects.none { it is PickupEffect.RequestRoute })
    }

    @Test fun reopeningInvalidatesDetectedCandidateAndOldEdge() {
        val f = Fixture()
        f.arrive(); f.candidate()
        f.engine.doorChanged(RearSide.RIGHT, true)
        assertEquals(PickupState.ARRIVED, f.engine.state)
        f.clock.advance(1); f.engine.doorChanged(RearSide.RIGHT, false); f.debounce()
        assertEquals(PickupState.ARRIVED, f.engine.state)
    }

    @Test fun emptySeatInvalidatesDetectedCandidate() {
        val f = Fixture()
        f.arrive(); f.candidate(); f.engine.occupancyChanged(RearSide.RIGHT, false); f.engine.tick()
        assertEquals(PickupState.ARRIVED, f.engine.state)
        assertTrue(f.serverTypes().none { it == EventType.BOARDED })
    }

    @Test fun everyNonParkGearInvalidatesCandidateAndConfirmation() {
        for (gear in listOf(Gear.DRIVE, Gear.NEUTRAL, Gear.REVERSE, Gear.UNKNOWN)) {
            val f = Fixture()
            f.arrive(); f.candidate(); f.engine.gearChanged(gear); f.engine.confirmBoarding()
            assertEquals(PickupState.APPROACHING, f.engine.state)
            assertFalse(f.engine.snapshot.canConfirmBoarding)
            f.engine.gearChanged(Gear.PARK); f.engine.tick()
            assertEquals(PickupState.ARRIVED, f.engine.state)
        }
    }

    @Test fun doorCycleBeforeArrivalOrWhileDrivingIsNotEvidence() {
        for (parked in listOf(false, true)) {
            val f = Fixture()
            f.engine.start(); f.engine.gearChanged(if (parked) Gear.PARK else Gear.DRIVE)
            f.door(); f.engine.occupancyChanged(RearSide.RIGHT, true)
            f.engine.locationDistanceUpdated(10.0); f.engine.gearChanged(Gear.PARK); f.debounce()
            assertEquals(PickupState.ARRIVED, f.engine.state)
        }
    }

    @Test fun oppositeSideAndInitialTrueSnapshotDoNotDetectBoarding() {
        for (opposite in listOf(false, true)) {
            val f = Fixture()
            f.arrive(); f.door()
            if (opposite) f.engine.occupancyChanged(RearSide.LEFT, false)
            f.engine.occupancyChanged(RearSide.LEFT, true); f.debounce()
            assertEquals(PickupState.ARRIVED, f.engine.state)
        }
    }

    @Test fun repeatedTrueSensorValuesDoNotBecomeFreshEdges() {
        val f = Fixture()
        f.engine.occupancyChanged(RearSide.RIGHT, true)
        f.arrive(); f.door(); f.engine.occupancyChanged(RearSide.RIGHT, true); f.debounce()
        assertEquals(PickupState.ARRIVED, f.engine.state)
    }

    @Test fun openAndCloseEachRequireFullOneSecond() {
        for (shortOpen in listOf(false, true)) {
            val f = Fixture()
            f.arrive(); f.engine.doorChanged(RearSide.RIGHT, true)
            f.clock.millis += if (shortOpen) 999 else 1_000
            f.engine.doorChanged(RearSide.RIGHT, false); f.engine.occupancyChanged(RearSide.RIGHT, true)
            f.clock.millis += 999; f.engine.tick()
            assertEquals(PickupState.ARRIVED, f.engine.state)
            f.clock.millis += 1; f.engine.tick()
            assertEquals(if (shortOpen) PickupState.ARRIVED else PickupState.BOARDING_DETECTED, f.engine.state)
        }
    }

    @Test fun freshBeltEdgeCanDetectButCannotConfirmIdentity() {
        val f = Fixture()
        f.arrive(); f.door(); f.engine.beltChanged(RearSide.RIGHT, true); f.debounce()
        assertEquals(PickupState.BOARDING_DETECTED, f.engine.state)
        assertTrue(f.serverTypes().none { it == EventType.BOARDED })
    }

    @Test fun sensorEdgeWindowIsInclusiveAtSixtySecondsAfterClose() {
        for (seconds in listOf(60L, 61L)) {
            val f = Fixture()
            f.arrive(); f.door(); f.clock.advance(seconds)
            f.engine.occupancyChanged(RearSide.RIGHT, true)
            assertEquals(if (seconds == 60L) PickupState.BOARDING_DETECTED else PickupState.ARRIVED, f.engine.state)
        }
    }

    @Test fun sensorEdgeWindowIsInclusiveAtSixtySecondsBeforeClose() {
        for (seconds in listOf(59L, 60L)) {
            val f = Fixture()
            f.arrive(); f.engine.occupancyChanged(RearSide.RIGHT, true); f.clock.advance(seconds)
            f.door(); f.debounce()
            assertEquals(if (seconds == 59L) PickupState.BOARDING_DETECTED else PickupState.ARRIVED, f.engine.state)
        }
    }

    @Test fun leavingParkPausesWaitingAndRequiresFreshLocationToResume() {
        val f = Fixture()
        f.arrive(); f.clock.advance(120); f.engine.gearChanged(Gear.DRIVE)
        f.clock.advance(600); f.engine.tick()
        assertEquals(120L, f.engine.snapshot.waitingSeconds)
        f.engine.gearChanged(Gear.PARK)
        assertEquals(PickupState.APPROACHING, f.engine.state)
        f.engine.locationDistanceUpdated(10.0); f.clock.advance(180); f.engine.tick()
        assertEquals(300L, f.engine.snapshot.waitingSeconds)
        assertEquals(1, f.engine.drainEffects().count { it is PickupEffect.WaitingAlert })
        f.clock.advance(20); f.engine.tick()
        assertTrue(f.engine.drainEffects().none { it is PickupEffect.WaitingAlert })
    }

    @Test fun learningUsesOnlyParkedDwellAndWaitFreezesAfterConfirmation() {
        val f = Fixture(false)
        f.arrive(); f.clock.advance(40); f.engine.gearChanged(Gear.DRIVE)
        f.clock.advance(600); f.engine.gearChanged(Gear.PARK); f.engine.locationDistanceUpdated(10.0)
        f.clock.advance(60); f.engine.locationDistanceUpdated(10.0); f.engine.confirmBoarding()
        val sample = f.engine.drainEffects().filterIsInstance<PickupEffect.LearningUpdated>().single()
        assertEquals(100L, sample.waitSeconds)
        assertEquals(335L, sample.durationSeconds)
        f.clock.advance(600)
        assertEquals(100L, f.engine.snapshot.waitingSeconds)
    }

    @Test fun waitAlertOccursOnceAtFiveParkedMinutes() {
        val f = Fixture()
        f.arrive(); f.clock.advance(299); f.engine.tick()
        assertTrue(f.engine.drainEffects().isEmpty())
        f.clock.advance(1); f.engine.tick(); f.clock.advance(300); f.engine.tick()
        assertEquals(1, f.engine.drainEffects().count { it is PickupEffect.WaitingAlert })
    }

    @Test fun cancellationAndTerminalInputsNeverLearnOrRestart() {
        val f = Fixture()
        f.arrive(); f.candidate(); f.engine.destinationChanged(false)
        assertEquals(PickupState.CANCELLED, f.engine.state)
        f.engine.drainEffects()
        f.engine.start(); f.engine.destinationArrived(); f.engine.confirmBoarding(); f.engine.cancel("again")
        f.engine.updateEta(0); f.engine.tick()
        assertTrue(f.engine.drainEffects().isEmpty())
        assertEquals(300L, f.engine.snapshot.learnedDurationSeconds)
    }

    @Test fun completedTripCannotRestartAndDestinationChangeAfterConfirmationDoesNotCancel() {
        val f = Fixture()
        f.arrive(); f.engine.confirmBoarding(); f.engine.destinationChanged(false)
        assertEquals(PickupState.BOARDED, f.engine.state)
        f.engine.gearChanged(Gear.DRIVE); f.engine.drainEffects()
        f.engine.start(); f.engine.destinationArrived(); f.engine.confirmBoarding(); f.engine.tick()
        assertEquals(PickupState.DONE, f.engine.state)
        assertTrue(f.engine.drainEffects().isEmpty())
    }

    @Test fun etaLeadBoundaryOscillationThrottleAndNoPrematureSentSpeech() {
        val f = Fixture()
        f.engine.updateEta(0)
        assertEquals(PickupState.IDLE, f.engine.state)
        f.engine.start(); f.engine.updateEta(-1)
        assertEquals(null, f.engine.snapshot.etaSeconds)
        f.engine.updateEta(601)
        f.clock.advance(59); f.engine.updateEta(331)
        assertEquals(PickupState.EN_ROUTE, f.engine.state)
        f.clock.advance(1); f.engine.updateEta(330)
        assertEquals(PickupState.CALLED, f.engine.state)
        listOf(700L, 100L, 0L).forEach(f.engine::updateEta)
        val effects = f.engine.drainEffects()
        assertEquals(listOf(11, 6), effects.filterIsInstance<PickupEffect.ServerEvent>().filter { it.type == EventType.ETA }.map { it.etaMin })
        assertEquals(1, effects.filterIsInstance<PickupEffect.ServerEvent>().count { it.type == EventType.CALL })
        assertTrue(effects.none { it is PickupEffect.Speak })
    }

    @Test fun resumedEtaAfterParkedArrivalUpdatesSnapshotWithoutBlockingGuardianBoarding() {
        val f = Fixture()
        f.arrive()
        f.clock.advance(60)
        f.engine.gearChanged(Gear.DRIVE)
        f.engine.updateEta(600)
        assertEquals(PickupState.APPROACHING, f.engine.state)
        assertEquals(600L, f.engine.snapshot.etaSeconds)
        assertTrue(f.engine.drainEffects().filterIsInstance<PickupEffect.ServerEvent>().none { it.type == EventType.ETA })
        f.engine.gearChanged(Gear.PARK)
        f.engine.locationDistanceUpdated(10.0)
        f.engine.updateEta(30)
        assertEquals(30L, f.engine.snapshot.etaSeconds)
        f.engine.confirmBoarding()
        val events = f.engine.drainEffects().filterIsInstance<PickupEffect.ServerEvent>()
        assertTrue(events.none { it.type == EventType.ETA || it.type == EventType.ARRIVED })
        assertEquals(1, events.count { it.type == EventType.BOARDED })
        assertEquals(PickupState.BOARDED, f.engine.state)
    }

    @Test fun backwardsClockCannotUndoWaitingOrFreshness() {
        val f = Fixture()
        f.arrive(); f.clock.advance(10)
        assertEquals(10L, f.engine.snapshot.waitingSeconds)
        f.clock.advance(-5)
        assertEquals(10L, f.engine.snapshot.waitingSeconds)
        assertTrue(f.engine.snapshot.canConfirmBoarding)
    }

    @Test fun learningIncreasesDecreasesAndKeepsMiddleRange() {
        val store = InMemoryLearningStore()
        val key = LearningKey("a", "c", 1)
        assertEquals(335L, store.record(key, 100, 300, "1"))
        assertEquals(305L, store.record(key, 30, 300, "2"))
        assertEquals(305L, store.record(key, 60, 300, "3"))
        assertEquals(305L, store.record(key, 31, 300, "4"))
    }

    @Test fun learningHasBoundsAndExtremeInputCannotOverflow() {
        val store = InMemoryLearningStore()
        val key = LearningKey("a", "c", 1)
        assertEquals(60L, store.durationSeconds(key, -10))
        assertEquals(1_200L, store.durationSeconds(key, Long.MAX_VALUE))
        assertEquals(60L, store.record(key, 0, 60, "1"))
        assertEquals(1_200L, store.record(key, Long.MAX_VALUE, 60, "2"))
    }

    @Test fun learningSeparatesAcademyChildAndWeekdayAndDeduplicatesSamples() {
        val store = InMemoryLearningStore()
        val key = LearningKey("a", "c", 1)
        store.record(key, 100, 300, "trip")
        assertEquals(335L, store.record(key, 100, 300, "trip"))
        assertEquals(300L, store.durationSeconds(key.copy(weekday = 2)))
        assertEquals(300L, store.durationSeconds(key.copy(childId = "other")))
        assertEquals(300L, store.durationSeconds(key.copy(academyId = "other")))
    }
    @Test fun dropoffIgnoresBoardingSensorsAndRequiresExplicitFreshParkedHandoff() {
        val clock = FakeClock()
        val engine = PickupEngine(PickupPlan("link", "민지", "서울학교", institutionType = InstitutionType.SCHOOL,
            journeyType = JourneyType.DROPOFF), clock)
        engine.start(); engine.gearChanged(Gear.DRIVE); engine.locationDistanceUpdated(20.0)
        engine.confirmHandoff()
        assertFalse(engine.snapshot.canConfirmHandoff)
        engine.gearChanged(Gear.PARK)
        engine.occupancyChanged(RearSide.RIGHT, false); engine.doorChanged(RearSide.RIGHT, true)
        clock.advance(1); engine.doorChanged(RearSide.RIGHT, false)
        engine.occupancyChanged(RearSide.RIGHT, true); engine.beltChanged(RearSide.RIGHT, true)
        clock.advance(1); engine.tick(); engine.confirmBoarding()
        assertEquals(PickupState.ARRIVED, engine.state)
        assertFalse(engine.snapshot.canConfirmBoarding)
        assertTrue(engine.snapshot.canConfirmHandoff)
        assertTrue(engine.drainEffects().filterIsInstance<PickupEffect.ServerEvent>().none { it.type == EventType.BOARDED || it.type == EventType.HANDED_OVER })
        clock.advance(31); engine.confirmHandoff()
        assertEquals(PickupState.ARRIVED, engine.state)
        engine.locationDistanceUpdated(20.0); engine.confirmHandoff(); engine.confirmHandoff()
        assertEquals(PickupState.HANDED_OVER, engine.state)
        assertEquals(JourneyType.DROPOFF, engine.snapshot.journeyType)
        assertEquals(null, engine.snapshot.boardedAtMillis)
        assertEquals(clock.millis, engine.snapshot.handedOverAtMillis)
        val effects = engine.drainEffects()
        assertEquals(listOf(EventType.HANDED_OVER), effects.filterIsInstance<PickupEffect.ServerEvent>().map { it.type })
        assertTrue(effects.none { it is PickupEffect.LearningUpdated || it is PickupEffect.RequestRoute })
        engine.gearChanged(Gear.DRIVE); engine.start(); engine.confirmBoarding(); engine.confirmHandoff()
        assertEquals(PickupState.HANDED_OVER, engine.state)
    }

    @Test fun pickupCannotUseHandoffAndPlanCopyDoesNotMutateRunningDirection() {
        val clock = FakeClock()
        val plan = PickupPlan("link", "민지", "유치원", institutionType = InstitutionType.KINDERGARTEN)
        val engine = PickupEngine(plan, clock)
        engine.start(); engine.gearChanged(Gear.PARK); engine.locationDistanceUpdated(20.0)
        plan.copy(journeyType = JourneyType.DROPOFF)
        engine.confirmHandoff()
        assertEquals(PickupState.ARRIVED, engine.state)
        assertEquals(JourneyType.PICKUP, engine.snapshot.journeyType)
        assertFalse(engine.snapshot.canConfirmHandoff)
        engine.confirmBoarding()
        assertEquals(PickupState.BOARDED, engine.state)
    }

    @Test fun journeyLabelsAndLearningSeparateAllDirections() {
        assertEquals("등교", InstitutionType.SCHOOL.journeyLabel(JourneyType.DROPOFF))
        assertEquals("하교", InstitutionType.SCHOOL.journeyLabel(JourneyType.PICKUP))
        for (type in listOf(InstitutionType.KINDERGARTEN, InstitutionType.DAYCARE, InstitutionType.ACADEMY)) {
            assertEquals("등원", type.journeyLabel(JourneyType.DROPOFF))
            assertEquals("하원", type.journeyLabel(JourneyType.PICKUP))
        }
        val store = InMemoryLearningStore()
        val key = LearningKey("a", "c", 1)
        store.record(key, 100, 300, "trip")
        assertEquals(300L, store.durationSeconds(key.copy(journeyType = JourneyType.DROPOFF)))
    }

}
