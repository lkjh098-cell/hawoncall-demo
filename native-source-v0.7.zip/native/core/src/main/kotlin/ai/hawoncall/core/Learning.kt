package ai.hawoncall.core

/** childId is the stable server link ID, rather than a display name. Weekday uses ISO 1..7. */
data class LearningKey(val academyId: String, val childId: String, val weekday: Int, val journeyType: JourneyType = JourneyType.PICKUP) {
    init { require(weekday in 1..7) }
}

interface LearningStore {
    fun durationSeconds(key: LearningKey, initialSeconds: Long = 300): Long
    /** sampleId must uniquely identify a trip; implementations must reject duplicate sample IDs. */
    fun record(key: LearningKey, waitSeconds: Long, initialSeconds: Long, sampleId: String): Long
}

/** Inject a durable implementation in production. No savings are inferred without real observations. */
class InMemoryLearningStore : LearningStore {
    private val values = mutableMapOf<LearningKey, Long>()
    private val samples = mutableSetOf<Pair<LearningKey, String>>()

    @Synchronized override fun durationSeconds(key: LearningKey, initialSeconds: Long): Long =
        values[key] ?: initialSeconds.coerceIn(60, 1_200)

    @Synchronized override fun record(key: LearningKey, waitSeconds: Long, initialSeconds: Long, sampleId: String): Long {
        require(waitSeconds >= 0)
        require(sampleId.isNotBlank())
        val current = durationSeconds(key, initialSeconds)
        if (!samples.add(key to sampleId)) return current
        val next = when {
            waitSeconds > 60 -> {
                // Bound before adding, so even corrupt extreme input cannot overflow.
                val increment = ((waitSeconds - 30) / 2).coerceAtMost(1_200)
                current + increment
            }
            waitSeconds <= 30 -> current - 30
            else -> current
        }.coerceIn(60, 1_200)
        values[key] = next
        return next
    }
}
