plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "ai.hawoncall.car"
    compileSdk = 35
    defaultConfig {
        applicationId = "ai.hawoncall.car"
        minSdk = 28
        targetSdk = 35
        versionCode = 7
        versionName = "0.7.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    flavorDimensions += "platform"
    productFlavors {
        create("demo") {
            dimension = "platform"
            applicationIdSuffix = ".demo"
            buildConfigField("boolean", "SIMULATED_SIGNALS", "true")
            resValue("string", "app_name", "하원콜 · 모의 시연")
        }
        create("pleos") {
            dimension = "platform"
            buildConfigField("boolean", "SIMULATED_SIGNALS", "false")
            resValue("string", "app_name", "하원콜")
        }
    }
    buildTypes {
        release { isMinifyEnabled = false }
        debug { applicationIdSuffix = ".debug" }
    }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    useLibrary("android.car")
    testOptions { unitTests.isReturnDefaultValues = true }
}
dependencies {
    implementation(project(":core"))
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
    testImplementation("junit:junit:4.13.2")
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")
}
val pleosDependencies = file("pleos-dependencies.gradle.kts")
if (pleosDependencies.exists()) apply(from = pleosDependencies)
dependencies { testImplementation("org.json:json:20240303") }
