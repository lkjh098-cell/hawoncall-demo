package ai.hawoncall.car.platform

import android.content.Context
import ai.hawoncall.core.Gear

/** All signals in this flavor are simulated. It is not the Pleos Virtual Console demo. */
class DemoPlatformSignals : PlatformSignals {
    private var listener: SignalListener? = null
    override fun connect(listener: SignalListener) {
        this.listener = listener
        listener.onGear(Gear.PARK)
        listener.onCapabilities(true, true)
        listener.onUxRestricted(false)
        listener.onStatus("모든 차량·내비 신호가 모의인 시연 빌드")
        listener.onNavigationState(NavigationStatus(message = "모의 시연 · 실제 내비 연결 없음"))
    }
    override fun route(destination: Destination) {
        listener?.onStatus("모의 경로 요청 · 실제 내비로 전송하지 않음: ${destination.name}")
    }
    override fun openNavigation() { listener?.onStatus("모의 시연 · 실제 내비 화면 연결 없음") }
    override fun pollNavigation() = Unit
    override fun close() { listener = null }
}
fun createPlatformSignals(context: Context, academy: Destination): PlatformSignals = DemoPlatformSignals()
