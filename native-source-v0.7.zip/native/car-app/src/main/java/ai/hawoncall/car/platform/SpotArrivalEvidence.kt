package ai.hawoncall.car.platform

import ai.hawoncall.core.PickupSpot
import kotlin.math.*

/** Ephemeral real Pleos Fused coordinates. Never persisted or sent to the server. */
data class FusedPositionObservation(
    val latitude: Double, val longitude: Double, val timestampMillis: Long,
    val accuracyMeters: Double? = null,
)
data class SpotArrivalEvidence(val spotId: String, val observedAtMillis: Long, val distanceMeters: Double, val accuracyMeters: Double?)

object SpotArrivalEvidencePolicy {
    fun evidence(spot: PickupSpot?, position: FusedPositionObservation?, nowMillis: Long, observationAgeMillis: Long): SpotArrivalEvidence? {
        if (spot == null || position == null || observationAgeMillis !in 0..30_000 || nowMillis - position.timestampMillis !in 0..30_000) return null
        if (!position.latitude.isFinite() || position.latitude !in -90.0..90.0 || !position.longitude.isFinite() || position.longitude !in -180.0..180.0) return null
        if (position.accuracyMeters != null && (!position.accuracyMeters.isFinite() || position.accuracyMeters !in 0.0..20.0)) return null
        val lat1=Math.toRadians(position.latitude); val lat2=Math.toRadians(spot.latitude)
        val dLat=lat2-lat1; val dLon=Math.toRadians(spot.longitude-position.longitude)
        val h=(sin(dLat/2).pow(2)+cos(lat1)*cos(lat2)*sin(dLon/2).pow(2)).coerceIn(0.0,1.0)
        val distance=6_371_000.0*2*atan2(sqrt(h),sqrt(1-h))
        if (distance > 30.0) return null
        return SpotArrivalEvidence(spot.id,position.timestampMillis,distance,position.accuracyMeters)
    }
}

/** Counts only observed fresh point proximity while P. Motion and stale gaps add no dwell. */
class SpotDwellTracker {
    private var totalMillis=0L
    private var since: Long?=null
    private var validUntil=0L
    fun reset() { totalMillis=0; since=null; validUntil=0 }
    private fun accrue(at: Long) {
        since?.let { start ->
            val end=minOf(at,validUntil).coerceAtLeast(start)
            totalMillis+=(end-start)
            since=if (at<validUntil) at else null
        }
    }
    fun observe(at: Long, eligible: Boolean, validForMillis: Long = 30_000) {
        accrue(at)
        if (!eligible) { since=null; return }
        since=at
        validUntil=at+validForMillis.coerceIn(0,30_000)
    }
    fun pause(at: Long) { accrue(at); since=null }
    fun seconds(at: Long): Long { accrue(at); return totalMillis/1_000 }
}
