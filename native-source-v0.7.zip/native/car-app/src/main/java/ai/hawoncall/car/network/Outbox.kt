package ai.hawoncall.car.network

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.time.Instant
import java.util.UUID
import java.util.concurrent.TimeUnit

interface TextStore { fun read(): String; fun write(value: String) }
class ApiFailure(val status: Int, message: String, val code: String = "") : IOException(message)
class ConfigurationChangedFailure(message: String) : IOException(message)

/** A single durable document commits a command together with its trip-id mappings.
 * Idempotency keys survive retries and process death. Unsafe legacy boarding is quarantined, never relabeled as confirmed.
 */
class Outbox(private val store: TextStore, private val baseUrl: String, private val token: String,
             private val client: OkHttpClient = OkHttpClient.Builder().followRedirects(false).followSslRedirects(false).callTimeout(8, TimeUnit.SECONDS).build()) {
    private var data = runCatching { JSONObject(store.read()) }.getOrElse { error ->
        if (store.read().isBlank()) JSONObject() else throw IOException("전송 기록을 읽을 수 없습니다", error)
    }
    init {
        if (!data.has("queue")) data.put("queue", JSONArray())
        if (!data.has("trips")) data.put("trips", JSONObject())
        val queue = data.getJSONArray("queue")
        val unsafe = (0 until queue.length()).filter { index ->
            val body = queue.getJSONObject(index).optJSONObject("body")
            body != null && body.optString("type") in setOf("BOARDED", "HANDED_OVER") && body.optString("confirmation") != "GUARDIAN"
        }
        if (unsafe.isNotEmpty()) commit { draft ->
            if (!draft.has("confirmationRequired")) draft.put("confirmationRequired", JSONArray())
            for (index in unsafe) {
                val command = draft.getJSONArray("queue").getJSONObject(index)
                // Retain the original evidence locally. It cannot be sent as guardian-confirmed.
                draft.getJSONArray("confirmationRequired").put(JSONObject(command.toString()))
                command.put("body", JSONObject().put("eventId", UUID.randomUUID().toString())
                    .put("type", "CANCEL").put("at", Instant.now().toString()))
                if (draft.optString("activeClientId") == command.getString("clientTripId")) {
                    draft.put("activeClientId", "")
                }
            }
        }
    }
    /** Old sensor-only records retained for review; their trips are queued for cancellation. */
    @Synchronized fun confirmationRequired(): Int = data.optJSONArray("confirmationRequired")?.length() ?: 0
    @Synchronized fun configurationConflict(): Boolean = data.optString("blockedCode") == "LINK_CONFIGURATION_CHANGED"
    @Synchronized fun pending(): Int = data.getJSONArray("queue").length()
    @Synchronized fun activeClientId(): String = data.optString("activeClientId")
    @Synchronized fun activeServerId(): String? = data.getJSONObject("trips").optString(activeClientId()).takeIf { it.isNotBlank() }
    @Synchronized fun begin(linkId: String, journeyType: String = "PICKUP", institutionType: String = "ACADEMY", serviceArea: String = "SEOUL"): String {
        check(!configurationConflict()) { "연결 설정 변경 기록을 먼저 보관해 주세요" }
        require(journeyType in setOf("PICKUP", "DROPOFF"))
        require(institutionType in setOf("SCHOOL", "KINDERGARTEN", "DAYCARE", "ACADEMY"))
        require(serviceArea == "SEOUL")
        check(activeClientId().isBlank()) { "이전 픽업 처리가 남아 있습니다" }
        val id = UUID.randomUUID().toString()
        commit { draft ->
            draft.put("activeClientId", id)
            draft.getJSONArray("queue").put(JSONObject().put("kind", "CREATE").put("clientTripId", id).put("linkId", linkId).put("journeyType", journeyType).put("institutionType", institutionType).put("serviceArea", serviceArea))
        }
        return id
    }
    @Synchronized fun event(type: String, etaMin: Int? = null, arrivalSpotEvidence: JSONObject? = null) {
        require(arrivalSpotEvidence == null || type in setOf("ARRIVED", "BOARDED", "HANDED_OVER"))
        val id = activeClientId()
        check(id.isNotBlank()) { "픽업이 시작되지 않았습니다" }
        val body = JSONObject().put("eventId", UUID.randomUUID().toString()).put("type", type)
            .put("at", Instant.now().toString())
        if (etaMin != null) body.put("etaMin", etaMin)
        if (arrivalSpotEvidence != null) body.put("arrivalSpotEvidence", JSONObject(arrivalSpotEvidence.toString()))
        // Terminal child completion effects only follow explicit guardian confirmation.
        if (type in setOf("BOARDED", "HANDED_OVER")) body.put("confirmation", "GUARDIAN")
        commit { draft ->
            if (type in setOf("BOARDED", "HANDED_OVER", "CANCEL")) draft.put("activeClientId", "")
            draft.getJSONArray("queue").put(JSONObject().put("kind", "EVENT").put("clientTripId", id).put("body", body))
        }
    }
    @Synchronized fun finishLocal() {
        if (activeClientId().isNotBlank()) commit { it.put("activeClientId", "") }
    }
    /** User-authorized recovery archives old-identity commands locally. They can never drain under a new token. */
    @Synchronized fun quarantineForRePairing(reason: String = "CAR_AUTHORIZATION_REVOKED"): Int {
        val count = pending()
        commit { draft ->
            val archive = draft.optJSONArray("credentialQuarantine") ?: JSONArray().also { draft.put("credentialQuarantine", it) }
            if (count > 0 || draft.optString("activeClientId").isNotBlank()) archive.put(JSONObject()
                .put("at", Instant.now().toString()).put("reason", reason)
                .put("queue", JSONObject(draft.toString()).getJSONArray("queue"))
                .put("trips", JSONObject(draft.toString()).getJSONObject("trips"))
                .put("activeClientId", draft.optString("activeClientId")))
            draft.put("queue", JSONArray()).put("trips", JSONObject()).put("activeClientId", "").remove("blockedCode")
        }
        return count
    }
    /** The current document changes only after the replacement is durable. Caller owns the lock. */
    private fun commit(change: (JSONObject) -> Unit) {
        val draft = JSONObject(data.toString())
        change(draft)
        store.write(draft.toString())
        data = draft
    }
    /** Serialize all drains on one executor; producers may append while HTTP is in flight. */
    fun drainOne(): Boolean {
        val command = synchronized(this) {
            if (configurationConflict()) throw ConfigurationChangedFailure("연결 설정이 변경됐어요. 주차 후 기록을 보관하고 다시 연결해 주세요")
            if (pending() == 0) return false
            JSONObject(data.getJSONArray("queue").getJSONObject(0).toString())
        }
        val localId = command.getString("clientTripId")
        val result = try { if (command.getString("kind") == "CREATE") {
            request("POST", "/api/trips", JSONObject().put("linkId", command.getString("linkId")).put("clientTripId", localId)
                .put("journeyType", command.optString("journeyType", "PICKUP"))
                .put("institutionType", command.optString("institutionType", "ACADEMY"))
                .put("serviceArea", command.optString("serviceArea", "SEOUL")))
        } else {
            val serverId = synchronized(this) { data.getJSONObject("trips").getString(localId) }
            request("POST", "/api/trips/$serverId/events", command.getJSONObject("body"))
        }
        } catch (failure: ApiFailure) {
            if (command.getString("kind") == "CREATE" && failure.status == 409 && failure.code == "LINK_CONFIGURATION_CHANGED") {
                synchronized(this) { commit { it.put("blockedCode", failure.code) } }
                throw ConfigurationChangedFailure(failure.message.orEmpty())
            }
            throw failure
        }
        synchronized(this) {
            commit { draft ->
                if (command.getString("kind") == "CREATE") draft.getJSONObject("trips").put(localId, result.getJSONObject("trip").getString("id"))
                draft.getJSONArray("queue").remove(0)
                // Producers may append while HTTP is in flight; retain every appended command.
                if (draft.getJSONArray("queue").length() == 0) {
                    val ids = draft.getJSONObject("trips")
                    ids.keys().asSequence().toList().filter { it != draft.optString("activeClientId") }.forEach(ids::remove)
                }
            }
        }
        return true
    }
    fun request(method: String, path: String, body: JSONObject? = null): JSONObject {
        val builder = Request.Builder().url(baseUrl.trimEnd('/') + path).header("Authorization", "Bearer $token")
        if (method != "GET") builder.method(method, (body ?: JSONObject()).toString().toRequestBody("application/json".toMediaType()))
        client.newCall(builder.build()).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val errorBody = runCatching { JSONObject(raw) }.getOrNull()
                val detail = errorBody?.optString("message").orEmpty()
                throw ApiFailure(response.code, detail.ifBlank { "서버 응답 ${response.code}" }, errorBody?.optString("code").orEmpty())
            }
            return if (raw.isBlank()) JSONObject() else JSONObject(raw)
        }
    }
}
