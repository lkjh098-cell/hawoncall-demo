package ai.hawoncall.car

import android.app.Application
import androidx.lifecycle.AndroidViewModel

/** UI holder only. Pickup lifetime belongs to the application session and foreground service. */
class CarViewModel(app: Application) : AndroidViewModel(app) {
    val session: CarSession = (app as HawonApplication).session
}
