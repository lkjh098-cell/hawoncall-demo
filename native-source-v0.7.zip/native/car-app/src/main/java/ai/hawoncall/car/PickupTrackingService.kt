package ai.hawoncall.car

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder

/** Visible, user-started pickup lifetime. Never starts an activity or alters a navigation route. */
class PickupTrackingService : Service() {
    override fun onCreate() {
        super.onCreate()
        val manager=getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL,"픽업 진행 상태",NotificationManager.IMPORTANCE_LOW).apply {
            description="내비 사용 중에도 보호자 확인 전까지 픽업 상태를 유지해요"
            setSound(null,null)
            enableVibration(false)
            setShowBadge(false)
        })
        val intent=Intent(this,MainActivity::class.java)
        val pending=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification=Notification.Builder(this,CHANNEL)
            .setSmallIcon(ai.hawoncall.car.R.drawable.ic_notification)
            .setContentTitle("하원콜 픽업 진행 중")
            .setContentText("기존 내비 경로를 유지하며 하원 상태를 확인해요")
            .setContentIntent(pending).setOngoing(true).setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE).build()
        try { startForeground(31,notification) }
        catch (failure: Exception) {
            (application as HawonApplication).session.onTrackingServiceEnded()
            stopSelf()
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        (application as HawonApplication).session.onTrackingServiceEnded()
        super.onDestroy()
    }
    companion object { private const val CHANNEL="pickup_tracking" }
}
