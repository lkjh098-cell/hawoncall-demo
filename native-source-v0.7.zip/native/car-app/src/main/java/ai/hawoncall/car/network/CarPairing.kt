package ai.hawoncall.car.network

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URI
import java.util.Locale
import java.util.concurrent.TimeUnit

/** The production transport stays HTTPS; only the existing debug loopback endpoints are exempt. */
object CarPairingPolicy {
    fun serverUrl(input: String, debug: Boolean): String? {
        val value = input.trim().trimEnd('/')
        val uri = runCatching { URI(value) }.getOrNull() ?: return null
        if (uri.host.isNullOrBlank() || uri.rawUserInfo != null || uri.rawQuery != null || uri.rawFragment != null || !uri.rawPath.isNullOrBlank()) return null
        if (uri.scheme == "https") return value
        return value.takeIf { debug && it in setOf("http://10.0.2.2:3000", "http://localhost:3000", "http://127.0.0.1:3000") }
    }
    fun code(input: String): String? = input.trim().uppercase(Locale.ROOT)
        .takeIf { it.matches(Regex("[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{8}")) }
}

/** Blocking transport: callers must invoke on an IO dispatcher, never the UI thread. */
class CarPairingClient(private val client: OkHttpClient = OkHttpClient.Builder().followRedirects(false).followSslRedirects(false).callTimeout(10, TimeUnit.SECONDS).build()) {
    fun claim(baseUrl: String, code: String): JSONObject {
        val body = JSONObject().put("code", code).toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder().url("${baseUrl.trimEnd('/')}/api/car/pairing").post(body).build()
        return client.newCall(request).execute().use { response ->
            val payload = runCatching { JSONObject(response.body?.string().orEmpty()) }.getOrNull()
            if (!response.isSuccessful) {
                throw IllegalStateException(when (response.code) {
                    409 -> "진행 중인 픽업을 마친 후 다시 연결해 주세요"
                    429 -> "연결 요청이 많아요. 잠시 후 다시 시도해 주세요"
                    400 -> "연결 코드가 만료되었거나 이미 사용됐어요. 휴대폰에서 새 코드를 발급해 주세요"
                    else -> "서버 연결을 확인하고 다시 시도해 주세요"
                })
            }
            check(payload != null && payload.optString("carToken").isNotBlank() && listOf("id", "childName", "academyName").all { payload.optJSONObject("link")?.optString(it)?.isNotBlank() == true }) { "차량 연결 응답을 확인할 수 없어요" }
            payload
        }
    }
}
