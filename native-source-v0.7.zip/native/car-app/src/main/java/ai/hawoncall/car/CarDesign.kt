package ai.hawoncall.car

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal val Navy = Color(0xFF101C2D)
internal val ActionBlue = Color(0xFF70E4E2)
internal val MainText = Color(0xFFF2F7FF)
internal val Muted = Color(0xFFA2B4C8)
internal val Paper = Color(0xFF080F1B)
internal val Border = Color(0xFF26364B)
internal val BlueTint = Color(0xFF16383F)
internal val StateGreen = Color(0xFF9DE6C3)

@Composable internal fun DesignCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(26.dp), border = BorderStroke(1.dp, Border), colors = CardDefaults.cardColors(containerColor = Navy)) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp), content = content)
    }
}

@Composable internal fun InfoPill(text: String, color: Color = ActionBlue, tint: Color = BlueTint) {
    Text(text, Modifier.background(tint, RoundedCornerShape(50)).padding(horizontal = 13.dp, vertical = 8.dp), color = color, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
}

@Composable internal fun SectionHeading(title: String, description: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = MainText)
        if (description != null) Text(description, fontSize = 17.sp, color = Muted, lineHeight = 26.sp)
    }
}
