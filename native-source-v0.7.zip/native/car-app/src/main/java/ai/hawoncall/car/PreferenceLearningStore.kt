package ai.hawoncall.car

import android.content.SharedPreferences
import ai.hawoncall.core.*
import org.json.JSONObject

/** Learned values and deduplication IDs are committed in one preferences transaction. */
class PreferenceLearningStore(private val prefs: SharedPreferences) : LearningStore {
    private fun key(k: LearningKey) = "${k.academyId}|${k.childId}|${k.weekday}" + if (k.journeyType == JourneyType.PICKUP) "" else "|${k.journeyType.name}"
    private fun data() = JSONObject(prefs.getString("learning", "{}").orEmpty())
    @Synchronized override fun durationSeconds(key: LearningKey, initialSeconds: Long): Long =
        data().optJSONObject(key(key))?.optLong("duration", initialSeconds)?.coerceIn(60,1200) ?: initialSeconds.coerceIn(60,1200)
    @Synchronized override fun record(key: LearningKey, waitSeconds: Long, initialSeconds: Long, sampleId: String): Long {
        require(waitSeconds >= 0)
        val all = data()
        val record = all.optJSONObject(key(key)) ?: JSONObject()
        val current = record.optLong("duration", initialSeconds).coerceIn(60,1200)
        val samples = record.optJSONObject("samples") ?: JSONObject()
        if (samples.has(sampleId)) return current
        val next = when { waitSeconds > 60 -> current + ((waitSeconds - 30) / 2).coerceAtMost(1200); waitSeconds <= 30 -> current - 30; else -> current }.coerceIn(60,1200)
        samples.put(sampleId, true)
        record.put("duration",next).put("samples",samples)
        all.put(key(key),record)
        check(prefs.edit().putString("learning",all.toString()).commit()) { "학습값 저장 실패" }
        return next
    }
}
