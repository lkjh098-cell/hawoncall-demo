package ai.hawoncall.car

import android.app.Application

class HawonApplication : Application() {
    val session: CarSession by lazy { CarSession(this) }
}
