package ai.hawoncall.car.platform

import ai.hawoncall.core.Gear
import android.location.Location
import android.os.Handler
import android.os.Looper
import java.io.Closeable

/** Debug-only navigation fallback. It never creates vehicle/location signals or OEM routes. */
internal class NavigationOnlyDemo(
    private val academy: Destination,
    private val emit: ((SignalListener) -> Unit) -> Unit,
) : Closeable {
    private val timer = Handler(Looper.getMainLooper())
    private var gear = Gear.UNKNOWN
    private var uxRestricted = true
    private var activeAcademyRoute = false
    private var remainingSeconds = 600L
    private var closed = false
    private val tick = object : Runnable {
        override fun run() {
            if (closed || !activeAcademyRoute) return
            if (gear == Gear.DRIVE) {
                remainingSeconds = (remainingSeconds - 30).coerceAtLeast(0)
                emitState()
                val eta = remainingSeconds
                emit { it.onEta(eta) }
                if (eta == 0L) {
                    emit {
                        it.onStatus("내비 모의 도착 · 탑승 판정은 실제 P·후석 센서 필요")
                        it.onArrived()
                    }
                    activeAcademyRoute = false
                    emitState()
                    return
                }
            }
            timer.postDelayed(this, 1_000)
        }
    }

    fun connect() {
        if (!closed) emitState()
    }

    fun onGear(value: Gear) {
        if (closed) return
        val startedDriving = gear != Gear.DRIVE && value == Gear.DRIVE
        gear = value
        if (activeAcademyRoute && startedDriving) {
            emitState()
            emit { it.onEta(remainingSeconds) }
        }
    }

    fun onUxRestricted(value: Boolean) { uxRestricted = value }

    /** An explicit developer simulation action only; pickup start does not call this. */
    fun route(destination: Destination) {
        if (closed) return
        if (gear != Gear.PARK || uxRestricted) {
            emit { it.onStatus("내비 모의 시작도 정차 후 사용할 수 있습니다") }
            return
        }
        timer.removeCallbacks(tick)
        activeAcademyRoute = false
        if (!destination.latitude.isFinite() || !destination.longitude.isFinite() ||
            destination.latitude !in -90.0..90.0 || destination.longitude !in -180.0..180.0) {
            emitState()
            emit { it.onStatus("내비 모의 목적지 좌표 오류") }
            return
        }
        val distance = FloatArray(1)
        Location.distanceBetween(academy.latitude, academy.longitude,
            destination.latitude, destination.longitude, distance)
        if (distance[0] > 75f || destination.name != academy.name) {
            emitState()
            emit { it.onStatus("다른 목적지 모의 입력 · 실제 내비 경로를 변경하지 않음") }
            return
        }
        remainingSeconds = 600
        activeAcademyRoute = true
        emitState()
        emit {
            it.onDestinationChanged(true)
            it.onStatus("내비만 모의 시연 · 실제 기어 D에서 1초마다 ETA 30초 감소")
        }
        timer.postDelayed(tick, 1_000)
    }

    private fun emitState() {
        val state = NavigationStatus(
            connected = true,
            active = activeAcademyRoute,
            academyMatched = activeAcademyRoute,
            destinationName = if (activeAcademyRoute) academy.name else "",
            remainingSeconds = if (activeAcademyRoute) remainingSeconds else null,
            routeKey = if (activeAcademyRoute) "DEBUG-SIMULATION" else "",
            message = "내비만 모의 시연 · 실제 OEM 내비 수신 아님",
            verified = activeAcademyRoute,
        )
        emit { it.onNavigationState(state) }
    }

    override fun close() {
        closed = true
        activeAcademyRoute = false
        timer.removeCallbacksAndMessages(null)
    }
}
