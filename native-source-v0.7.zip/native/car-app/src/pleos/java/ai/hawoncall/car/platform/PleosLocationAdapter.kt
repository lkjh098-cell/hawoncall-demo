package ai.hawoncall.car.platform

import ai.pleos.playground.location.fused.FusedLocation
import ai.pleos.playground.location.fused.listener.FusedLocationListener
import ai.pleos.playground.location.fused.listener.ProximityAlertListener
import ai.pleos.playground.location.fused.model.LocationData
import ai.pleos.playground.location.fused.model.ProximityAlertEvent
import ai.pleos.playground.location.fused.model.ProximityAlertRequest
import ai.pleos.playground.location.fused.model.ProximityTransition
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import java.io.Closeable

internal class PleosLocationAdapter(
    private val context: Context,
    private val academy: Destination,
    private val emit: ((SignalListener) -> Unit) -> Unit,
) : Closeable {
    private val fused = FusedLocation(context)
    private var initialized = false
    @Volatile private var closed = false
    private var alertId: String? = null
    private val callback = object : FusedLocationListener {
        override fun onChanged(location: LocationData?) {
            if (closed || location == null) return
            if (!location.latitude.isFinite() || !location.longitude.isFinite() ||
                location.latitude !in -90.0..90.0 || location.longitude !in -180.0..180.0) return
            // An old last-known location must never manufacture a fresh arrival.
            val ageMillis = System.currentTimeMillis() - location.timestampMillis
            if (ageMillis !in 0..30_000) return
            val result = FloatArray(1)
            Location.distanceBetween(location.latitude, location.longitude,
                academy.latitude, academy.longitude, result)
            emit {
                // SDK 1.1.3 exposes confidence, not accuracy in meters. Do not reinterpret it.
                it.onFusedPosition(FusedPositionObservation(location.latitude,location.longitude,location.timestampMillis))
                it.onDistance(result[0].toDouble())
            }
        }
        override fun onError(exception: Exception) = failure("위치 수신", exception)
    }
    private val proximity = object : ProximityAlertListener {
        override fun onRegistered(alertId: String) {
            if (closed) runCatching { fused.removeProximityAlert(alertId) }
            else this@PleosLocationAdapter.alertId = alertId
        }
        override fun onTransition(event: ProximityAlertEvent) {
            if (!closed && event.transition == ProximityTransition.ENTER) emit { it.onProximityEntered() }
        }
        override fun onError(exception: Exception) = failure("근접 알림", exception)
    }

    fun connect() {
        if (closed || initialized) return
        if (context.checkSelfPermission(PERMISSION) != PackageManager.PERMISSION_GRANTED) {
            emit { it.onStatus("FusedLocation 권한 동의 필요 · 위치 미연결") }
            return
        }
        attempt("FusedLocation 초기화") {
            if (!fused.isSupported()) {
                emit { it.onStatus("이 기기에는 Pleos FusedLocation 서비스가 없습니다") }
                return@attempt
            }
            fused.initialize()
            initialized = true
            fused.registerFusedLocationCallback(callback)
            fused.addProximityAlert(ProximityAlertRequest(
                latitude = academy.latitude,
                longitude = academy.longitude,
                radiusMeters = 150f,
                transitionTypes = setOf(ProximityTransition.ENTER),
            ), proximity)
            fused.getLastKnownLocation(callback)
        }
    }

    fun poll() {
        if (closed) return
        if (!initialized) connect()
        if (initialized) attempt("마지막 위치 조회") { fused.getLastKnownLocation(callback) }
    }

    private fun failure(operation: String, error: Exception) =
        emit { it.onStatus("$operation 실패: ${error.javaClass.simpleName}") }
    private inline fun attempt(operation: String, block: () -> Unit) {
        try { block() } catch (error: Exception) { failure(operation, error) }
    }

    override fun close() {
        closed = true
        if (initialized) {
            alertId?.let { runCatching { fused.removeProximityAlert(it) } }
            runCatching { fused.unregisterFusedLocationCallback(callback) }
            runCatching { fused.release() }
        }
    }

    companion object { const val PERMISSION = "pleos.car.permission.FUSED_LOCATION" }
}
