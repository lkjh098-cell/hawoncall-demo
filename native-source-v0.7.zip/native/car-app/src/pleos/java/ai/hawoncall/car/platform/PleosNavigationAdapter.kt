package ai.hawoncall.car.platform

import ai.hawoncall.core.Gear
import ai.pleos.playground.navi.constants.NaviErrorCode
import ai.pleos.playground.navi.constants.NavigationStatus as SdkNavigationStatus
import ai.pleos.playground.navi.data.DestinationArrivedInfo
import ai.pleos.playground.navi.data.DestinationInfo
import ai.pleos.playground.navi.data.NavigationScreenRequest
import ai.pleos.playground.navi.data.RouteInfo
import ai.pleos.playground.navi.data.RouteStateInfo
import ai.pleos.playground.navi.data.RouteStartInfo
import ai.pleos.playground.navi.helper.NaviHelper
import ai.pleos.playground.navi.helper.listener.NaviHelperEventListener
import android.content.Context
import android.location.Location
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.io.Closeable
import java.util.Locale

/** Observes the OEM route. Connecting, polling and pickup state changes never mutate it. */
internal class PleosNavigationAdapter(
    context: Context,
    private val academy: Destination,
    private val emit: ((SignalListener) -> Unit) -> Unit,
) : Closeable {
    private val helper = NaviHelper(context)
    private val main = Handler(Looper.getMainLooper())
    private var initialized = false
    private var connecting = false
    @Volatile private var closed = false
    private var gear = Gear.UNKNOWN
    private var uxRestricted = true
    private var activeRoute: Boolean? = null
    private var routeStateAt = 0L
    private var lastDestination: DestinationInfo? = null
    private var destinationAt = 0L
    private var candidateKey = ""
    private var candidateFirstAt = 0L
    private var consistentSnapshots = 0
    private var destinationIsAcademy = false
    private var lastStatus = NavigationStatus()
    private val expire = Runnable { publish() }

    private val callback = object : NaviHelperEventListener {
        override fun onDestinationChanged() = onMain {
            invalidate("내비 목적지 변경 · 새 목적지 확인 중", notifyChange = true)
            activeRoute = null
            routeStateAt = 0L
            pollConnected()
        }

        override fun onDestinationInfo(destinationInfo: DestinationInfo) = onMain {
            if (!validCoordinates(destinationInfo.latitude, destinationInfo.longitude)) {
                invalidate("내비 목적지 좌표 확인 필요", notifyChange = true)
                return@onMain
            }
            val now = SystemClock.elapsedRealtime()
            val nextKey = key(destinationInfo)
            if (candidateKey != nextKey) {
                val replacingKnownDestination = candidateKey.isNotEmpty()
                invalidate("내비 목적지 확인 중", notifyChange = replacingKnownDestination)
                candidateKey = nextKey
                candidateFirstAt = now
                consistentSnapshots = 1
                // A destination callback cannot establish whether guidance is active.
                // In a changed route, ask the provider again before accepting ETA.
                if (replacingKnownDestination) {
                    activeRoute = null
                    routeStateAt = 0L
                    attempt("내비 경로 상태 조회") { helper.getRouteStateInfo() }
                }
            } else if (now - candidateFirstAt >= CONSISTENCY_DELAY_MS) {
                consistentSnapshots++
            }
            lastDestination = destinationInfo
            destinationAt = now
            publish()
        }

        override fun onRouteStateInfo(routeStateInfo: RouteStateInfo) = onMain {
            activeRoute = routeStateInfo.isRouting
            routeStateAt = SystemClock.elapsedRealtime()
            if (!routeStateInfo.isRouting) {
                invalidate("기존 내비 경로 없음 · 내비에서 목적지를 설정하세요", notifyChange = destinationIsAcademy)
            }
            publish()
        }

        override fun onRouteStarted(routeStartInfo: RouteStartInfo) = onMain {
            activeRoute = null
            routeStateAt = 0L
            invalidate("내비 경로 탐색 중 · ETA 보류", notifyChange = false)
        }

        override fun onNavigationStatus(status: SdkNavigationStatus) = onMain {
            when (status) {
                SdkNavigationStatus.INACTIVE, SdkNavigationStatus.FREE_DRIVE -> {
                    activeRoute = false
                    routeStateAt = SystemClock.elapsedRealtime()
                    invalidate("기존 내비 경로 없음 · 내비에서 목적지를 설정하세요", notifyChange = destinationIsAcademy)
                }
                SdkNavigationStatus.INITIALIZING -> {
                    activeRoute = null
                    routeStateAt = 0L
                    invalidate("기존 내비 준비 중 · ETA 보류", notifyChange = false)
                }
                SdkNavigationStatus.ROUTE_DRIVE -> pollConnected()
            }
        }

        override fun onRoutingCompleted() = onMain {
            invalidate("내비 경로 확인 중", notifyChange = true)
            activeRoute = null
            routeStateAt = 0L
            pollConnected()
        }

        override fun onReRouteEnded() = onMain {
            invalidate("내비 재탐색 완료 · ETA 재확인 중", notifyChange = false)
            activeRoute = null
            routeStateAt = 0L
            pollConnected()
        }

        override fun onDestinationArrived(destinationArrivedInfo: DestinationArrivedInfo) = onMain {
            val info = lastDestination
            val sameName = info != null && normalize(info.name) == normalize(destinationArrivedInfo.name)
            val sameAddress = info != null && (info.address.isBlank() || destinationArrivedInfo.address.isBlank() ||
                normalize(info.address) == normalize(destinationArrivedInfo.address))
            if (isFresh() && destinationIsAcademy && sameName && sameAddress) emit { it.onArrived() }
        }

        override fun onRouteCancelled() = onMain {
            activeRoute = false
            routeStateAt = SystemClock.elapsedRealtime()
            invalidate("내비 경로 취소됨", notifyChange = false)
            emit { it.onNavigationCancelled() }
        }

        override fun onError(errorCode: NaviErrorCode) = onMain {
            activeRoute = null
            routeStateAt = 0L
            invalidate("내비 오류 · ETA 확인 중: $errorCode", notifyChange = false)
        }
    }

    fun onGear(value: Gear) = onMain { gear = value }
    fun onUxRestricted(value: Boolean) = onMain { uxRestricted = value }

    fun connect() = onMain {
        if (initialized || connecting) return@onMain
        connecting = true
        emitState(NavigationStatus(message = "기존 내비 연결 중"))
        try {
            helper.initialize(onConnected = {
                onMain {
                    connecting = false
                    initialized = true
                    helper.addListener(callback)
                    publish("기존 내비 상태 확인 중")
                    pollConnected()
                }
            }, onFailed = { error ->
                onMain { connectionFailed("내비 서비스 연결 실패: ${error.javaClass.simpleName}") }
            })
        } catch (error: Exception) {
            connectionFailed("내비 서비스 초기화 실패: ${error.javaClass.simpleName}")
        }
    }

    private fun connectionFailed(message: String) {
        connecting = false
        initialized = false
        activeRoute = null
        invalidate(message, notifyChange = false)
        emit { it.onStatus(message) }
    }

    /** This build is an observer: even an accidental call cannot replace an OEM route. */
    fun route(destination: Destination) = onMain {
        emit { it.onStatus("순정 내비 경로 유지 모드 · 목적지 변경은 순정 내비에서 해주세요") }
    }

    /** Called only by the user's foreground-navigation button. */
    fun openNavigation() = onMain {
        if (!safeForUserAction()) return@onMain
        attempt("기존 내비 열기") {
            helper.requestNavigationScreen(NavigationScreenRequest.Foreground)
            emit { it.onStatus("기존 내비 화면 열기 요청 · 현재 경로 유지") }
        }
    }

    private fun safeForUserAction(): Boolean {
        if (gear != Gear.PARK || uxRestricted) {
            emit { it.onStatus("내비 화면 조작은 정차 후 사용할 수 있습니다") }
            return false
        }
        if (!initialized) {
            emit { it.onStatus("내비 연결을 확인하세요 · 요청은 보관하지 않습니다") }
            return false
        }
        return true
    }

    fun poll() = onMain {
        // Expire old values before asking for fresh asynchronous snapshots.
        publish()
        if (!initialized) connect() else pollConnected()
    }

    private fun pollConnected() {
        if (!initialized) return
        attempt("내비 경로 상태 조회") { helper.getRouteStateInfo() }
        attempt("내비 목적지 조회") { helper.getDestinationInfo() }
    }

    private fun invalidate(message: String, notifyChange: Boolean) {
        main.removeCallbacks(expire)
        lastDestination = null
        destinationAt = 0L
        candidateKey = ""
        candidateFirstAt = 0L
        consistentSnapshots = 0
        destinationIsAcademy = false
        if (notifyChange) emit { it.onDestinationChanged(false) }
        publish(message)
    }

    private fun isFresh(): Boolean {
        val now = SystemClock.elapsedRealtime()
        return initialized && activeRoute == true && consistentSnapshots >= 2 &&
            now - routeStateAt in 0..FRESHNESS_MS && now - destinationAt in 0..FRESHNESS_MS
    }

    private fun publish(message: String? = null) {
        val info = lastDestination
        val fresh = isFresh()
        val matched = fresh && info != null && matchesAcademy(info)
        val previousMatch = destinationIsAcademy
        destinationIsAcademy = matched
        val eta = if (fresh && info != null && info.remainTime >= 0) info.remainTime.toLong() else null
        val status = NavigationStatus(
            connected = initialized,
            active = activeRoute == true && SystemClock.elapsedRealtime() - routeStateAt in 0..FRESHNESS_MS,
            academyMatched = matched,
            destinationName = info?.name.orEmpty(),
            destinationLatitude = if (fresh) info?.latitude else null,
            destinationLongitude = if (fresh) info?.longitude else null,
            poiId = if (fresh) info?.poiId.orEmpty() else "",
            poiSubId = if (fresh) info?.poiSubId.orEmpty() else "",
            poiProvider = if (fresh) info?.poiProvider.orEmpty() else "",
            remainingSeconds = eta,
            routeKey = candidateKey,
            message = message ?: when {
                !initialized -> "기존 내비 연결 확인 필요"
                activeRoute == false -> "기존 내비 경로 없음 · 내비에서 목적지를 설정하세요"
                !fresh -> "기존 내비 목적지·ETA 확인 중"
                matched -> "기존 내비의 학원 경로 연결됨"
                else -> "기존 내비의 다른 목적지 경로 유지 중"
            },
            verified = fresh,
        )
        emitState(status)
        if (fresh && info != null) {
            if (matched || previousMatch) emit { it.onDestinationChanged(matched) }
            if (matched && eta != null) emit { it.onEta(eta) }
            main.removeCallbacks(expire)
            val oldest = minOf(routeStateAt, destinationAt)
            main.postDelayed(expire, (FRESHNESS_MS - (SystemClock.elapsedRealtime() - oldest) + 1).coerceAtLeast(1))
        }
    }

    private fun emitState(status: NavigationStatus) {
        // Identical ETA values still refresh the observation lease.
        lastStatus = status
        emit { it.onNavigationState(status) }
    }

    private fun matchesAcademy(info: DestinationInfo): Boolean {
        if (academy.poiId.isNotBlank()) {
            return academy.poiId == info.poiId &&
                (academy.poiSubId.isBlank() || academy.poiSubId == info.poiSubId.orEmpty()) &&
                (academy.poiProvider.isBlank() || academy.poiProvider == info.poiProvider)
        }
        // Coordinate proximity alone can confuse neighbouring academies.
        if (!validCoordinates(academy.latitude, academy.longitude) || academy.name.isBlank() ||
            normalize(academy.name) != normalize(info.name)) return false
        val distance = FloatArray(1)
        Location.distanceBetween(academy.latitude, academy.longitude, info.latitude, info.longitude, distance)
        return distance[0] <= 75f
    }

    private fun key(info: DestinationInfo): String = listOf(
        info.poiProvider, info.poiId, info.poiSubId.orEmpty(), normalize(info.name),
        String.format(Locale.ROOT, "%.6f,%.6f", info.latitude, info.longitude),
    ).joinToString("|")

    private fun normalize(name: String) = name.lowercase(Locale.ROOT).filterNot { it.isWhitespace() }

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            if (!closed) block()
        } else main.post { if (!closed) block() }
    }

    private inline fun attempt(operation: String, block: () -> Unit) {
        try { block() } catch (error: Exception) {
            activeRoute = null
            routeStateAt = 0L
            invalidate("$operation 실패: ${error.javaClass.simpleName}", notifyChange = false)
            emit { it.onStatus("$operation 실패: ${error.javaClass.simpleName}") }
        }
    }

    private fun validCoordinates(latitude: Double, longitude: Double) =
        latitude.isFinite() && longitude.isFinite() &&
            latitude in -90.0..90.0 && longitude in -180.0..180.0

    override fun close() {
        closed = true
        main.removeCallbacksAndMessages(null)
        lastDestination = null
        runCatching { helper.removeListener(callback) }
        runCatching { helper.release() }
        initialized = false
        connecting = false
    }

    private companion object {
        const val FRESHNESS_MS = 15_000L
        const val CONSISTENCY_DELAY_MS = 1_000L
    }
}
