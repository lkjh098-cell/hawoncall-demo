package ai.hawoncall.car.platform

import ai.hawoncall.core.RearSide
import ai.pleos.playground.vehicle.Vehicle
import ai.pleos.playground.vehicle.api.model.area.DoorArea
import ai.pleos.playground.vehicle.api.model.area.SeatArea
import ai.pleos.playground.vehicle.api.model.capability.AccessType
import ai.pleos.playground.vehicle.api.model.capability.AreaBounds
import ai.pleos.playground.vehicle.constant.area.DoorValue
import ai.pleos.playground.vehicle.constant.area.SeatValue
import ai.pleos.playground.vehicle.listener.DoorPositionListener
import ai.pleos.playground.vehicle.listener.SeatBeltBuckledStateListener
import ai.pleos.playground.vehicle.listener.SeatOccupancyListener
import android.content.Context
import android.util.Log
import java.io.Closeable

internal class PleosVehicleAdapter(
    context: Context,
    private val emit: ((SignalListener) -> Unit) -> Unit,
) : Closeable {
    private val settings = context.getSharedPreferences("car-settings", Context.MODE_PRIVATE)
    private val vehicle = Vehicle(context)
    private val door get() = vehicle.getDoor()
    private val seat get() = vehicle.getSeat()
    @Volatile private var closed = false
    private var initialized = false
    private var occupancyPresent = true // unknown stays conservative
    private var beltPresent = true
    private val doorSubscriptions = mutableListOf<Pair<DoorArea, DoorPositionListener>>()
    private val seatSubscriptions = mutableListOf<Pair<SeatArea, SeatOccupancyListener>>()
    private val beltSubscriptions = mutableListOf<Pair<SeatArea, SeatBeltBuckledStateListener>>()

    fun connect() {
        attempt("Vehicle 초기화") {
            vehicle.initialize()
            initialized = true
            inspectDoors()
            inspectSeats()
        }
    }

    private fun inspectDoors() {
        door.checkDoorPositionCapabilities(onComplete = { config, bounds ->
            if (closed) return@checkDoorPositionCapabilities
            if (!config.accessType.readable()) {
                status("후석 문 조회 권한/기능 없음: ${config.accessType}")
                return@checkDoorPositionCapabilities
            }
            for (side in RearSide.entries) {
                val value = if (side == RearSide.LEFT) DoorValue.ROW_2_LEFT else DoorValue.ROW_2_RIGHT
                val area = DoorArea(value)
                val range = bounds.entries.firstOrNull { value in it.key.values }?.value
                if (range == null || range.minValue != 0 || range.maxValue <= 0) {
                    status("$side 후석 문 닫힘 기준 0 확인 필요 또는 미지원")
                    continue
                }
                val callback = object : DoorPositionListener {
                    override fun onPositionUpdated(pos: Int?) = doorValue(side, range, pos)
                    override fun onFailed(e: Exception) = failure("$side 문", e)
                }
                attempt("$side 문 구독") {
                    door.registerDoorPosition(area, callback)
                    doorSubscriptions += area to callback
                    door.getCurrentDoorPosition(area, { doorValue(side, range, it) }, { failure("$side 문 초기값", it) })
                }
            }
        }, onFailed = { failure("문 capabilities", it) })
    }

    private fun inspectSeats() {
        seat.checkSeatOccupancyCapabilities(onComplete = { config, areas ->
            if (closed) return@checkSeatOccupancyCapabilities
            val available = if (config.accessType.readable()) supportedSides(areas) else emptyList()
            occupancyPresent = !config.accessType.readable() || available.isNotEmpty()
            capabilities()
            if (!config.accessType.readable()) status("착석 조회 권한/기능 미확인: ${config.accessType}")
            if (available.isNotEmpty() && !settings.getBoolean("occupancyMappingVerified", false)) {
                status("착석 센서 연결됨 · Empty/Occupied 실측 미확인으로 자동 판정 보류")
            }
            available.forEach { (side, area) ->
                val callback = object : SeatOccupancyListener {
                    override fun onSeatOccupancyUpdated(occupancy: Boolean?) = this@PleosVehicleAdapter.occupancy(side, occupancy)
                    override fun onFailed(e: Exception) = failure("$side 착석", e)
                }
                attempt("$side 착석 구독") {
                    seat.registerSeatOccupancy(area, callback)
                    seatSubscriptions += area to callback
                    seat.getCurrentSeatOccupancy(area, { occupancy(side, it) }, { failure("$side 착석 초기값", it) })
                }
            }
        }, onFailed = { failure("착석 capabilities (기능 없음으로 취급하지 않음)", it) })
        seat.checkSeatBeltBuckledCapabilities(onComplete = { config, areas ->
            if (closed) return@checkSeatBeltBuckledCapabilities
            val available = if (config.accessType.readable()) supportedSides(areas) else emptyList()
            beltPresent = !config.accessType.readable() || available.isNotEmpty()
            if (!config.accessType.readable()) status("벨트 조회 권한/기능 미확인: ${config.accessType}")
            capabilities()
            available.forEach { (side, area) ->
                val callback = object : SeatBeltBuckledStateListener {
                    override fun onSeatBeltBuckledStateUpdated(state: Boolean?) = belt(side, state)
                    override fun onFailed(e: Exception) = failure("$side 벨트", e)
                }
                attempt("$side 벨트 구독") {
                    seat.registerSeatBeltBuckledState(area, callback)
                    beltSubscriptions += area to callback
                    seat.getCurrentSeatBeltBuckledState(area, { belt(side, it) }, { failure("$side 벨트 초기값", it) })
                }
            }
        }, onFailed = { failure("벨트 capabilities (기능 없음으로 취급하지 않음)", it) })
    }

    private fun supportedSides(areas: List<SeatArea>): List<Pair<RearSide, SeatArea>> =
        RearSide.entries.mapNotNull { side ->
            val value = if (side == RearSide.LEFT) SeatValue.ROW_2_LEFT else SeatValue.ROW_2_RIGHT
            if (areas.any { value in it.values }) side to SeatArea(value) else null
        }

    private fun doorValue(side: RearSide, bounds: AreaBounds<Int>, value: Int?) {
        if (closed || value == null) return
        if (value !in bounds.minValue..bounds.maxValue) {
            status("$side 문 값 범위 밖: $value")
            return
        }
        emit { it.onDoor(side, value > bounds.minValue) }
    }

    private fun occupancy(side: RearSide, raw: Boolean?) {
        if (closed || raw == null) return
        Log.d("HawonVehicle", "occupancy side=$side sdkBoolean=$raw")
        if (!settings.getBoolean("occupancyMappingVerified", false)) return
        val occupied = if (settings.getBoolean("occupancyTrueMeansOccupied", true)) raw else !raw
        emit { it.onOccupancy(side, occupied) }
    }

    private fun belt(side: RearSide, raw: Boolean?) {
        if (!closed && raw != null) emit { it.onBelt(side, raw) }
    }

    private fun capabilities() = emit { it.onCapabilities(occupancyPresent, beltPresent) }
    private fun AccessType.readable() = this == AccessType.READ || this == AccessType.READ_WRITE
    private fun status(message: String) = emit { it.onStatus(message) }
    private fun failure(operation: String, error: Exception) {
        Log.w("HawonVehicle", operation, error)
        status("$operation 실패: ${error.javaClass.simpleName}")
    }
    private inline fun attempt(operation: String, block: () -> Unit) {
        try { block() } catch (error: Exception) { failure(operation, error) }
    }

    override fun close() {
        closed = true
        doorSubscriptions.forEach { (area, callback) -> runCatching { door.unregisterDoorPosition(area, callback) } }
        seatSubscriptions.forEach { (area, callback) -> runCatching { seat.unregisterSeatOccupancy(area, callback) } }
        beltSubscriptions.forEach { (area, callback) -> runCatching { seat.unregisterSeatBeltBuckledState(area, callback) } }
        doorSubscriptions.clear()
        seatSubscriptions.clear()
        beltSubscriptions.clear()
        if (initialized) runCatching { vehicle.release() }
    }
}
