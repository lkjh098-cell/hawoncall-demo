package ai.hawoncall.car.platform

import ai.hawoncall.core.Gear
import android.car.Car
import android.car.VehicleGear
import android.car.VehiclePropertyIds
import android.car.drivingstate.CarUxRestrictionsManager
import android.car.hardware.CarPropertyValue
import android.car.hardware.property.CarPropertyManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.Closeable

/** Gear and driving restrictions use the public AAOS APIs, independent of Vehicle SDK. */
internal class AaosSafetyAdapter(
    private val context: Context,
    private val emit: ((SignalListener) -> Unit) -> Unit,
) : Closeable {
    private var car: Car? = null
    private var properties: CarPropertyManager? = null
    private var restrictions: CarUxRestrictionsManager? = null
    @Volatile private var closed = false
    private val gearCallback = object : CarPropertyManager.CarPropertyEventCallback {
        override fun onChangeEvent(value: CarPropertyValue<*>) {
            if (closed || value.propertyId != VehiclePropertyIds.GEAR_SELECTION) return
            if (value.status != CarPropertyValue.STATUS_AVAILABLE) {
                emit { it.onGear(Gear.UNKNOWN) }
                return
            }
            publishGear(value.value as? Int)
        }
        override fun onErrorEvent(propertyId: Int, areaId: Int) {
            if (propertyId == VehiclePropertyIds.GEAR_SELECTION) failClosed("기어 신호 오류")
        }
    }
    private val uxCallback = CarUxRestrictionsManager.OnUxRestrictionsChangedListener { value ->
        if (!closed) emit { it.onUxRestricted(value.isRequiresDistractionOptimization) }
    }

    fun connect() {
        try {
            car = Car.createCar(context, Handler(Looper.getMainLooper()),
                Car.CAR_WAIT_TIMEOUT_DO_NOT_WAIT) { connectedCar, ready ->
                if (closed) return@createCar
                if (!ready) {
                    failClosed("AAOS 차량 서비스 연결 끊김")
                    properties = null
                    restrictions = null
                    return@createCar
                }
                attach(connectedCar)
            }
        } catch (error: Exception) {
            failClosed("AAOS 서비스 연결 실패: ${error.javaClass.simpleName}")
        }
    }

    private fun attach(connectedCar: Car) {
        try {
            val manager = connectedCar.getCarManager(Car.PROPERTY_SERVICE) as CarPropertyManager
            properties = manager
            val registered = manager.registerCallback(gearCallback, VehiclePropertyIds.GEAR_SELECTION,
                CarPropertyManager.SENSOR_RATE_ONCHANGE)
            if (!registered) {
                failClosed("기어 속성 구독 미지원")
            } else {
                val initial = manager.getProperty<Int>(VehiclePropertyIds.GEAR_SELECTION, 0)
                if (initial != null && initial.status == CarPropertyValue.STATUS_AVAILABLE) publishGear(initial.value)
                else emit { it.onGear(Gear.UNKNOWN) }
            }
        } catch (error: Exception) {
            failClosed("기어 조회 실패: ${error.javaClass.simpleName}")
        }
        try {
            val manager = connectedCar.getCarManager(Car.CAR_UX_RESTRICTION_SERVICE) as CarUxRestrictionsManager
            restrictions = manager
            manager.registerListener(uxCallback)
            val current = manager.currentCarUxRestrictions
            emit { it.onUxRestricted(current == null || current.isRequiresDistractionOptimization) }
        } catch (error: Exception) {
            emit {
                it.onUxRestricted(true)
                it.onStatus("운전 제한 상태 조회 실패 · 조작 잠금 유지: ${error.javaClass.simpleName}")
            }
        }
    }

    private fun publishGear(value: Int?) {
        val gear = when (value) {
            VehicleGear.GEAR_PARK -> Gear.PARK
            VehicleGear.GEAR_DRIVE -> Gear.DRIVE
            VehicleGear.GEAR_REVERSE -> Gear.REVERSE
            VehicleGear.GEAR_NEUTRAL -> Gear.NEUTRAL
            else -> Gear.UNKNOWN
        }
        emit { it.onGear(gear) }
    }

    private fun failClosed(message: String) = emit {
        it.onGear(Gear.UNKNOWN)
        it.onUxRestricted(true)
        it.onStatus(message)
    }

    override fun close() {
        closed = true
        runCatching { properties?.unregisterCallback(gearCallback) }
        runCatching { restrictions?.unregisterListener() }
        runCatching { car?.disconnect() }
        properties = null
        restrictions = null
        car = null
    }
}
