package ai.hawoncall.car.platform

import android.content.Context

fun createPlatformSignals(context: Context, academy: Destination): PlatformSignals =
    PleosPlatformSignals(context.applicationContext, academy)
