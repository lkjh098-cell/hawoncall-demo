package ai.hawoncall.car.network

import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException

class OutboxTest {
    private class MemoryStore : TextStore {
        var text=""
        var failWrites=false
        override fun read()=text
        override fun write(value:String) {
            if (failWrites) throw IOException("injected disk failure")
            text=value
        }
    }
    @Test fun `failed event retries identical id after process restart`() {
        MockWebServer().use { server ->
            val store=MemoryStore()
            val box=Outbox(store,server.url("/").toString(),"car-token")
            box.begin("link-1"); box.event("CALL")
            server.enqueue(MockResponse().setBody("""{"trip":{"id":"trip-1"}}"""))
            assertTrue(box.drainOne())
            server.enqueue(MockResponse().setResponseCode(503))
            assertThrows(ApiFailure::class.java) { box.drainOne() }
            assertEquals(1,box.pending())
            val restarted=Outbox(store,server.url("/").toString(),"car-token")
            server.enqueue(MockResponse().setBody("{}"))
            assertTrue(restarted.drainOne())
            val create=server.takeRequest()
            val failed=server.takeRequest()
            val retry=server.takeRequest()
            assertEquals("Bearer car-token",create.getHeader("Authorization"))
            assertEquals("/api/trips/trip-1/events",retry.path)
            assertEquals(failed.body.readUtf8(),retry.body.readUtf8())
            assertEquals(0,restarted.pending())
        }
    }
    @Test fun `create idempotency key and event order survive lost response`() {
        MockWebServer().use { server ->
            val store=MemoryStore(); val box=Outbox(store,server.url("/").toString(),"token")
            box.begin("link"); box.event("CALL"); box.event("ARRIVED"); box.event("BOARDED")
            assertEquals("",box.activeClientId())
            server.enqueue(MockResponse().setResponseCode(500))
            assertThrows(ApiFailure::class.java) { box.drainOne() }
            val restored=Outbox(store,server.url("/").toString(),"token")
            server.enqueue(MockResponse().setBody("""{"trip":{"id":"t"}}"""))
            restored.drainOne()
            val first=JSONObject(server.takeRequest().body.readUtf8())
            val retried=JSONObject(server.takeRequest().body.readUtf8())
            assertEquals(first.getString("clientTripId"),retried.getString("clientTripId"))
            for(type in listOf("CALL","ARRIVED","BOARDED")) {
                server.enqueue(MockResponse().setBody("{}")); restored.drainOne()
                val sent = JSONObject(server.takeRequest().body.readUtf8())
                assertEquals(type,sent.getString("type"))
                if (type == "BOARDED") assertEquals("GUARDIAN",sent.getString("confirmation"))
                else assertFalse(sent.has("confirmation"))
            }
            assertEquals(0,restored.pending())
        }
    }
    @Test fun `corrupt durable data fails instead of silently discarding pending commands`() {
        val store=MemoryStore().also { it.text="not json" }
        assertThrows(java.io.IOException::class.java) { Outbox(store,"https://localhost","token") }
    }
    @Test fun `failed begin commit leaves no phantom active trip or queued create`() {
        val store=MemoryStore()
        val box=Outbox(store,"https://localhost","token")
        store.failWrites=true
        assertThrows(IOException::class.java) { box.begin("link") }
        assertEquals("",box.activeClientId())
        assertEquals(0,box.pending())
        assertEquals("",store.text)
        store.failWrites=false
        assertTrue(box.begin("link").isNotBlank())
        assertEquals(1,box.pending())
    }
    @Test fun `failed terminal event commit preserves active trip and original durable queue`() {
        val store=MemoryStore(); val box=Outbox(store,"https://localhost","token")
        val id=box.begin("link")
        val saved=store.text
        store.failWrites=true
        assertThrows(IOException::class.java) { box.event("BOARDED") }
        assertEquals(id,box.activeClientId())
        assertEquals(1,box.pending())
        assertEquals(saved,store.text)
        val restored=Outbox(store,"https://localhost","token")
        assertEquals(id,restored.activeClientId())
        assertEquals(1,restored.pending())
        store.failWrites=false
        box.event("BOARDED")
        assertEquals("",box.activeClientId())
        assertEquals(2,box.pending())
    }
    @Test fun `failed regular event commit does not append an in memory only command`() {
        val store=MemoryStore(); val box=Outbox(store,"https://localhost","token")
        box.begin("link")
        val saved=store.text
        store.failWrites=true
        assertThrows(IOException::class.java) { box.event("CALL") }
        assertEquals(1,box.pending())
        assertEquals(saved,store.text)
        store.failWrites=false
        box.event("CALL")
        assertEquals(2,box.pending())
    }
    @Test fun `failed create acknowledgement commit retains identical create for retry`() {
        MockWebServer().use { server ->
            val store=MemoryStore(); val box=Outbox(store,server.url("/").toString(),"token")
            box.begin("link")
            val saved=store.text
            server.enqueue(MockResponse().setBody("""{"trip":{"id":"trip-1"}}"""))
            store.failWrites=true
            assertThrows(IOException::class.java) { box.drainOne() }
            assertEquals(1,box.pending())
            assertNull(box.activeServerId())
            assertEquals(saved,store.text)
            store.failWrites=false
            server.enqueue(MockResponse().setBody("""{"trip":{"id":"trip-1"}}"""))
            assertTrue(box.drainOne())
            assertEquals(server.takeRequest().body.readUtf8(),server.takeRequest().body.readUtf8())
            assertEquals(0,box.pending())
            assertEquals("trip-1",box.activeServerId())
        }
    }
    @Test fun `failed event acknowledgement commit keeps mapping and retries event after restart`() {
        MockWebServer().use { server ->
            val store=MemoryStore(); val box=Outbox(store,server.url("/").toString(),"token")
            box.begin("link")
            server.enqueue(MockResponse().setBody("""{"trip":{"id":"trip-1"}}"""))
            box.drainOne(); server.takeRequest()
            box.event("CANCEL")
            val saved=store.text
            store.failWrites=true
            server.enqueue(MockResponse().setBody("{}"))
            assertThrows(IOException::class.java) { box.drainOne() }
            assertEquals(1,box.pending())
            assertEquals(saved,store.text)
            val failed=server.takeRequest().body.readUtf8()
            store.failWrites=false
            val restored=Outbox(store,server.url("/").toString(),"token")
            server.enqueue(MockResponse().setBody("{}"))
            assertTrue(restored.drainOne())
            val retry=server.takeRequest()
            assertEquals("/api/trips/trip-1/events",retry.path)
            assertEquals(failed,retry.body.readUtf8())
            assertEquals(0,restored.pending())
            assertEquals(0,JSONObject(store.text).getJSONObject("trips").length())
        }
    }
    @Test fun `failed finish commit preserves active trip`() {
        val store=MemoryStore(); val box=Outbox(store,"https://localhost","token")
        val id=box.begin("link")
        val saved=store.text
        store.failWrites=true
        assertThrows(IOException::class.java) { box.finishLocal() }
        assertEquals(id,box.activeClientId())
        assertEquals(saved,store.text)
    }
    @Test fun `legacy boarding is quarantined and cancelled without inventing guardian confirmation`() {
        MockWebServer().use { server ->
            val store=MemoryStore().also { it.text="""{"queue":[{"kind":"EVENT","clientTripId":"old-local","body":{"eventId":"old-event","type":"BOARDED","at":"2026-10-24T10:00:00Z"}}],"trips":{"old-local":"old-server"},"activeClientId":""}""" }
            val box=Outbox(store,server.url("/").toString(),"token")
            assertEquals(1,box.pending())
            assertEquals(1,box.confirmationRequired())
            val saved=JSONObject(store.text)
            val original=saved.getJSONArray("confirmationRequired").getJSONObject(0).getJSONObject("body")
            assertEquals("old-event",original.getString("eventId"))
            assertEquals("BOARDED",original.getString("type"))
            assertFalse(original.has("confirmation"))
            val replacement=saved.getJSONArray("queue").getJSONObject(0).getJSONObject("body")
            assertEquals("CANCEL",replacement.getString("type"))
            assertFalse(replacement.has("confirmation"))
            assertNotEquals("old-event",replacement.getString("eventId"))
            val restored=Outbox(store,server.url("/").toString(),"token")
            assertEquals(1,restored.confirmationRequired())
            server.enqueue(MockResponse().setBody("{}"));assertTrue(restored.drainOne())
            val sent=JSONObject(server.takeRequest().body.readUtf8())
            assertEquals("CANCEL",sent.getString("type"));assertFalse(sent.has("confirmation"))
            assertEquals(0,restored.pending())
            assertEquals(1,restored.confirmationRequired())
        }
    }
    @Test fun `failed legacy migration preserves durable original and fails closed`() {
        val store=MemoryStore().also { it.text="""{"queue":[{"kind":"EVENT","clientTripId":"old","body":{"eventId":"legacy","type":"BOARDED"}}],"trips":{"old":"server"}}""" }
        val saved=store.text
        store.failWrites=true
        assertThrows(IOException::class.java) { Outbox(store,"https://localhost","token") }
        assertEquals(saved,store.text)
    }
    @Test fun `new guardian marker and event id survive retry and restart`() {
        MockWebServer().use { server ->
            val store=MemoryStore();val box=Outbox(store,server.url("/").toString(),"token")
            box.begin("link")
            server.enqueue(MockResponse().setBody("""{"trip":{"id":"trip"}}"""));box.drainOne();server.takeRequest()
            box.event("BOARDED")
            server.enqueue(MockResponse().setResponseCode(503))
            assertThrows(ApiFailure::class.java) {box.drainOne()}
            val failed=server.takeRequest().body.readUtf8()
            val restored=Outbox(store,server.url("/").toString(),"token")
            assertEquals(0,restored.confirmationRequired())
            server.enqueue(MockResponse().setBody("{}"));restored.drainOne()
            assertEquals(failed,server.takeRequest().body.readUtf8())
            assertEquals("GUARDIAN",JSONObject(failed).getString("confirmation"))
        }
    }

    @Test fun `revoked credential produces typed 401 and archive prevents boarding replay under new identity`() {
        MockWebServer().use { server ->
            val store=MemoryStore()
            val old=Outbox(store,server.url("/").toString(),"revoked-token")
            old.begin("old-link"); old.event("CALL"); old.event("BOARDED")
            server.enqueue(MockResponse().setResponseCode(401))
            val failure=assertThrows(ApiFailure::class.java) { old.drainOne() }
            assertEquals(401,failure.status)
            assertEquals(3,old.pending())
            assertEquals(3,old.quarantineForRePairing())
            val saved=JSONObject(store.text)
            val archived=saved.getJSONArray("credentialQuarantine").getJSONObject(0).getJSONArray("queue")
            assertEquals("GUARDIAN",archived.getJSONObject(2).getJSONObject("body").getString("confirmation"))
            assertEquals("BOARDED",archived.getJSONObject(2).getJSONObject("body").getString("type"))
            val newIdentity=Outbox(store,server.url("/").toString(),"new-token")
            assertEquals(0,newIdentity.pending())
            assertFalse(newIdentity.drainOne())
            newIdentity.begin("new-link")
            server.enqueue(MockResponse().setBody("""{"trip":{"id":"new-trip"}}"""))
            assertTrue(newIdentity.drainOne())
            server.takeRequest()
            val newRequest=server.takeRequest()
            assertEquals("Bearer new-token",newRequest.getHeader("Authorization"))
            assertEquals("new-link",JSONObject(newRequest.body.readUtf8()).getString("linkId"))
            assertEquals(2,server.requestCount)
            assertEquals(1,JSONObject(store.text).getJSONArray("credentialQuarantine").length())
        }
    }
    @Test fun `failed recovery archive preserves all original commands atomically`() {
        val store=MemoryStore(); val box=Outbox(store,"https://localhost","old-token")
        box.begin("old-link"); box.event("CALL")
        val original=store.text
        store.failWrites=true
        assertThrows(IOException::class.java) { box.quarantineForRePairing() }
        assertEquals(original,store.text)
        assertEquals(2,box.pending())
        store.failWrites=false
        assertEquals(2,box.quarantineForRePairing())
        assertEquals(0,box.pending())
    }

    @Test fun `dropoff create freezes direction and handoff is guardian terminal`() {
        MockWebServer().use { server ->
            val store=MemoryStore(); val box=Outbox(store,server.url("/").toString(),"token")
            box.begin("link", "DROPOFF", "DAYCARE", "SEOUL")
            box.event("CALL"); box.event("ARRIVED"); box.event("HANDED_OVER")
            assertEquals("",box.activeClientId())
            val restored=Outbox(store,server.url("/").toString(),"token")
            server.enqueue(MockResponse().setBody("""{"trip":{"id":"t"}}""")); restored.drainOne()
            val create=JSONObject(server.takeRequest().body.readUtf8())
            assertEquals("DROPOFF",create.getString("journeyType"))
            assertEquals("DAYCARE",create.getString("institutionType"))
            assertEquals("SEOUL",create.getString("serviceArea"))
            for(type in listOf("CALL","ARRIVED","HANDED_OVER")) {
                server.enqueue(MockResponse().setBody("{}")); restored.drainOne()
                val event=JSONObject(server.takeRequest().body.readUtf8())
                assertEquals(type,event.getString("type"))
                if(type=="HANDED_OVER") assertEquals("GUARDIAN",event.getString("confirmation"))
            }
            assertEquals(0,restored.pending())
        }
    }

    @Test fun `create configuration mismatch pauses durably until explicit archive`() {
        MockWebServer().use { server ->
            val store=MemoryStore(); val box=Outbox(store,server.url("/").toString(),"token")
            box.begin("link", "DROPOFF", "SCHOOL"); box.event("CALL")
            server.enqueue(MockResponse().setResponseCode(409).setBody("""{"code":"LINK_CONFIGURATION_CHANGED","message":"changed"}"""))
            assertThrows(ConfigurationChangedFailure::class.java) { box.drainOne() }
            assertTrue(box.configurationConflict()); assertEquals(2,box.pending())
            val restored=Outbox(store,server.url("/").toString(),"token")
            assertThrows(ConfigurationChangedFailure::class.java) { restored.drainOne() }
            assertEquals(1,server.requestCount)
            assertEquals(2,restored.quarantineForRePairing("LINK_CONFIGURATION_CHANGED"))
            assertFalse(restored.configurationConflict()); assertEquals(0,restored.pending())
            val archive=JSONObject(store.text).getJSONArray("credentialQuarantine").getJSONObject(0)
            assertEquals("LINK_CONFIGURATION_CHANGED",archive.getString("reason"))
            assertEquals("DROPOFF",archive.getJSONArray("queue").getJSONObject(0).getString("journeyType"))
        }
    }

    @Test fun `other create and active event conflicts remain retryable without quarantine`() {
        MockWebServer().use { server ->
            val store=MemoryStore(); val box=Outbox(store,server.url("/").toString(),"token")
            box.begin("link"); box.event("CALL")
            server.enqueue(MockResponse().setResponseCode(409).setBody("{}"))
            assertThrows(ApiFailure::class.java) { box.drainOne() }
            assertFalse(box.configurationConflict()); assertEquals(2,box.pending())
            server.enqueue(MockResponse().setBody("""{"trip":{"id":"t"}}""")); box.drainOne()
            server.enqueue(MockResponse().setResponseCode(409).setBody("""{"code":"LINK_CONFIGURATION_CHANGED"}"""))
            assertThrows(ApiFailure::class.java) { box.drainOne() }
            assertFalse(box.configurationConflict()); assertEquals(1,box.pending())
            assertFalse(JSONObject(store.text).has("credentialQuarantine"))
        }
    }

    @Test fun `point evidence is arrival only and frozen across durable restart`() {
        val store=MemoryStore(); val box=Outbox(store,"https://localhost","token")
        box.begin("link")
        val evidence=JSONObject().put("spotId","point").put("observedAt","2026-10-25T00:00:00Z")
            .put("distanceMeters",12.0).put("source","PLEOS_FUSED_LOCATION")
        assertThrows(IllegalArgumentException::class.java) { box.event("CALL",arrivalSpotEvidence=evidence) }
        box.event("ARRIVED",arrivalSpotEvidence=evidence)
        evidence.put("spotId","mutated")
        val restored=Outbox(store,"https://localhost","token")
        assertEquals(2,restored.pending())
        val body=JSONObject(store.text).getJSONArray("queue").getJSONObject(1).getJSONObject("body")
        assertEquals("point",body.getJSONObject("arrivalSpotEvidence").getString("spotId"))
        assertFalse(body.toString().contains("latitude")); assertFalse(body.toString().contains("longitude"))
    }

}
