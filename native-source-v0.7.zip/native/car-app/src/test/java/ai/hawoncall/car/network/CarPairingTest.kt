package ai.hawoncall.car.network

import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class CarPairingTest {
    @Test fun `production accepts HTTPS only and debug exceptions remain loopback port 3000`() {
        assertEquals("https://pickup.example", CarPairingPolicy.serverUrl(" https://pickup.example/ ", false))
        assertNull(CarPairingPolicy.serverUrl("http://pickup.example", true))
        assertNull(CarPairingPolicy.serverUrl("http://localhost:3000", false))
        assertEquals("http://localhost:3000", CarPairingPolicy.serverUrl("http://localhost:3000", true))
        assertNull(CarPairingPolicy.serverUrl("http://localhost:3001", true))
        assertNull(CarPairingPolicy.serverUrl("https://user:secret@pickup.example", false))
        assertNull(CarPairingPolicy.serverUrl("https://pickup.example?token=x", false))
        assertNull(CarPairingPolicy.serverUrl("https://pickup.example/config", false))
    }
    @Test fun `mobile code normalizes case and rejects ambiguous or non eight character codes`() {
        assertEquals("ABCD2345", CarPairingPolicy.code(" abcd2345 "))
        assertNull(CarPairingPolicy.code("ABCD1234"))
        assertNull(CarPairingPolicy.code("ABCD234"))
        assertNull(CarPairingPolicy.code("ABCD-2345"))
    }
    @Test fun `claim sends only the short lived code and accepts the new car credential`() {
        MockWebServer().use { server ->
            server.enqueue(MockResponse().setBody("""{"link":{"id":"lk_test","childName":"민준","academyName":"푸른학원"},"carToken":"new-private-car-token"}"""))
            val response = CarPairingClient().claim(server.url("/").toString(), "ABCD2345")
            assertEquals("new-private-car-token", response.getString("carToken"))
            val request = server.takeRequest()
            assertEquals("/api/car/pairing", request.path)
            assertEquals("POST", request.method)
            assertEquals(setOf("code"), JSONObject(request.body.readUtf8()).keySet())
            assertNull(request.getHeader("Authorization"))
        }
    }
    @Test fun `claim will not forward a code to a redirect target`() {
        MockWebServer().use { origin ->
            MockWebServer().use { destination ->
                origin.enqueue(MockResponse().setResponseCode(307).addHeader("Location", destination.url("/steal")))
                destination.enqueue(MockResponse().setBody("{}"))
                val result = runCatching { CarPairingClient().claim(origin.url("/").toString(), "ABCD2345") }
                assertTrue(result.isFailure)
                assertEquals(0, destination.requestCount)
            }
        }
    }
    @Test fun `active pickup response is not treated as successful pairing`() {
        MockWebServer().use { server ->
            server.enqueue(MockResponse().setResponseCode(409).setBody("{}"))
            val result = runCatching { CarPairingClient().claim(server.url("/").toString(), "ABCD2345") }
            assertTrue(result.isFailure)
            assertTrue(result.exceptionOrNull()?.message.orEmpty().contains("진행 중인 픽업"))
        }
    }
}
