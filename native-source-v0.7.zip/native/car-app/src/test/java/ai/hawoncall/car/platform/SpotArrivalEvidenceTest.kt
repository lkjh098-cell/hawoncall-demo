package ai.hawoncall.car.platform

import ai.hawoncall.core.PickupSpot
import org.junit.Assert.*
import org.junit.Test

class SpotArrivalEvidenceTest {
    private val spot=PickupSpot("permitted","허가 지점",37.55,126.98)
    private val now=1_000_000L
    private val position=FusedPositionObservation(37.55,126.98,now)
    @Test fun `only current actual position near selected point supplies evidence`() {
        assertEquals("permitted",SpotArrivalEvidencePolicy.evidence(spot,position,now,0)?.spotId)
        assertNull(SpotArrivalEvidencePolicy.evidence(null,position,now,0))
        assertNull(SpotArrivalEvidencePolicy.evidence(spot,null,now,0))
        assertNull(SpotArrivalEvidencePolicy.evidence(spot,position.copy(latitude=37.56),now,0))
        assertNull(SpotArrivalEvidencePolicy.evidence(spot,position.copy(latitude=Double.NaN),now,0))
        assertNull(SpotArrivalEvidencePolicy.evidence(spot,position,now+30_001,0))
        assertNull(SpotArrivalEvidencePolicy.evidence(spot,position,now,30_001))
        assertNull(SpotArrivalEvidencePolicy.evidence(spot,position,now-1,0))
        assertNotNull(SpotArrivalEvidencePolicy.evidence(spot,position,now+30_000,30_000))
    }
    @Test fun `accuracy when provided must be finite and at most twenty meters`() {
        assertNotNull(SpotArrivalEvidencePolicy.evidence(spot,position.copy(accuracyMeters=20.0),now,0))
        for (accuracy in listOf(20.1,-1.0,Double.NaN,Double.POSITIVE_INFINITY))
            assertNull(SpotArrivalEvidencePolicy.evidence(spot,position.copy(accuracyMeters=accuracy),now,0))
    }
    @Test fun `point dwell excludes movement outside point and stale gaps`() {
        val tracker=SpotDwellTracker()
        tracker.observe(0,true); tracker.observe(10_000,true)
        tracker.pause(15_000)
        assertEquals(15L,tracker.seconds(100_000))
        tracker.observe(100_000,true)
        assertEquals(45L,tracker.seconds(200_000))
        tracker.observe(200_000,false)
        assertEquals(45L,tracker.seconds(300_000))
        tracker.reset(); assertEquals(0L,tracker.seconds(400_000))
    }

}
