package ai.hawoncall.car.platform

import ai.hawoncall.core.*
import org.junit.Test
import org.junit.Assert.*

class PickupNavigationGateTest {
    private val nav=NavigationStatus(connected=true,active=true,academyMatched=true,verified=true,routeKey="academy")
    @Test fun invalidGuidanceCannotTriggerCallFromGps() {
        for (invalid in listOf(nav.copy(verified=false),nav.copy(active=false),nav.copy(academyMatched=false),nav.copy(routeKey="other"))) {
            val engine=PickupEngine(PickupPlan("link","아이","학원"),Clock { 1000 });engine.start();engine.gearChanged(Gear.PARK)
            if(PickupNavigationGate.positionAllowed(invalid,"academy",0,engine.state))engine.locationDistanceUpdated(20.0)
            assertEquals(PickupState.PLANNED,engine.state)
            assertTrue(engine.drainEffects().none { it is PickupEffect.ServerEvent })
        }
    }
    @Test fun trustedExistingRouteAllowsParkedArrivalWithoutRouteRequest() {
        val engine=PickupEngine(PickupPlan("link","아이","학원"),Clock { 1000 });engine.start();engine.gearChanged(Gear.PARK)
        if(PickupNavigationGate.positionAllowed(nav,"academy",0,engine.state))engine.locationDistanceUpdated(20.0)
        assertEquals(PickupState.ARRIVED,engine.state)
        assertTrue(engine.drainEffects().none { it is PickupEffect.RequestRoute })
    }
    @Test fun etaLeaseRejectsStaleFutureAndDifferentRouteObservations() {
        assertTrue(PickupNavigationGate.boundFresh(nav,"academy",15000))
        for(age in listOf(-1L,15001L))assertFalse(PickupNavigationGate.boundFresh(nav,"academy",age))
        assertFalse(PickupNavigationGate.boundFresh(nav,"",0))
    }
    @Test fun arrivalCanRefreshPositionAfterOemGuidanceEnds() {
        for(state in listOf(PickupState.ARRIVED,PickupState.BOARDING_DETECTED))
            assertTrue(PickupNavigationGate.positionAllowed(nav.copy(active=false,verified=false),"academy",20000,state))
        assertFalse(PickupNavigationGate.positionAllowed(nav.copy(active=false,verified=false),"academy",20000,PickupState.APPROACHING))
    }
}
