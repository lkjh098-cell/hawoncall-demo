package ai.hawoncall.car

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** External fake vehicle inputs for the debug demo; absent from the Pleos and release builds. */
class DemoVehicleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!BuildConfig.DEBUG || !BuildConfig.SIMULATED_SIGNALS || intent.action != "ai.hawoncall.demo.VEHICLE_SIGNAL") return
        val session = (context.applicationContext as HawonApplication).session
        when (intent.getStringExtra("signal")) {
            "route" -> session.simulateExistingRoute()
            "drive" -> session.simulateNavigation()
            "approach" -> session.simulateApproach()
            "park" -> session.simulatePark()
            "door" -> session.simulateDoor()
            "seat" -> session.simulateOccupancy()
            "depart" -> session.simulateDeparture()
            "other_destination" -> session.simulateRouteChange()
        }
        // Start and guardian confirmation require the actual parked UI.
    }
}
