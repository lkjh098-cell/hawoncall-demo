# 0.3 장치 검증 체크리스트

완료 기록과 미검증 범위를 구분합니다. 실제 현대차에 설치하기 전에 Pleos의 권한·카테고리·배포 절차를 따라야 합니다.

## 일반 Android demo에서 완료

- [x] 최종 APK 설치 및 실행
- [x] 기존 모의 경로 연결, 자동 경로 요청 없음
- [x] D·접근에서 조작 숨김, 도착/탑승 이벤트 없음
- [x] 화면을 홈으로 전환해도 foreground service로 세션 유지
- [x] P와 최근 근접 위치에서만 도착
- [x] 문·착석 센서는 감지까지만, 서버 확인값 null
- [x] D 전환 시 열린 확인창 닫힘
- [x] P에서 보호자 명시 확인 뒤 GUARDIAN BOARDED 기록
- [x] 도착 뒤 늦은 ETA가 후속 확인 전송을 막지 않음
- [x] 최종 설치본으로 센서·보호자 확인 흐름 재실행

## Pleos 및 실제 현대차에서 남음

- [ ] 공식 Pleos Connect Emulator와 Virtual Console의 실제 API 바인딩·권한 동의
- [ ] 기존 내비 목적지·옵션·경유지 유지, 새로운 경로 요청 0회 실측
- [ ] 목적지 POI 등록, 이름이 다른 학원 연결, 다른 목적지·취소·만료·지연 콜백 처리
- [ ] 실제 기어·문·좌우 착석/벨트·위치 매핑과 센서 미지원 수동 확인
- [ ] NAVI_CUSTOM_MAP Foreground 요청 및 OS의 지도/앱 창 배치
- [ ] Android35 location service 시작/전환·장시간 유지, 재연결·권한 거부
- [ ] 주행 중 OS 노출 허용, 차량/OEM 배포 승인
- [ ] 프로세스 강제 종료 뒤 기존 인계 완료를 복원하지 않고 취소로 정리하는 장치 동작
- [ ] 실제 한국어 음성·오디오 포커스, 사용성·주의 분산·CPU/RAM 실측

시연 입력은 demoDebug receiver `ai.hawoncall.demo.VEHICLE_SIGNAL`에 signal=route/drive/approach/park/door/seat/depart/other_destination을 보냅니다. 시작과 보호자 확인 입력은 receiver에서 지원하지 않으며 실제 P 화면 버튼을 사용합니다. Pleos/release에는 이 receiver가 없습니다.
