# 하원콜 0.3 검수 결과

2026-10-25. 자동 테스트 **76/76 통과**, `demoDebug`·`pleosDebug` 빌드 및 APK v2 서명 검증 통과. 일반 Android 에뮬레이터에서 최종 demo APK를 설치·실행하고 픽업 흐름을 확인했습니다. 실제 현대차 및 Pleos 내비 서비스 실행 검증은 아직 하지 않았습니다.

| 검증 | 결과 | 범위 |
|---|---|---|
| Core | 36/36 | 경로 요청 0, 접근/P 도착 구분, 센서 후보·보호자 확인 분리, 최근 위치·기어, 재출발, 주차 대기 학습, 중복/취소, 도착 후 ETA 전송 차단 |
| 내비 입력 정책 | 4/4 | 내비 미확인·다른 경로의 GPS 자동 호출 차단, 15초 관찰 유효기간, 도착 후 안내가 끝난 경우 위치 갱신 |
| Android Outbox | 12/12 | 순서·재시도·프로세스 재생성·저장 실패, 신규 보호자 확인 marker, 구버전 센서 BOARDED 격리/취소 |
| 서버 | 19/19 | 인증·격리·중복·WS·DB, GUARDIAN 필수, 기존 확인기록 null, 도착 후 늦은 ETA 수락 및 후속 확인 전송 |
| 웹 시연 동작 | 5/5 | 센서 자동 완료 금지, 자동 재생은 감지까지만, 별도 보호자 확인, 도착 전 차단 |
| APK | 두 종류 성공 | compile/target 35, min 28, debug 서명. 두 APK `apksigner verify` 통과 |
| Android 실행 | demo APK 성공 | AOSP API30 arm64, 800×1280, 240dpi. 실제 SDK 신호 대신 모의 입력 |

## 직접 실행한 차내 흐름

가상 호칭과 시연 학원만 사용했습니다. 실제 아동·학원이나 외부 메시지 수신자는 없습니다.

1. P 상태에서 기존 모의 내비 경로를 픽업에 연결했습니다. 지도·경로 요청은 보내지 않습니다.
2. D·근접 상태에서 ‘학원 근처예요’가 표시되고 조작 버튼이 사라졌습니다. 서버는 CALLED이고 ARRIVED/BOARDED는 발생하지 않았습니다.
3. 홈으로 화면을 전환했습니다. OS의 foreground service가 유지된 상태에서 P·근접 위치와 문·착석 신호를 입력했습니다. 서버 ARRIVED와 확인값 null을 확인했습니다.
4. 앱 복귀 후 ‘뒷좌석 탑승 신호 감지’와 별도 보호자 확인 버튼을 확인했습니다. 센서만으로 BOARDED는 전송되지 않았습니다.
5. 확인창에서 D로 전환했을 때 창과 확인 버튼이 사라졌습니다. 이 과정에서 발견한 도착 후 ETA 큐 막힘을 수정하고 회귀 테스트를 추가했습니다.
6. 다시 P에서 보호자가 아이 본인·안전한 주차를 확인한 뒤에만 BOARDED 한 건과 GUARDIAN 기록이 서버에 저장됐습니다.
7. 최종 수정 APK를 다시 설치하고 접근→P→센서 감지→보호자 확인 흐름을 재실행했습니다. 최종 앱에서도 센서 감지 때는 확인값 null, 확인 뒤에만 GUARDIAN인 것을 대조했습니다.

`ui-v0.3/`는 이 Android 실행 화면의 실제 캡처입니다. `native-flow.png`는 원본 캡처 세 장을 잘라 나란히 놓은 검수용 모음입니다. 실제 현대차 전체 디스플레이나 순정 내비 지도 캡처가 아닙니다. `ui-v0.2/`는 이전 웹 UI의 이력입니다.

## 경로와 지속 실행 검증의 한계

실행 코드에 `requestRoute` 호출이 없고 최종 Pleos manifest에는 조회용 NAVI_ROUTE가 있으며 요청용 NAVI_ROUTE_SEARCH는 없습니다. 앱은 다음 목적지를 자동 설정하지 않습니다. 이 코드·권한 검증은 실차에서 기존 경로의 옵션·경유지가 보존됐다는 실측을 대신하지 않습니다.

최종 병합 manifest에서 demo service는 dataSync, Pleos service는 location이며, 외부 모의 입력 receiver는 demoDebug에만 포함됨을 확인했습니다. Android API30에서 실제 service가 foreground로 유지되며 무음 알림을 사용하는 것을 확인했습니다. Android35·Pleos의 위치 권한/서비스 시작 수락, 장시간 동작, 내비 Foreground 화면 요청, OS 분할 배치와 실제 차량 신호는 추가 검증이 필요합니다.

기어 P와 위치는 안전·합법적인 정차 장소 또는 아이 신원의 증명이 아닙니다. 보호자의 명시 확인을 받고 서버는 그 확인 방식을 기록합니다. 학원 ARRIVED는 최초 P 도착 이력이며 현재 P를 지속 보장하는 실시간 차량 상태가 아닙니다.

실차 성능·주의 분산·대기시간 절감 효과, 한국어 TTS·오디오 포커스, 장치의 프로세스 종료·재시작, 토큰 철회/개인정보 삭제, 운영 HTTPS 및 release/OEM 배포 승인은 미검증입니다. 이 결과를 실차 서비스 출시 완료로 표현하지 않습니다.

Android foreground location 구현 근거: [foreground service 시작 조건](https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start), [가시 Activity에서 시작한 서비스의 위치 접근](https://developer.android.com/training/permissions/requesting). SDK별 근거는 SDK_VERIFICATION.md를 참고하세요.
