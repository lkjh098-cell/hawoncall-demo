# 권한 사용 근거 — V0.3

| 권한 | 사용 목적 | 차량 제어 |
| --- | --- | --- |
| INTERNET | HTTPS 하원 상태 송수신, WebSocket과 폴링 | 없음 |
| pleos.car.permission.CAR_DOORS | 2열 문 열림·닫힘 조회 | 없음 |
| pleos.car.permission.CAR_SEATS | 2열 착석·벨트와 기능 지원 조회 | 없음 |
| pleos.car.permission.NAVI_ROUTE | 기존 내비 목적지·남은 시간·경로 상태 조회 | 없음 |
| pleos.car.permission.NAVI_CUSTOM_MAP | 정차 중 사용자가 ‘기존 내비 열기’를 누른 경우 공식 Foreground 화면 요청 | 기존 내비 화면 열기만 요청 |
| pleos.car.permission.FUSED_LOCATION | 학원 거리·근접 진입 관찰, 좌표는 차량 내부에만 사용 | 없음 |
| android.car.permission.CAR_POWERTRAIN | 기어 P 확인 | 없음 |
| android.permission.ACCESS_FINE_LOCATION | Pleos 위치 유형 서비스·위치 관찰의 Android 위치 동의 | 없음 |
| android.permission.FOREGROUND_SERVICE | 진행 중 픽업 추적 서비스 | 없음 |
| android.permission.FOREGROUND_SERVICE_DATA_SYNC | 기본 앱의 `dataSync` 유형 서비스 | 없음 |
| android.permission.FOREGROUND_SERVICE_LOCATION | Pleos flavor의 `location` 유형 서비스 | 없음 |

V0.3은 경로 요청용 `NAVI_ROUTE_SEARCH` 권한을 제거하고 조회용 `NAVI_ROUTE`를 유지합니다. 내비 어댑터의 `route()`는 경로 요청을 보내지 않으며 자동·수동 `requestRoute` 호출이 없습니다. 픽업 시작·탑승·재연결은 기존 OEM 내비 목적지와 경로를 변경하지 않습니다. `NAVI_CUSTOM_MAP`은 이 앱에서 지도 생성에 쓰지 않으며, 사용자가 실제 P·UX 허용 상태에서 누른 Foreground 화면 요청에만 사용합니다. 앱은 OS 화면 분할이나 HUD를 제어하지 않습니다.

공식 NaviHelper 3.0.5 `NaviHelper.kt`의 `getRouteStateInfo` 346행·`getDestinationInfo` 392행은 `NAVI_ROUTE`, `requestRoute` 127행은 `NAVI_ROUTE_SEARCH`, `requestNavigationScreen` 481행은 `NAVI_CUSTOM_MAP`을 요구합니다. 권한 이름의 직관 대신 이 SDK 계약을 기준으로 기록했습니다. 배포된 `NaviHelper-sources.jar`에서 해당 줄을 직접 재확인했습니다.

`CONTROL_*` 권한을 선언하지 않습니다. SDK가 병합하는 서비스 바인딩용 권한·package visibility와 경로 권한의 최종 제거는 최종 merged manifest에서 함께 확인해야 합니다. 진행 중 픽업을 CarSession과 foreground service가 추적하도록 구현했습니다. `PickupTrackingService`는 외부 공개하지 않으며 기본 manifest는 `dataSync`, Pleos manifest는 이를 `location`으로 교체합니다. 서비스 권한·유형의 최종 병합 결과, OS의 서비스 시작 수락, 알림 표시와 백그라운드 동작은 Android 실행 검수 및 차량 검증으로 별도 확인해야 합니다.

위치 동의는 기어 P 및 UX 조작 허용 상태에서 런타임에 요청합니다. 권한 동의가 필요하면 정차 상태에서 앱을 열고 동의해야 합니다. 권한 요청 자체도 코드에서 기어 P 및 UX 허용 상태로 제한합니다. 실제 Pleos 권한창 동작은 미검증입니다. 서버·학원 화면은 위치 권한을 요청하지 않습니다. 현재 내비 목적지를 학원으로 연결할 때 저장하는 좌표·POI 정보도 차량 내부에만 보관합니다. 아이 연결은 호칭·학원·요일·시각·준비시간·동의 시각을 저장합니다. 토큰은 서버에 해시로 저장하고, Android는 백업이 꺼진 앱 전용 저장소에 둡니다. 운영 배포에는 단말 키 저장소와 토큰 교체·철회 정책 검토가 추가로 필요합니다.
