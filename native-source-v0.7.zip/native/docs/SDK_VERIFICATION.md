# Pleos SDK 검증 기록

확인일: 2026-10-25. 이 문서는 **공식 배포 소스와 API 형태 검증** 기록이다. 에뮬레이터나 실제 차량에서 신호를 수신한 기록이 아니다. 실제 오류 UI, Virtual Console 값 매핑, 내비 주행 및 도착은 아직 실측하지 않았다.

## 확인 근거

- [공식 Vehicle 샘플](https://github.com/Pleos-Playground/pleos-sample-vehicle-app/tree/959981d960ec71144accb27af5ae5d341e72a644), commit `959981d960ec71144accb27af5ae5d341e72a644`. 샘플의 Vehicle 버전은 2.3.1이다.
- [공식 NaviHelper 샘플](https://github.com/Pleos-Playground/pleos-sample-navi-app/tree/76ed592487a1eab7ba102b9d4b321705426886fe), commit `76ed592487a1eab7ba102b9d4b321705426886fe`, NaviHelper 3.0.5.
- [공식 FusedLocation 샘플](https://github.com/Pleos-Playground/pleos-sample-fusedlocation-app/tree/c955c3a811371892e8803f3b1d9ad3f0426e832c), commit `c955c3a811371892e8803f3b1d9ad3f0426e832c`, FusedLocation 1.1.3.
- 공식 Maven 저장소 `https://nexus-playground.pleos.ai/repository/maven-releases/`에서 아래 버전의 AAR, `-sources.jar` 및 NaviHelper POM을 실제 다운로드하여 Kotlin 소스를 읽었다. 접속 차단으로 확인하지 못했다는 개발지시서의 환경 설명은 이번 작업 환경에는 해당하지 않았다.
- [Android Car](https://developer.android.com/reference/android/car/Car), [CarPropertyManager](https://developer.android.com/reference/android/car/hardware/property/CarPropertyManager), [CarUxRestrictionsManager](https://developer.android.com/reference/android/car/drivingstate/CarUxRestrictionsManager) 공식 레퍼런스.

## 직접 연결한 API

| 신호 | 실제 SDK와 호출 | 검증 범위 |
| --- | --- | --- |
| 차량 서비스 | `ai.pleos.playground.vehicle.Vehicle(context)`, `initialize()`, `release()` | Vehicle 2.3.2 배포 소스 |
| 후석 문 | `getDoor()`, `checkDoorPositionCapabilities((CapabilityConfig, Map<DoorArea, AreaBounds<Int>>) -> Unit, ...)`, `registerDoorPosition`, `unregisterDoorPosition` | `DoorArea(DoorValue.ROW_2_LEFT/RIGHT)`와 `DoorPositionListener.onPositionUpdated(Int?)` 확인 |
| 후석 착석 | `getSeat()`, `checkSeatOccupancyCapabilities((CapabilityConfig, List<SeatArea>) -> Unit, ...)`, `registerSeatOccupancy`, `unregisterSeatOccupancy` | `SeatArea(SeatValue.ROW_2_LEFT/RIGHT)`와 `SeatOccupancyListener.onSeatOccupancyUpdated(Boolean?)` 확인 |
| 후석 벨트 | `checkSeatBeltBuckledCapabilities`, `registerSeatBeltBuckledState`, `unregisterSeatBeltBuckledState` | `SeatBeltBuckledStateListener.onSeatBeltBuckledStateUpdated(Boolean?)` 확인 |
| 기어 | `CarPropertyManager`, `VehiclePropertyIds.GEAR_SELECTION`, `VehicleGear.GEAR_PARK/DRIVE/REVERSE/NEUTRAL` | 공개 AAOS API. 구독 실패·값 오류·연결 끊김은 UNKNOWN 처리 |
| 주행 제한 | `CarUxRestrictionsManager.registerListener`, `currentCarUxRestrictions.isRequiresDistractionOptimization`, `unregisterListener` | 초기값과 조회 실패는 조작 잠금 |
| 내비 관찰 | `ai.pleos.playground.navi.helper.NaviHelper`, `initialize`, `addListener`, `getRouteStateInfo`, `getDestinationInfo`, `removeListener`, `release` | NaviHelper 3.0.5 공식 소스와 샘플. 연결·픽업 시작·탑승 시 기존 경로를 변경하지 않음 |
| 기존 내비 열기 | `requestNavigationScreen(NavigationScreenRequest.Foreground)` | 공식 NaviHelper 3.0.5 소스 481–484행. `NAVI_CUSTOM_MAP` 권한 필요. 사용자 버튼 + 실제 P + UX 허용일 때만 호출 |
| 경로 보존 | `route()`는 항상 경로 요청을 보내지 않음 | V0.3은 자동·수동 `requestRoute` 호출 0. 경로 요청용 `NAVI_ROUTE_SEARCH` 권한도 제거 |
| ETA·목적지·도착 | `NaviHelperEventListener.onDestinationInfo(DestinationInfo)`, `onDestinationChanged()`, `onDestinationArrived(DestinationArrivedInfo)` | `DestinationInfo.remainTime`은 초. 활성 경로와 최신 목적지의 반복 관측을 확인하고 등록 학원과 대조한 뒤 ETA 사용 |
| 위치 | `ai.pleos.playground.location.fused.FusedLocation`, `isSupported`, `initialize`, `registerFusedLocationCallback`, `getLastKnownLocation`, `unregisterFusedLocationCallback`, `release` | FusedLocation 1.1.3 공식 소스 |
| 근접 알림 | `addProximityAlert(ProximityAlertRequest(... radiusMeters=150f, transitionTypes=setOf(ProximityTransition.ENTER)), ProximityAlertListener)`, `removeProximityAlert(alertId)` | `onRegistered(String)`, `onTransition(ProximityAlertEvent)` 확인 |

SDK 호출은 `src/pleos/java/ai/hawoncall/car/platform/` 안에 있으며 reflection이나 가상 SDK 클래스는 사용하지 않는다. `demo` flavor는 이 SDK를 의존하지 않는다. `pleos` flavor 의존성은 `car-app/pleos-dependencies.gradle.kts`에 고정했다. NaviHelper POM의 실제 전이 의존성은 `navi-data:3.0.4`와 `navi-aidl:3.0.1`이다.

NaviHelper의 초기화는 실제 소스에 있는 `initialize(onConnected: () -> Unit, onFailed: (Throwable) -> Unit)` 오버로드를 사용한다. 서비스 연결 성공 콜백 뒤에만 리스너를 등록하고 조회를 수행한다. **V0.3은 기존 OEM 내비를 읽는 관찰 모드**이며 `route()`는 항상 경로 요청을 보내지 않는다. 연결·픽업 시작·탑승 완료·수동 조작으로 `requestRoute`를 호출하는 경로가 없고 경로 요청용 `NAVI_ROUTE_SEARCH` 권한도 제거했다. 연결 전 경로·화면 요청은 보관하지 않으므로 나중에 갑자기 기존 경로가 바뀌는 대기열도 없다. 초기화가 반환되었다는 이유만으로 연결 완료를 주장하지 않는다.

## 내비 권한의 정확한 대응

공식 `NaviHelper-sources.jar` 안의 `NaviHelper.kt`를 다시 확인했다. `getRouteStateInfo()` 346행과 `getDestinationInfo()` 392행은 `@RequiresPermission(PermissionUtils.NAVI_ROUTE)`, `requestRoute()` 127행은 `NAVI_ROUTE_SEARCH`, `requestNavigationScreen()` 481행은 `NAVI_CUSTOM_MAP`을 요구한다. `PermissionUtils`는 이 상수를 같은 이름의 `pleos.car.permission.*` 문자열로 정의한다. 따라서 V0.3 관찰 모드에서는 **조회용 NAVI_ROUTE를 유지하고 경로 요청용 NAVI_ROUTE_SEARCH를 제거**했다. NAVI_ROUTE를 보유한다는 사실을 경로 요청 기능으로 설명하지 않는다.

## 구현상 보수적으로 처리한 부분

Vehicle capability의 `AccessType.READ/READ_WRITE`만 읽기 가능한 것으로 취급한다. 지원 영역에 실제 2열 좌·우가 있는지 확인하고 개별 영역만 구독한다. capability 조회 오류·권한 오류는 센서가 없는 증거가 아니므로 수동 탑승 확인을 자동 허용하지 않는다. Vehicle 2.3.2의 `VehicleServiceManager.requestAreaListCapability`는 **빈 영역 목록을 실패 콜백으로 전달**하므로 오류 하나만으로 물리 센서 부재를 확정할 수 없다. 읽기 가능한 정상 결과에 앞좌석만 있고 후석이 없는 경우에만 후석 capability를 false로 전달한다.

문은 capability의 min/max 범위를 확인한다. 공식 `Door.kt`는 닫힘 최솟값이 일반적으로 0이고 완전 열림 최댓값은 차량마다 다르다고 명시한다. 이 구현은 min=0과 max>0인 영역만 채택하고 `position>0`을 열림으로 읽는다. 다른 범위는 실측 전까지 사용하지 않는다.

착석 SDK의 실제 구현은 raw 정수 `1`을 Boolean true로 바꾼다. 이 사실만으로 Virtual Console의 Empty/Occupied UI와 실제 반전 여부를 확정할 수 없다. 따라서 착석 콜백은 연결하여 `HawonVehicle` 로그에 기록하되, `car-settings` SharedPreferences의 `occupancyMappingVerified`가 기본 false이면 탑승 판정으로 전달하지 않는다. 센서가 연결되어 있으면 capability는 true로 유지해 이를 "센서 없음"으로 오인하지 않는다. 검증 후 `occupancyTrueMeansOccupied`를 실측 결과에 맞게 설정하고 `occupancyMappingVerified=true`로 바꾼다. 벨트 신호는 계속 사용한다. 이 설정은 현재 일반 사용자 UI에 노출하지 않으며 개발자 검증 단계에서 설정해야 한다.

`LocationData.timestampMillis`가 현재 시각에서 30초 이내인 위치만 거리 신호로 전달한다. 과거 마지막 위치로 도착을 발생시키지 않기 위함이다. 서비스에는 mock provider를 넣지 않는다. 근접 ENTER는 `onProximityEntered`로만 전달하며 내비 도착인 `onArrived`와 구분한다. 근접 알림은 앱 종료 시 제거하며, 등록 완료가 종료 이후 도착하는 경우에도 즉시 제거한다.

현재 주행의 ETA는 `DestinationInfo.remainTime`만 사용한다. `onTripInfo(TripInfo)`는 경로 추정 결과이므로 사용하지 않는다. 등록 데이터에 POI ID가 있으면 SDK의 `poiId`, 선택적 `poiSubId`·`poiProvider`를 대조한다. ID가 없으면 공백·대소문자를 정규화한 학원명이 일치하면서 목적지 좌표가 75m 안에 있어야 학원 후보로 판별한다. 이는 공식 POI 동일성 확인과 같지 않으며, 출입구 좌표 차이·동일명 인접 학원은 실제 데이터로 검증해야 한다. 단순한 200m 좌표 근접만으로 학원 경로를 채택하던 처리는 제거했다.

목적지 정보는 `getRouteStateInfo`로 받은 실제 `RouteStateInfo.isRouting=true`와 함께 있어야 소비한다. 목적지 식별 키(POI/provider/subID, 이름, 소수점 6자리 좌표)가 같은 스냅샷을 최소 1초 간격으로 두 번 관측한 뒤 ETA를 허용한다. 목적지 변경·재탐색·경로 완료·취소·오류에서는 이전 목적지와 ETA를 즉시 지운다. 경로 상태와 목적지 수신 시각을 단조 시계로 기록하고 둘 중 하나라도 15초가 지나면 상태의 `remainingSeconds=null`, `verified=false`로 무효화한다. V0.3은 5초 주기로 재조회하며, 별도 만료 타이머도 둔다. 상태 값과 ETA가 이전과 같아도 확인 응답을 CarSession에 다시 전달해 관측 시각을 갱신한다. 경로가 없거나 다른 목적지인 경우에도 이를 내비 상태로 UI에 전달한다. 활성·반복 확인된 다른 목적지는 좌표와 POI ID/subID/provider도 상태에 담아 정차 중 사용자가 현재 목적지를 학원에 연결할 수 있게 한다. 확인 중이거나 만료된 상태에는 이 좌표·POI 필드를 지워 오래된 목적지 연결을 막는다. 이 연결은 등록값을 변경할 뿐 OEM 경로를 요청하지 않는다. `verified`는 이 시간·반복 관측 조건 충족을 뜻하며, 실차 검증 통과를 뜻하지 않는다.

**SDK 제약:** 공개된 `DestinationInfo`·`RouteStateInfo`와 콜백에는 요청 ID, 경로 ID 또는 제공자 수신 시각이 없다. 따라서 앱의 `routeKey`는 목적지 식별용이며 실제 경로 ID가 아니다. 목적지 변경 직후 도착한 서로 다른 키는 모두 다시 확인하며 오래된 값의 즉시 재사용을 막지만, 늦게 도착한 동일 목적지의 두 응답을 새 응답과 완벽하게 구분할 수는 없다. 이 검증을 제공자 수준의 요청 상관관계 보장으로 주장하지 않는다. 도착 이벤트도 최신 학원 목적지의 이름과, 양쪽에 주소가 있으면 주소까지 일치해야 전달한다. 그러나 도착 이벤트에도 경로 ID가 없어 동일 이름·주소의 과거 도착 이벤트를 완전히 구분할 수는 없다. 실제 서비스의 응답 순서·지연을 확인하기 전에는 자동 호출의 실차 검증 완료를 주장하지 않는다. 0,0을 문서에 없는 특수값으로 가정하지 않는다.

기존 내비 열기 버튼만 `Foreground` 화면 요청을 사용한다. 이 요청은 경로·목적지를 설정하지 않는다. 다만 실제 내비 화면의 표시 성공이나 HUD 연동은 확인하지 않았으며, 앱 화면에 가짜 지도나 HUD를 제공하지 않는다. 주행·UX 제한·미연결에서는 화면 요청도 거절하고 보관하지 않는다.

## 에뮬레이터에서 남은 필수 검증

### Pleos의 내비 모의 진행 차단

V0.3 CarSession은 `navigationDemo` 저장값을 false로 초기화·저장하며 사용자 설정 UI에서도 해당 항목을 제거했다. 따라서 정상 Pleos 앱 흐름은 내비만 모의 진행하는 경로를 사용하지 않는다. 남아 있는 `NavigationOnlyDemo` 클래스는 실제 내비 검증 근거나 사용자 기능으로 취급하지 않는다.

별도 `demo` flavor만 모든 차량·내비 신호를 모의 생성하는 개발용 시연을 제공한다. 이 flavor의 내비 열기는 실제 지도 연결이 없음을 표시한다. 모의 영상·결과를 실제 OEM 내비/HUD 연동 검증으로 제시하면 안 된다.

### 화면 전환 뒤 세션 수명

Application 범위의 CarSession이 차량·내비 구독, 호출 판정과 전송 상태를 소유하고 진행 중 픽업에는 PickupTrackingService를 사용한다. Activity가 OEM 내비 화면으로 전환되거나 다시 생성되어도 추적을 계속하도록 구현했다. 기본 manifest의 foreground service 유형은 `dataSync`이며 Pleos flavor는 `location`으로 교체한다. 이는 구현 구조와 선언 기록이며 OS의 실제 서비스 유지·알림 표시·배터리 정책 수락을 검증했다는 뜻이 아니다. 프로세스가 종료되면 기존 진행 중 픽업은 영구 전송 대기열에 CANCEL로 정리하며 센서 판정 맥락을 복원했다고 가정하지 않는다. 실제 Android 에뮬레이터 실행 결과는 아직 대기 중이고, 실제 Pleos 차량 동작은 미실행이다.

### 실제 신호 검증

1. Pleos Connect Emulator 2.1.0에서 SDK 서비스 버전을 확인한다. Vehicle AAR 메타데이터는 서비스 최소 `2.3.13`/code65, NaviHelper는 `2.0.1`/code11, FusedLocation은 `0.5.0`/code1을 선언한다. SDK 버전과 서비스 버전은 다른 값이다.
2. 앱의 `CAR_DOORS`, `CAR_SEATS`, `NAVI_ROUTE`, `NAVI_CUSTOM_MAP`, `CAR_POWERTRAIN` 선언과 `NAVI_ROUTE_SEARCH` 제거를 확인한다. `FUSED_LOCATION`·`ACCESS_FINE_LOCATION`, foreground service 권한·유형의 최종 병합 결과를 함께 확인한다. 위치 권한은 정차 상태에서 런타임 동의를 받아야 한다. SDK AAR의 서비스 바인딩·package visibility 선언도 최종 병합 manifest에서 확인한다.
3. Virtual Console의 2열 좌·우 문을 닫힘/열림으로 바꾸고 capability 범위 및 콜백 값을 기록한다. 문을 1초 이상 열었다 닫았을 때 core의 디바운스와 결합되는지 확인한다.
4. 2열 좌·우를 각각 Empty→Occupied→Empty로 변경하고 `adb logcat -s HawonVehicle`의 `sdkBoolean`과 대조한다. 매핑을 기록하기 전 `occupancyMappingVerified`를 켜지 않는다. 벨트 Buckled/Unbuckled도 별도로 확인한다.
5. OEM 내비에서 학원 경로를 먼저 설정한 뒤 앱을 열고 픽업을 시작한다. 시작·탑승·앱 재연결·수동 조작에서도 경로 요청·취소가 전송되지 않는지 확인한다. Destination에는 선택적 POI ID/subID/provider를 보존하지만 경로 요청에는 사용하지 않는다. 명시적 ‘기존 내비 열기’ 외 자동 화면 전환도 없어야 한다.
6. 실제 `onDestinationChanged`→조회→remainTime, 학원/다른 목적지 전환, 경로 취소·없음, 도착을 확인한다. 5초 조회와 15초 만료를 확인하고, 목적지 변경 전의 늦은 ETA를 주입하여 확인 대기 중 자동 호출이 발생하지 않는지 확인한다. 등록 POI 정확 일치·인접 학원·같은 이름의 다른 지점도 검사한다. 내비 열기 버튼이 P·UX 허용일 때만 기존 OEM 화면을 요청하며 실제 경로는 유지되는지 확인한다.
7. `adb emu geo fix <경도> <위도>`로 학원 반경 바깥→안쪽을 재현하여 ENTER 이벤트와 마지막 위치의 시간·거리 정확도를 확인한다. 백그라운드 동작·도착 중복 여부·서비스 재연결은 아직 실측하지 않았다.
8. 기어 D/UNKNOWN 및 UX 제한 수신 실패에서 모든 입력이 잠기는지 확인한다. SDK 미지원 환경의 실제 오류 화면은 아직 테스트하지 않았다. OEM 내비를 연 뒤 Activity가 가려져도 서비스가 구독·5초 조회·전송을 유지하는지, 복귀 후 동일 세션인지, 프로세스 종료 후 기존 픽업이 CANCEL로 정리되는지 확인한다. OS의 실제 분할 배치·HUD·실차 동작은 이 코드 검토로 검증하지 않는다.

위 항목은 API 이름 검증으로 대체할 수 없는 실제 장치 검증이다. 현재 파일만으로 차량·내비 연동 완료 또는 제출용 주행 검증 통과를 주장하지 않는다.

## 배포물 SHA-256

| 배포물 | SHA-256 |
| --- | --- |
| Vehicle 2.3.2 AAR | `e11fdfe498cad3ecc0d5a2a6992b0c4a4d135195f1455018127bc069fd5ef937` |
| Vehicle 2.3.2 sources | `62b5dd2c4c0523fd13c2e64040cd775bc89a14ce54f35a37560d0eb4eb3fab40` |
| NaviHelper 3.0.5 AAR | `15fadd11c7c611b1abdf7ebf9ce91f2a6ce2728e60b4e38b4343e11bb9c12e97` |
| NaviHelper 3.0.5 sources | `915feb7246215e6999f4695ba6b51cf31e4c6a5d8a8c1b36f16a3ba353569201` |
| FusedLocation 1.1.3 AAR | `20ff6dc2efbea53f32d1ce4712d517fc4abac3a9ce4b990f4aca52c35ebef081` |
| FusedLocation 1.1.3 sources | `784a27bc24a19f1f0b493f46587ee1195edc14683ab0e24fd04725812755d627` |
| navi-data 3.0.4 sources | `4da974b6b0050662c4b346d3fca96073c8c1f241ce10c7d667cfef64cbceedaf` |

## 주행 중 화면의 OS 차단 검증

[공식 Pleos 주행 정책](https://document.pleos.ai/docs/pleos-only/vehicle-app-planning-guide/driving-restiction-policy)과 [주행 규제 개발 가이드](https://document.pleos.ai/docs/pleos-only/vehicle-app-developer-guide/driving-restriction-development-guide)는 DO 미선언 앱이 주행 중 차단될 수 있음을 설명한다. 에뮬레이터에서 최소 상태 화면을 검수하도록 **debug manifest에만** `distractionOptimized=true`를 선언했다. 설정과 버튼은 여전히 실제 기어 P 및 UX 제한 해제를 모두 요구한다.

이 debug 선언은 플랫폼의 심사 승인 또는 release 배포 허용을 의미하지 않는다. release에는 이를 선언하지 않는다. [Android 일반 AAOS 가이드](https://developer.android.com/training/cars/platforms/automotive-os)는 일반 배포에서 Car App Library의 CarAppActivity에만 DO 메타데이터를 두도록 안내하므로, 현재 Compose activity를 그대로 release로 배포하며 주행 중 표시된다고 주장하지 않는다. Pleos의 앱 카테고리·DO 승인 절차를 확인하고 필요하면 Car App Library 화면으로 전환해야 한다. 이 차이는 제출 전 해결할 플랫폼 통합 항목이다.
