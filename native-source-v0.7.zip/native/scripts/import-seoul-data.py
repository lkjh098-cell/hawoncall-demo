#!/usr/bin/env python3
"""Rebuild Seoul reference data from downloaded public source files; never issues permissions.

Requires openpyxl, pyproj and shapely. Usage: python import-seoul-data.py SOURCE_DIR
Raw source hashes, transformations and excluded rows are recorded in sources.json.
"""
import collections
import hashlib
import json
from pathlib import Path
import sys

import openpyxl
from pyproj import Transformer
from shapely.geometry import shape, mapping, Point, LineString
from shapely.ops import unary_union

src = Path(sys.argv[1])
out = Path(__file__).resolve().parents[1] / 'server/data'
out.mkdir(parents=True, exist_ok=True)

def write(name, value):
    (out / name).write_text(json.dumps(value, ensure_ascii=False, separators=(',', ':')) + '\n')

def read(name):
    return json.loads((src / name).read_text(encoding='utf-8-sig'))

boundary_source = read('boundary-20250401.geojson')
districts = [f for f in boundary_source['features'] if f['properties']['sido'] == '11']
boundary = unary_union([shape(f['geometry']) for f in districts])
assert boundary.is_valid and not boundary.is_empty
write('seoul-boundary.geojson', {'type':'Feature','properties':{
    'name':'서울특별시 서비스 범위', 'sourceId':'SGIS-vuski-20250401',
    'sourceName':'통계청 SGIS / vuski-admdongkor', 'referenceDate':'2025-04-01',
    'sourceUrl':'https://github.com/vuski/admdongkor', 'license':'CC BY 4.0 + SGIS attribution',
    'note':'행정동을 합친 참고 경계. 법적 경계 또는 최신 측량 결과가 아님.'}, 'geometry':mapping(boundary)})

road_url = 'https://data.seoul.go.kr/dataList/OA-15060/F/1/datasetView.do'
groups = collections.defaultdict(list)
w = openpyxl.load_workbook(src/'roads-2025.xlsx', read_only=True, data_only=True)
rows = w.active.values
assert next(rows) == ('LINK_ID','VER_SEQ','GRS80TM_X','GRS80TM_Y')
# GRS80 middle-belt TM: easting 200000 / northing 500000. Values are checked
# against Seoul bounds; CRS interpretation remains explicit in provenance.
transform = Transformer.from_crs('EPSG:5181','EPSG:4326',always_xy=True)
vertex_count=0
blank_rows=0
for link, seq, x, y in rows:
    if all(v is None for v in (link,seq,x,y)):
        blank_rows += 1
        continue
    assert all(v is not None for v in (link,seq,x,y)), 'Partial road row requires source review'
    lon, lat = transform.transform(float(x),float(y))
    assert 125 < lon < 129 and 36 < lat < 39, 'Unexpected CRS/range'
    groups[str(link)].append((int(seq),[round(lon,8),round(lat,8)]))
    vertex_count += 1
roads=[]
for link, vertices in groups.items():
    vertices.sort()
    assert len({p[0] for p in vertices}) == len(vertices), 'Duplicate sequence'
    if len(vertices)<2: continue
    line=LineString([v[1] for v in vertices]).intersection(boundary)
    if line.is_empty or line.geom_type not in ('LineString','MultiLineString'): continue
    roads.append({'type':'Feature','id':link,'properties':{'sourceId':'OA-15060','linkId':link},'geometry':mapping(line)})
write('seoul-roads.geojson', {'type':'FeatureCollection','sourceId':'OA-15060','sourceName':'서울시 교통소통 서비스링크 보간점 · 2025','sourceUrl':road_url,'referenceDate':'2025-03-06','source':{'name':'서울특별시 TOPIS · 교통소통 서비스링크','referenceDate':'2025-03-06','url':road_url,'year':2025},'features':roads})

parking=read('parking.json')['DATA']
spots=[]; excluded=collections.Counter(); ids=set()
for row in parking:
    lat, lon=row.get('lat'),row.get('lot')
    if not isinstance(lat,(int,float)) or not isinstance(lon,(int,float)):
        excluded['missingCoordinates']+=1; continue
    if not boundary.covers(Point(lon,lat)):
        excluded['outsideReferenceSeoulBoundary']+=1; continue
    sid='SEOUL-PARK-'+str(row['pklt_cd'])
    if sid in ids: excluded['duplicateId']+=1; continue
    ids.add(sid)
    spots.append({'type':'Feature','id':sid,'geometry':{'type':'Point','coordinates':[lon,lat]},'properties':{
        'name':row['pklt_nm'],'address':'서울특별시 '+row['addr'], 'sourceId':'OA-13122',
        'sourceName':'서울시 공영주차장 안내 정보','sourceUrl':'https://data.seoul.go.kr/dataList/OA-13122/S/1/datasetView.do',
        'sourceSyncedAt':row.get('last_data_sync_tm'),'referenceKind':'PUBLIC_PARKING',
        'parkingKind':row.get('pklt_knd_nm'),'operationKind':row.get('oper_se_nm'),
        'state':'UNVERIFIED','note':'공영주차장 대표좌표. 입구·승하차 위치 및 보행 연결은 현장 확인 필요.'}})
write('seoul-reference.geojson',{'type':'FeatureCollection','features':spots})

w=openpyxl.load_workbook(src/'zones-2026.xlsx',read_only=True,data_only=True)
zone_rows=list(w['어린이보호구역 지정현황'].values)
zones=[]
for row in zone_rows[5:]:
    _,number,district,dong,address,name,kind,year,*_=row
    if not isinstance(number,(int,float)) or not name or not address: continue
    zones.append({'district':district,'neighborhood':dong,'address':str(address).strip(),
                  'name':name,'institutionTypeLabel':kind,'designationYear':year})
assert len(zones)==1630, 'Source header count mismatch: inspect new source before importing'
write('seoul-protection-zones.json',{'sourceId':'OA-2799','referenceDate':'2026-06-30',
      'sourceUrl':'https://data.seoul.go.kr/dataList/OA-2799/F/1/datasetView.do',
      'geometryAvailable':False,'note':'지정 시설 주소 목록. 도로별 규제 경계나 승하차 허용 지점 목록이 아님.', 'records':zones})

counts={'sourceRoadVertices':vertex_count,'sourceRoadLinks':len(groups),'seoulRoadLinks':len(roads),
        'blankRoadRowsExcluded':blank_rows,
        'sourceParkingRows':len(parking),'seoulParkingReferences':len(spots),'excludedParking':dict(excluded),
        'protectionFacilities':len(zones),'seoulBoundarySourceFeatures':len(districts),'verifiedPickupPoints':0}
write('sources.json',{'collectedOn':'2026-10-25','counts':counts,
      'sourceFiles':[{ 'file':name,'sha256':hashlib.sha256((src/name).read_bytes()).hexdigest()} for name in ['roads-2025.xlsx','parking.json','zones-2026.xlsx','boundary-20250401.geojson']],
      'sources':[
        {'id':'OA-15060','url':road_url,'publisher':'서울특별시','license':'공공누리 제1유형','referenceDate':'2025-03-06','transformation':'LINK_ID별 VER_SEQ순 선형 구성, EPSG:5181 해석 → WGS84 변환, 서울 참고경계 교차. 골목 전체/방향별 진입/정차 규제가 아닌 교통소통 서비스 링크.'},
        {'id':'OA-13122','url':'https://data.seoul.go.kr/dataList/OA-13122/S/1/datasetView.do','publisher':'서울특별시','license':'공공누리 제1유형','transformation':'좌표 없는 행/서울 참고경계 밖 제외. 원본 대표좌표 유지. 현장 허용 여부 미확인.'},
        {'id':'OA-2799','url':'https://data.seoul.go.kr/dataList/OA-2799/F/1/datasetView.do','publisher':'서울특별시','license':'공공누리 제1유형','referenceDate':'2026-06-30','transformation':'어린이보호구역 지정현황 시트의 시설 1630행. 다른 시트의 과거 기준 집계 미사용. 좌표/도로규제 경계 미제공.'},
        {'id':'SGIS-vuski-20250401','url':'https://github.com/vuski/admdongkor','publisher':'통계청 SGIS 원자료 / vuski 가공','license':'CC BY 4.0; SGIS 공공누리 제1유형 출처 승계','referenceDate':'2025-04-01','transformation':'sido=11 행정동만 추출하여 합역. 법적경계/최신시점 보장 없음.'}
      ],'permissionNote':'공개 참고 자료는 허용 근거를 만들지 않는다. 별도 현장·운영 검증 전 허용 지점 0개.'})
print(json.dumps(counts,ensure_ascii=False,indent=2))
