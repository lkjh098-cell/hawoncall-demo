#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
ADB_BIN=${ADB_BIN:-adb}
MODE=${1:-test}
case "$MODE" in
  test)
    "$ADB_BIN" install -r "$ROOT/apk/hawoncall-guardian-debug.apk"
    "$ADB_BIN" install -r "$ROOT/apk/hawoncall-car-demo-debug.apk"
    ;;
  guardian) "$ADB_BIN" install -r "$ROOT/apk/hawoncall-guardian-debug.apk" ;;
  pleos) "$ADB_BIN" install -r "$ROOT/apk/hawoncall-pleos-debug.apk" ;;
  *) echo 'Usage: install-android.sh test|guardian|pleos'; exit 2 ;;
esac
