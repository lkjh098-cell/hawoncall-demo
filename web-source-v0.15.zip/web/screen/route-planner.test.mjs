import test from 'node:test';
import assert from 'node:assert/strict';
import {REAL_ROUTE} from './route-data.mjs';
import {PRESET_PLACES,PROVIDER_CONFIG,parsePlaceResults,parseRouteResponse,buildExampleRoute,validPlannedRoute,isSeoulCoordinate,searchUrl,routeUrl,searchPlaces} from './route-planner.mjs';
const origin=PRESET_PLACES[0],target=PRESET_PLACES[1];
function response(){return {code:'Ok',routes:[{distance:REAL_ROUTE.totalMeters,duration:REAL_ROUTE.durationSeconds,geometry:{type:'LineString',coordinates:structuredClone(REAL_ROUTE.coordinates)},legs:[{steps:structuredClone(REAL_ROUTE.steps)}]}]};}
function feature(coordinates=[127.05,37.5],properties={name:'실제 응답 이름',city:'서울특별시',street:'테헤란로',housenumber:'1',countrycode:'KR'}){return {type:'Feature',geometry:{type:'Point',coordinates},properties};}
const collection=features=>({type:'FeatureCollection',features});
test('all offline places are inside precise Seoul scope and example is a valid complete route',()=>{
  for(const p of PRESET_PLACES)assert.equal(isSeoulCoordinate(p.coordinates),true,p.name);
  const r=buildExampleRoute();assert.equal(validPlannedRoute(r),true);assert.match(r.institution.name,/예시/);assert.equal(r.institution.type,'academy');assert.notEqual(r.coordinates,REAL_ROUTE.coordinates);assert.deepEqual(r.origin.coordinates,REAL_ROUTE.coordinates[0]);assert.deepEqual(r.target.coordinates,REAL_ROUTE.coordinates.at(-1));
});
test('Photon results retain returned identity, address, and geometry without inventing searched names',()=>{
  const [p]=parsePlaceResults(collection([feature()]));assert.equal(p.name,'실제 응답 이름');assert.match(p.address,/테헤란로 1/);assert.deepEqual(p.coordinates,[127.05,37.5]);assert.match(p.sourceUrl,/openstreetmap/);
  assert.deepEqual(parsePlaceResults(collection([feature([127.05,37.5],{})])),[]);
  const [address]=parsePlaceResults(collection([feature([127.05,37.5],{street:'테헤란로',housenumber:'1'})]));assert.equal(address.name,'테헤란로 1');
});
test('search rejects non-Seoul results even inside broad bbox, malformed points, other countries, and duplicates',()=>{
  assert.deepEqual(parsePlaceResults(collection([feature([127.139,37.595]),feature([126.95,37.4]),feature(['127.05',37.5]),feature([NaN,37.5]),feature([127.05,37.5],{name:'not Korea',countrycode:'JP'})])),[]);
  assert.equal(parsePlaceResults(collection([feature(),feature()])).length,1);assert.deepEqual(parsePlaceResults({features:[feature()]}),[]);assert.deepEqual(parsePlaceResults(null),[]);
});
test('search bounds are explicit and provider endpoints switch without rewriting code',()=>{
  const u=new URL(searchUrl('선릉역','https://example.org/search'));assert.equal(u.searchParams.get('q'),'선릉역');assert.equal(u.searchParams.get('bbox'),'126.76,37.42,127.19,37.71');assert.equal(u.searchParams.get('limit'),'6');assert.equal(u.origin,'https://example.org');assert.throws(()=>searchUrl('a'));for(const base of ['http://example.org','javascript:alert(1)','https://user:pass@example.org/','https://example.org/?key=secret'])assert.throws(()=>searchUrl('서울',base));assert.match(PROVIDER_CONFIG.search,/photon/);
});
test('OSRM request contains selected coordinates only, excludes the custom institution name',()=>{
  const r=buildExampleRoute({name:'입력한 기관명',type:'school'}),u=routeUrl(r.origin,r.target);assert.ok(u.includes('127.049657,37.504591;127.062978,37.494462'));assert.equal(new URL(u).searchParams.get('steps'),'true');assert.equal(u.includes(r.institution.name),false);assert.throws(()=>routeUrl({...origin,coordinates:[126.95,37.4]},target));
});
test('valid OSRM road response preserves real distance, duration, and maneuver steps',()=>{
  const p=parseRouteResponse(response(),origin,target);assert.equal(p.totalMeters,2149.6);assert.equal(p.durationSeconds,146.6);assert.equal(p.steps.length,4);assert.equal(p.steps.at(-1).maneuver.type,'arrive');assert.notEqual(p.coordinates,REAL_ROUTE.coordinates);
});
test('route rejects wrong endpoint snaps and invalid places rather than silently relocating',()=>{
  assert.equal(parseRouteResponse(response(),{...origin,coordinates:[126.978,37.5665]},target),null);
  assert.equal(parseRouteResponse(response(),origin,{...target,coordinates:[127.1002,37.5133]}),null);
  assert.equal(parseRouteResponse(response(),{...origin,name:''},target),null);
});
test('route rejects outside Seoul geometry, nonfinite data, invalid distances, oversized or short routes',()=>{
  for(const patch of [r=>r.code='NoRoute',r=>r.routes[0].distance=0,r=>r.routes[0].distance=151,r=>r.routes[0].distance=Infinity,r=>r.routes[0].duration=-1,r=>r.routes[0].duration=90000,r=>r.routes[0].geometry.type='Point',r=>r.routes[0].geometry.coordinates[2]=[127.139,37.595],r=>r.routes[0].geometry.coordinates[2]=[127.05,NaN],r=>r.routes[0].geometry.coordinates=Array.from({length:20001},()=>[127.05,37.5]),r=>r.routes[0].distance=100000]){const r=response();patch(r);assert.equal(parseRouteResponse(r,origin,target),null);}
});
test('route rejects malformed maneuver structures and inconsistent step totals',()=>{
  for(const patch of [r=>r.routes[0].legs=null,r=>r.routes[0].legs={},r=>r.routes[0].legs=[null],r=>r.routes[0].legs.push({}),r=>r.routes[0].legs[0].steps=[],r=>r.routes[0].legs[0].steps[0].distance=NaN,r=>r.routes[0].legs[0].steps[0].duration=-2,r=>r.routes[0].legs[0].steps[1].maneuver.location=[126.95,37.4],r=>r.routes[0].legs[0].steps[0].maneuver.type='arrive',r=>r.routes[0].legs[0].steps.at(-1).maneuver.type='turn',r=>r.routes[0].legs[0].steps[1].geometry.coordinates=[[127.05,37.5]],r=>r.routes[0].legs[0].steps[0].name=null,r=>r.routes[0].legs[0].steps[0].distance=90000]){const r=response();patch(r);assert.equal(parseRouteResponse(r,origin,target),null);}
});
test('saved route validation requires all metadata and rejects mutated road geometry',()=>{
  const r=buildExampleRoute({name:'서울학교',type:'school'});assert.equal(validPlannedRoute(r),true);
  for(const patch of [r=>delete r.origin,r=>r.id='',r=>r.institution.type='unknown',r=>r.institution.name='',r=>r.target.coordinates=[127.139,37.595],r=>r.coordinates[5]=[NaN,37.5]]){const copy=structuredClone(r);patch(copy);assert.equal(validPlannedRoute(copy),false);}
});
test('search is explicitly requested, cached, and cannot continue a cancelled query',async()=>{
  const old=globalThis.fetch;let calls=0;globalThis.fetch=async()=>{calls++;return {ok:true,text:async()=>JSON.stringify(collection([feature()]))};};
  try{const options={base:'https://example.org/test-cache'};const a=await searchPlaces('서울 테스트',options),b=await searchPlaces('서울 테스트',options);assert.equal(calls,1);assert.deepEqual(a,b);a[0].name='changed';assert.equal(b[0].name,'실제 응답 이름');const controller=new AbortController();controller.abort();await assert.rejects(searchPlaces('다른 검색',{...options,signal:controller.signal}),{name:'AbortError'});assert.equal(calls,1);}finally{globalThis.fetch=old;}
});
