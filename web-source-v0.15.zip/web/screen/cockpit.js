import {mountRoutePlanner,validPlannedRoute} from './route-planner.mjs';
import {mountShowcase} from './showcase.mjs';
import {mountStopZone,stopZoneNotice} from './stop-zone.mjs';
import {mountDriveControls} from './drive-controls.mjs';
import {mountLiveGPS} from './live-gps-ui.mjs';
import {mountOperations} from './operations-ui.mjs';
import {createInitialState,reduce,view} from './model.mjs';
import {REAL_ROUTE} from './route-data.mjs';
import {createRoadMap,guidanceForProgress,navigationPoseForProgress} from './real-map.mjs';
import {DEMO_STORAGE_KEY,packDemoState,restoreDemoState} from './sync.mjs';
import {mountPleosShell,updatePleosShell,openShellApp} from './pleos-shell.mjs';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const source=globalThis.crypto?.randomUUID?.()||Math.random().toString(36).slice(2);
const ROUTE_STORAGE_KEY=DEMO_STORAGE_KEY+'.route';
let activeRoute=REAL_ROUTE;
try{const saved=JSON.parse(localStorage.getItem(ROUTE_STORAGE_KEY)||'null');if(validPlannedRoute(saved))activeRoute=saved;}catch{}
const initial=()=>createInitialState({now:Date.now(),route:activeRoute,institution:activeRoute.institution?.type,playbackRate:1});
let state=initial(), revision=0, lastPaint=0,lastPublish=0,lastFrame=performance.now(),follow=true,toastTimer,activeView=(['guardian','child'].includes(new URL(location.href).searchParams.get('view'))?new URL(location.href).searchParams.get('view'):location.pathname.endsWith('/child')?'child':'vehicle');
const childOnly=activeView==='child',guardianOnly=activeView==='guardian'||childOnly;
const fmtDistance=n=>n>=1000?`${(n/1000).toFixed(1)}km`:`${Math.max(0,Math.round(n/10)*10)}m`;
let channel;try{channel=new BroadcastChannel(DEMO_STORAGE_KEY);}catch{}
let storageAvailable=true;try{const p=JSON.parse(localStorage.getItem(DEMO_STORAGE_KEY)||'null'),s=restoreDemoState(p,initial());if(s){state={...s,playing:false,now:Date.now()};revision=p.revision;}}catch{storageAvailable=false;}
const map=createRoadMap($('#mapViewport'),{route:activeRoute,statusElement:$('#mapStatus'),onFollowChange:syncFollow,maplibre:childOnly?null:globalThis.maplibregl});
const operations=mountOperations({getJourney:()=>{const v=view({...state,now:Date.now()});return {...v,turnDistanceMeters:guidanceForProgress(activeRoute,v.progress).distanceMeters};},guardianOnly,source,toast,route:activeRoute});
mountPleosShell({map,toast,openBrief:()=>operations.openBrief()});
let driveControls,showcase,routePlanner;
function syncFollow(enabled){follow=enabled;$('#orientation').classList.toggle('active',enabled);$('#orientation').setAttribute('aria-pressed',String(enabled));$('#orientation').setAttribute('aria-label',enabled?'차량 따라가는 중':'차량 위치로 돌아가기');}
const liveGPS=mountLiveGPS({map,route:activeRoute,getJourney:()=>view({...state,now:Date.now()}),toast,onPause:()=>send('PAUSE'),childOnly,guardianOnly});
const stopZones=mountStopZone({getJourney:()=>view({...state,now:Date.now()}),hasMeetingPreview:()=>liveGPS.hasMeetingPreview(),guardianOnly});
if(activeRoute!==REAL_ROUTE)stopZones.setScenario?.('unknown');
driveControls=mountDriveControls({getJourney:()=>view({...state,now:Date.now()}),play:()=>send('PLAY'),pause:()=>send('PAUSE'),reset, setRate:rate=>send('PLAYBACK_RATE',{rate}),openNavigation:()=>{openShellApp('navigation');follow=true;map.follow(true);},guardianOnly});
showcase=mountShowcase({onScene:openPresentationScene,getJourney:()=>view({...state,now:Date.now()}),guardianOnly});
function openPresentationScene(id){
  operations.stop('장면이 바뀌어 음성 안내를 멈췄어요.');
  $$('dialog[open]').forEach(d=>d.close());
  $('#simulationDrawer').hidden=true;$('#drawerToggle').setAttribute('aria-expanded','false');
  driveControls.setRepeat(false);
  if(state.playing)send('PAUSE');
  if(id==='guardian'){switchView('guardian');return true;}
  if(id==='child'){switchView('child');return true;}
  switchView('vehicle');
  if(id==='start'){openShellApp('navigation');reset();send('PLAYBACK_RATE',{rate:3});send('PLAY');liveGPS.startDemo();return true;}
  if(id==='meeting'){
    if(state.confirmed||state.routeMismatch)reset();
    send('PARK');openShellApp('navigation');
    if(!liveGPS.startDemo())return false;
    map.focusLiveTarget();liveGPS.openMeeting();return true;
  }
  if(id==='approach'){
    liveGPS.stop('기관 경로 시연으로 돌아왔어요.');
    if(state.confirmed||state.routeMismatch)reset();
    openShellApp('navigation');stopZones.setScenario?.('prohibited');send('APPROACH');
    $('#simulationDrawer').hidden=false;$('#drawerToggle').setAttribute('aria-expanded','true');return true;
  }
  if(id==='boarding'){
    liveGPS.stop('기관 경로에서 탑승 확인을 시연해요.');
    if(state.confirmed||state.routeMismatch)reset();
    stopZones.setScenario?.('unknown');send('APPROACH');send('PARK');send('SENSOR');
    openShellApp('hawon');openConfirm();return true;
  }
  if(id==='briefing'){if(state.gear!=='P')send('PARK');openShellApp('media');operations.openBrief();return true;}
  if(id==='operations'){
    if(state.gear!=='P')send('PARK');openShellApp('hawon');operations.showPanel('readiness');
    $('#simulationDrawer').hidden=false;$('#drawerToggle').setAttribute('aria-expanded','true');return true;
  }
  if(id==='apps'){if(state.gear!=='P')send('PARK');openShellApp('library');return true;}
  return false;
}
function applyRoute(route,{remote=false}={}){
 if(!remote&&state.gear!=='P'){toast('P 정차 후 경로를 바꿔 주세요.');return false;}
 activeRoute=route;operations.stop('새 경로로 운행을 준비해요.');liveGPS.setRoute(route);operations.setRoute(route);map.setRoute(route);
 driveControls.setRepeat(false);state=createInitialState({now:Date.now(),route,tripGeneration:(state.tripGeneration||0)+1,institution:route.institution?.type||state.institution,mode:state.mode,playbackRate:state.playbackRate});
 stopZones.setScenario?.('unknown');syncFollow(true);
 if(!remote){try{localStorage.setItem(ROUTE_STORAGE_KEY,JSON.stringify(route));}catch{storageAvailable=false;}openShellApp('navigation');publish();render();toast('새 경로와 하원콜 기관을 반영했어요. 시연 재생으로 출발하세요.');}
 return true;
}
routePlanner=mountRoutePlanner({getRoute:()=>activeRoute,getJourney:()=>view(state),onApply:applyRoute,toast,onOpen:()=>{operations.stop();openShellApp('navigation');}});
$('.system-left').append($('#routePlannerOpen'));
if(guardianOnly)$('#routePlannerOpen').hidden=true;
const searchIcon=$('.system-left > svg');if(searchIcon){const searchButton=document.createElement('button');searchButton.className='status-place-search';searchButton.setAttribute('aria-label','출발지 도착지 검색');searchIcon.replaceWith(searchButton);searchButton.append(searchIcon);searchButton.onclick=()=>{if(!guardianOnly)routePlanner.open();};}
function publish(){if(guardianOnly)return;const p=packDemoState(state,source,revision=Math.max(Date.now(),revision+1));try{localStorage.setItem(DEMO_STORAGE_KEY,JSON.stringify(p));}catch{storageAvailable=false;}try{channel?.postMessage(p);}catch{}lastPublish=performance.now();}
function receive(p){if(p?.source===source||p?.revision<=revision)return;let nextRoute=p?.routeId===REAL_ROUTE.id?REAL_ROUTE:activeRoute;if(p?.routeId!==activeRoute.id&&p?.routeId!==REAL_ROUTE.id){try{const saved=JSON.parse(localStorage.getItem(ROUTE_STORAGE_KEY)||'null');if(validPlannedRoute(saved)&&saved.id===p.routeId)nextRoute=saved;}catch{}}
const restored=restoreDemoState(p,createInitialState({now:Date.now(),route:nextRoute}));if(!restored)return;if(nextRoute!==activeRoute)applyRoute(nextRoute,{remote:true});state=restored;revision=p.revision;render();}
if(channel)channel.onmessage=e=>receive(e.data);
window.addEventListener('storage',e=>{if(e.key===DEMO_STORAGE_KEY){try{receive(JSON.parse(e.newValue));}catch{}}});
function toast(t){$('#toast').textContent=t;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),3000);}
function send(type,extra={}){if(guardianOnly)return;if(['PLAY','DRIVE','APPROACH'].includes(type)){map.follow(true);syncFollow(true);}const previous=state;state=reduce(state,{type,now:Date.now(),...extra});operations.onTransition(type,previous);driveControls?.onTransition(type);if(['RESET','SCENARIO','NAVIGATION','PLAY','DRIVE','APPROACH'].includes(type))liveGPS?.onJourneyChange();render();publish();}
function switchView(v){operations.stop('화면이 바뀌어 음성 안내를 멈췄어요.');activeView=v;$('#vehicleView').hidden=v!=='vehicle';$('#guardianView').hidden=v!=='guardian';$('#childView').hidden=v!=='child';document.body.classList.toggle('child-active',v==='child');document.body.classList.toggle('guardian-active',v==='guardian');$('#guardianToggle').textContent=v==='guardian'?'차량 화면':'보호자 화면';setTimeout(()=>map.resize(),40);}
function openConfirm(){if(guardianOnly)return;if(!view(state).canConfirm){toast(state.mode==='dropoff'?'D 근접 → P 주차 후 직접 인계를 확인해 주세요.':'D 근접 → P 주차 → 가상 탑승 신호 순서로 진행해 주세요.');return;}$('#confirmDialog').showModal();}
function reset(){send('RESET');follow=true;$('#orientation').classList.add('active');map.follow(true);}
const directions={left:['↰','좌회전'],right:['↱','우회전'],'slight left':['↖','왼쪽 방향'],'slight right':['↗','오른쪽 방향'],'sharp left':['↰','크게 좌회전'],'sharp right':['↱','크게 우회전'],uturn:['↶','유턴'],straight:['↑','직진']};
function navigationArrow(modifier,near){
 const path=near?'M16 48V8m0 3h27l-7 9 7 9H16':modifier==='uturn'?'M41 47V20a13 13 0 0 0-26 0v15m-10-10 10 10 10-10':modifier==='straight'?'M28 48V8m-13 13L28 8l13 13':'M17 48V24q0-10 10-10h20m-12-10 12 10-12 10';
 const transform=!near&&modifier.includes('left')?' transform="translate(56 0) scale(-1 1)"':'';
 return `<svg viewBox="0 0 56 56" fill="none" stroke="currentColor" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${path}"${transform}/></svg>`;
}
function render(){
 const v=view({...state,now:Date.now()}), drop=v.mode==='dropoff', noun=v.institutionLabel, destination=activeRoute.institution?.name||activeRoute.destination||`대치동 ${noun}(시연)`, done=v.confirmed,near=v.near,parked=v.arrival,mins=Math.max(1,Math.ceil(v.etaSeconds/60));
 const confirmWord=drop?'인계':'탑승', confirmObject=drop?'인계를':'탑승을', movement=v.institution==='school'?(drop?'등교':'하교'):(drop?'등원':'하원');
 $('#institution').value=v.institution;$$('[data-mode]').forEach(b=>{b.classList.toggle('selected',b.dataset.mode===v.mode);b.setAttribute('aria-pressed',String(b.dataset.mode===v.mode));b.innerHTML=(v.institution==='school'?(b.dataset.mode==='dropoff'?'등교':'하교'):(b.dataset.mode==='dropoff'?'등원':'하원'))+' <small>'+ (b.dataset.mode==='dropoff'?'DROPOFF':'PICKUP')+'</small>';});
 updatePleosShell({...v,motionHeading:navigationPoseForProgress(activeRoute.coordinates,v.progress).heading,motionCoordinates:activeRoute.coordinates});driveControls?.render(v);
 $('#modeLabel').textContent=movement;$('#destinationName').textContent=destination;$('#childContext').textContent=`${noun} · ${activeRoute.institution?.name?'등록 기관':'시연 데이터'}`;$('#mapViewport').setAttribute('aria-label',`${activeRoute.origin?.name||'선릉역 인근'}에서 ${destination}까지 실제 도로 지도`);$('.scenario-note').textContent=activeRoute.name||`${activeRoute.origin?.name||'출발지'} → ${destination}`;map.setDestination?.(destination);
 $('#speed').textContent=Math.round(v.speedKph);$('#gear').textContent=v.gear;$('#clock').textContent=new Date().toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit',hour12:false});
 $('#etaText').textContent=parked||done?`P 주차 · ${confirmWord} ${done?'확인 완료':'확인 전'}`:`약 ${mins}분 · ${fmtDistance(v.remainingMeters)} · 시연 ETA`;
 $('#arrivalTime').textContent=parked||done?'도착':new Date(Date.now()+v.etaSeconds*1000).toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit',hour12:false});
 const g=guidanceForProgress(activeRoute,v.progress),[arrow,direction]=directions[g.modifier]||directions.straight;
 $('#turnArrow').innerHTML=navigationArrow(g.modifier,near);$('#turnDistance').innerHTML=near?(parked?'P <small>정차</small>':'150 <small>m 이내</small>'):`${Math.round(g.distanceMeters/10)*10} <small>m</small>`;
 $('#turnRoad').textContent=near?(parked?`${destination} · 정차 중`:'D 근접 · 안전하게 정차 후 P 전환'):`${g.road} · ${direction}`;
 const copies={
 ready:[`${movement} 준비`,`${noun}까지<br>약 ${mins}분`,drop?'도착 후 보호자가 직접 인계를 확인해요.':'도착 시간에 맞춰 하원 준비를 알려드려요.','↗','현재 내비 경로 유지','시연 조작에서 재생할 수 있어요.'],
 driving:[`${movement} · 이동 중`,`도착 약 ${mins}분 전`,drop?'도착 후 인계를 준비해 주세요.':'기관에 준비 알림을 보낸 시나리오예요.','↗','준비 요청 · 시연','현재 내비 경로를 그대로 따라가요.'],
 approach:[`${noun} 근처 · D`, '정차를 기다려요','근접만으로 도착을 확정하지 않아요.','P','아직 주행 상태예요','정차 후 P를 확인해 주세요.'],
 arrived:[`${noun} 근처 · P`,drop?'인계를 확인해 주세요':'탑승을 기다려요','기관 근처에서 가상 P를 확인했어요.','P','정차 상태 확인',drop?'기관 담당자에게 직접 인계한 뒤 확인해요.':'탑승 신호는 보호자 확인 전까지 후보예요.'],
 candidate:['보호자 확인이 필요해요',drop?'아이의 인계를<br>직접 확인해 주세요':'아이가 탔는지<br>한 번 더 확인해요',drop?'문·좌석 신호는 하차 후보예요.<br>기관 담당자에게 인계했는지 확인해요.':'문·착석 신호는 탑승 후보예요.<br>실제 아이의 탑승을 직접 확인해요.','✓',`${drop?'하차':'탑승'} 신호 · 아직 미확인`,drop?'센서는 기관 입실이나 인계를 증명하지 않아요.':'센서 신호만으로 탑승을 확정하지 않아요.'],
 confirmed:[`${movement} 완료`,`${confirmWord} 확인 완료`,`보호자가 직접 ${confirmObject} 확인했어요.`,'✓',`보호자 ${confirmWord} 확인`,'시연 기록에 반영했어요.'],
 stale:['차량 정보 확인 중','최근 차량 정보를<br>기다리고 있어요','최신 가상 상태가 필요해요.<br>시연 단계를 다시 선택해 주세요.','·','정보 수신 대기','오래된 신호로 확인을 진행하지 않아요.'],
 'route-changed':['경로 확인 중','경로가 바뀌어<br>확인을 멈췄어요','미리 저장된 경로를 확인해 주세요.','↗','경로 변경','처음부터 다시 시연해 주세요.'],
 departed:['차량 출발','안전한 이동을<br>이어가요','보호자가 직접 확인한 기록만 유지해요.','↗','차량 출발','처음부터 다시 체험할 수 있어요.']
 };
 const zone=stopZoneNotice(v,{scenario:stopZones.getScenario(),meetingPreview:liveGPS.hasMeetingPreview()});
 const c=[...(copies[v.stage]||copies.ready)];if(zone?.kind==='prohibited'&&['approach','arrived'].includes(v.stage)){c[1]='허용된 장소를 확인해요';c[2]='금지구역을 가정한 시연이에요. 현장 규제를 확인해 주세요.';c[3]='⊘';c[4]='이곳에는 정차하지 마세요';c[5]='P 기어는 정차 허용을 뜻하지 않아요.';}
 if(zone&&near)$('#turnRoad').textContent=zone.kind==='prohibited'?'금지구역 가정 · 허용된 지점 확인':zone.kind==='allowed'?'가능구역 가정 · 현장 표지·시간 확인':'주정차 여부 · 현장 확인 필요';$('#eyebrow').textContent=activeRoute.institution?.name&&['ready','driving'].includes(v.stage)?`${activeRoute.institution.name} · ${c[0]}`:c[0];$('#journeyTitle').innerHTML=c[1];$('#journeyDescription').innerHTML=c[2];$('#stateIcon').textContent=c[3];$('#stateTitle').textContent=c[4];$('#stateDetail').textContent=c[5];
 $('#stepMove').classList.add('active');$('#stepPark').classList.toggle('active',parked||done);$('#stepConfirm').classList.toggle('active',done);
 $('#assuranceText').textContent=drop?'보호자 인계 확인 · 센서는 기관 입실 증명 불가':'최종 탑승은 보호자가 직접 확인해요.';
 const action=$('#actionArea');let confirmButton=action.querySelector('button');if(v.canConfirm){if(!confirmButton){confirmButton=document.createElement('button');confirmButton.className='primary-button';confirmButton.onclick=openConfirm;action.append(confirmButton);}confirmButton.textContent=`보호자 ${confirmWord} 확인`;}else if(confirmButton)action.replaceChildren();
 const active=done?'guardian':v.candidate?'sensor':parked?'park':near?'approach':v.stage==='driving'?'driving':null;
 $$('[data-stage]').forEach(b=>{const stage=b.dataset.stage;b.classList.toggle('active',stage===active);b.setAttribute('aria-pressed',String(stage===active));b.disabled=stage==='park'?(!near||done):stage==='sensor'?(!v.canSensor||v.candidate):stage==='guardian'?!v.canConfirm:false;});
 $('#sensorLabel').textContent=drop?'하차 신호':'탑승 신호';$('#playIcon').textContent=v.playing?'Ⅱ':'▶';$('#playText').textContent=v.playing?'일시 정지':done?'시연 완료':near?'단계 선택':'시연 재생';$('#playPause').disabled=near||done;
 $('#directorHint').textContent=near&&!parked?'D 근접이에요. P 주차를 직접 선택해 주세요.':v.candidate?`센서는 후보예요. 보호자가 ${confirmObject} 직접 확인해 주세요.`:done?`보호자가 명시적으로 ${confirmObject} 확인한 시연 기록이에요.`:parked?(drop?'직접 인계했다면 보호자 확인을 선택해 주세요. 하차 신호는 선택 사항이에요.':'가상 탑승 신호를 선택하면 보호자 확인으로 이어져요.'):`재생 속도 ${v.playbackRate}× · 가상 차량이 실제 도로 위를 이동해요.`;
 $('#eventMessage').textContent=v.notice||(drop?'DROPOFF · 보호자의 직접 인계가 최종 단계예요. 센서는 기관 입실을 증명하지 않아요.':'PICKUP · 최종 탑승은 보호자가 직접 확인해요. 지도 외 모든 차량 신호·알림은 시연이에요.');
 $('#guardianInstitution').textContent=destination;$('#guardianTitle').textContent=done?`보호자가 ${confirmObject} 확인했어요`:v.candidate?`${confirmObject} 직접 확인해 주세요`:parked?'차량이 P로 주차했어요':near?'차량이 근처에 있어요':v.stage==='driving'?`약 ${mins}분 뒤 만나요`:'아직 출발 전이에요';
 $('#guardianDescription').textContent=done?(drop?'직접 인계한 보호자의 시연 기록이에요. 기관 입실을 증명하는 기록은 아니에요.':'아이의 실제 탑승을 직접 확인한 보호자의 시연 기록이에요.'):v.candidate?(drop?'하차 신호만으로 입실은 확인되지 않아요. 기관 담당자에게 직접 인계했는지 확인해 주세요.':'문·착석 신호가 감지됐어요. 아이가 실제 차량에 탔는지 직접 확인해 주세요.'):'이 화면의 차량 상태와 준비 요청은 모두 가상 시연이에요.';
 $('#guardianEta').textContent=done?`${confirmWord} 확인 완료`:parked?'기관 근처 P 주차':near?'150m 이내 · D 근접':`약 ${mins}분 후 도착`;$('#guardianGear').textContent=`${v.gear} · ${done?'보호자 확인 완료':parked?`${confirmWord} 확인 전`:'가상 차량 상태'}`;
 $('#guardianTimeline').innerHTML=`<div class="${v.progress>0?'done':'pending'}">${v.progress>0?'✓':'○'} 도착 예정 안내 · 시연</div><div class="${parked||done?'done':'pending'}">${parked||done?'✓':'○'} 100m 이내 · P 주차</div><div class="${done?'done':'pending'}">${done?'✓':'○'} 보호자 직접 ${confirmWord} 확인</div>`;
 $('#guardianConfirm').textContent=done?`보호자 ${confirmWord} 확인 완료`:'차량에서 보호자 확인을 기다려요';$('#guardianConfirm').disabled=true;
 $('#guardianFootnote').textContent=drop?'문·좌석 센서는 기관 입실이나 인계를 증명하지 않아요.':'문·착석 신호만으로 탑승을 확정하지 않아요.';
 $('#guardianRule').textContent=drop?'기관 담당자에게 아이를 직접 인계한 보호자가 차량 화면에서 확인해요. 모바일 화면은 일정·요청을 작성하고, 차량에서만 직접 인계를 확정해요.':'아이의 실제 탑승을 직접 확인한 보호자가 차량 화면에서 확인해요. 모바일 화면은 일정·요청을 작성하고, 차량에서만 직접 탑승을 확정해요.';
 $('#syncStatus').textContent=storageAvailable?'같은 브라우저의 시연 상태 동기화':'이 화면에서 시연 가능 · 브라우저 저장소 제한';
 $('#confirmTitle').innerHTML=drop?'아이를 담당자에게<br>직접 인계했나요?':'아이의 실제 탑승을<br>직접 확인했나요?';$('#confirmDescription').textContent=drop?'기관 담당자에게 아이를 직접 인계했는지 보호자가 확인해 주세요. 문·좌석 센서는 기관 입실을 증명하지 않아요.':'아이의 실제 차량 탑승을 눈으로 확인한 뒤 눌러주세요. 문·착석 신호는 확인 후보일 뿐이에요.';$('#confirmGuardian').textContent=`네, ${confirmObject} 확인했어요`;
 if(!v.canConfirm&&$('#confirmDialog').open)$('#confirmDialog').close();map.setProgress(v.progress);operations.render();liveGPS.render();stopZones.render(v);showcase?.render(v);
}
$('#institution').onchange=e=>{send('SCENARIO',{institution:e.target.value});follow=true;$('#orientation').classList.add('active');map.follow(true);toast('운행의 기관 종류를 바꿨어요. 장소·기관 이름은 경로·기관에서 설정하세요.');};
$$('[data-mode]').forEach(b=>b.onclick=()=>{send('SCENARIO',{mode:b.dataset.mode});follow=true;$('#orientation').classList.add('active');map.follow(true);});
$('#playPause').onclick=()=>send(state.playing?'PAUSE':'PLAY');$('#restart').onclick=reset;
function stageAction(stage){if(stage==='driving'){reset();send('DRIVE');}if(stage==='approach')send('APPROACH');if(stage==='park')send('PARK');if(stage==='sensor')send('SENSOR');if(stage==='guardian')openConfirm();}
$$('[data-stage]').forEach(b=>b.onclick=()=>stageAction(b.dataset.stage));
$('#confirmGuardian').onclick=()=>{send('TICK',{dtMs:0});if(!view(state).canConfirm){toast('P 주차와 최근 가상 신호를 다시 확인해 주세요.');return;}$('#confirmDialog').close();send('CONFIRM');toast(`보호자의 ${state.mode==='dropoff'?'인계':'탑승'} 확인을 시연 기록에 남겼어요.`);};
$('#settings').onclick=()=>$('#settingsDialog').showModal();$$('[data-close]').forEach(b=>b.onclick=()=>$('#'+b.dataset.close).close());
$$('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}}));
$('#clearData').onclick=()=>{try{for(const key of Object.keys(localStorage)){if(key.startsWith(DEMO_STORAGE_KEY))localStorage.removeItem(key);}}catch{}operations.clear();liveGPS.clear();routePlanner.clear();applyRoute(REAL_ROUTE,{remote:true});reset();$('#settingsDialog').close();toast('가상 시연 기록을 초기화했어요.');};
$('#guardianToggle').onclick=()=>switchView(activeView==='guardian'?'vehicle':'guardian');$('#backVehicle').onclick=()=>switchView('vehicle');
$('#openGuardian').onclick=()=>{publish();const url=new URL(location.href);url.searchParams.set('view','guardian');window.open(url.href,'_blank','noopener');};
$('#zoomIn').onclick=()=>map.zoomIn();$('#zoomOut').onclick=()=>map.zoomOut();$('#overview').onclick=()=>{follow=false;$('#orientation').classList.remove('active');map.fit();};
$('#orientation').onclick=()=>{map.follow(true);syncFollow(true);};
$('#fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else if(document.documentElement.requestFullscreen)await document.documentElement.requestFullscreen();else{document.body.classList.toggle('presentation');toast('브라우저의 전체 화면 기능으로 더 크게 볼 수 있어요.');}setTimeout(()=>map.resize(),80);}catch{toast('브라우저 메뉴의 전체 화면으로 더 크게 볼 수 있어요.');}};
window.addEventListener('fullscreenchange',()=>setTimeout(()=>map.resize(),80));
document.addEventListener('keydown',e=>{if(guardianOnly)return;if($$('dialog').some(d=>d.open)||['INPUT','SELECT','TEXTAREA','BUTTON'].includes(document.activeElement.tagName))return;if(e.code==='Space'){e.preventDefault();if(!$('#playPause').disabled)$('#playPause').click();}if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();const buttons=$$('[data-stage]'),i=buttons.findIndex(b=>b.classList.contains('active'));const next=e.key==='ArrowRight'?Math.min(i+1,4):Math.max(i-1,0);if(!buttons[next].disabled)buttons[next].click();}});
new ResizeObserver(()=>{if(activeView==='vehicle')map.resize();}).observe($('.navigation'));
if(guardianOnly)document.body.classList.add('guardian-only');switchView(activeView);render();
syncFollow(map.isFollowing());
if(!guardianOnly&&new URL(location.href).searchParams.get('present')==='1')showcase.open();
if(!guardianOnly)setInterval(()=>{send('HEARTBEAT');},5000);
function frame(t){const dt=t-lastFrame;lastFrame=t;if(state.playing&&!guardianOnly){state=reduce(state,{type:'TICK',now:Date.now(),dtMs:dt});map.setProgress(state.progress);if(t-lastPublish>400)publish();}if(t-lastPaint>300){render();lastPaint=t;}requestAnimationFrame(frame);}requestAnimationFrame(frame);
