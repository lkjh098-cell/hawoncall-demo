package ai.hawoncall.child

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.*
import android.os.*
import ai.hawoncall.core.PhoneFixPolicy
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.update

/** Explicit foreground start only. No background location permission and no restart after death. */
class ChildLocationService: Service(), LocationListener {
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
    private var manager: LocationManager?=null
    private var api: ChildApi?=null
    private var credentials: ChildCredentials?=null
    private var deadlineElapsed=0L
    private val uploadGate=ai.hawoncall.core.PhoneUploadGate()
    private var stopping=false
    private val main=Handler(Looper.getMainLooper())
    private val leaseCheck=object: Runnable {
        override fun run() {
            if(stopping) return
            if(SystemClock.elapsedRealtime()>=deadlineElapsed || !hasPrecisePermission() || !notificationVisible()) stopSharing("위치 공유가 종료됐어요. 보호자에게 새 코드를 받아 주세요.")
            else main.postDelayed(this,1000)
        }
    }
    override fun onBind(intent: Intent?) = null
    override fun onStartCommand(intent: Intent?,flags: Int,startId: Int): Int {
        if(intent?.action==ACTION_STOP) { stopSharing("위치 공유를 중지했어요. 새로 공유하려면 보호자에게 새 코드를 받아 주세요."); return START_NOT_STICKY }
        if(credentials!=null || stopping) return START_NOT_STICKY
        val s=ChildRuntime.credentials
        if(s==null || !hasPrecisePermission() || s.expiresAtMillis<=System.currentTimeMillis()) { stopSharing("위치 권한과 연결 코드를 다시 확인해 주세요."); return START_NOT_STICKY }
        credentials=s
        api=ChildApi(BuildConfig.DEBUG)
        val remaining=(s.expiresAtMillis-System.currentTimeMillis()).coerceAtMost(30*60_000L)
        deadlineElapsed=SystemClock.elapsedRealtime()+remaining
        try {
            val nm=getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL,"아이 위치 공유",NotificationManager.IMPORTANCE_LOW))
            if(!notificationVisible()) { stopSharing("공유 알림을 허용하고 다시 연결해 주세요."); return START_NOT_STICKY }
            val stop=PendingIntent.getService(this,1,Intent(this,ChildLocationService::class.java).setAction(ACTION_STOP),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val open=PendingIntent.getActivity(this,2,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val notification=Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle("하원콜 · 아이 위치 공유 중").setContentText("보호자와 연결 차량에 공유 · 최대 30분 · 중지할 수 있어요")
                .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true).addAction(Notification.Action.Builder(null,"공유 중지",stop).build()).build()
            if(Build.VERSION.SDK_INT>=29) startForeground(NOTIFICATION,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            else startForeground(NOTIFICATION,notification)
            ChildRuntime.mutable.update { it.copy(sharing=true,status="위치를 확인 중이에요. 알림에서 언제든 중지할 수 있어요.") }
            manager=getSystemService(LocationManager::class.java)
            var registered=false
            // Both providers may supply real fixes; accuracy/time/mock gates apply to every callback.
            listOf(LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER).forEach { provider ->
                if(manager?.isProviderEnabled(provider)==true) {
                    runCatching { manager?.requestLocationUpdates(provider,1000L,0f,this,Looper.getMainLooper()); registered=true }
                }
            }
            if(!registered) { stopSharing("휴대폰 위치 기능과 정확한 위치 권한을 켜고 다시 연결해 주세요."); return START_NOT_STICKY }
            main.post(leaseCheck)
        } catch(_: Exception) { stopSharing("위치 공유를 시작하지 못했어요. 화면을 연 상태에서 권한과 알림을 확인해 주세요.") }
        return START_NOT_STICKY
    }
    private fun notificationVisible(): Boolean {
        val manager=getSystemService(NotificationManager::class.java)
        return manager.areNotificationsEnabled() && manager.getNotificationChannel(CHANNEL)?.importance!=NotificationManager.IMPORTANCE_NONE
    }
    private fun hasPrecisePermission()=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
    override fun onLocationChanged(location: Location) {
        val s=credentials ?: return
        if(stopping || !hasPrecisePermission()) { stopSharing("정확한 위치 권한이 없어 공유를 중지했어요."); return }
        val now=SystemClock.elapsedRealtime()
        if(now>=deadlineElapsed) { stopSharing("위치 공유 시간이 끝났어요."); return }
        @Suppress("DEPRECATION") val mock=if(Build.VERSION.SDK_INT>=31) location.isMock else location.isFromMockProvider
        if(!location.hasAccuracy() || !PhoneFixPolicy.acceptable(location.latitude,location.longitude,location.accuracy.toDouble(),
                location.time,location.elapsedRealtimeNanos,System.currentTimeMillis(),SystemClock.elapsedRealtimeNanos(),mock)) {
            ChildRuntime.mutable.update { it.copy(status="정확도 50m 이내의 최근 실제 위치를 기다리고 있어요.") }; return
        }
        // Drop busy/throttled callbacks immediately. No offline queue, history or retry of a fix.
        val seq=uploadGate.acquire(location.time,now) ?: return
        val latitude=location.latitude; val longitude=location.longitude; val accuracy=location.accuracy
        val observed=location.time
        val fixNanos=location.elapsedRealtimeNanos
        scope.launch {
            try {
                // The fix may age while dispatching; check again immediately before sending.
                if(!PhoneFixPolicy.acceptable(latitude,longitude,accuracy.toDouble(),observed,fixNanos,System.currentTimeMillis(),SystemClock.elapsedRealtimeNanos(),mock)) return@launch
                withContext(Dispatchers.IO) { api?.upload(s,latitude,longitude,accuracy.toDouble(),observed,seq) }
                if(!stopping && credentials===s) ChildRuntime.mutable.update { it.copy(status="최근 위치를 공유하고 있어요.",accuracyMeters=accuracy,uploadedAtMillis=observed) }
            } catch(e: Exception) {
                if(e is CancellationException) throw e
                if(e is ChildApiFailure && e.status==401) stopSharing("공유 연결이 종료됐어요. 보호자에게 새 코드를 받아 주세요.")
                else if(!stopping) ChildRuntime.mutable.update { it.copy(status="위치를 전송하지 못했어요. 다음 실제 위치에서 다시 시도해요.") }
            } finally { uploadGate.release() }
        }
    }
    @Deprecated("Legacy callback") override fun onStatusChanged(provider: String?,status: Int,extras: Bundle?) = Unit
    override fun onProviderEnabled(provider: String) = Unit
    override fun onProviderDisabled(provider: String) {
        if(manager?.isProviderEnabled(LocationManager.GPS_PROVIDER)!=true && manager?.isProviderEnabled(LocationManager.NETWORK_PROVIDER)!=true)
            stopSharing("휴대폰 위치 기능이 꺼져 공유를 중지했어요.")
    }
    private fun stopSharing(message: String) {
        if(stopping) return
        stopping=true
        val s=credentials ?: ChildRuntime.credentials
        credentials=null; ChildRuntime.forget(message)
        main.removeCallbacksAndMessages(null)
        runCatching { manager?.removeUpdates(this) }; manager=null
        uploadGate.close(); api?.cancel(); scope.cancel()
        // Revocation has a bounded best-effort request; the server independently expires the last fix.
        if(s!=null) {
            val stopApi=ChildApi(BuildConfig.DEBUG)
            CoroutineScope(Dispatchers.IO).launch { try { stopApi.stop(s) } catch(_: Exception) { } finally { stopApi.close() } }
        }
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    override fun onTaskRemoved(rootIntent: Intent?) { stopSharing("앱이 닫혀 위치 공유를 중지했어요."); super.onTaskRemoved(rootIntent) }
    override fun onDestroy() { stopSharing("위치 공유 실행이 종료됐어요. 다시 연결해 주세요."); api?.close(); api=null; super.onDestroy() }
    companion object { const val ACTION_STOP="ai.hawoncall.child.STOP"; private const val CHANNEL="child_location"; private const val NOTIFICATION=1101 }
}
