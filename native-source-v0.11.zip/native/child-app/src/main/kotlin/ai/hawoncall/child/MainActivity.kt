package ai.hawoncall.child

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.update
import java.util.Locale

class MainActivity: ComponentActivity() {
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
    private var visible=false
    private var permissionPending=false
    private val permissions=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if(permissionPending && visible) { permissionPending=false; startIfGranted() }
        else permissionPending=false
    }
    override fun onStart() { super.onStart(); visible=true }
    override fun onStop() { visible=false; permissionPending=false; super.onStop() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val state by ChildRuntime.state.collectAsStateWithLifecycle()
            var server by rememberSaveable { mutableStateOf(if(BuildConfig.DEBUG) "http://10.0.2.2:3000" else "") }
            var code by remember { mutableStateOf("") }
            var busy by remember { mutableStateOf(false) }
            var notice by remember { mutableStateOf("") }
            var clock by remember { mutableLongStateOf(System.currentTimeMillis()) }
            LaunchedEffect(Unit) { while(isActive) { clock=System.currentTimeMillis(); delay(1000) } }
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
                        .verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(18.dp)) {
                        Text("하원콜 · 아이 위치",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
                        Text("보호자가 발급한 아이 위치 코드로 연결해요. 화면에서 공유를 직접 시작하면 보호자와 연결 차량에 최근 위치가 전송돼요.")
                        Card { Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                            Text(if(state.paired) "${state.childName} · 연결됨" else "공유 중이 아니에요",fontWeight=FontWeight.Bold)
                            Text(state.status)
                            if(state.sharing) {
                                Text("알림에 ‘위치 공유 중’이 표시돼요. 화면을 잠가도 최대 30분 동안 공유하며, 알림의 공유 중지로 바로 끌 수 있어요.")
                                val age=state.uploadedAtMillis?.let { ((clock-it)/1000).coerceAtLeast(0) }
                                Text(if(age!=null) "마지막 전송 위치 ${age}초 전 · 정확도 약 ${state.accuracyMeters?.toInt() ?: 0}m" else "전송된 위치 없음")
                            }
                        } }
                        if(!state.paired) {
                            OutlinedTextField(server,{server=it},label={Text("보호자와 같은 HTTPS 서버")},singleLine=true,enabled=!busy,modifier=Modifier.fillMaxWidth())
                            OutlinedTextField(code,{code=it.uppercase(Locale.ROOT).filter { c -> c.isLetterOrDigit() }.take(8)},label={Text("아이 위치 연결 코드 8자리")},singleLine=true,enabled=!busy,modifier=Modifier.fillMaxWidth())
                            Button(onClick={
                                if(busy) return@Button
                                notice=""; busy=true
                                val enteredServer=server; val enteredCode=code
                                scope.launch {
                                    val api=ChildApi(BuildConfig.DEBUG)
                                    try {
                                        val paired=withContext(Dispatchers.IO) { api.pair(enteredServer,enteredCode) }
                                        ChildRuntime.paired(paired); code=""
                                    } catch(e: Exception) {
                                        if(e is CancellationException) throw e
                                        notice=if(e is IllegalArgumentException) e.message ?: "입력을 확인해 주세요." else "연결하지 못했어요. 서버 주소와 보호자의 새 코드를 확인해 주세요."
                                    } finally { api.close(); busy=false }
                                }
                            },enabled=!busy && code.length==8,modifier=Modifier.fillMaxWidth().heightIn(min=52.dp)) { Text(if(busy) "연결 중" else "보호자 코드로 연결") }
                        } else {
                            if(!state.sharing) {
                                Text("정확한 위치와 알림 권한이 필요해요. 허용한 후 ‘위치 공유 시작’을 누르면 실제 위치만 전송합니다.")
                                Button(onClick=::requestSharing,modifier=Modifier.fillMaxWidth().heightIn(min=52.dp)) { Text("위치 공유 시작") }
                            }
                            OutlinedButton(onClick={
                                if(state.sharing) startService(Intent(this@MainActivity,ChildLocationService::class.java).setAction(ChildLocationService.ACTION_STOP))
                                else {
                                    val old=ChildRuntime.credentials
                                    ChildRuntime.forget("연결을 해제했어요.")
                                    if(old!=null) scope.launch(Dispatchers.IO) { val api=ChildApi(BuildConfig.DEBUG); try { api.stop(old) } catch(_: Exception) { } finally { api.close() } }
                                }
                            },modifier=Modifier.fillMaxWidth().heightIn(min=52.dp)) { Text(if(state.sharing) "위치 공유 중지 · 연결 해제" else "연결 해제") }
                        }
                        if(notice.isNotBlank()) Text(notice,color=MaterialTheme.colorScheme.error)
                        Text("위치는 만날 곳을 정하기 위한 참고 정보예요. 승하차·주정차 허가나 실제 탑승 확인이 아닙니다. 정확도 50m 초과, 오래된 위치, 모의 위치는 전송하지 않아요.",style=MaterialTheme.typography.bodySmall)
                        Text("위치와 연결 인증은 앱 메모리에서만 사용해요. 앱 종료 후 다시 공유하려면 보호자의 새 코드가 필요해요.",style=MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
    private fun requestSharing() {
        if(!visible || ChildRuntime.credentials==null || ChildRuntime.state.value.sharing) return
        val required=mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION)
        if(Build.VERSION.SDK_INT>=33) required.add(Manifest.permission.POST_NOTIFICATIONS)
        if(required.any { checkSelfPermission(it)!=PackageManager.PERMISSION_GRANTED }) {
            permissionPending=true; permissions.launch(required.toTypedArray())
        } else startIfGranted()
    }
    private fun startIfGranted() {
        if(!visible || ChildRuntime.credentials==null || ChildRuntime.state.value.sharing) return
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED ||
            !getSystemService(NotificationManager::class.java).areNotificationsEnabled()) {
            ChildRuntime.mutable.update { it.copy(status="공유하려면 정확한 위치와 알림을 허용해 주세요. 위치는 아직 전송하지 않았어요.") }; return
        }
        try { startForegroundService(Intent(this,ChildLocationService::class.java)) }
        catch(_: Exception) { ChildRuntime.mutable.update { it.copy(status="공유 실행을 시작하지 못했어요. 앱 화면에서 다시 시도해 주세요.") } }
    }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
