package ai.hawoncall.child

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.Closeable
import java.io.IOException
import java.time.Instant
import java.util.concurrent.TimeUnit

internal object ChildServerPolicy {
    fun validate(raw: String, allowLocal: Boolean): HttpUrl {
        val u=raw.trim().toHttpUrlOrNull() ?: throw IllegalArgumentException("서버 주소를 확인해 주세요.")
        require(u.username.isEmpty() && u.password.isEmpty() && u.query==null && u.fragment==null && u.encodedPath=="/") { "서버 주소만 입력해 주세요." }
        require(u.isHttps || allowLocal && u.scheme=="http" && u.host in setOf("localhost","127.0.0.1","10.0.2.2")) { "HTTPS 서버가 필요합니다." }
        return u
    }
}
internal data class ChildCredentials(val server: String,val token: String,val sessionId: String,val expiresAtMillis: Long,val childName: String)
internal class ChildApiFailure(val status: Int): IOException("위치 공유 요청을 처리하지 못했어요.")
/** No logger, interceptor, disk cache, retry, redirects, URL coordinates or persisted token. */
internal class ChildApi(private val allowLocal: Boolean): Closeable {
    private val client=OkHttpClient.Builder().followRedirects(false).followSslRedirects(false).retryOnConnectionFailure(false)
        .connectTimeout(5,TimeUnit.SECONDS).readTimeout(5,TimeUnit.SECONDS).callTimeout(8,TimeUnit.SECONDS).build()
    private fun request(server: String,path: String,body: JSONObject,token: String?=null,method: String="POST"): JSONObject {
        val u=ChildServerPolicy.validate(server,allowLocal).newBuilder().encodedPath(path).build()
        val builder=Request.Builder().url(u).method(method,body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
        if(token!=null) builder.header("Authorization","Bearer $token")
        return client.newCall(builder.build()).execute().use { r ->
            if(!r.isSuccessful) throw ChildApiFailure(r.code)
            if(r.code==204) return@use JSONObject()
            val source=r.body?.source() ?: throw IOException("서버 응답을 확인해 주세요.")
            source.request(32769); if(source.buffer.size>32768) throw IOException("서버 응답을 확인해 주세요.")
            JSONObject(source.readUtf8())
        }
    }
    fun pair(server: String,code: String): ChildCredentials {
        require(code.matches(Regex("[A-Z0-9]{8}"))) { "보호자 연결 코드 8자리를 입력해 주세요." }
        val o=request(server,"/api/child/pair",JSONObject().put("pairCode",code))
        val session=o.getJSONObject("session")
        val token=o.getString("childToken")
        require(token.length in 20..256)
        val paired=ChildCredentials(ChildServerPolicy.validate(server,allowLocal).toString(),token,session.getString("id"),
            Instant.parse(session.getString("expiresAt")).toEpochMilli(),o.getJSONObject("link").getString("childName"))
        if(o.getJSONObject("link").getString("journeyType")!="PICKUP") {
            runCatching { stop(paired) }
            throw IllegalArgumentException("아이 위치 길찾기는 하교·하원 연결에서 이용할 수 있어요.")
        }
        return paired
    }
    fun upload(s: ChildCredentials,latitude: Double,longitude: Double,accuracy: Double,observed: Long,sequence: Long) {
        request(s.server,"/api/child/location",JSONObject().put("latitude",latitude).put("longitude",longitude)
            .put("accuracyMeters",accuracy).put("observedAt",Instant.ofEpochMilli(observed).toString()).put("sequence",sequence),s.token,"PUT")
    }
    fun stop(s: ChildCredentials) { request(s.server,"/api/child/location-sharing/stop",JSONObject(),s.token) }
    fun cancel() { client.dispatcher.cancelAll() }
    override fun close() { cancel(); client.connectionPool.evictAll(); client.dispatcher.executorService.shutdown() }
}
