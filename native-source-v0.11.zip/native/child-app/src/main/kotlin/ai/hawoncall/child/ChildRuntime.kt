package ai.hawoncall.child

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

internal data class ChildUiState(val paired: Boolean=false,val childName: String="",val sharing: Boolean=false,
    val status: String="보호자에게 아이 위치 연결 코드를 받아 주세요.",val accuracyMeters: Float?=null,val uploadedAtMillis: Long?=null)
/** Credentials, current fix metadata and sequence are process memory only. */
internal object ChildRuntime {
    @Volatile var credentials: ChildCredentials?=null
    val mutable=MutableStateFlow(ChildUiState())
    val state=mutable.asStateFlow()
    fun paired(s: ChildCredentials) { credentials=s; mutable.value=ChildUiState(true,s.childName,status="연결됐어요. 위치 공유 시작을 눌러야 위치가 전송돼요.") }
    fun forget(message: String) { credentials=null; mutable.value=ChildUiState(status=message) }
}
