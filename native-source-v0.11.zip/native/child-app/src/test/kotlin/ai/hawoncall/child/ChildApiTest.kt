package ai.hawoncall.child

import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class ChildApiTest {
    @Test fun releaseRejectsHttpAndDebugRejectsNonLocalHttp() {
        assertThrows(IllegalArgumentException::class.java) { ChildServerPolicy.validate("http://localhost:3000",false) }
        assertThrows(IllegalArgumentException::class.java) { ChildServerPolicy.validate("http://192.168.0.2:3000",true) }
        assertThrows(IllegalArgumentException::class.java) { ChildServerPolicy.validate("https://user:password@example.com",false) }
        assertEquals("https",ChildServerPolicy.validate("https://example.com",false).scheme)
    }
    @Test fun manualPairIsScopedAndUploadHasOnlyFiveFixFields() {
        val server=MockWebServer(); server.start()
        val api=ChildApi(true)
        try {
            server.enqueue(MockResponse().setBody("""{"childToken":"abcdefghijklmnopqrstuvwxyz0123456789","session":{"id":"s1","expiresAt":"2026-10-26T02:00:00Z"},"link":{"childName":"지우","journeyType":"PICKUP"}}"""))
            val s=api.pair(server.url("/").toString(),"ABCDEFGH")
            val pair=server.takeRequest()
            assertEquals("/api/child/pair",pair.path); assertNull(pair.getHeader("Authorization"))
            assertEquals(setOf("pairCode"),JSONObject(pair.body.readUtf8()).keySet())
            server.enqueue(MockResponse().setBody("{\"accepted\":true}"))
            api.upload(s,37.5665,126.978,12.0,1792976400123,1)
            val upload=server.takeRequest()
            assertEquals("PUT",upload.method); assertEquals("/api/child/location",upload.path)
            assertEquals("Bearer ${s.token}",upload.getHeader("Authorization"))
            val body=JSONObject(upload.body.readUtf8())
            assertEquals(setOf("latitude","longitude","accuracyMeters","observedAt","sequence"),body.keySet())
            assertEquals(java.time.Instant.ofEpochMilli(1792976400123).toString(),body.getString("observedAt"))
            server.enqueue(MockResponse().setResponseCode(204)); api.stop(s)
            assertEquals("/api/child/location-sharing/stop",server.takeRequest().path)
        } finally { api.close(); server.shutdown() }
    }
    @Test fun revokedSessionFailsAndNeverRetriesFix() {
        val server=MockWebServer(); server.start(); val api=ChildApi(true)
        try {
            server.enqueue(MockResponse().setResponseCode(401))
            val s=ChildCredentials(server.url("/").toString(),"secret","session",Long.MAX_VALUE,"child")
            val failure=assertThrows(ChildApiFailure::class.java) { api.upload(s,37.56,126.97,10.0,1,1) }
            assertEquals(401,failure.status); assertEquals(1,server.requestCount)
        } finally { api.close(); server.shutdown() }
    }
}
