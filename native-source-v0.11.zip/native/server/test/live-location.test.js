import { test } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApplication } from '../src/app.js';
import { createAcademy } from '../src/store.js';
const auth=token=>({Authorization:`Bearer ${token}`});
const password='location-test-password-long';
async function fixture(t,options={}) {
  let clock=Date.now(),closed=false;
  const ctx=createApplication({databasePath:':memory:',rateLimit:false,...options,locationNow:()=>clock});
  await new Promise((resolve,reject)=>{ctx.server.once('error',reject);ctx.server.listen(0,'127.0.0.1',resolve);});
  const close=async()=>{if(!closed){closed=true;await ctx.close();}};t.after(close);
  createAcademy(ctx.db,{code:'LOC01',name:'서울기관',password});
  const register=async childName=>(await request(ctx.server).post('/api/guardian/links').send({academyCode:'LOC01',childName,weekday:[1],pickupTime:'18:00',guardianConsent:true}).expect(201)).body;
  const a=await register('아이'),b=await register('다른아이');
  const carFor=async guardianToken=>{
    const {code}=(await request(ctx.server).post('/api/guardian/pairing').set(auth(guardianToken)).send({}).expect(200)).body;
    return (await request(ctx.server).post('/api/car/pairing').send({code}).expect(200)).body.carToken;
  };
  const car=await carFor(a.guardianToken),otherCar=await carFor(b.guardianToken);
  const academy=(await request(ctx.server).post('/api/academy/session').send({code:'LOC01',password}).expect(200)).body.token;
  return {ctx,a,b,car,otherCar,academy,carFor,now:()=>clock,advance:ms=>{clock+=ms;},close};
}
const create=f=>request(f.ctx.server).post('/api/guardian/location-sharing').set(auth(f.a.guardianToken)).send({consent:true});
const pair=(f,pairCode)=>request(f.ctx.server).post('/api/child/pair').send({pairCode});
const read=(f,token=f.a.guardianToken,role='guardian')=>request(f.ctx.server).get(`/api/${role}/live-location`).set(auth(token));
const fix=(f,extra={})=>({latitude:37.56651234,longitude:126.97804321,accuracyMeters:12.5,observedAt:new Date(f.now()).toISOString(),sequence:1,...extra});
const upload=(f,token,body=fix(f))=>request(f.ctx.server).put('/api/child/location').set(auth(token)).send(body);
const start=async f=>{const issued=(await create(f).expect(201)).body;return {...issued,...(await pair(f,issued.pairCode).expect(200)).body};};
const trip=async f=>(await request(f.ctx.server).post('/api/trips').set(auth(f.car)).send({linkId:f.a.link.id,clientTripId:crypto.randomUUID()}).expect(201)).body.trip;
const cancel=(f,id)=>request(f.ctx.server).post(`/api/trips/${id}/events`).set(auth(f.car)).send({eventId:crypto.randomUUID(),type:'CANCEL',at:new Date().toISOString()});

test('live consent and one-use pairing are bounded, replaced and explicitly wait for child fix',async t=>{
  const f=await fixture(t);
  for(const body of [{consent:false},{consent:true,linkId:f.b.link.id}])await request(f.ctx.server).post('/api/guardian/location-sharing').set(auth(f.a.guardianToken)).send(body).expect(400);
  const old=(await create(f).expect(201)).body,issued=(await create(f).expect(201)).body;
  assert.match(issued.pairCode,/^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{8}$/);assert.equal(Date.parse(issued.pairExpiresAt)-f.now(),300000);assert.equal(Date.parse(issued.session.expiresAt)-f.now(),1800000);assert.equal(issued.session.status,'AWAITING_CHILD');
  await pair(f,old.pairCode).expect(400);
  const paired=(await pair(f,issued.pairCode).expect(200)).body;assert.equal(paired.session.status,'WAITING_FOR_FIX');assert.equal(paired.session.pairExpiresAt,null);assert.equal(paired.link.childName,'아이');
  await pair(f,issued.pairCode).expect(400);assert.equal((await read(f).expect(200)).body.location,null);
  await create(f).expect(201);await upload(f,paired.childToken).expect(401);
});

test('real HTTP child fix reaches only its guardian and current vehicle with no institution exposure',async t=>{
  const f=await fixture(t),s=await start(f);await upload(f,s.childToken).expect(200);
  for(const [token,role] of [[f.a.guardianToken,'guardian'],[f.car,'car']]) {
    const r=(await read(f,token,role).expect(200)).body;assert.equal(r.fresh,true);assert.equal(r.session.status,'SHARING');assert.equal(r.location.latitude,fix(f).latitude);assert.equal(r.location.accuracyMeters,12.5);assert.equal(r.location.source,'CHILD_PHONE_GPS');assert.equal(r.permissionInferenceAllowed,false);assert.equal(r.automaticRouteChangeAllowed,false);
  }
  for(const [token,role] of [[f.b.guardianToken,'guardian'],[f.otherCar,'car']])assert.equal((await read(f,token,role).expect(200)).body.location,null);
  for(const [token,role] of [[f.car,'guardian'],[f.academy,'guardian'],[s.childToken,'guardian'],[f.a.guardianToken,'car'],[s.childToken,'car']])await read(f,token,role).expect(401);
  for(const token of [f.a.guardianToken,f.car,f.academy])await upload(f,token).expect(401);
  await request(f.ctx.server).get('/api/academy/live-location').set(auth(f.academy)).expect(404);
  await request(f.ctx.server).get('/api/guardian/live-location').expect(401);
});

test('stale live snapshot omits coordinates until a newer fix arrives',async t=>{
  const f=await fixture(t),s=await start(f);await upload(f,s.childToken).expect(200);f.advance(30001);
  const r=(await read(f).expect(200)).body;assert.equal(r.fresh,false);assert.equal(r.location,null);assert.equal(r.session.status,'STALE');assert(!JSON.stringify(r).includes(String(fix(f).latitude)));
  await upload(f,s.childToken,fix(f,{sequence:2})).expect(200);assert.equal((await read(f).expect(200)).body.fresh,true);
});

test('live validation bounds Seoul, accuracy, age, types and fields without replacing fix or echoing input',async t=>{
  const f=await fixture(t),s=await start(f);await upload(f,s.childToken).expect(200);
  for(const delta of [{latitude:35,longitude:129},{latitude:'37.5665'},{latitude:null},{accuracyMeters:51},{accuracyMeters:0},{accuracyMeters:-1},{accuracyMeters:null},{observedAt:'2026-02-31T00:00:00Z'},{observedAt:new Date(f.now()-30001).toISOString()},{observedAt:new Date(f.now()+5001).toISOString()},{observedAt:'today'},{sequence:0},{sequence:1.5},{sequence:Number.MAX_SAFE_INTEGER+1},{mock:true},{linkId:f.b.link.id},{location:{lat:37.5,lon:127}}]) {
    const r=await upload(f,s.childToken,fix(f,{sequence:2,...delta})).expect(400);assert(!JSON.stringify(r.body).includes(String(fix(f).latitude)));
  }
  assert.equal((await read(f).expect(200)).body.location.sequence,1);
  await request(f.ctx.server).put('/api/child/location?latitude=37').set(auth(s.childToken)).send(fix(f,{sequence:2})).expect(400);
  await request(f.ctx.server).get('/api/guardian/live-location?linkId=other').set(auth(f.a.guardianToken)).expect(400);
  await upload(f,s.childToken,{}).expect(400);
});

test('live monotonic sequence and observed time reject replay',async t=>{
  const f=await fixture(t),s=await start(f);await upload(f,s.childToken).expect(200);await upload(f,s.childToken).expect(409);await upload(f,s.childToken,fix(f,{sequence:2})).expect(409);
  f.advance(2000);await upload(f,s.childToken,fix(f,{sequence:1})).expect(409);await upload(f,s.childToken,fix(f,{sequence:2})).expect(200);assert.equal((await read(f).expect(200)).body.location.sequence,2);
});

test('guardian revoke and child stop clear credentials and fix while scopes prevent another role stopping them',async t=>{
  const f=await fixture(t),s=await start(f);await upload(f,s.childToken).expect(200);
  await request(f.ctx.server).delete('/api/guardian/location-sharing').set(auth(f.car)).expect(401);
  await request(f.ctx.server).post('/api/child/location-sharing/stop').set(auth(f.a.guardianToken)).send({}).expect(401);
  await request(f.ctx.server).delete('/api/guardian/location-sharing').set(auth(f.b.guardianToken)).expect(204);assert.equal((await read(f).expect(200)).body.fresh,true);
  await request(f.ctx.server).delete('/api/guardian/location-sharing').set(auth(f.a.guardianToken)).expect(204);await upload(f,s.childToken).expect(401);assert.equal((await read(f).expect(200)).body.session,null);
  await request(f.ctx.server).delete('/api/guardian/location-sharing').set(auth(f.a.guardianToken)).expect(204);
  const next=await start(f);await upload(f,next.childToken).expect(200);await request(f.ctx.server).post('/api/child/location-sharing/stop').set(auth(next.childToken)).send({}).expect(204);await upload(f,next.childToken).expect(401);assert.equal((await read(f).expect(200)).body.location,null);
});

test('pair expiry and session expiry fail closed without client cooperation',async t=>{
  const f=await fixture(t),issued=(await create(f).expect(201)).body;f.advance(300000);await pair(f,issued.pairCode).expect(400);assert.equal((await read(f).expect(200)).body.session,null);
  const s=await start(f);await upload(f,s.childToken).expect(200);f.advance(1800000);await upload(f,s.childToken).expect(401);assert.equal((await read(f,f.car,'car').expect(200)).body.session,null);
});

test('live session binds current or next trip and all terminal states prevent further updates',async t=>{
  const f=await fixture(t),s=await start(f),active=await trip(f);assert.equal((await read(f).expect(200)).body.session.tripId,active.id);await upload(f,s.childToken).expect(200);
  await cancel(f,active.id).expect(200);await upload(f,s.childToken).expect(401);assert.equal((await read(f).expect(200)).body.location,null);
  for(const status of ['BOARDED','HANDED_OVER']){const active=await trip(f),next=await start(f);assert.equal(next.session.tripId,active.id);await upload(f,next.childToken).expect(200);f.ctx.db.prepare('UPDATE trips SET status=? WHERE id=?').run(status,active.id);await upload(f,next.childToken).expect(401);assert.equal((await read(f).expect(200)).body.session,null);}
});

test('live vehicle rotation and link changes revoke the credential scope',async t=>{
  const f=await fixture(t),s=await start(f);await upload(f,s.childToken).expect(200);const nextCar=await f.carFor(f.a.guardianToken);await upload(f,s.childToken).expect(401);await read(f,f.car,'car').expect(401);assert.equal((await read(f,nextCar,'car').expect(200)).body.location,null);
  const next=await start(f);await upload(f,next.childToken).expect(200);f.ctx.db.prepare("UPDATE links SET journey_type='DROPOFF' WHERE id=?").run(f.a.link.id);await upload(f,next.childToken).expect(401);assert.equal((await read(f).expect(200)).body.session,null);
});

test('no live fix or secret enters DB/events and process restart forgets all location sessions',async t=>{
  const directory=mkdtempSync(join(tmpdir(),'hawon-location-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));const path=join(directory,'data.sqlite'),f=await fixture(t,{databasePath:path}),active=await trip(f),s=await start(f);await upload(f,s.childToken).expect(200);
  const tables=f.ctx.db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all(),persisted=JSON.stringify(tables.map(({name})=>f.ctx.db.prepare(`SELECT * FROM ${name}`).all()));for(const secret of [String(fix(f).latitude),String(fix(f).longitude),s.childToken,s.pairCode,'CHILD_PHONE_GPS'])assert(!persisted.includes(secret));assert.equal(f.ctx.db.prepare('SELECT count(*) n FROM events WHERE trip_id=?').get(active.id).n,0);
  await f.close();const ctx=createApplication({databasePath:path,rateLimit:false});t.after(()=>ctx.close());await new Promise(resolve=>ctx.server.listen(0,'127.0.0.1',resolve));await request(ctx.server).put('/api/child/location').set(auth(s.childToken)).send(fix(f)).expect(401);assert.equal((await request(ctx.server).get('/api/guardian/live-location').set(auth(f.a.guardianToken)).expect(200)).body.session,null);
});

test('pair guesses throttle and browser location policy is limited to child page',async t=>{
  const f=await fixture(t,{rateLimit:true});for(let i=0;i<20;i++)assert.equal((await pair(f,'ABCDEFGH').expect(400)).body.code,'INVALID_PAIR_CODE');await pair(f,'ABCDEFGH').expect(429);
  assert.match((await request(f.ctx.server).get('/child').expect(200)).headers['permissions-policy'],/geolocation=\(self\)/);assert.match((await request(f.ctx.server).get('/').expect(200)).headers['permissions-policy'],/geolocation=\(\)/);
});

test('external browser origins require exact HTTPS allowlist and scoped bearer auth even after preflight',async t=>{
  const origin='https://lkjh098-cell.github.io',f=await fixture(t,{allowedWebOrigins:[origin]});
  const preflight=await request(f.ctx.server).options('/api/child/location').set({Origin:origin,'Access-Control-Request-Method':'PUT','Access-Control-Request-Headers':'Authorization,Content-Type'}).expect(204);assert.equal(preflight.headers['access-control-allow-origin'],origin);assert(!preflight.headers['access-control-allow-credentials']);assert.match(preflight.headers.vary,/Origin/);
  await request(f.ctx.server).get('/api/guardian/live-location').set({Origin:origin}).expect(401);
  await request(f.ctx.server).get('/api/guardian/live-location').set({...auth(f.a.guardianToken),Origin:origin}).expect(200);
  for(const bad of ['https://evil.example','https://lkjh098-cell.github.io.evil.example','null'])await request(f.ctx.server).get('/api/guardian/live-location').set({...auth(f.a.guardianToken),Origin:bad}).expect(403);
});

test('same-origin child page injects unique script nonces while legacy page CSP stays strict',async t=>{
  const f=await fixture(t),one=await request(f.ctx.server).get('/child').expect(200),two=await request(f.ctx.server).get('/child.html').expect(200);
  const nonce=response=>/nonce-([^']+)/.exec(response.headers['content-security-policy'])?.[1];
  assert(nonce(one));assert(nonce(two));assert.notEqual(nonce(one),nonce(two));
  for(const response of [one,two]) {
    const scriptTags=response.text.match(/<script\b[^>]*>/g)??[];assert(scriptTags.length>=2);
    assert(scriptTags.every(tag=>tag.includes(`nonce="${nonce(response)}"`)));
    assert.match(response.text,/아이 휴대폰/);assert.match(response.headers['permissions-policy'],/geolocation=\(self\)/);
    assert(!/script-src[^;]*unsafe-inline/.test(response.headers['content-security-policy']));
    assert.equal(response.headers['cache-control'],'no-store');
  }
  const legacy=await request(f.ctx.server).get('/').expect(200);
  assert(!legacy.headers['content-security-policy'].includes('unsafe-inline'));assert(!legacy.headers['content-security-policy'].includes('nonce-'));
});
