import { test, after, before } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import WebSocket from 'ws';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApplication } from '../src/app.js';
import { createAcademy, openStore, prune } from '../src/store.js';

const password='test-password-long-and-private';
let ctx,base,academy,academyB,car,otherCar,link,linkB;
const auth=(token)=>({Authorization:`Bearer ${token}`});
const register=(code='HAWON01',childName='지우')=>({academyCode:code,childName,weekday:[1,3,5],pickupTime:'21:50',baseLeadSeconds:300,guardianConsent:true});
const event=(type,extra={})=>({eventId:crypto.randomUUID(),type,at:new Date().toISOString(),...(type==='BOARDED'?{confirmation:'GUARDIAN'}:{}),...extra});
const newTrip=async(token=car,l=link)=>{const res=await request(ctx.app).post('/api/trips').set(auth(token)).send({linkId:l.id,clientTripId:crypto.randomUUID()}).expect(201);return res.body.trip;};
const send=(trip,e,token=car)=>request(ctx.app).post(`/api/trips/${trip.id}/events`).set(auth(token)).send(e);
const socket=(path)=>new Promise((resolve,reject)=>{const ws=new WebSocket(base.replace('http','ws')+path);ws.once('open',()=>resolve(ws));ws.once('error',reject);});
const message=ws=>new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(new Error('WS message timeout')),2000);ws.once('message',data=>{clearTimeout(timeout);resolve(JSON.parse(data));});});
const closed=ws=>new Promise(resolve=>ws.once('close',(code)=>resolve(code)));
before(async()=>{
  ctx=createApplication({databasePath:':memory:',rateLimit:false,authTimeoutMs:100});
  createAcademy(ctx.db,{code:'HAWON01',name:'오늘수학',password});createAcademy(ctx.db,{code:'OTHER01',name:'다른학원',password});
  await new Promise((resolve,reject)=>{ctx.server.once('error',reject);ctx.server.listen(0,'127.0.0.1',resolve);});base=`http://127.0.0.1:${ctx.server.address().port}`;
  academy=(await request(ctx.app).post('/api/academy/session').send({code:'HAWON01',password}).expect(200)).body.token;
  academyB=(await request(ctx.app).post('/api/academy/session').send({code:'OTHER01',password}).expect(200)).body.token;
  let r=await request(ctx.app).post('/api/links').send(register()).expect(201);car=r.body.carToken;link=r.body.link;
  r=await request(ctx.app).post('/api/links').send(register('OTHER01','민서')).expect(201);otherCar=r.body.carToken;linkB=r.body.link;
});
after(async()=>{await ctx.close();});
test('health and static pages disclose local/privacy context',async()=>{const r=await request(ctx.app).get('/api/health').expect(200);assert.equal(r.body.coordinatesCollected,true);assert.equal(r.body.coordinatesPersisted,false);assert.equal(r.body.vehicleRawGpsStored,false);for(const path of ['/','/setup','/demo','/academy/HAWON01'])await request(ctx.app).get(path).expect(200).expect('Content-Type',/html/);});
test('passwords and bearer tokens are stored only as hashes',()=>{const a=ctx.db.prepare('SELECT * FROM academies WHERE code=?').get('HAWON01');assert.notEqual(a.password_hash,password);assert(!a.password_hash.includes(password));const l=ctx.db.prepare('SELECT * FROM links WHERE id=?').get(link.id);assert.notEqual(l.car_token_hash,car);assert.equal(l.car_token_hash.length,64);});
test('login rejects wrong password; car and academy APIs require proper token type',async()=>{await request(ctx.app).post('/api/academy/session').send({code:'HAWON01',password:'wrong'}).expect(401);await request(ctx.app).get('/api/academy/trips').expect(401);await request(ctx.app).get('/api/academy/trips').set(auth(car)).expect(401);await request(ctx.app).get('/api/car/config').set(auth(academy)).expect(401);const r=await request(ctx.app).get('/api/car/config').set(auth(car)).expect(200);assert.equal(r.body.link.childName,'지우');assert.equal(r.body.link.academyCode,'HAWON01');});
test('registration validates explicit consent, schedule, duration and unknown coordinate fields',async()=>{for(const delta of [{guardianConsent:false},{guardianConsent:'true'},{weekday:[0]},{weekday:[1,1]},{pickupTime:'24:00'},{baseLeadSeconds:0},{latitude:37.5},{childName:'<script>'}])await request(ctx.app).post('/api/links').send({...register(),...delta}).expect(400);});
test('trip lifecycle, release, idempotent retry and terminal ordering',async()=>{
  const t=await newTrip();const eta=event('ETA',{etaMin:9});let r=await send(t,eta).expect(200);assert.equal(r.body.trip.status,'EN_ROUTE');
  await send(t,{...eta,etaMin:10}).expect(409);
  r=await send(t,event('CALL')).expect(200);assert.equal(r.body.trip.status,'CALLED');
  r=await request(ctx.app).post(`/api/trips/${t.id}/released`).set(auth(academy)).send({}).expect(200);const released=r.body.trip.releasedAt;assert(released);
  r=await request(ctx.app).post(`/api/trips/${t.id}/released`).set(auth(academy)).send({}).expect(200);assert.equal(r.body.trip.releasedAt,released);
  await send(t,event('ARRIVED')).expect(200);const boarded=event('BOARDED');r=await send(t,boarded).expect(200);assert.equal(r.body.trip.status,'BOARDED');assert.equal(r.body.trip.confirmation,'GUARDIAN');
  const saved=ctx.db.prepare("SELECT payload FROM events WHERE trip_id=? AND type='BOARDED'").get(t.id);assert.equal(JSON.parse(saved.payload).confirmation,'GUARDIAN');
  r=await send(t,eta).expect(200);assert.equal(r.body.idempotent,true);assert.equal(r.body.trip.status,'BOARDED');
  await send(t,event('CALL')).expect(409);await send(t,event('CANCEL')).expect(409);await send(t,event('ETA',{etaMin:2})).expect(409);await send(t,boarded).expect(200);
});
test('ARRIVED before CALL establishes a call; delayed CALL never regresses status',async()=>{const t=await newTrip();let r=await send(t,event('ARRIVED')).expect(200);assert(r.body.trip.calledAt);r=await send(t,event('CALL')).expect(200);assert.equal(r.body.trip.status,'ARRIVED');r=await send(t,event('ETA',{etaMin:4})).expect(200);assert.equal(r.body.trip.status,'ARRIVED');assert.equal(r.body.trip.etaMin,0);await send(t,event('BOARDED')).expect(200);});
test('nanosecond Instant timestamps from Android are accepted',async()=>{const t=await newTrip();const at=new Date().toISOString().replace(/\.(\d{3})Z$/,'.$1123456Z');await send(t,event('ETA',{etaMin:3,at})).expect(200);await send(t,event('CANCEL')).expect(200);});
test('illegal boarding, duplicate active trip, and trip-start retry',async()=>{const clientTripId=crypto.randomUUID();const body={linkId:link.id,clientTripId};let r=await request(ctx.app).post('/api/trips').set(auth(car)).send(body).expect(201);const t=r.body.trip;r=await request(ctx.app).post('/api/trips').set(auth(car)).send(body).expect(200);assert.equal(r.body.trip.id,t.id);assert.equal(r.body.idempotent,true);await request(ctx.app).post('/api/trips').set(auth(car)).send({...body,clientTripId:crypto.randomUUID()}).expect(409);await send(t,event('BOARDED')).expect(409);await send(t,event('CANCEL')).expect(200);});
test('car and academy tenant isolation across every trip route',async()=>{const t=await newTrip();await request(ctx.app).get(`/api/trips/${t.id}`).set(auth(otherCar)).expect(404);await send(t,event('CALL'),otherCar).expect(404);await request(ctx.app).post(`/api/trips/${t.id}/released`).set(auth(academyB)).send({}).expect(404);const r=await request(ctx.app).get('/api/academy/trips').set(auth(academyB)).expect(200);assert(!r.body.trips.some(x=>x.id===t.id));await request(ctx.app).post('/api/trips').set(auth(otherCar)).send({linkId:link.id,clientTripId:'tenant-test'}).expect(404);await send(t,event('CANCEL')).expect(200);});
test('events reject coordinates, unknown fields, invalid times and ETA shapes',async()=>{const t=await newTrip();for(const e of [event('CALL',{latitude:37}),event('CALL',{location:{lat:37,lon:127}}),event('ETA',{etaMin:1.5}),event('ETA',{etaMin:-1}),event('CALL',{etaMin:5}),event('CALL',{at:'not-a-date'}),event('CALL',{at:'2026-02-31T00:00:00Z'}),event('CALL',{at:'2099-01-01T00:00:00Z'})])await send(t,e).expect(400);await send(t,event('CANCEL')).expect(200);});
test('academy and car websocket broadcast real REST changes without coordinates or secrets',async()=>{
  const t=await newTrip(),a=await socket('/ws/academy/HAWON01');let next=message(a);a.send(JSON.stringify({type:'AUTH',token:academy}));assert.equal((await next).type,'TRIPS');
  const c=await socket(`/ws/car/${t.id}`);next=message(c);c.send(JSON.stringify({type:'AUTH',token:car}));assert.equal((await next).type,'TRIP');
  const na=message(a),nc=message(c);await send(t,event('CALL')).expect(200);assert.equal((await na).trips.find(x=>x.id===t.id).status,'CALLED');assert.equal((await nc).trip.status,'CALLED');
  const notice=message(c);await request(ctx.app).post(`/api/trips/${t.id}/released`).set(auth(academy)).send({}).expect(200);const data=await notice;assert(data.trip.releasedAt);const json=JSON.stringify(data);for(const forbidden of ['latitude','longitude','carToken','password','token_hash'])assert(!json.includes(forbidden));
  a.close();c.close();await send(t,event('CANCEL')).expect(200);
});
test('websocket unauthenticated timeout and cross-tenant auth denial',async()=>{
  let ws=await socket('/ws/academy/HAWON01');assert.equal(await closed(ws),4401);
  ws=await socket('/ws/academy/HAWON01');const done=closed(ws);ws.send(JSON.stringify({type:'AUTH',token:academyB}));assert.equal(await done,4403);
  const t=await newTrip();ws=await socket(`/ws/car/${t.id}`);const denied=closed(ws);ws.send(JSON.stringify({type:'AUTH',token:otherCar}));assert.equal(await denied,4403);await send(t,event('CANCEL')).expect(200);
});
test('retention deletes trips and event payloads after 90 days',async()=>{const t=await newTrip();await send(t,event('CANCEL')).expect(200);const old=new Date(Date.now()-91*86400000).toISOString();ctx.db.prepare('UPDATE trips SET created_at=? WHERE id=?').run(old,t.id);prune(ctx.db);assert.equal(ctx.db.prepare('SELECT count(*) n FROM trips WHERE id=?').get(t.id).n,0);assert.equal(ctx.db.prepare('SELECT count(*) n FROM events WHERE trip_id=?').get(t.id).n,0);});
test('database survives restart and academy sessions can be revoked',async()=>{const dir=mkdtempSync(join(tmpdir(),'hawoncall-'));try{const path=join(dir,'test.sqlite');let db=openStore(path);createAcademy(db,{code:'PERSIST',name:'지속학원',password});db.close();db=openStore(path);assert.equal(db.prepare('SELECT name FROM academies').get().name,'지속학원');db.close();}finally{rmSync(dir,{recursive:true,force:true});}const login=(await request(ctx.app).post('/api/academy/session').send({code:'HAWON01',password}).expect(200)).body.token;await request(ctx.app).delete('/api/academy/session').set(auth(login)).expect(204);await request(ctx.app).get('/api/academy/trips').set(auth(login)).expect(401);});

test('logout immediately closes its authenticated academy websocket',async()=>{
  const token=(await request(ctx.app).post('/api/academy/session').send({code:'HAWON01',password}).expect(200)).body.token;
  const ws=await socket('/ws/academy/HAWON01');const first=message(ws);ws.send(JSON.stringify({type:'AUTH',token}));await first;const done=closed(ws);
  await request(ctx.app).delete('/api/academy/session').set(auth(token)).expect(204);assert.equal(await done,4401);
});
test('cross-site websocket origins and URL tokens are rejected before upgrade',async()=>{
  for(const [path,options] of [['/ws/academy/HAWON01?token=secret',{}],['/ws/academy/HAWON01',{origin:'https://untrusted.example'}]]) {
    const ws=new WebSocket(base.replace('http','ws')+path,options);const result=await new Promise(resolve=>{ws.once('open',()=>resolve('open'));ws.once('error',()=>resolve('rejected'));});assert.equal(result,'rejected');ws.terminate();
  }
});

test('boarding requires an explicit guardian confirmation marker and rejects other event markers',async()=>{
  const t=await newTrip();await send(t,event('ARRIVED')).expect(200);
  for(const confirmation of [undefined,null,false,'SENSOR','guardian','']) await send(t,event('BOARDED',{confirmation})).expect(400);
  await send(t,event('CALL',{confirmation:'GUARDIAN'})).expect(400);
  let r=await request(ctx.app).get(`/api/trips/${t.id}`).set(auth(car)).expect(200);
  assert.equal(r.body.trip.status,'ARRIVED');assert.equal(r.body.trip.confirmation,null);
  const e=event('BOARDED');r=await send(t,e).expect(200);assert.equal(r.body.trip.confirmation,'GUARDIAN');
  const list=await request(ctx.app).get('/api/academy/trips').set(auth(academy)).expect(200);
  assert.equal(list.body.trips.find(x=>x.id===t.id).confirmation,'GUARDIAN');
  await send(t,e).expect(200);
  assert.equal(ctx.db.prepare("SELECT count(*) n FROM events WHERE trip_id=? AND type='BOARDED'").get(t.id).n,1);
});
test('legacy boarded rows without confirmation remain unverified after store restart',async()=>{
  const dir=mkdtempSync(join(tmpdir(),'hawoncall-confirmation-'));
  try {
    const path=join(dir,'legacy.sqlite');let db=openStore(path);
    db.exec('ALTER TABLE trips DROP COLUMN boarding_confirmation');db.close();
    db=openStore(path);const column=db.prepare('PRAGMA table_info(trips)').all().find(c=>c.name==='boarding_confirmation');
    assert(column);assert.equal(column.dflt_value,null);db.close();
  } finally {rmSync(dir,{recursive:true,force:true});}
  const t=await newTrip();ctx.db.prepare("UPDATE trips SET status='BOARDED',boarded_at=? WHERE id=?").run(new Date().toISOString(),t.id);
  const r=await request(ctx.app).get(`/api/trips/${t.id}`).set(auth(car)).expect(200);
  assert.equal(r.body.trip.status,'BOARDED');assert.equal(r.body.trip.confirmation,null);
});

test('late queued ETA drains idempotently after arrival and does not block guardian boarding',async()=>{
  const t=await newTrip();
  let r=await send(t,event('ARRIVED')).expect(200);const arrivedAt=r.body.trip.arrivedAt;
  const lateEta=event('ETA',{etaMin:9});
  r=await send(t,lateEta).expect(200);
  assert.equal(r.body.trip.status,'ARRIVED');assert.equal(r.body.trip.etaMin,0);assert.equal(r.body.trip.arrivedAt,arrivedAt);
  r=await send(t,lateEta).expect(200);assert.equal(r.body.idempotent,true);
  assert.equal(r.body.trip.status,'ARRIVED');assert.equal(r.body.trip.etaMin,0);
  await send(t,{...lateEta,etaMin:10}).expect(409);
  assert.equal(ctx.db.prepare('SELECT count(*) n FROM events WHERE trip_id=? AND event_id=?').get(t.id,lateEta.eventId).n,1);
  r=await send(t,event('BOARDED')).expect(200);
  assert.equal(r.body.trip.status,'BOARDED');assert.equal(r.body.trip.confirmation,'GUARDIAN');
});
