import express from 'express';
import { registerOperations } from './operations.js';
import { registerLiveLocation } from './live-location.js';
import { createServer } from 'node:http';
import { WebSocketServer, WebSocket } from 'ws';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';
import { digest, opaque, pairingCode, openStore, prune, verifyPassword, passwordHash, institutionTypes } from './store.js';
import { createSpotService, insideSeoul, loadSeoulCatalog, nearbyRoadContext } from './seoul-spots.js';

const terminal = new Set(['BOARDED', 'HANDED_OVER', 'CANCELLED']);
const codePattern = /^[A-Z0-9_-]{4,24}$/;
const idPattern = /^[A-Za-z0-9_-]{1,100}$/;
const fail = (status, message, code) => { const e = new Error(message); e.status = status; if(code)e.code=code; throw e; };
const exact = (body, keys) => {
  if (!body || Array.isArray(body) || typeof body !== 'object' || Object.keys(body).some(k => !keys.includes(k))) fail(400, '허용되지 않은 입력입니다.');
};
const str = (value, max = 60) => typeof value === 'string' && value.trim().length > 0 && value.length <= max;
const clientId = value => typeof value === 'string' && idPattern.test(value);
const bearer = req => /^Bearer ([A-Za-z0-9_-]{40,100})$/.exec(req.headers.authorization || '')?.[1];
const apiTrip = r => ({
  id:r.id, linkId:r.link_id, clientTripId:r.client_trip_id, childName:r.child_name,
  academyName:r.academy_name, status:r.status, etaMin:r.eta_min, createdAt:r.created_at,
  updatedAt:r.updated_at, calledAt:r.called_at, arrivedAt:r.arrived_at, boardedAt:r.boarded_at,
  cancelledAt:r.cancelled_at, releasedAt:r.released_at, confirmation:r.boarding_confirmation ?? null,
  journeyType:r.journey_type, handedOverAt:r.handed_over_at
});
const apiLink = r => ({ id:r.id, childName:r.child_name, academyName:r.academy_name,
  academyCode:r.academy_code, weekday:JSON.parse(r.weekday), pickupTime:r.pickup_time,
  baseLeadSeconds:r.base_lead_seconds, guardianConsent:true, institutionType:r.institution_type,
  journeyType:r.journey_type, serviceArea:r.service_area, institutionName:r.academy_name, institutionCode:r.academy_code,isDemoInstitution:r.is_demo===1 });
const tripSql = `SELECT t.*, l.child_name, l.academy_id, a.name academy_name FROM trips t JOIN links l ON l.id=t.link_id JOIN academies a ON a.id=l.academy_id`;
const linkSql = `SELECT l.*, a.name academy_name, a.code academy_code, a.is_demo FROM links l JOIN academies a ON a.id=l.academy_id`;

export function createApplication({ databasePath, db = openStore(databasePath), authTimeoutMs = 5000, rateLimit = true, spotCatalog = loadSeoulCatalog(), locationNow = Date.now, allowedWebOrigins = process.env.WEB_ALLOWED_ORIGINS ?? '' } = {}) {
  prune(db);
  const spots=createSpotService(db,spotCatalog);
  const configuredLink = link => ({...apiLink(link),pickupSpot:spots.selected(link)});
  const webOrigins = new Set((Array.isArray(allowedWebOrigins)?allowedWebOrigins:String(allowedWebOrigins).split(',')).filter(Boolean).map(value=>{
    const origin=String(value).trim(); let url;
    try {url=new URL(origin);} catch {throw new Error('WEB_ALLOWED_ORIGINS must contain exact HTTPS origins.');}
    if(url.protocol!=='https:'||url.origin!==origin)throw new Error('WEB_ALLOWED_ORIGINS must contain exact HTTPS origins.');
    return origin;
  }));
  const app = express();
  const server = createServer(app);
  const wss = new WebSocketServer({ noServer:true, maxPayload:4096 });
  const academySockets = new Map(), carSockets = new Map();
  const authDummy = passwordHash(opaque());
  const limits = new Map();
  const timer = setInterval(() => { prune(db); limits.clear(); }, 3600000).unref();
  app.disable('x-powered-by');
  app.use((req,res,next) => {
    res.set({ 'X-Content-Type-Options':'nosniff', 'Referrer-Policy':'no-referrer',
      'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
      'Permissions-Policy':`geolocation=(${['/child','/child.html'].includes(req.path)?'self':''}), microphone=(), camera=()`, 'Cache-Control':'no-store' });
    next();
  });
  // Cross-device web clients are opt-in exact HTTPS origins. Bearer tokens only; no cookies.
  app.use('/api',(req,res,next)=>{
    const origin=req.headers.origin;
    if(!origin)return next();
    let sameOrigin=false;try{sameOrigin=new URL(origin).host===req.headers.host;}catch{}
    if(sameOrigin)return next();
    res.vary('Origin');
    if(!webOrigins.has(origin))return res.status(403).json({error:'REQUEST_ERROR',code:'CORS_ORIGIN_DENIED',message:'허용된 웹 주소에서 연결하세요.'});
    res.set({'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Methods':'GET, POST, PUT, DELETE, OPTIONS','Access-Control-Allow-Headers':'Authorization, Content-Type'});
    if(req.method==='OPTIONS')return res.status(204).end();
    next();
  });
  app.use(express.json({limit:'8kb', strict:true}));
  const limited = (bucket, max) => (req,res,next) => {
    if (!rateLimit) return next();
    const key = `${bucket}:${req.socket.remoteAddress}`;
    const now = Date.now();
    let row = limits.get(key);
    if (!row || now > row.until) { row={count:0,until:now+15*60000}; limits.set(key,row); }
    if (++row.count > max) { res.set('Retry-After',String(Math.ceil((row.until-now)/1000))); return next(Object.assign(new Error('요청이 많습니다. 잠시 후 다시 시도하세요.'),{status:429})); }
    next();
  };
  const academyFor = token => token && db.prepare('SELECT a.* FROM sessions s JOIN academies a ON a.id=s.academy_id WHERE s.token_hash=? AND s.expires_at>?').get(digest(token),new Date().toISOString());
  const guardianFor = token => token && db.prepare(`${linkSql} JOIN guardian_tokens g ON g.link_id=l.id WHERE g.token_hash=?`).get(digest(token));
  const carFor = token => token && db.prepare(`${linkSql} WHERE l.car_token_hash=?`).get(digest(token));
  const academyAuth = (req,res,next) => { req.academy=academyFor(bearer(req)); if (!req.academy) return next(Object.assign(new Error('학원 로그인이 필요합니다.'),{status:401})); next(); };
  const guardianAuth = (req,res,next) => { req.link=guardianFor(bearer(req)); if (!req.link) return next(Object.assign(new Error('보호자 연결 토큰을 확인하세요.'),{status:401})); next(); };
  const carAuth = (req,res,next) => { req.link=carFor(bearer(req)); if (!req.link) return next(Object.assign(new Error('차량 연결 토큰을 확인하세요.'),{status:401})); next(); };
  const tripById = id => db.prepare(`${tripSql} WHERE t.id=?`).get(id);
  const ownedTrip = req => { const t=tripById(req.params.id); if (!t || t.link_id!==req.link.id) fail(404,'픽업을 찾을 수 없습니다.'); return t; };
  const tripsFor = academyId => db.prepare(`${tripSql} WHERE l.academy_id=? ORDER BY CASE WHEN t.status IN ('BOARDED','HANDED_OVER','CANCELLED') THEN 1 ELSE 0 END, CASE WHEN t.status='ARRIVED' THEN 0 WHEN t.status='CALLED' THEN 1 ELSE 2 END, COALESCE(t.eta_min,999), t.created_at DESC LIMIT 200`).all(academyId).map(apiTrip);
  const send = (ws,value) => { if(ws.readyState===WebSocket.OPEN) { if(ws.bufferedAmount>1024*1024) return ws.close(1013,'Slow client'); ws.send(JSON.stringify(value)); } };
  const broadcast = t => {
    for (const ws of academySockets.get(t.academy_id)||[]) send(ws,{type:'TRIPS',trips:tripsFor(t.academy_id)});
    for (const ws of carSockets.get(t.id)||[]) send(ws,{type:'TRIP',trip:apiTrip(t)});
  };
  const liveLocation=registerLiveLocation({app,db,guardianAuth,carAuth,limited,boundary:spotCatalog.boundary,now:locationNow});
  app.get('/api/health', (req,res) => res.json({ok:true,service:'hawoncall',retentionDays:90,coordinatesCollected:true,coordinatesPersisted:false,vehicleRawGpsStored:false,liveCoordinatesInMemoryOnly:true,locationHistoryStored:false,serviceArea:'SEOUL',catalogQueriesEphemeral:true}));
  app.post('/api/academy/session', limited('login',20), (req,res) => {
    exact(req.body,['code','password']);
    const {code,password}=req.body;
    if(typeof code!=='string'||!codePattern.test(code)||!str(password,128)) fail(400,'학원 코드와 비밀번호를 확인하세요.');
    const a=db.prepare('SELECT * FROM academies WHERE code=?').get(code);
    if(!verifyPassword(password,a?.password_hash||authDummy)||!a) fail(401,'학원 코드 또는 비밀번호가 일치하지 않습니다.');
    const token=opaque(), expiresAt=new Date(Date.now()+12*3600000).toISOString();
    db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(digest(token),a.id,expiresAt);
    res.json({token,expiresAt,academy:{id:a.id,code:a.code,name:a.name,institutionType:a.institution_type,serviceArea:a.service_area,isDemoInstitution:a.is_demo===1}});
  });
  app.delete('/api/academy/session',academyAuth,(req,res) => {
    const hash=digest(bearer(req));
    db.prepare('DELETE FROM sessions WHERE token_hash=?').run(hash);
    for(const ws of academySockets.get(req.academy.id)||[]) if(ws.sessionHash===hash) ws.close(4401,'Session revoked');
    res.status(204).end();
  });
  const registerLink = guardian => (req,res) => {
    exact(req.body,['academyCode','childName','weekday','pickupTime','baseLeadSeconds','guardianConsent','institutionType','journeyType','serviceArea']);
    const {academyCode,childName,weekday,pickupTime,baseLeadSeconds=300,guardianConsent,institutionType,journeyType='PICKUP',serviceArea='SEOUL'}=req.body;
    if(typeof academyCode!=='string'||!codePattern.test(academyCode)||!str(childName,30)||/[<>\u0000-\u001f]/u.test(childName)) fail(400,'학원 코드와 아이 호칭을 확인하세요.');
    if(!Array.isArray(weekday)||!weekday.length||weekday.length>7||new Set(weekday).size!==weekday.length||weekday.some(v=>!Number.isInteger(v)||v<1||v>7)) fail(400,'하원 요일을 선택하세요.');
    if(typeof pickupTime!=='string'||!/^([01]\d|2[0-3]):[0-5]\d$/.test(pickupTime)) fail(400,'하원 시각은 HH:MM 형식입니다.');
    if(!Number.isInteger(baseLeadSeconds)||baseLeadSeconds<60||baseLeadSeconds>1200) fail(400,'준비 시간은 1~20분입니다.');
    if(guardianConsent!==true) fail(400,'법정대리인의 동의가 필요합니다.');
    const a=db.prepare('SELECT * FROM academies WHERE code=?').get(academyCode);
    if(!a) fail(404,'연결 코드를 확인하세요.');
    const resolvedType=institutionType ?? a.institution_type;
    if (!institutionTypes.includes(resolvedType) || resolvedType !== a.institution_type || !['PICKUP','DROPOFF'].includes(journeyType) || serviceArea !== 'SEOUL' || a.service_area !== 'SEOUL') fail(400,'서울 서비스의 기관 유형과 등하원 방향을 확인하세요.');
    const id=`lk_${opaque().slice(0,20)}`,carToken=opaque(),now=new Date().toISOString();
    // Keep the legacy links schema stable. Guardian registration never exposes this initial vehicle secret.
    const guardianToken=guardian?opaque():null;
    db.exec('BEGIN IMMEDIATE');
    try {
      db.prepare('INSERT INTO links(id,academy_id,child_name,weekday,pickup_time,base_lead_seconds,car_token_hash,consent_at,created_at,institution_type,journey_type,service_area) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').run(id,a.id,childName.trim(),JSON.stringify(weekday),pickupTime,baseLeadSeconds,digest(carToken),now,now,resolvedType,journeyType,serviceArea);
      if(guardian) db.prepare('INSERT INTO guardian_tokens VALUES(?,?,?)').run(digest(guardianToken),id,now);
      db.exec('COMMIT');
    } catch(e) { db.exec('ROLLBACK'); throw e; }
    res.status(201).json({link:configuredLink(db.prepare(`${linkSql} WHERE l.id=?`).get(id)),...(guardian?{guardianToken}:{carToken})});
  };
  app.post('/api/links',limited('links',40),registerLink(false));
  app.post('/api/guardian/links',limited('links',40),registerLink(true));
  app.get('/api/guardian/config',guardianAuth,(req,res)=>res.json({link:configuredLink(req.link)}));
  app.get('/api/guardian/pickup-spots',guardianAuth,limited('spot-catalog',200),(req,res)=>{
    if (Object.keys(req.query).some(k=>!['lat','lon','q'].includes(k))) fail(400,'검색 좌표만 입력하세요.');
    let coordinates;
    if (req.query.lat!==undefined || req.query.lon!==undefined) {
      if (typeof req.query.lat!=='string' || typeof req.query.lon!=='string' || !req.query.lat.trim() || !req.query.lon.trim()) fail(400,'위도와 경도를 함께 입력하세요.');
      coordinates=[Number(req.query.lon),Number(req.query.lat)];
      if (!insideSeoul(coordinates,spotCatalog.boundary)) fail(400,'서울 행정구역 안의 지점을 조회하세요.');
    }
    if(req.query.q!==undefined && (typeof req.query.q!=='string' || req.query.q.length>80)) fail(400,'검색어는 80자 이내로 입력하세요.');
    const result=spots.list(req.link,coordinates,req.query.q?.trim() ?? '');
    const recommended=result.find(s=>s.recommendationRank===1);
    res.json({serviceArea:'SEOUL',spots:result.slice(0,200),total:result.length,truncated:result.length>200,selectionAllowed:result.some(s=>s.eligible),recommendedSpotId:recommended?.id ?? null,recommendationBasis:recommended?'NEARBY_CONFIRMED_PARKED_WAIT':null});
  });
  app.get('/api/guardian/road-context',guardianAuth,limited('road-context',200),(req,res)=>{
    if (Object.keys(req.query).some(k=>!['lat','lon'].includes(k))) fail(400,'검색 좌표만 입력하세요.');
    let coordinates;
    if (req.query.lat!==undefined || req.query.lon!==undefined) {
      if (typeof req.query.lat!=='string' || typeof req.query.lon!=='string' || !req.query.lat.trim() || !req.query.lon.trim()) fail(400,'위도와 경도를 함께 입력하세요.');
      coordinates=[Number(req.query.lon),Number(req.query.lat)];
      if (!insideSeoul(coordinates,spotCatalog.boundary)) fail(400,'서울 행정구역 안의 지점을 조회하세요.');
    }
    const context=nearbyRoadContext(spotCatalog.roads,coordinates);
    res.json({serviceArea:'SEOUL',radiusMeters:2000,limit:500,requiresCoordinates:context.requiresCoordinates,truncated:context.truncated,featureCollection:{type:'FeatureCollection',features:context.features},source:spotCatalog.roads?.source ?? (spotCatalog.roads?.sourceId?{id:spotCatalog.roads.sourceId,name:spotCatalog.roads.sourceName,url:spotCatalog.roads.sourceUrl,referenceDate:spotCatalog.roads.referenceDate}:null),permissionInferenceAllowed:false});
  });
  app.get('/api/guardian/protection-facilities',guardianAuth,limited('protection-facilities',200),(req,res)=>{
    if(Object.keys(req.query).some(k=>k!=='q') || req.query.q!==undefined && (typeof req.query.q!=='string' || req.query.q.length>80)) fail(400,'검색어는 80자 이내로 입력하세요.');
    const q=req.query.q?.trim().toLocaleLowerCase('ko') ?? '', data=spotCatalog.protectionFacilities ?? {records:[]};
    const records=(data.records??[]).filter(r=>!q || `${r.name??''} ${r.address??''} ${r.district??''}`.toLocaleLowerCase('ko').includes(q));
    res.json({serviceArea:'SEOUL',records:records.slice(0,100),total:records.length,limit:100,truncated:records.length>100,protectionAreaGeometryAvailable:false,completeHazardMap:false,permissionInferenceAllowed:false,source:{id:data.sourceId??null,name:data.sourceName??'서울시 어린이보호구역 지정 현황',url:data.sourceUrl??null,referenceDate:data.referenceDate??null},note:data.note??'지정 시설 주소 참고자료이며 도로 규제 경계나 승하차 허가 목록이 아닙니다.'});
  });
  app.post('/api/guardian/pickup-spot',guardianAuth,limited('spot-select',40),(req,res)=>{
    exact(req.body,['spotId']);
    if (!str(req.body.spotId,160)) fail(400,'승하차 지점을 선택하세요.');
    const check=spots.eligibility(req.body.spotId,req.link);
    if (check.reason==='UNKNOWN_SPOT') fail(404,'승하차 지점을 찾을 수 없습니다.');
    if (!check.eligible) fail(409,'현재 방향·차량에 유효한 운영자 확인 허가가 없는 지점입니다.');
    db.prepare('UPDATE links SET selected_spot_id=? WHERE id=?').run(req.body.spotId,req.link.id);
    liveLocation.revoke(req.link.id);
    res.json({link:configuredLink(db.prepare(`${linkSql} WHERE l.id=?`).get(req.link.id))});
  });
  app.get('/api/guardian/trips',guardianAuth,(req,res)=>res.json({trips:db.prepare(`${tripSql} WHERE t.link_id=? ORDER BY t.created_at DESC, t.rowid DESC LIMIT 200`).all(req.link.id).map(apiTrip)}));
  app.post('/api/guardian/pairing',guardianAuth,limited('pairing-issue',40),(req,res)=>{
    exact(req.body,[]);
    let code;
    do { code=pairingCode(); } while(db.prepare('SELECT 1 FROM pairing_codes WHERE code_hash=?').get(digest(code)));
    const expiresAt=new Date(Date.now()+5*60000).toISOString();
    // Issuing a replacement invalidates any older unclaimed code for this guardian.
    db.prepare('INSERT INTO pairing_codes VALUES(?,?,?) ON CONFLICT(link_id) DO UPDATE SET code_hash=excluded.code_hash,expires_at=excluded.expires_at').run(digest(code),req.link.id,expiresAt);
    res.json({code,expiresAt});
  });
  app.post('/api/car/pairing',limited('pairing-claim',20),(req,res)=>{
    exact(req.body,['code']);
    const {code}=req.body;
    if(typeof code!=='string'||!/^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{8}$/.test(code)) fail(400,'차량 연결 코드 8자리를 확인하세요.');
    const now=new Date().toISOString(),hash=digest(code),carToken=opaque();
    let link;
    db.exec('BEGIN IMMEDIATE');
    try {
      const pairing=db.prepare('SELECT * FROM pairing_codes WHERE code_hash=? AND expires_at>?').get(hash,now);
      if(!pairing) fail(400,'연결 코드가 만료되었거나 이미 사용되었습니다.');
      link=db.prepare(`${linkSql} WHERE l.id=?`).get(pairing.link_id);
      if(db.prepare("SELECT 1 FROM trips WHERE link_id=? AND status NOT IN ('BOARDED','HANDED_OVER','CANCELLED')").get(link.id)) fail(409,'진행 중인 픽업을 마친 후 차량을 다시 연결하세요.');
      db.prepare('UPDATE links SET car_token_hash=? WHERE id=?').run(digest(carToken),link.id);
      db.prepare('DELETE FROM pairing_codes WHERE code_hash=?').run(hash);
      db.exec('COMMIT');
    } catch(e) { db.exec('ROLLBACK'); throw e; }
    liveLocation.revoke(link.id);
    for(const ws of wss.clients) if(ws.linkId===link.id) ws.close(4401,'Vehicle pairing replaced');
    res.json({link:configuredLink(link),carToken});
  });
  app.get('/api/car/config',carAuth,(req,res)=>res.json({link:configuredLink(req.link)}));
  app.post('/api/trips',carAuth,(req,res)=>{
    exact(req.body,['linkId','clientTripId','journeyType','institutionType','serviceArea']);
    if(req.body.linkId!==req.link.id) fail(404,'연결을 찾을 수 없습니다.');
    if(!clientId(req.body.clientTripId)) fail(400,'clientTripId가 필요합니다.');
    const previous=db.prepare('SELECT id FROM trips WHERE link_id=? AND client_trip_id=?').get(req.link.id,req.body.clientTripId);
    if(previous) return res.json({trip:apiTrip(tripById(previous.id)),idempotent:true});
    if (['journeyType','institutionType','serviceArea'].some(key=>req.body[key]!==undefined && req.body[key]!==({journeyType:req.link.journey_type,institutionType:req.link.institution_type,serviceArea:req.link.service_area})[key])) fail(409,'연결 설정이 변경되었습니다. 최신 설정을 확인하세요.','LINK_CONFIGURATION_CHANGED');
    const active=db.prepare("SELECT id FROM trips WHERE link_id=? AND status NOT IN ('BOARDED','HANDED_OVER','CANCELLED')").get(req.link.id);
    if(active) fail(409,'진행 중인 픽업을 먼저 마치거나 취소하세요.');
    const id=`tr_${opaque().slice(0,20)}`,now=new Date().toISOString();
    db.prepare("INSERT INTO trips(id,link_id,client_trip_id,status,created_at,updated_at,journey_type,pickup_spot_snapshot) VALUES(?,?,?,'PLANNED',?,?,?,?)").run(id,req.link.id,req.body.clientTripId,now,now,req.link.journey_type,spots.snapshot(req.link));
    const trip=tripById(id); liveLocation.bindTrip(trip); broadcast(trip); res.status(201).json({trip:apiTrip(trip)});
  });
  app.get('/api/trips/:id',carAuth,(req,res)=>res.json({trip:apiTrip(ownedTrip(req))}));
  app.get('/api/academy/trips',academyAuth,(req,res)=>res.json({trips:tripsFor(req.academy.id)}));
  app.post('/api/trips/:id/events',carAuth,(req,res)=>{
    exact(req.body,['eventId','type','etaMin','at','confirmation','arrivalSpotEvidence']);
    const {eventId,type,etaMin,at,confirmation,arrivalSpotEvidence}=req.body;
    if(!clientId(eventId)||!['ETA','CALL','ARRIVED','BOARDED','HANDED_OVER','CANCEL'].includes(type)) fail(400,'유효한 eventId와 이벤트 종류가 필요합니다.');
    if(typeof at!=='string'||!/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,9})?Z$/.test(at)||!Number.isFinite(Date.parse(at))||Date.parse(at)>Date.now()+5*60000) fail(400,'at은 UTC ISO 시각이어야 하며 미래일 수 없습니다.');
    if(type==='ETA' ? !Number.isInteger(etaMin)||etaMin<0||etaMin>1440 : etaMin!==undefined) fail(400,'ETA 이벤트에만 0~1440분의 etaMin을 보냅니다.');
    if(['BOARDED','HANDED_OVER'].includes(type) ? confirmation!=='GUARDIAN' : confirmation!==undefined) fail(400,'탑승·인계 완료에는 차량 앱의 명시 확인 기록 confirmation: GUARDIAN이 필요합니다.');
    if(arrivalSpotEvidence!==undefined && !['ARRIVED','BOARDED','HANDED_OVER'].includes(type)) fail(400,'승하차 지점 관측 증거는 도착·명시 완료 이벤트에만 허용됩니다.');
    const t=ownedTrip(req),normalizedAt=new Date(at).toISOString();
    if(normalizedAt.slice(0,19)!==at.slice(0,19)) fail(400,'존재하는 날짜와 시각을 입력하세요.');
    const payload=JSON.stringify({type,at:normalizedAt,...(type==='ETA'?{etaMin}:{}),...(['BOARDED','HANDED_OVER'].includes(type)?{confirmation}:{}),...(arrivalSpotEvidence!==undefined?{arrivalSpotEvidence}:{})});
    const duplicate=db.prepare('SELECT payload FROM events WHERE trip_id=? AND event_id=?').get(t.id,eventId);
    if(duplicate) { if(duplicate.payload!==payload) fail(409,'같은 eventId에 다른 내용을 사용할 수 없습니다.'); return res.json({trip:apiTrip(t),idempotent:true}); }
    if(arrivalSpotEvidence!==undefined && !spots.validArrivalShape(arrivalSpotEvidence)) fail(400,'승하차 지점 도착 관측 형식을 확인하세요.');
    // Offline proof can expire in the queue. Drain the safety event, but never learn from stale or mismatched evidence.
    const arrivalEvidenceAccepted=arrivalSpotEvidence!==undefined && spots.validateArrival(t,arrivalSpotEvidence);
    if(terminal.has(t.status)) fail(409,'종료된 픽업은 변경할 수 없습니다.');
    if((type==='BOARDED' && t.journey_type!=='PICKUP') || (type==='HANDED_OVER' && t.journey_type!=='DROPOFF')) fail(409,'등하원 방향에 맞는 완료 이벤트를 사용하세요.');
    if(['BOARDED','HANDED_OVER'].includes(type)&&t.status!=='ARRIVED') fail(409,'도착 후에만 탑승·인계를 완료할 수 있습니다.');
    if(['BOARDED','HANDED_OVER'].includes(type) && t.arrived_at && normalizedAt < t.arrived_at) fail(409,'완료 시각은 도착 시각 이후여야 합니다.');
    const now=new Date().toISOString();
    db.exec('BEGIN IMMEDIATE');
    try {
      db.prepare('INSERT INTO events(trip_id,event_id,type,at,received_at,payload) VALUES(?,?,?,?,?,?)').run(t.id,eventId,type,normalizedAt,now,payload);
      let status=t.status,eta=t.eta_min,called=t.called_at,arrived=t.arrived_at,boarded=t.boarded_at,cancelled=t.cancelled_at;
      // A late/legacy ETA must drain successfully without regressing a parked arrival.
      if(type==='ETA'&&status!=='ARRIVED') { if(!t.last_event_at||normalizedAt>=t.last_event_at) { eta=etaMin; db.prepare('UPDATE trips SET eta_observed_at=?,eta_received_at=? WHERE id=?').run(normalizedAt,now,t.id); } if(status==='PLANNED') status='EN_ROUTE'; }
      if(type==='CALL') { called ||= normalizedAt; if(status!=='ARRIVED') status='CALLED'; }
      if(type==='ARRIVED' && arrivalEvidenceAccepted) db.prepare('UPDATE trips SET spot_arrival_received_at=COALESCE(spot_arrival_received_at,?),spot_arrival_evidence=COALESCE(spot_arrival_evidence,?) WHERE id=?').run(now,JSON.stringify(arrivalSpotEvidence),t.id);
      if(type==='ARRIVED') { db.prepare('UPDATE trips SET arrival_received_at=COALESCE(arrival_received_at,?) WHERE id=?').run(now,t.id); status='ARRIVED'; arrived ||= normalizedAt; called ||= normalizedAt; eta=0; }
      if(type==='BOARDED') { status='BOARDED'; boarded=normalizedAt; db.prepare('UPDATE trips SET boarding_confirmation=? WHERE id=?').run(confirmation,t.id); }
      if(type==='HANDED_OVER') { status='HANDED_OVER'; db.prepare('UPDATE trips SET handed_over_at=?,boarding_confirmation=? WHERE id=?').run(normalizedAt,confirmation,t.id); }
      if(type==='CANCEL') { status='CANCELLED'; cancelled=normalizedAt; }
      db.prepare('UPDATE trips SET status=?,eta_min=?,called_at=?,arrived_at=?,boarded_at=?,cancelled_at=?,updated_at=?,last_event_at=? WHERE id=?').run(status,eta,called,arrived,boarded,cancelled,now,t.last_event_at&&t.last_event_at>normalizedAt?t.last_event_at:normalizedAt,t.id);
      spots.learn(tripById(t.id),now,arrivalSpotEvidence);
      db.exec('COMMIT');
    } catch(e) { db.exec('ROLLBACK'); throw e; }
    const trip=tripById(t.id); liveLocation.tripChanged(trip); broadcast(trip); res.json({trip:apiTrip(trip),...(arrivalSpotEvidence!==undefined?{arrivalEvidenceAccepted}:{})});
  });
  app.post('/api/trips/:id/released',academyAuth,(req,res)=>{
    exact(req.body??{},[]);
    const t=tripById(req.params.id);
    if(!t||t.academy_id!==req.academy.id) fail(404,'픽업을 찾을 수 없습니다.');
    if(t.journey_type!=='PICKUP') fail(409,'등원은 보호자의 인계 확인으로 완료합니다.');
    if(!['CALLED','ARRIVED'].includes(t.status)) fail(409,'호출 또는 도착 상태에서 내려보낼 수 있습니다.');
    if(!t.released_at) { const now=new Date().toISOString(); db.prepare('UPDATE trips SET released_at=?,updated_at=? WHERE id=?').run(now,now,t.id); }
    const trip=tripById(t.id); broadcast(trip); res.json({trip:apiTrip(trip)});
  });
  registerOperations({app,db,spots,guardianAuth,carAuth,academyAuth,limited,tripById,ownedTrip,broadcast});
  const publicDir=fileURLToPath(new URL('../public/',import.meta.url));
  let childPage;
  app.get(['/child','/child.html'],(req,res,next)=>{
    const nonce=opaque();
    res.set('Content-Security-Policy',`default-src 'self'; script-src 'self' 'nonce-${nonce}'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; connect-src 'self' https:; worker-src 'self' blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'`);
    try {
      childPage ??= readFileSync(`${publicDir}child.html`,'utf8');
      res.type('html').send(childPage.replace(/<(script|style)(?=[\s>])/g,`<$1 nonce="${nonce}"`));
    } catch(error) {
      if(error.code==='ENOENT')return res.status(503).json({error:'CHILD_WEB_UNAVAILABLE',message:'아이 웹 화면 빌드를 설치한 뒤 다시 연결하세요.'});
      next(error);
    }
  });
  app.use(express.static(publicDir,{index:false}));
  for (const route of ['/', '/setup', '/demo', '/academy/:code']) app.get(route,(req,res)=>res.sendFile(`${publicDir}index.html`));
  app.use('/api',(req,res)=>res.status(404).json({error:'NOT_FOUND',message:'요청한 API를 찾을 수 없습니다.'}));
  app.use((err,req,res,next)=>{ if(res.headersSent) return next(err); const status=err.status||500; res.status(status).json({error:status===500?'INTERNAL_ERROR':'REQUEST_ERROR',message:status===500?'서버 오류가 발생했습니다.':err.type==='entity.parse.failed'?'JSON 형식을 확인하세요.':err.message,...(err.code && status!==500?{code:err.code}:{})}); });

  server.on('upgrade',(req,socket,head)=>{
    const url=new URL(req.url,'http://localhost');
    const match=/^\/ws\/(academy|car)\/([A-Za-z0-9_-]{1,100})$/.exec(url.pathname);
    if(!match||url.search) return socket.destroy();
    // Browsers must originate from the same site; native clients omit Origin.
    if(req.headers.origin) { try { if(new URL(req.headers.origin).host!==req.headers.host) return socket.destroy(); } catch { return socket.destroy(); } }
    wss.handleUpgrade(req,socket,head,ws=>{
      wss.emit('connection',ws,req);
      let authenticated=false,group,key;
      const timeout=setTimeout(()=>ws.close(4401,'Authentication required'),authTimeoutMs).unref();
      ws.on('error',()=>{});
      ws.on('message',(data,isBinary)=>{
        if(authenticated) return ws.close(4400,'Read only channel');
        if(isBinary) return ws.close(4400,'JSON required');
        let m; try { m=JSON.parse(data.toString()); } catch { return ws.close(4400,'JSON required'); }
        if(!m||m.type!=='AUTH'||typeof m.token!=='string'||Object.keys(m).some(k=>!['type','token'].includes(k))) return ws.close(4401,'Invalid authentication');
        if(match[1]==='academy') {
          const a=academyFor(m.token); if(!a||a.code!==match[2]) return ws.close(4403,'Forbidden');
          group=academySockets; key=a.id; ws.sessionHash=digest(m.token);
          send(ws,{type:'TRIPS',trips:tripsFor(a.id)});
          const expiry=db.prepare('SELECT expires_at FROM sessions WHERE token_hash=?').get(digest(m.token));
          ws.sessionTimer=setTimeout(()=>ws.close(4401,'Session expired'),Math.max(1,Date.parse(expiry.expires_at)-Date.now())).unref();
        } else {
          const l=carFor(m.token),t=tripById(match[2]); if(!l||!t||l.id!==t.link_id) return ws.close(4403,'Forbidden');
          group=carSockets; key=t.id; ws.linkId=l.id; send(ws,{type:'TRIP',trip:apiTrip(t)});
        }
        authenticated=true; clearTimeout(timeout);
        if(!group.has(key)) group.set(key,new Set()); group.get(key).add(ws);
      });
      ws.on('close',()=>{clearTimeout(timeout);clearTimeout(ws.sessionTimer);if(group){group.get(key)?.delete(ws);if(!group.get(key)?.size)group.delete(key);}});
    });
  });
  const heartbeat=setInterval(()=>{for(const ws of wss.clients){if(ws.alive===false){ws.terminate();continue;}ws.alive=false;ws.ping();}},30000).unref();
  wss.on('connection',ws=>ws.on('pong',()=>{ws.alive=true;}));
  // handleUpgrade does not emit connection automatically.
  server.on('close',()=>{liveLocation.close();clearInterval(timer);clearInterval(heartbeat);for(const ws of wss.clients)ws.terminate();wss.close();});
  return {app,server,db,wss,close:()=>new Promise(resolve=>{liveLocation.close();for(const ws of wss.clients)ws.terminate();server.close(()=>{db.close();resolve();});})};
}
