import { digest, opaque, pairingCode } from './store.js';
import { insideSeoul } from './seoul-spots.js';

const terminal = new Set(['BOARDED', 'HANDED_OVER', 'CANCELLED']);
const TTL = 30000, SESSION_TTL = 30 * 60000, PAIR_TTL = 5 * 60000;
const notice = '실시간 위치는 승하차·주정차 허가가 아닙니다. 목적지 변경은 보호자가 직접 확인하세요.';
const error = (status, code, message) => { throw Object.assign(new Error(message), {status, code}); };
const invalid = () => error(400, 'INVALID_LOCATION_FIX', '위치 관측 조건을 확인하세요.');
const exact = (body, keys) => {
  if (!body || typeof body !== 'object' || Array.isArray(body) || Object.keys(body).some(key => !keys.includes(key))) error(400, 'INVALID_INPUT', '허용되지 않은 입력입니다.');
};
const signature = link => JSON.stringify([link.car_token_hash, link.academy_id, link.journey_type, link.institution_type, link.service_area, link.selected_spot_id, link.child_name, link.weekday, link.pickup_time, link.base_lead_seconds]);

// Deliberately no database writes, coordinate arrays/history, request logging or socket broadcasts.
// Only a single fresh fix per explicit session is ever retained, and all tokens are hashed.
export function registerLiveLocation({app, db, guardianAuth, carAuth, limited, boundary, now = Date.now}) {
  const byLink = new Map(), byCode = new Map(), byToken = new Map();
  const activeTrip = linkId => db.prepare("SELECT id,status FROM trips WHERE link_id=? AND status NOT IN ('BOARDED','HANDED_OVER','CANCELLED') ORDER BY created_at DESC LIMIT 1").get(linkId);
  const clearFix = session => { clearTimeout(session.fixTimer); session.fixTimer = null; session.fix = null; };
  const revoke = linkId => {
    const session = byLink.get(linkId);
    if (!session) return;
    clearFix(session); clearTimeout(session.expiryTimer); clearTimeout(session.pairTimer);
    if (session.codeHash) byCode.delete(session.codeHash);
    if (session.tokenHash) byToken.delete(session.tokenHash);
    byLink.delete(linkId);
  };
  const validate = session => {
    if (!session) return null;
    const link = db.prepare('SELECT * FROM links WHERE id=?').get(session.linkId);
    if (now() >= session.expiresAt || (!session.tokenHash && now() >= session.pairExpiresAt) || !link || signature(link) !== session.linkSignature) { revoke(session.linkId); return null; }
    if (session.tripId) {
      const trip = db.prepare('SELECT status FROM trips WHERE id=? AND link_id=?').get(session.tripId, session.linkId);
      if (!trip || terminal.has(trip.status)) { revoke(session.linkId); return null; }
    } else {
      const trip = activeTrip(session.linkId);
      if (trip) session.tripId = trip.id;
    }
    if (session.fix && (now() - session.fix.observedMs > TTL || now() - session.fix.receivedMs > TTL)) clearFix(session);
    return session;
  };
  const metadata = session => ({id:session.id, linkId:session.linkId, tripId:session.tripId,
    status:!session.tokenHash?'AWAITING_CHILD':session.fix?'SHARING':session.lastSequence?'STALE':'WAITING_FOR_FIX',
    source:'CHILD_PHONE_GPS', startedAt:new Date(session.startedAt).toISOString(), expiresAt:new Date(session.expiresAt).toISOString(),
    pairExpiresAt:session.codeHash?new Date(session.pairExpiresAt).toISOString():null});
  const noQuery = (req,res,next) => { if (Object.keys(req.query).length) return next(Object.assign(new Error('쿼리 입력은 허용되지 않습니다.'),{status:400,code:'INVALID_INPUT'})); next(); };
  const childAuth = (req,res,next) => {
    const token = /^Bearer ([A-Za-z0-9_-]{40,100})$/.exec(req.headers.authorization || '')?.[1];
    req.locationSession = token && validate(byToken.get(digest(token)));
    if (!req.locationSession) return next(Object.assign(new Error('아이 위치 공유가 종료되었거나 연결이 필요합니다.'),{status:401,code:'CHILD_SESSION_UNAVAILABLE'}));
    next();
  };
  app.post('/api/guardian/location-sharing', guardianAuth, limited('location-create',40), noQuery, (req,res) => {
    exact(req.body,['consent']);
    if (req.body.consent !== true) error(400,'CONSENT_REQUIRED','보호자의 명시적 위치 공유 동의가 필요합니다.');
    revoke(req.link.id);
    let code, codeHash;
    do { code = pairingCode(); codeHash = digest(code); } while (byCode.has(codeHash));
    const startedAt = now(), session = {id:`ls_${opaque().slice(0,20)}`,linkId:req.link.id,tripId:activeTrip(req.link.id)?.id ?? null,
      linkSignature:signature(req.link),startedAt,expiresAt:startedAt+SESSION_TTL,pairExpiresAt:startedAt+PAIR_TTL,
      codeHash,tokenHash:null,fix:null,lastSequence:0,lastObservedMs:null};
    session.expiryTimer = setTimeout(() => revoke(session.linkId),SESSION_TTL).unref();
    session.pairTimer = setTimeout(() => { if (!session.tokenHash) revoke(session.linkId); },PAIR_TTL).unref();
    byLink.set(session.linkId,session); byCode.set(codeHash,session);
    res.status(201).json({pairCode:code,pairExpiresAt:new Date(session.pairExpiresAt).toISOString(),session:metadata(session)});
  });
  app.post('/api/child/pair', limited('child-pair',20), noQuery, (req,res) => {
    exact(req.body,['pairCode']);
    const code = req.body.pairCode;
    const session = typeof code==='string' && /^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{8}$/.test(code) && validate(byCode.get(digest(code)));
    if (!session) error(400,'INVALID_PAIR_CODE','연결 코드가 만료되었거나 사용할 수 없습니다.');
    const childToken = opaque(); session.tokenHash=digest(childToken);
    byCode.delete(session.codeHash); session.codeHash=null; clearTimeout(session.pairTimer);
    byToken.set(session.tokenHash,session);
    const link=db.prepare('SELECT l.child_name,l.journey_type,a.name FROM links l JOIN academies a ON a.id=l.academy_id WHERE l.id=?').get(session.linkId);
    res.json({childToken,session:metadata(session),link:{childName:link.child_name,institutionName:link.name,journeyType:link.journey_type}});
  });
  app.put('/api/child/location', childAuth, limited('child-location',3000), noQuery, (req,res) => {
    exact(req.body,['latitude','longitude','accuracyMeters','observedAt','sequence']);
    const {latitude,longitude,accuracyMeters,observedAt,sequence}=req.body, receivedMs=now();
    if (![latitude,longitude,accuracyMeters].every(value=>typeof value==='number'&&Number.isFinite(value)) || accuracyMeters<=0 || accuracyMeters>50 || !insideSeoul([longitude,latitude],boundary) || !Number.isSafeInteger(sequence) || sequence<1) invalid();
    if (typeof observedAt!=='string' || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,3})?Z$/.test(observedAt)) invalid();
    const observedMs=Date.parse(observedAt);
    if (!Number.isFinite(observedMs) || new Date(observedMs).toISOString().slice(0,19)!==observedAt.slice(0,19) || receivedMs-observedMs>TTL || observedMs-receivedMs>5000) invalid();
    const session=req.locationSession;
    if (sequence<=session.lastSequence || (session.lastObservedMs!==null && observedMs<=session.lastObservedMs)) error(409,'LOCATION_OUT_OF_ORDER','새로운 위치 관측을 전송하세요.');
    clearFix(session);
    session.lastSequence=sequence; session.lastObservedMs=observedMs;
    session.fix={latitude,longitude,accuracyMeters,observedAt:new Date(observedMs).toISOString(),receivedAt:new Date(receivedMs).toISOString(),sequence,observedMs,receivedMs};
    // Both observation and receipt deadlines matter. A delayed upload never buys extra freshness.
    session.fixTimer=setTimeout(()=>clearFix(session),Math.max(1,Math.min(observedMs+TTL,receivedMs+TTL)-receivedMs)).unref();
    res.json({accepted:true,sequence,sessionExpiresAt:new Date(session.expiresAt).toISOString(),freshForSeconds:30});
  });
  const snapshot = (req,res) => {
    const session=validate(byLink.get(req.link.id)),fix=session?.fix;
    const location=fix?{latitude:fix.latitude,longitude:fix.longitude,accuracyMeters:fix.accuracyMeters,observedAt:fix.observedAt,receivedAt:fix.receivedAt,sequence:fix.sequence,ageSeconds:Math.max(0,(now()-fix.observedMs)/1000),source:'CHILD_PHONE_GPS'}:null;
    res.json({session:session?metadata(session):null,location,fresh:!!location,maxAgeSeconds:30,pollAfterSeconds:2,permissionInferenceAllowed:false,automaticRouteChangeAllowed:false,notice});
  };
  app.get('/api/guardian/live-location',guardianAuth,noQuery,snapshot);
  app.get('/api/car/live-location',carAuth,noQuery,snapshot);
  app.delete('/api/guardian/location-sharing',guardianAuth,noQuery,(req,res)=>{exact(req.body??{},[]);revoke(req.link.id);res.status(204).end();});
  app.post('/api/child/location-sharing/stop',childAuth,noQuery,(req,res)=>{exact(req.body,[]);revoke(req.locationSession.linkId);res.status(204).end();});
  // Validate external link changes and terminal states even without subsequent API reads.
  const sweep=setInterval(()=>{for(const session of byLink.values())validate(session);},1000).unref();
  return {revoke,bindTrip:trip=>{const session=validate(byLink.get(trip.link_id));if(session&&!session.tripId)session.tripId=trip.id;},tripChanged:trip=>{if(terminal.has(trip.status))revoke(trip.link_id);},close:()=>{clearInterval(sweep);for(const linkId of byLink.keys())revoke(linkId);}};
}
