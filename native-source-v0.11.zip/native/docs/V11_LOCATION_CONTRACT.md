# v0.11 foreground child-phone location contract

All endpoints are same-origin HTTPS in production. Guardian/car use existing Bearer credentials; child uses its separate, one-session Bearer childToken. No coordinate URLs, logs, persistence, history, WebSocket broadcasts, academy access, or analytics. Pairing + tokens + latest fix exist only in process memory; restart fails closed. Poll at most once every 2 seconds. Child UI starts sharing explicitly after pairing. Browser sharing stops when hidden/backgrounded. Android may continue only in an explicitly user-started location foreground service with a persistent sharing notification and STOP action; no background-location permission, boot receiver or automatic restart. Both clients stop on permission loss, session expiry, revocation or user stop.

## Guardian consent and pairing

`POST /api/guardian/location-sharing` with `{ "consent": true }` issues/replaces one session. HTTP 201:

```json
{"pairCode":"ABCDEFGH","pairExpiresAt":"2026-10-26T01:05:00.000Z","session":{"id":"ls_random","linkId":"lk_random","tripId":null,"status":"AWAITING_CHILD","source":"CHILD_PHONE_GPS","startedAt":"2026-10-26T01:00:00.000Z","expiresAt":"2026-10-26T01:30:00.000Z","pairExpiresAt":"2026-10-26T01:05:00.000Z"}}
```

Code: random unambiguous uppercase 8 characters, one-use, 5 minutes. Session: maximum 30 minutes from guardian creation. Starting again revokes the old code/token/fix. Session scopes to guardian link, current car credential and active trip if present. If no active trip, first subsequent trip binds it. Car rotation, pickup point change, link configuration change, bound trip completion/cancellation, revoke, child stop, pair expiry or session expiry clears fix and prevents updates. API has no requested duration or link override.

`POST /api/child/pair` with `{ "pairCode": "ABCDEFGH" }` returns HTTP 200:

```json
{"childToken":"opaque-secret","session":{"id":"ls_random","linkId":"lk_random","tripId":null,"status":"WAITING_FOR_FIX","source":"CHILD_PHONE_GPS","startedAt":"2026-10-26T01:00:00.000Z","expiresAt":"2026-10-26T01:30:00.000Z","pairExpiresAt":null},"link":{"childName":"지우","institutionName":"하원기관","journeyType":"PICKUP"}}
```

Pairing alone sends no GPS; child must explicitly press share. Pair error is generic 400 `INVALID_PAIR_CODE`; throttled attempts return 429. Codes and tokens are stored hashed in process memory only.

## Upload

`PUT /api/child/location` with child Bearer token:

```json
{"latitude":37.5665,"longitude":126.978,"accuracyMeters":12.5,"observedAt":"2026-10-26T01:00:02.000Z","sequence":1}
```

Only these five fields are accepted. All numbers finite; latitude/longitude inside Seoul boundary; accuracy >0 and <=50 meters; observedAt UTC ISO timestamp no older than 30 seconds and no more than 5 seconds future; sequence safe positive integer strictly increasing per session and observedAt strictly increasing. Device mock locations must be refused by child client. No replay/offline queue. Rejected payloads never replace the last fix and errors never echo input. HTTP 200: `{ "accepted": true, "sequence": 1, "sessionExpiresAt": "...", "freshForSeconds": 30 }`. Expired/revoked/stopped/wrong child token returns 401 `CHILD_SESSION_UNAVAILABLE`; validation 400 `INVALID_LOCATION_FIX`; replay/order 409 `LOCATION_OUT_OF_ORDER`.

## Shared snapshot

`GET /api/guardian/live-location` or `GET /api/car/live-location`, no query/body. HTTP 200:

```json
{"session":{"id":"ls_random","linkId":"lk_random","tripId":null,"status":"SHARING","source":"CHILD_PHONE_GPS","startedAt":"2026-10-26T01:00:00.000Z","expiresAt":"2026-10-26T01:30:00.000Z","pairExpiresAt":null},"location":{"latitude":37.5665,"longitude":126.978,"accuracyMeters":12.5,"observedAt":"2026-10-26T01:00:02.000Z","receivedAt":"2026-10-26T01:00:03.000Z","sequence":1,"ageSeconds":1,"source":"CHILD_PHONE_GPS"},"fresh":true,"maxAgeSeconds":30,"pollAfterSeconds":2,"permissionInferenceAllowed":false,"automaticRouteChangeAllowed":false,"notice":"실시간 위치는 승하차·주정차 허가가 아닙니다. 목적지 변경은 보호자가 직접 확인하세요."}
```

No session: `session:null,location:null,fresh:false`. Before first fix: status `AWAITING_CHILD` or `WAITING_FOR_FIX`, location null. Once stale: status `STALE`, location null; actual fix is erased at TTL. Revoked/stopped/expired/terminal sessions also return session null, location null. Freshness is computed from both observedAt and receivedAt, <=30 seconds; ageSeconds = nonnegative observed age, including fractional seconds (no freshness-extending rounding). Latest coordinates are absent whenever fresh=false. Snapshot status is computed, not a durable claim. Session ID may only be used locally; no endpoint accepts another link/session ID. Neither role can view other links or upload GPS. Academy endpoints never include GPS.

## Stop

`DELETE /api/guardian/location-sharing` with no body (or `{}`), guardian Bearer -> 204, idempotent. `POST /api/child/location-sharing/stop` with `{}`, child Bearer -> 204. Stops clear the token, code and fix immediately; stopped child cannot send again. Child keeps sequence only in memory and forgets childToken on stop; browser also forgets it on background. Android foreground service may retain it in memory while its persistent sharing notification remains visible. Guardian can observe sharing through shared snapshot; child does not need a read/status endpoint.

Operational requirement: TLS endpoint and real foreground location permission must be configured on both phones; localhost/simulator tests are not evidence of physical cross-device or GPS validation. Location is advisory and never auto-starts navigation, reroutes, confirms boarding or changes pickup permission.

## Optional external web origin

Default is same-origin. Set `WEB_ALLOWED_ORIGINS=https://lkjh098-cell.github.io` on the deployed HTTPS backend only when that web client is intended. Comma-separated exact HTTPS origins are accepted; wildcard, paths and cookies are forbidden. Allowed origin responses and OPTIONS preflight permit Authorization/Content-Type and GET/POST/PUT/DELETE; unexpected cross-origin requests fail 403. This is transport policy, not authentication. The browser must still use the separate scoped Bearer credential.

## Same-origin child web delivery

The frozen standalone web build is copied into `server/public/child.html`. Both `/child` and `/child.html` inject a unique cryptographic nonce into every script/style tag per response. Script execution uses that nonce; existing institution pages retain their stricter original CSP. Only these two child routes permit same-origin geolocation. No GPS is started by loading the page. The child page defaults to the same-origin API, with explicit pairing and share confirmation still required.

Navigation target adoption is an advisory navigation handoff and must not automatically send a terminal trip event. Real trip completion/cancellation still revokes sharing. The old institution arrival/boarding engine must be suspended during an explicit live-meeting route; child coordinates cannot become vehicle arrival evidence.
