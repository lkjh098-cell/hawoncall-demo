package ai.hawoncall.car.network

import android.content.SharedPreferences
import okhttp3.*
import org.json.JSONObject
import java.io.Closeable
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.TimeUnit

class PreferenceTextStore(private val prefs: SharedPreferences, private val key: String) : TextStore {
    override fun read() = prefs.getString(key, "").orEmpty()
    override fun write(value: String) { check(prefs.edit().putString(key, value).commit()) { "전송 기록 저장 실패" } }
}

class CarRepository(prefs: SharedPreferences, private val baseUrl: String, private val token: String,
                    private val onStatus: (String, Int) -> Unit, private val onTrip: (JSONObject) -> Unit,
                    private val onAuthorizationLost: () -> Unit = {},
                    private val onConfigurationChanged: () -> Unit = {},
                    private val onOperations: (Result<ai.hawoncall.core.OperationSnapshot>) -> Unit = {},
                    private val onChildLive: (Result<ai.hawoncall.core.ChildLiveSnapshot>) -> Unit = {}) : Closeable {
    private val client = OkHttpClient.Builder().followRedirects(false).followSslRedirects(false).callTimeout(8, TimeUnit.SECONDS).pingInterval(20, TimeUnit.SECONDS).build()
    private val outbox = Outbox(PreferenceTextStore(prefs, "outbox"), baseUrl, token, client)
    private val worker = Executors.newSingleThreadScheduledExecutor()
    private val callbacksLock = Any()
    @Volatile private var socket: WebSocket? = null
    @Volatile private var closed = false
    @Volatile private var authorizationLost = prefs.getBoolean("authorizationLost", false)
    @Volatile private var configurationChanged = outbox.configurationConflict()
    private var conflictNotified = false
    private var socketTrip: String? = null
    private var nextAttempt = 0L
    private var failures = 0
    private var lastPoll = 0L
    private var lastOperationsPoll = 0L
    private var lastChildLivePoll = 0L
    @Volatile private var liveConfirmationPending=false
    private var sendError: String? = null
    init {
        // The sensor baseline cannot safely be reconstructed after process death.
        if (!configurationChanged && outbox.activeClientId().isNotBlank()) {
            outbox.event("CANCEL")
            outbox.finishLocal()
        }
        worker.scheduleWithFixedDelay(::sync, 0, 1, TimeUnit.SECONDS)
    }
    fun loadConfig(callback: (Result<JSONObject>) -> Unit) {
        if (closed) return
        try {
            worker.execute {
                if (closed) return@execute
                val result = runCatching {
                    if (authorizationLost) throw ApiFailure(401, "차량 연결이 갱신되어 다시 연결해야 해요")
                    outbox.request("GET", "/api/car/config")
                }
                result.exceptionOrNull()?.let(::checkAuthorization)
                synchronized(callbacksLock) { if (!closed) callback(result) }
            }
        } catch (error: RejectedExecutionException) {
            if (!closed) throw error
        }
    }
    private fun readOperations() {
        if(closed || authorizationLost || configurationChanged) return
        val trip=outbox.activeServerId()
        val path="/api/car/operations?serviceDate=${ai.hawoncall.core.BriefingPolicy.serviceDate()}"+(trip?.let { "&tripId=$it" } ?: "")
        val result=runCatching { ai.hawoncall.core.OperationsJson.snapshot(outbox.request("GET",path)) }
        result.exceptionOrNull()?.let(::checkAuthorization)
        synchronized(callbacksLock) { if(!closed) onOperations(result) }
    }
    private fun readChildLive(callback: ((Result<ai.hawoncall.core.ChildLiveSnapshot>)->Unit)? = null) {
        if(closed || authorizationLost || configurationChanged) {
            if(!closed) callback?.invoke(Result.failure(ApiFailure(401,"아이 위치 공유 권한을 다시 확인해 주세요")))
            return
        }
        lastChildLivePoll=nowMillis()
        val result=runCatching { ai.hawoncall.core.ChildLiveJson.snapshot(outbox.request("GET","/api/car/live-location"),android.os.SystemClock.elapsedRealtime()) }
        result.exceptionOrNull()?.let(::checkAuthorization)
        synchronized(callbacksLock) { if(!closed) { onChildLive(result); callback?.invoke(result) } }
    }
    fun refreshChildLive(callback: (Result<ai.hawoncall.core.ChildLiveSnapshot>)->Unit) {
        liveConfirmationPending=true
        try { worker.execute {
            val wait=(2000-(nowMillis()-lastChildLivePoll)).coerceAtLeast(0)
            worker.schedule({ try { readChildLive(callback) } finally { liveConfirmationPending=false } },wait,TimeUnit.MILLISECONDS)
        } } catch(_: RejectedExecutionException) { liveConfirmationPending=false }
    }
    fun refreshOperations() {
        try { worker.execute { readOperations() } } catch(_: RejectedExecutionException) { }
    }
    fun requestIssue(tripId: String,requestId: String,kind: String,message: String,callback: (Result<Unit>)->Unit) {
        try { worker.execute {
            val result=runCatching {
                check(!closed && !authorizationLost && !configurationChanged)
                require(tripId.matches(Regex("[A-Za-z0-9_-]+")))
                check(outbox.activeClientId().isBlank() || outbox.activeServerId()==tripId) { "현재 이동을 다시 확인하세요." }
                outbox.request("POST","/api/car/trips/$tripId/issues",JSONObject().put("requestId",requestId).put("kind",kind).put("message",message)); Unit
            }
            result.exceptionOrNull()?.let(::checkAuthorization)
            synchronized(callbacksLock) { if(!closed) callback(result) }
        } } catch(failure: RejectedExecutionException) { if(!closed) callback(Result.failure(failure)) }
    }
    fun begin(linkId: String, journeyType: String = "PICKUP", institutionType: String = "ACADEMY", serviceArea: String = "SEOUL"): String {
        check(!closed); return outbox.begin(linkId, journeyType, institutionType, serviceArea)
    }
    fun enqueue(type: String, etaMin: Int? = null, arrivalSpotEvidence: JSONObject? = null) { check(!closed); outbox.event(type, etaMin, arrivalSpotEvidence); status("전송 대기") }
    fun finishLocal() = outbox.finishLocal()
    fun hasPending() = outbox.pending() > 0
    fun quarantineForRePairing(callback: (Result<Int>) -> Unit) {
        try {
            worker.execute {
                val result = runCatching { outbox.quarantineForRePairing(if (configurationChanged) "LINK_CONFIGURATION_CHANGED" else "CAR_AUTHORIZATION_REVOKED") }
                synchronized(callbacksLock) { if (!closed) callback(result) }
            }
        } catch (failure: RejectedExecutionException) { if (!closed) callback(Result.failure(failure)) }
    }
    private fun checkAuthorization(failure: Throwable) {
        if (failure !is ApiFailure || failure.status != 401) return
        authorizationLost = true
        socket?.cancel(); socket=null
        synchronized(callbacksLock) { if (!closed) onAuthorizationLost() }
    }
    private fun notifyConfigurationChanged() {
        configurationChanged = true
        socket?.cancel(); socket=null
        synchronized(callbacksLock) { if (!closed && !conflictNotified) { conflictNotified=true; onConfigurationChanged() } }
    }
    private fun sync() {
        if (closed || authorizationLost) return
        if (configurationChanged) {
            notifyConfigurationChanged()
            status("연결 설정 변경 · P단 주차 후 다시 연결해 주세요")
            return
        }
        if (nowMillis() >= nextAttempt) {
            try {
                // A large/rejected queue must not starve release/cancellation polling.
                val batchStarted = nowMillis()
                var count = 0
                while (!closed && count < 4 && outbox.drainOne()) {
                    count++
                    if (nowMillis() - batchStarted >= 1_000) break
                }
                failures = 0
                sendError = null
            } catch (error: Exception) {
                if (error is ConfigurationChangedFailure) {
                    notifyConfigurationChanged()
                    status("연결 설정 변경 · P단 주차 후 다시 연결해 주세요")
                    return
                }
                checkAuthorization(error)
                if (authorizationLost) { status("차량 연결이 만료되어 다시 연결해야 해요"); return }
                failures = (failures + 1).coerceAtMost(6)
                nextAttempt = nowMillis() + (1L shl failures) * 1000
                sendError = "전송 대기 · ${error.message.orEmpty().take(80)}"
            }
        }
        if (closed) return
        if(!liveConfirmationPending && nowMillis()-lastChildLivePoll>=2_000) { readChildLive() }
        if(nowMillis()-lastOperationsPoll>=10_000) { lastOperationsPoll=nowMillis(); readOperations() }
        var receiveError: String? = null
        try {
            val tripId = outbox.activeServerId()
            if (tripId == null) {
                socket?.close(1000, "trip ended"); socket = null; socketTrip = null
            } else {
                if (socketTrip != tripId || socket == null) connectSocket(tripId)
                // Poll even when the socket appears alive: half-open connections can be silent.
                if (nowMillis() - lastPoll >= 10_000) {
                    lastPoll = nowMillis()
                    val receivedTrip = outbox.request("GET", "/api/trips/$tripId").getJSONObject("trip")
                    trip(receivedTrip)
                }
            }
        } catch (error: Exception) {
            checkAuthorization(error)
            if (authorizationLost) { status("차량 연결이 만료되어 다시 연결해야 해요"); return }
            receiveError = "수신 연결 대기 · ${error.message.orEmpty().take(80)}"
        }
        status(sendError ?: receiveError ?: if (outbox.pending() > 0) "전송 대기" else "서버 연결됨")
    }
    private fun connectSocket(tripId: String) {
        if (closed) return
        socket?.close(1000, "reconnect")
        if (socketTrip != tripId) lastPoll = 0L
        socketTrip = tripId
        val wsUrl = baseUrl.replaceFirst("https://", "wss://").replaceFirst("http://", "ws://").trimEnd('/') + "/ws/car/$tripId"
        socket = client.newWebSocket(Request.Builder().url(wsUrl).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (closed) webSocket.cancel()
                else webSocket.send(JSONObject().put("type", "AUTH").put("token", token).toString())
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                if (closed || webSocket !== socket) return
                runCatching {
                    val message = JSONObject(text)
                    if (message.optString("type") == "TRIP") {
                        trip(message.getJSONObject("trip"))
                    }
                }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { disconnected(webSocket) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { if (code == 4401) checkAuthorization(ApiFailure(401,"차량 연결이 갱신됐어요")); disconnected(webSocket) }
            private fun disconnected(ws: WebSocket) { if (socket === ws) socket = null }
        })
    }
    private fun nowMillis() = System.nanoTime() / 1_000_000
    private fun status(message: String) {
        val count = outbox.pending()
        synchronized(callbacksLock) { if (!closed) onStatus(message, count) }
    }
    private fun trip(value: JSONObject) {
        // A response already in flight may belong to the previous trip on this repository.
        if (value.optString("id") != outbox.activeServerId()) return
        synchronized(callbacksLock) { if (!closed) onTrip(value) }
    }
    override fun close() {
        synchronized(callbacksLock) { closed = true }
        socket?.cancel(); socket = null
        worker.shutdownNow()
        client.dispatcher.cancelAll()
        client.dispatcher.executorService.shutdown()
        client.connectionPool.evictAll()
    }
}
