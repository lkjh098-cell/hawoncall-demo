package ai.hawoncall.car

import android.app.Application
import android.os.SystemClock
import ai.hawoncall.car.voice.*
import androidx.compose.runtime.*
import ai.hawoncall.car.network.CarRepository
import ai.hawoncall.car.network.CarPairingClient
import ai.hawoncall.car.network.CarPairingPolicy
import ai.hawoncall.car.platform.*
import ai.hawoncall.core.*
import kotlinx.coroutines.*
import org.json.JSONObject
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale

class CarSession(private val application: Application) : SignalListener {
    private val app = application
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var tickJob: Job? = null
    private var uiVisible = false
    private var trackingRequested = false
    private var boundRouteKey = ""
    private var navigationObservedAt = 0L
    var navigation by mutableStateOf(NavigationStatus()); private set
    private val prefs = app.getSharedPreferences("car-settings", 0)
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val learning = PreferenceLearningStore(prefs)
    private var platform: PlatformSignals? = null
    private var repository: CarRepository? = null
    private var connectionGeneration = 0
    private data class PendingConfiguration(val generation: Int, val identity: String, val link: JSONObject)
    private var pendingConfiguration: PendingConfiguration? = null
    private var voice: BriefingVoice? = null
    var voiceStatus by mutableStateOf("P단에서 음성 사용을 켜 주세요"); private set
    var voiceEnabled by mutableStateOf(false); private set
    var operations by mutableStateOf<OperationSnapshot?>(null); private set
    var operationsError by mutableStateOf(""); private set
    var operationsBusy by mutableStateOf(false); private set
    var operationsNotice by mutableStateOf(""); private set
    private var operationsReceivedAt=0L
    private var operationsClock by mutableLongStateOf(SystemClock.elapsedRealtime())
    private var pendingIssue: Pair<String,String>?=null
    private var voiceIdentity=""
    private var explicitlyBoarded=false
    private var outboundOffered=false
    private var afterBoardingOffered=false
        private val playedBriefings=mutableSetOf<String>()
    private var engine: PickupEngine? = null
    private var ticker = 0
    private var persistedLog = ""
    private var capabilities = true to true
    private val doorBaselines = mutableMapOf<RearSide, Boolean>()
    private val occupancyBaselines = mutableMapOf<RearSide, Boolean>()
    private val beltBaselines = mutableMapOf<RearSide, Boolean>()
    private var sequence: Job? = null
    var baseUrl by mutableStateOf(prefs.getString("baseUrl", if (BuildConfig.DEBUG) "http://10.0.2.2:3000" else "").orEmpty()); private set
    var pairingBusy by mutableStateOf(false); private set
    var pairingAwaitingPark by mutableStateOf(prefs.getString("pendingPairingToken", "").orEmpty().isNotBlank()); private set
    var linked by mutableStateOf(false); private set
    var configurationVerified by mutableStateOf(false); private set
    var authorizationLost by mutableStateOf(prefs.getBoolean("authorizationLost", false)); private set
    var configurationChanged by mutableStateOf(prefs.getBoolean("configurationChanged", false)); private set
    val recoveryRequired get() = authorizationLost || configurationChanged
    var recoveryBusy by mutableStateOf(false); private set
    var childName by mutableStateOf(""); private set
    var academyName by mutableStateOf("기관 연결을 기다리고 있어요"); private set
    var timetable by mutableStateOf(""); private set
    var settingsVisible by mutableStateOf(false); private set
    var restricted by mutableStateOf(!BuildConfig.SIMULATED_SIGNALS); private set
    var gear by mutableStateOf(Gear.UNKNOWN); private set
    var snapshot by mutableStateOf<PickupSnapshot?>(null); private set
    var connection by mutableStateOf("서버 연결 전"); private set
    var platformStatus by mutableStateOf("차량 신호 확인 중"); private set
    var releasedAt by mutableStateOf(""); private set
    var error by mutableStateOf(""); private set
    var pending by mutableIntStateOf(0); private set
    var logs by mutableStateOf(listOf<String>()); private set
    var doorOpen by mutableStateOf(false); private set
    var occupied by mutableStateOf(false); private set
    var sensorsAvailable by mutableStateOf(true); private set
    var nextName by mutableStateOf(prefs.getString("nextName", "집").orEmpty()); private set
    var navigationDemo by mutableStateOf(BuildConfig.DEBUG && !BuildConfig.SIMULATED_SIGNALS && prefs.getBoolean("navigationDemo",false)); private set
    var routeStatus by mutableStateOf(""); private set
    var institutionTrackingSuspended by mutableStateOf(false); private set
    val canResumeInstitutionTracking get() = parked && institutionTrackingSuspended && !recoveryRequired && navigation.verified && navigation.active && navigation.academyMatched && !navigation.childLiveTarget
    fun resumeInstitutionTracking() {
        if(!canResumeInstitutionTracking) return
        boundRouteKey=navigation.routeKey
        engine?.resumeInstitutionNavigation(); institutionTrackingSuspended=false
        liveRouteMessage="기관 경로를 다시 확인했어요. 새 차량 위치로 도착 여부를 확인해요."
        collect()
    }
    var childLive by mutableStateOf<ChildLiveSnapshot?>(null); private set
    var childLiveError by mutableStateOf(""); private set
    var liveRouteBusy by mutableStateOf(false); private set
    var liveRouteMessage by mutableStateOf(""); private set
    var liveTargetObservedAt by mutableStateOf(""); private set
    val childFixFresh get(): Boolean { val clock=operationsClock; return childLive?.usable(SystemClock.elapsedRealtime())==true && configurationVerified && !recoveryRequired }
    val canRouteToChild get() = parked && uiVisible && !isDropoff && linked && configurationVerified && !recoveryRequired && childFixFresh && !liveRouteBusy && !pairingAwaitingPark
    fun childFixAgeSeconds(): Long? { val clock=operationsClock; return childLive?.ageMillis(SystemClock.elapsedRealtime())?.div(1000) }
    fun requestLiveMeetingDestination(frozen: ChildLiveSnapshot) {
        if(!canRouteToChild || !LiveMeetingRoutePolicy.allowed(frozen,childLive,parked,!isDropoff,configurationVerified && !recoveryRequired,SystemClock.elapsedRealtime())) return
        val repo=repository ?: return
        val generation=connectionGeneration
        liveRouteBusy=true; liveRouteMessage="아이 위치와 공유 권한을 다시 확인 중이에요"
        // Re-authorize at confirmation, while retaining the point the user reviewed.
        repo.refreshChildLive { result -> main {
            if(generation!=connectionGeneration) return@main
            val authenticated=result.getOrNull()
            if(!uiVisible || !LiveMeetingRoutePolicy.allowed(frozen,authenticated,parked,!isDropoff,configurationVerified && !recoveryRequired,SystemClock.elapsedRealtime())) {
                liveRouteBusy=false; liveRouteMessage="공유 권한이나 최근 위치가 바뀌었어요. 아이 위치를 다시 확인해 주세요."; return@main
            }
            val signals=platform
            if(signals==null) { liveRouteBusy=false; liveRouteMessage="내비 연결을 확인해 주세요."; return@main }
            // An advisory phone target cannot retain the institution-arrival/boarding lease.
            boundRouteKey=""
            pointDwell.pause(SystemClock.elapsedRealtime()); fusedPosition=null; fusedPositionReceivedAt=0
            if(active) { institutionTrackingSuspended=true; mutate { suspendForAdvisoryNavigation() } }
            liveTargetObservedAt=frozen.fix?.observedAt.orEmpty()
            signals.requestLiveMeetingDestination(frozen) { response -> main {
                if(generation!=connectionGeneration) return@main
                liveRouteMessage=response.message
                liveRouteBusy=response.state==LiveRouteState.REQUESTED
            } }
        } }
    }
    private var linkId = ""
    private var currentClientTripId = ""
    
    private var initialDuration = 300L
    private var storedLink: JSONObject? = null
    private data class PendingServerEvent(val effect: PickupEffect.ServerEvent, val arrivalSpotEvidence: JSONObject?)
    private val serverEffects = java.util.ArrayDeque<PendingServerEvent>()
    private var fusedPosition: FusedPositionObservation? = null
    private var fusedPositionReceivedAt = 0L
    private var pointArrivalEvidenceQueued = false
    private val pointDwell=SpotDwellTracker()
    var pickupSoon by mutableStateOf(false); private set
    var institutionType by mutableStateOf(InstitutionType.ACADEMY); private set
    var journeyType by mutableStateOf(JourneyType.PICKUP); private set
    val journeyLabel get() = institutionType.journeyLabel(journeyType)
    val isDropoff get() = journeyType == JourneyType.DROPOFF
    val authorizedPickupSpot get() = storedLink?.let(::authorizedSpot)
    private fun updateSchedule() {
        val link = storedLink ?: return
        val now = LocalDateTime.now()
        val time = runCatching { LocalTime.parse(link.optString("pickupTime","21:50")) }.getOrDefault(LocalTime.of(21,50))
        val days = link.optJSONArray("weekday")
        val weekdays = if (days==null) emptySet() else (0 until days.length()).map { days.optInt(it) }.toSet()
        val next = (0L..7L).map { LocalDateTime.of(now.toLocalDate().plusDays(it),time) }.firstOrNull { it.dayOfWeek.value in weekdays && !it.isBefore(now) }
        if (next==null) { timetable="시간표를 확인해 주세요"; pickupSoon=false; return }
        val minutes=Duration.between(now,next).toMinutes()
        pickupSoon=minutes in 0..30
        val day=if(next.toLocalDate()==now.toLocalDate()) "오늘" else next.format(DateTimeFormatter.ofPattern("M월 d일 E요일",Locale.KOREAN))
        timetable="$day ${time.format(DateTimeFormatter.ofPattern("HH:mm"))} $journeyLabel" + if(pickupSoon) " · 30분 이내" else ""
    }
    private fun academyDestination() = Destination(prefs.getString("academyNavName", "").orEmpty().ifBlank { academyName },
        prefs.getString("academyLat", "")?.toDoubleOrNull() ?: Double.NaN,
        prefs.getString("academyLon", "")?.toDoubleOrNull() ?: Double.NaN,
        poiId=prefs.getString("academyPoiId", "").orEmpty(), poiSubId=prefs.getString("academyPoiSubId", "").orEmpty(), poiProvider=prefs.getString("academyPoiProvider", "").orEmpty())
    private fun nextDestination(): Destination? {
        val lat = prefs.getString("nextLat", "")?.toDoubleOrNull() ?: return null
        val lon = prefs.getString("nextLon", "")?.toDoubleOrNull() ?: return null
        return Destination(nextName, lat, lon)
    }
    val parked get() = !restricted && gear == Gear.PARK
    val active get() = snapshot?.state in setOf(PickupState.PLANNED,PickupState.EN_ROUTE,PickupState.CALLED,PickupState.APPROACHING,PickupState.ARRIVED,PickupState.BOARDING_DETECTED,PickupState.BOARDED)
    val guardianConfirmEnabled get() = parked && !institutionTrackingSuspended && !recoveryRequired && (snapshot?.canConfirmBoarding == true || snapshot?.canConfirmHandoff == true)
    val stopLocationFresh get() = !institutionTrackingSuspended && (snapshot?.canConfirmBoarding == true || snapshot?.canConfirmHandoff == true)
    val canBindCurrentDestination get() = parked && linked && configurationVerified && !pairingAwaitingPark && !active && pending==0 && navigation.active && navigation.verified && !navigation.childLiveTarget &&
        navigation.destinationLatitude?.isFinite()==true && navigation.destinationLongitude?.isFinite()==true
    val settingsAllowed get() = parked && !recoveryRequired && !active && pending == 0
    val recoveryAllowed get() = parked && recoveryRequired && !pairingBusy && !recoveryBusy
    private fun configurationAllowed() = settingsAllowed && !pairingBusy
    init {
        // V0.3 real build observes OEM navigation. Legacy navigation-only fake mode is retired.
        prefs.edit().putBoolean("navigationDemo",false).apply()
        navigationDemo=false
        platform = createPlatformSignals(app, academyDestination()).also { it.connect(this) }
        runCatching { val history=org.json.JSONArray(prefs.getString("transitionLog","[]")); logs=(0 until history.length()).map { history.getString(it) } }
        val token = prefs.getString("token", "").orEmpty()
        if (token.isNotBlank() && !pairingAwaitingPark) connect(baseUrl, token)
        startTicker()
    }
    private fun startTicker() {
        if (tickJob?.isActive==true) return
        tickJob=scope.launch {
            while (isActive) {
                delay(250)
                if (navigation.verified && SystemClock.elapsedRealtime()-navigationObservedAt>15_000) {
                    navigation=navigation.copy(verified=false,remainingSeconds=null,message="내비 신호 갱신을 기다려요")
                }
                engine?.tick(); collect()
                if (++ticker % 20 == 0) platform?.pollNavigation()
                if (ticker % 4 == 0) {
                    operationsClock=SystemClock.elapsedRealtime()
                    updateSchedule()
                    if (BuildConfig.SIMULATED_SIGNALS && navigation.active) navigationObservedAt=SystemClock.elapsedRealtime()
                    if (BuildConfig.SIMULATED_SIGNALS && active && gear==Gear.PARK && snapshot?.state in setOf(PickupState.ARRIVED,PickupState.BOARDING_DETECTED)) engine?.locationDistanceUpdated(35.0)
                }
                maybeStopTracking()
            }
        }
    }
    fun onUiVisible() {
        uiVisible=true
        if (platform==null) platform=createPlatformSignals(application,academyDestination()).also { it.connect(this) }
        if (repository==null && !pairingAwaitingPark) prefs.getString("token","")?.takeIf { it.isNotBlank() }?.let { connect(baseUrl,it) }
        startTicker()
    }
    fun onUiHidden() { uiVisible=false; childLive=null; releaseIdleResources() }
    private fun releaseIdleResources() {
        if (uiVisible || pairingBusy || recoveryBusy || recoveryRequired || active || pending>0 || serverEffects.isNotEmpty()) return
        voice?.release(); voice=null
        platform?.close(); platform=null
        gear=Gear.UNKNOWN; restricted=!BuildConfig.SIMULATED_SIGNALS
        repository?.close(); repository=null
        tickJob?.cancel();tickJob=null
        navigation=navigation.copy(connected=false,verified=false,remainingSeconds=null,message="차내 화면 복귀 후 내비 상태를 다시 확인해요")
    }
    private fun beginTracking(): Boolean = try {
        application.startForegroundService(android.content.Intent(application,PickupTrackingService::class.java))
        trackingRequested=true; true
    } catch (failure: Exception) {
        error="픽업 지속 실행을 시작하지 못했어요. 차량 위치 권한을 확인해 주세요."
        false
    }
    private fun maybeStopTracking() {
        if (trackingRequested && !active && pending==0 && serverEffects.isEmpty()) {
            trackingRequested=false
            application.stopService(android.content.Intent(application,PickupTrackingService::class.java))
            releaseIdleResources()
        }
    }
    fun onTrackingServiceEnded() {
        if (trackingRequested && active) {
            trackingRequested=false
            mutate { cancel("tracking_service_ended") }
            error="픽업 지속 실행이 종료되어 인계 자동 처리를 멈췄어요"
        }
    }
    fun bindCurrentDestination() {
        if (!canBindCurrentDestination) return
        val current=navigation
        prefs.edit().putString("academyNavName",current.destinationName).putString("academyBindingCode",storedLink?.optString("academyCode").orEmpty()).putString("academyLat",current.destinationLatitude.toString()).putString("academyLon",current.destinationLongitude.toString())
            .putString("academyPoiId",current.poiId).putString("academyPoiSubId",current.poiSubId).putString("academyPoiProvider",current.poiProvider).apply()
        routeStatus="현재 목적지를 ${institutionType.label}에 연결했어요 · 기존 경로는 그대로 유지해요"
        refreshPlatform()
    }
    fun openNavigation() {
        if (!parked) return
        platform?.openNavigation()
    }

    fun refreshPlatform() {
        if (active) mutate { cancel("vehicle_reconnected") }
        doorBaselines.clear(); occupancyBaselines.clear(); beltBaselines.clear()
        fusedPosition=null
        gear=Gear.UNKNOWN; restricted=!BuildConfig.SIMULATED_SIGNALS
        platform?.close(); platform=createPlatformSignals(application,academyDestination()).also { it.connect(this) }
    }
    fun showSettings() { if (configurationAllowed()) settingsVisible = true }
    fun hideSettings() { settingsVisible = false }
    fun saved(key: String, fallback: String = "") = prefs.getString(key, fallback).orEmpty()
    fun pairWithMobile(url: String, code: String) {
        if (!configurationAllowed()) return
        if (pairingAwaitingPark) { error = "저장된 차량 연결을 먼저 마무리해 주세요"; return }
        val server = CarPairingPolicy.serverUrl(url, BuildConfig.DEBUG)
        if (server == null) { error = "올바른 HTTPS 서버 주소를 입력해 주세요"; return }
        val normalizedCode = CarPairingPolicy.code(code)
        if (normalizedCode == null) { error = "휴대폰에 표시된 연결 코드 8자리를 확인해 주세요"; return }
        error = ""
        pairingBusy = true
        scope.launch {
            try {
                // Recheck PARK + UX + trip/outbox immediately before issuing the one-use claim.
                if (!settingsAllowed) return@launch
                val response = withContext(Dispatchers.IO) { CarPairingClient().claim(server, normalizedCode) }
                // The one-use claim rotates credentials. Persist it even if PARK/UX changed in flight.
                // These are staged secrets only; they do not change the active vehicle configuration.
                withContext(Dispatchers.IO) {
                    check(prefs.edit().putString("pendingPairingServer", server)
                        .putString("pendingPairingToken", response.getString("carToken"))
                        .putString("pendingPairingLink", response.getJSONObject("link").toString()).commit()) {
                        "차량 연결을 저장하지 못했어요. 휴대폰에서 새 코드를 발급해 주세요"
                    }
                }
                pairingAwaitingPark = true
                if (settingsAllowed) activatePendingPairing()
                else error = "연결 코드를 안전하게 보관했어요. P단 주차 후 연결을 마무리해 주세요"
            } catch (failure: Exception) {
                if (failure is CancellationException) throw failure
                error = failure.message?.takeIf { failure is IllegalStateException }
                    ?: "연결하지 못했어요. 서버 주소와 네트워크를 확인해 주세요"
            } finally {
                pairingBusy = false
                applyConfigurationIfSafe()
                releaseIdleResources()
            }
        }
    }
    fun recoverRevokedConnection() {
        if (!recoveryAllowed) return
        val oldRepository=repository ?: return
        val generation=connectionGeneration
        recoveryBusy=true
        oldRepository.quarantineForRePairing { result -> main {
            recoveryBusy=false
            if (generation != connectionGeneration) return@main
            result.onSuccess {
                if (!parked) { error="이전 기록을 보관했어요. P단 주차 후 다시 연결을 눌러 주세요"; return@onSuccess }
                ++connectionGeneration
                oldRepository.close(); repository=null
                prefs.edit().remove("token").remove("link").remove("linkIdentity")
                    .remove("academyBindingCode").remove("academyLat").remove("academyLon").remove("academyNavName")
                    .remove("academyPoiId").remove("academyPoiSubId").remove("academyPoiProvider")
                    .putBoolean("authorizationLost",false).putBoolean("configurationChanged",false).apply()
                engine=null; snapshot=null; serverEffects.clear(); pending=0
                currentClientTripId=""; boundRouteKey=""; pendingConfiguration=null
                authorizationLost=false; configurationChanged=false; linked=false; configurationVerified=false
                navigation=navigation.copy(academyMatched=false)
                trackingRequested=false
                application.stopService(android.content.Intent(application,PickupTrackingService::class.java))
                connection="이전 전송 기록 보관됨 · 새 차량 연결 대기"
                error=""; settingsVisible=true
            }.onFailure { error="이전 전송 기록을 안전하게 보관하지 못했어요. 다시 시도해 주세요" }
        } }
    }
    fun finishPendingPairing() {
        if (!configurationAllowed() || !pairingAwaitingPark) return
        activatePendingPairing()
    }
    private fun activatePendingPairing() {
        // No credential activation, academy reconfiguration or binding is allowed while driving.
        if (!settingsAllowed || !pairingAwaitingPark) return
        val server = prefs.getString("pendingPairingServer", "").orEmpty()
        val token = prefs.getString("pendingPairingToken", "").orEmpty()
        val link = runCatching { JSONObject(prefs.getString("pendingPairingLink", "").orEmpty()) }.getOrNull()
        if (CarPairingPolicy.serverUrl(server, BuildConfig.DEBUG) == null || token.isBlank() || link == null) {
            error = "저장된 차량 연결을 확인할 수 없어요"; return
        }
        prefs.edit().putString("baseUrl", server).putString("token", token).putBoolean("authorizationLost",false).putBoolean("configurationChanged",false)
            .remove("link").remove("linkIdentity").remove("academyBindingCode")
            .remove("academyLat").remove("academyLon").remove("academyNavName")
            .remove("academyPoiId").remove("academyPoiSubId").remove("academyPoiProvider")
            .remove("pendingPairingServer").remove("pendingPairingToken").remove("pendingPairingLink").apply()
        pairingAwaitingPark = false
        authorizationLost = false
        configurationChanged = false
        baseUrl = server
        navigation = navigation.copy(academyMatched = false)
        settingsVisible = false
        error = ""
        applyLink(link)
        connect(server, token)
    }
    fun saveSettings(url: String, token: String, academyLat: String, academyLon: String, name: String, nextLat: String, nextLon: String, navigationDemo: Boolean = false) {
        if (!configurationAllowed()) return
        val normalizedUrl=CarPairingPolicy.serverUrl(url, BuildConfig.DEBUG)
        if (normalizedUrl == null) {
            error = "HTTPS 주소를 입력하세요. 디버그 빌드는 로컬 3000번 포트도 사용할 수 있어요."; return
        }
        if (token.isBlank()) { error = "부모 등록 화면에서 발급한 차량 연결 토큰을 입력하세요"; return }
        fun valid(lat: String, lon: String) = lat.toDoubleOrNull()?.let { it in -90.0..90.0 } == true && lon.toDoubleOrNull()?.let { it in -180.0..180.0 } == true
        if (!valid(academyLat, academyLon) || ((nextLat.isNotBlank() || nextLon.isNotBlank()) && !valid(nextLat,nextLon))) {
            error = "목적지 위도·경도를 확인하세요"; return
        }
        prefs.edit().putString("baseUrl",normalizedUrl).putString("token",token.trim())
            .putString("academyLat",academyLat).putString("academyLon",academyLon).putString("nextName",name.ifBlank { "다음 목적지" })
            .putString("nextLat",nextLat).putString("nextLon",nextLon).putBoolean("navigationDemo",false).apply()
        // Manual coordinate editing invalidates any earlier POI/name binding.
        prefs.edit().remove("academyNavName").remove("academyPoiId").remove("academyPoiSubId").remove("academyPoiProvider").apply()
        baseUrl = normalizedUrl; nextName = name.ifBlank { "다음 목적지" }; this.navigationDemo=false
        settingsVisible = false; error = ""
        connect(baseUrl,token.trim())
    }
    private fun connect(url: String, token: String) {
        val generation = ++connectionGeneration
        voice?.release(); voice=null; voiceEnabled=false; childLive=null; childLiveError=""; liveRouteBusy=false; liveRouteMessage=""; liveTargetObservedAt=""; operations=null; operationsReceivedAt=0; pendingIssue=null
        val identity = java.security.MessageDigest.getInstance("SHA-256").digest((url+"|"+token).toByteArray()).joinToString("") { "%02x".format(it) }
        voiceIdentity=identity
        voiceEnabled=prefs.getBoolean("briefing-$identity",false)
        val cacheMatches = prefs.getString("linkIdentity", "") == identity
        linked=false; configurationVerified=false; storedLink=null; linkId=""; pendingConfiguration=null
        repository?.close()
        repository = CarRepository(prefs,url,token, { status,count -> main { if (generation==connectionGeneration) { connection=status; pending=count + serverEffects.size; applyConfigurationIfSafe() } } }, { trip -> main {
            if (generation!=connectionGeneration || trip.optString("clientTripId")!=currentClientTripId) return@main
            releasedAt = trip.optString("releasedAt").takeUnless { it == "null" }.orEmpty()
            if (trip.optString("status") in listOf("CANCELLED","CANCEL") && active) mutate { cancel("academy_cancelled") }
        } }, { main {
            if (generation != connectionGeneration) return@main
            voice?.stop(); authorizationLost=true; configurationVerified=false; linked=false
            prefs.edit().putBoolean("authorizationLost",true).apply()
            mutate { cancel("car_authorization_revoked") }
            error="차량 연결이 갱신됐어요. 주차 후 다시 연결해 주세요"
        } }, { main {
            if (generation != connectionGeneration) return@main
            voice?.stop(); configurationChanged=true; configurationVerified=false; linked=false
            prefs.edit().putBoolean("configurationChanged",true).apply()
            mutate { cancel("link_configuration_changed") }
            error="기관·등하원 설정이 변경됐어요. P단 주차 후 이전 기록을 보관하고 다시 연결해 주세요"
        } }, { result -> main {
            if(generation!=connectionGeneration) return@main
            result.onSuccess { operations=it; operationsReceivedAt=SystemClock.elapsedRealtime(); operationsClock=operationsReceivedAt; operationsError="" }
                .onFailure { operationsError="기관·일정 정보 수신 실패 · 마지막 정보의 최신 여부를 확인하세요." }
        } }, { result -> main {
            if(generation!=connectionGeneration) return@main
            result.onSuccess { childLive=it; childLiveError="" }.onFailure { childLive=null; childLiveError="아이 위치 수신 실패 · 최근 위치를 다시 확인해 주세요" }
        } })
        val cached = prefs.getString("link", "").orEmpty()
        if (!recoveryRequired && cacheMatches && cached.isNotBlank()) runCatching { applyLink(JSONObject(cached)) }
        repository?.loadConfig { result -> main {
            if (generation!=connectionGeneration) return@main
            result.onSuccess { response ->
                val link = response.optJSONObject("link")
                if (link == null || !validLink(link)) {
                    configurationVerified=false; linked=false; error="차량 연결 응답을 확인할 수 없어요"
                } else {
                    pendingConfiguration=PendingConfiguration(generation,identity,link)
                    applyConfigurationIfSafe()
                }
            }.onFailure { configurationVerified=false; linked=false; error = "연결 확인 실패: ${it.message}" }
        } }
    }
    private fun applyConfigurationIfSafe() {
        val configuration = pendingConfiguration ?: return
        if (configuration.generation != connectionGeneration || !configurationAllowed() || pairingAwaitingPark) return
        pendingConfiguration = null
        prefs.edit().putString("link",configuration.link.toString()).putString("linkIdentity",configuration.identity).apply()
        applyLink(configuration.link)
        configurationVerified=true
        error=""
        refreshPlatform()
        if(voiceEnabled && parked) ensureVoice()
    }
    private fun validLink(link: JSONObject): Boolean = runCatching {
        require(listOf("id", "childName", "academyName", "academyCode").all { link.optString(it).isNotBlank() })
        InstitutionType.valueOf(link.optString("institutionType", "ACADEMY"))
        JourneyType.valueOf(link.optString("journeyType", "PICKUP"))
        require(link.optString("serviceArea", "SEOUL") == "SEOUL")
        true
    }.getOrDefault(false)
    private fun authorizedSpot(link: JSONObject): PickupSpot? = runCatching {
        val value = link.optJSONObject("pickupSpot") ?: return null
        require(value.optString("serviceArea") == "SEOUL" && value.optString("state") == "VERIFIED" && value.optBoolean("eligible"))
        require(Instant.parse(value.getString("permissionExpiresAt")).isAfter(Instant.now()))
        PickupSpot(value.getString("id"), value.getString("name"), value.getDouble("latitude"), value.getDouble("longitude"))
    }.getOrNull()
    private fun applyLink(link: JSONObject) {
        require(validLink(link)) { "서울 기관 연결 설정을 확인해 주세요" }
        // Active trips are frozen; pending config must wait until the trip and its outbox end.
        check(!active)
        engine=null; snapshot=null; institutionTrackingSuspended=false
        institutionType=InstitutionType.valueOf(link.optString("institutionType", "ACADEMY"))
        journeyType=JourneyType.valueOf(link.optString("journeyType", "PICKUP"))
        storedLink=JSONObject(link.toString()); linkId=link.getString("id"); childName=link.getString("childName")
        if (prefs.getString("academyBindingCode", "").orEmpty() != link.optString("academyCode")) {
            prefs.edit().remove("academyNavName").remove("academyPoiId").remove("academyPoiSubId").remove("academyPoiProvider").apply()
        }
        academyName=link.getString("academyName"); initialDuration=link.optLong("baseLeadSeconds",300)
        updateSchedule()
        linked=true
    }
    private fun newEngine(): PickupEngine {
        val plan = PickupPlan(linkId,childName,academyName,storedLink?.optString("academyCode","academy") ?: "academy",
            LocalDate.now().dayOfWeek.value, initialDuration, institutionType, journeyType, ServiceArea.SEOUL, authorizedPickupSpot)
        return PickupEngine(plan, ai.hawoncall.core.Clock { SystemClock.elapsedRealtime() }, learning).also {
            it.setCapabilities(capabilities.first,capabilities.second); it.gearChanged(gear)
            doorBaselines.forEach { (side, value) -> it.doorChanged(side,value) }
            occupancyBaselines.forEach { (side, value) -> it.occupancyChanged(side,value) }
            beltBaselines.forEach { (side, value) -> it.beltChanged(side,value) }
            // Demo baselines are explicit. Real baselines come exclusively from the adapters.
            if (BuildConfig.SIMULATED_SIGNALS) {
                it.occupancyChanged(RearSide.RIGHT,false); it.beltChanged(RearSide.RIGHT,false); it.doorChanged(RearSide.RIGHT,false)
            }
        }
    }
    fun start() {
        if(institutionTrackingSuspended) return
        if (!parked || !linked || !configurationVerified || active || pairingBusy || pairingAwaitingPark || pending > 0 || !navigation.active || !navigation.verified || !navigation.academyMatched || navigation.routeKey.isBlank()) return
        if (!beginTracking()) return
        runCatching {
            boundRouteKey=navigation.routeKey
            val frozenEngine=newEngine()
            val plan=frozenEngine.plan
            currentClientTripId=repository?.begin(plan.linkId,plan.journeyType.name,plan.institutionType.name,plan.serviceArea.name) ?: error("서버 연결이 필요해요")
            explicitlyBoarded=false; outboundOffered=false; afterBoardingOffered=false; releasedAt=""; error=""; pointArrivalEvidenceQueued=false; pointDwell.reset(); doorOpen=false; occupied=false; engine=frozenEngine; engine?.start(); navigation.remainingSeconds?.let { engine?.updateEta(it) }; collect(); offerBriefing("OUTBOUND")
        }.onFailure { error=it.message.orEmpty(); maybeStopTracking() }
    }
    fun cancel() { if (parked) mutate { cancel("parent_cancelled") } }
    fun confirm() {
        if(!guardianConfirmEnabled) return
        mutate { if(plan.journeyType==JourneyType.DROPOFF) confirmHandoff() else confirmBoarding() }
        if(!isDropoff && snapshot?.state==PickupState.BOARDED) { explicitlyBoarded=true; offerBriefing("AFTER_BOARDING") }
    }
    val operationsAgeMillis get() = if(operationsReceivedAt>0) operationsClock-operationsReceivedAt else Long.MAX_VALUE
    val operationsFresh get() = operationsReceivedAt>0 && operationsClock-operationsReceivedAt in 0..120_000
    fun refreshOperations() { if(parked && !recoveryRequired) repository?.refreshOperations() }
    fun updateVoiceEnabled(enabled: Boolean) {
        if(!parked || !linked || recoveryRequired) return
        voiceEnabled=enabled
        prefs.edit().putBoolean("briefing-$voiceIdentity",enabled).apply()
        if(enabled) ensureVoice() else { voice?.release(); voice=null; voiceStatus="음성 사용 꺼짐" }
    }
    private fun ensureVoice(): BriefingVoice? {
        if(voice==null && parked && voiceEnabled) voice=runCatching { createBriefingVoice(app) { value -> main { voiceStatus=value } } }.getOrElse { voiceStatus="음성 서비스를 사용할 수 없습니다. 차량 권한을 확인하세요."; null }
        return voice
    }
    fun stopBriefing() { if(parked) voice?.stop() }
    fun speakBriefing() { if(parked && voiceEnabled) { offerBriefing(if(explicitlyBoarded) "AFTER_BOARDING" else "OUTBOUND",true) } }
    private fun offerBriefing(phase: String,manual: Boolean=false) {
        if(!voiceEnabled || recoveryRequired || currentClientTripId.isBlank()) return
        if(!manual) {
            if(phase=="OUTBOUND") { if(outboundOffered) return; outboundOffered=true }
            else { if(afterBoardingOffered) return; afterBoardingOffered=true }
        }
        val plan=operations?.dayPlan ?: return
        val text=BriefingPolicy.text(plan,phase,journeyType,explicitlyBoarded,SystemClock.elapsedRealtime()-operationsReceivedAt) ?: run { voiceStatus="오늘 일정·음성 동의·최신 정보를 확인하세요."; return }
        val key=BriefingPolicy.onceKey(voiceIdentity,currentClientTripId,plan.serviceDate,phase)
        if(!manual && (key in playedBriefings || prefs.getBoolean("spoken-$key",false))) return
        val speaker=voice ?: ensureVoice()
        if(speaker?.speak(text)==true && !manual) { playedBriefings.add(key); prefs.edit().putBoolean("spoken-$key",true).apply() }
    }
    fun requestIssue(kind: String,message: String) {
        if(!parked || !linked || recoveryRequired || operationsBusy || !operationsFresh) return
        val trip=operations?.tripId ?: return
        if(kind !in setOf("NO_STOP_SPACE","CHILD_DELAYED","ALTERNATE_POINT_REQUEST","CANCEL_REQUEST","RUNNING_LATE") || message.length>240 || message.any { it<' ' || it=='<' || it=='>' }) return
        val fingerprint="$trip|$kind|$message"
        val id=pendingIssue?.takeIf { it.first==fingerprint }?.second ?: java.util.UUID.randomUUID().toString().also { pendingIssue=fingerprint to it }
        val generation=connectionGeneration
        operationsBusy=true; operationsNotice=""
        repository?.requestIssue(trip,id,kind,message) { result -> main {
            if(generation!=connectionGeneration) return@main
            operationsBusy=false
            result.onSuccess { pendingIssue=null; operationsNotice="기관에 요청을 전송했어요. 응답을 기다려 주세요."; repository?.refreshOperations() }
                .onFailure { operationsError="요청 전송을 확인하지 못했어요. 같은 내용으로 다시 시도할 수 있습니다." }
        } } ?: run { operationsBusy=false; operationsError="서버 연결을 확인하세요." }
    }
    fun simulateExistingRoute() {
        if (!BuildConfig.SIMULATED_SIGNALS || !parked || active) return
        val d=academyDestination().let { if (it.latitude.isFinite() && it.longitude.isFinite()) it else Destination(academyName,37.498,127.061) }
        onNavigationState(NavigationStatus(true,true,true,academyName,540,"demo-existing-academy","시연용 기존 내비 경로",true,d.latitude,d.longitude,"demo-academy","0","DEMO"))
        routeStatus="기존 경로 관찰 중 · 경로 요청 0회"
    }
    fun simulateNavigation() {
        if (!BuildConfig.SIMULATED_SIGNALS || !parked || !active) return
        sequence?.cancel()
        sequence=scope.launch {
            onGear(Gear.DRIVE);onUxRestricted(true);demoEta(540)
            delay(3000);demoEta(300)
            delay(3000);simulateApproach()
            // Remain DRIVE. Park is a separate simulated vehicle input.
        }
    }
    private fun demoEta(seconds: Long) {
        onNavigationState(navigation.copy(active=true,academyMatched=true,remainingSeconds=seconds,verified=true))
        onEta(seconds)
    }
    fun simulateApproach() {
        if (!BuildConfig.SIMULATED_SIGNALS || !active) return
        onNavigationState(navigation.copy(remainingSeconds=60,verified=true))
        onProximityEntered();onDistance(120.0)
    }
    fun simulatePark() {
        if (!BuildConfig.SIMULATED_SIGNALS || !active) return
        onGear(Gear.PARK);onUxRestricted(false);onDistance(35.0)
    }
    fun simulateRouteChange() {
        if (!BuildConfig.SIMULATED_SIGNALS || !parked) return
        onNavigationState(NavigationStatus(true,true,false,"다른 목적지",600,"demo-other-route","사용자가 다른 목적지를 선택했어요",true,37.5,127.1))
    }
    fun simulateDoor() { if (BuildConfig.SIMULATED_SIGNALS && parked) { doorOpen=!doorOpen; onDoor(RearSide.RIGHT,doorOpen) } }
    fun simulateOccupancy() { if (BuildConfig.SIMULATED_SIGNALS && parked) { occupied=!occupied; onOccupancy(RearSide.RIGHT,occupied) } }
    fun simulateNoSensors() {
        if (!BuildConfig.SIMULATED_SIGNALS || !parked || active) return
        sensorsAvailable=!sensorsAvailable; onCapabilities(sensorsAvailable,sensorsAvailable)
    }
    fun simulateDeparture() {
        if (!BuildConfig.SIMULATED_SIGNALS || snapshot?.state != PickupState.BOARDED) return
        onGear(Gear.DRIVE);onUxRestricted(true)
    }
    private fun mutate(action: PickupEngine.() -> Unit) = main { engine?.apply(action); collect() }
    private fun collect() {
        val current = engine ?: return
        for (effect in current.drainEffects()) when(effect) {
            is PickupEffect.ServerEvent -> {
                val evidence=if (effect.type in setOf(EventType.ARRIVED,EventType.BOARDED,EventType.HANDED_OVER))
                    arrivalSpotEvidence(current.plan,effect.type != EventType.ARRIVED) else null
                if (evidence != null && effect.type == EventType.ARRIVED) pointArrivalEvidenceQueued=true
                serverEffects.addLast(PendingServerEvent(effect,evidence))
                if (effect.type in setOf(EventType.BOARDED,EventType.HANDED_OVER,EventType.CANCEL)) pointDwell.pause(SystemClock.elapsedRealtime())
            }
            // Routine pickup speech never competes with OEM driving guidance.
            is PickupEffect.Speak -> Unit // State confirmation stays visual; never accepts a TTS response as confirmation.
            is PickupEffect.RequestRoute -> { error="자동 경로 변경을 차단했어요 · 순정 내비 경로를 유지해요" }
            is PickupEffect.StateChanged -> logs=(logs + "${LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))} ${effect.from} → ${effect.to}").takeLast(50)
            is PickupEffect.LearningUpdated -> logs=(logs + "다음 호출 준비시간 ${effect.previousSeconds}초 → ${effect.durationSeconds}초").takeLast(50)
            is PickupEffect.WaitingAlert -> Unit
        }
        while (serverEffects.isNotEmpty()) {
            val item=checkNotNull(serverEffects.peekFirst())
            val effect=item.effect
            val stored=runCatching { checkNotNull(repository).enqueue(effect.type.name,effect.etaMin,item.arrivalSpotEvidence) }
            if (stored.isFailure) { pending=(pending.coerceAtLeast(1)); error="전송 기록 저장 실패 · 자동 재시도 중: ${stored.exceptionOrNull()?.message}"; break }
            serverEffects.removeFirst()
        }
        snapshot=current.snapshot
        if(snapshot?.state in setOf(PickupState.CANCELLED,PickupState.DONE,PickupState.BOARDED,PickupState.HANDED_OVER)) institutionTrackingSuspended=false
        if (logs.isNotEmpty()) {
            val serialized=org.json.JSONArray(logs).toString()
            if (serialized!=persistedLog) { prefs.edit().putString("transitionLog",serialized).apply(); persistedLog=serialized }
        }
    }
    private fun arrivalSpotEvidence(plan: PickupPlan, includeWait: Boolean = false): JSONObject? {
        val elapsed=SystemClock.elapsedRealtime()
        fun absent(): JSONObject? { pointDwell.pause(elapsed); return null }
        if (institutionTrackingSuspended || BuildConfig.SIMULATED_SIGNALS || gear != Gear.PARK) return absent()
        val selected = authorizedPickupSpot?.takeIf { it == plan.pickupSpot } ?: return absent()
        val evidence=SpotArrivalEvidencePolicy.evidence(selected,fusedPosition,System.currentTimeMillis(),elapsed-fusedPositionReceivedAt) ?: return absent()
        val validFor=30_000-(System.currentTimeMillis()-evidence.observedAtMillis).coerceIn(0,30_000)
        pointDwell.observe(elapsed,true,validFor)
        val wait=pointDwell.seconds(elapsed)
        if (includeWait) {
            val maximum=storedLink?.optJSONObject("pickupSpot")?.optInt("maxDwellSeconds",0) ?: 0
            if (!pointArrivalEvidenceQueued || maximum !in 1..3600 || wait > maximum) return null
        }
        return JSONObject().put("spotId",evidence.spotId).put("observedAt",Instant.ofEpochMilli(evidence.observedAtMillis).toString())
            .put("distanceMeters",evidence.distanceMeters).put("source","PLEOS_FUSED_LOCATION").also {
                evidence.accuracyMeters?.let { accuracy -> it.put("accuracyMeters",accuracy) }
                if (includeWait) it.put("parkedWaitSeconds",wait)
            }
    }
    override fun onFusedPosition(position: FusedPositionObservation) = main {
        if (!BuildConfig.SIMULATED_SIGNALS) {
            fusedPosition=position; fusedPositionReceivedAt=SystemClock.elapsedRealtime()
            val current=engine
            if (!institutionTrackingSuspended && current?.state in setOf(PickupState.ARRIVED,PickupState.BOARDING_DETECTED)) {
                val evidence=arrivalSpotEvidence(checkNotNull(current).plan)
                if (!pointArrivalEvidenceQueued && evidence != null) {
                    pointArrivalEvidenceQueued=true
                    serverEffects.addLast(PendingServerEvent(PickupEffect.ServerEvent(EventType.ARRIVED,SystemClock.elapsedRealtime()),evidence))
                    collect()
                }
            }
        }
    }
    private fun main(action: () -> Unit) { if (android.os.Looper.myLooper()==android.os.Looper.getMainLooper()) action() else handler.post(action) }
    override fun onGear(gear: Gear) = main {
        if (gear != Gear.PARK) pointDwell.pause(SystemClock.elapsedRealtime())
        if (gear==Gear.UNKNOWN) {
            fusedPosition=null
            if (active) mutate { cancel("vehicle_signal_lost") }
            doorBaselines.clear(); occupancyBaselines.clear(); beltBaselines.clear()
        }
        this.gear=gear
        if (gear!=Gear.PARK) settingsVisible=false
        mutate { gearChanged(gear) }
        applyConfigurationIfSafe()
        if(parked && voiceEnabled) ensureVoice()
    }
    override fun onDoor(side: RearSide, open: Boolean) = main { doorBaselines[side]=open; mutate { doorChanged(side,open) } }
    override fun onOccupancy(side: RearSide, occupied: Boolean) = main { occupancyBaselines[side]=occupied; mutate { occupancyChanged(side,occupied) } }
    override fun onBelt(side: RearSide, buckled: Boolean) = main { beltBaselines[side]=buckled; mutate { beltChanged(side,buckled) } }
    override fun onCapabilities(occupancy: Boolean, belt: Boolean) = main { capabilities=occupancy to belt; mutate { setCapabilities(occupancy,belt) } }
    private fun boundNavigationFresh() = !institutionTrackingSuspended && PickupNavigationGate.boundFresh(navigation,boundRouteKey,SystemClock.elapsedRealtime()-navigationObservedAt)
    override fun onEta(seconds: Long) = main {
        if (boundNavigationFresh()) mutate { updateEta(seconds) }
    }
    override fun onNavigationState(state: NavigationStatus) = main {
        navigation=state
        navigationObservedAt=SystemClock.elapsedRealtime()
        if (!institutionTrackingSuspended && active && snapshot?.state != PickupState.BOARDED && state.verified && state.active && (!state.academyMatched || state.routeKey!=boundRouteKey)) {
            mutate { cancel("navigation_destination_changed") }
            routeStatus="순정 내비의 새 경로를 유지하고 픽업 연결을 종료했어요"
        }
    }
    override fun onArrived() = main { if (boundNavigationFresh()) mutate { destinationArrived() } }
    override fun onProximityEntered() = main { if (boundNavigationFresh()) mutate { proximityEntered() } }
    override fun onNavigationCancelled() { if(!institutionTrackingSuspended) mutate { cancel("navigation_cancelled") } }
    override fun onDestinationChanged(isAcademy: Boolean) = Unit // Observing a destination never starts or replaces a route.
    override fun onDistance(meters: Double) = main {
        // Once genuinely parked, fresh position can continue after OEM guidance ends on arrival.
        if (!institutionTrackingSuspended && PickupNavigationGate.positionAllowed(navigation,boundRouteKey,SystemClock.elapsedRealtime()-navigationObservedAt,snapshot?.state))
            mutate { locationDistanceUpdated(meters) }
    }
    override fun onUxRestricted(restricted: Boolean) = main { this.restricted=restricted; if (restricted) settingsVisible=false; applyConfigurationIfSafe() }
    override fun onStatus(message: String) = main { platformStatus=message }
    fun close() { sequence?.cancel(); platform?.close(); repository?.close(); voice?.release(); scope.cancel() }
}
