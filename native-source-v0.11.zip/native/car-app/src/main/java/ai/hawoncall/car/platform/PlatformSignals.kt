package ai.hawoncall.car.platform

import ai.hawoncall.core.Gear
import ai.hawoncall.core.RearSide
import java.io.Closeable

data class Destination(val name: String, val latitude: Double, val longitude: Double, val address: String = "",
    val poiId: String = "", val poiSubId: String = "", val poiProvider: String = "")
/** verified means a fresh internally-consistent observation, not independent business identity. */
data class NavigationStatus(
    val connected: Boolean = false, val active: Boolean = false, val academyMatched: Boolean = false,
    val destinationName: String = "", val remainingSeconds: Long? = null, val routeKey: String = "",
    val message: String = "", val verified: Boolean = false,
    val destinationLatitude: Double? = null, val destinationLongitude: Double? = null,
    val poiId: String = "", val poiSubId: String = "", val poiProvider: String = "",
    val childLiveTarget: Boolean = false,
)
interface SignalListener {
    fun onGear(gear: Gear)
    fun onDoor(side: RearSide, open: Boolean)
    fun onOccupancy(side: RearSide, occupied: Boolean)
    fun onBelt(side: RearSide, buckled: Boolean)
    fun onCapabilities(occupancy: Boolean, belt: Boolean)
    fun onEta(seconds: Long)
    /** Explicit OEM navigation arrival, distinct from a geofence. */
    fun onArrived()
    fun onProximityEntered() = Unit
    fun onNavigationState(state: NavigationStatus) = Unit
    fun onNavigationCancelled() { onDestinationChanged(false) }
    fun onDestinationChanged(isAcademy: Boolean)
    fun onFusedPosition(position: FusedPositionObservation) = Unit
    fun onDistance(meters: Double)
    fun onUxRestricted(restricted: Boolean)
    fun onStatus(message: String)
}
enum class LiveRouteState { REQUESTED, CONFIRMED, FAILED }
data class LiveRouteResult(val state: LiveRouteState, val message: String)
interface PlatformSignals : Closeable {
    fun connect(listener: SignalListener)
    /** Reserved for a separate explicit user-authorized action. Pickup flow never calls it. */
    fun route(destination: Destination)
    /** Separate explicit confirmed action. The generic observer route() remains inert. */
    fun requestLiveMeetingDestination(frozen: ai.hawoncall.core.ChildLiveSnapshot, onResult: (LiveRouteResult)->Unit) {
        onResult(LiveRouteResult(LiveRouteState.FAILED,"이 빌드에서 실제 내비 목적지를 변경할 수 없어요."))
    }
    fun openNavigation() = Unit
    fun pollNavigation()
}
