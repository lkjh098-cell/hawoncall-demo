package ai.hawoncall.car.platform

import ai.hawoncall.core.PickupState

object PickupNavigationGate {
    fun boundFresh(nav: NavigationStatus, boundKey: String, observationAgeMillis: Long) =
        !nav.childLiveTarget && nav.verified && nav.active && nav.academyMatched && boundKey.isNotBlank() &&
            nav.routeKey == boundKey && observationAgeMillis in 0..15_000
    fun positionAllowed(nav: NavigationStatus, boundKey: String, observationAgeMillis: Long, state: PickupState?) =
        !nav.childLiveTarget && (boundFresh(nav,boundKey,observationAgeMillis) || state in setOf(PickupState.ARRIVED,PickupState.BOARDING_DETECTED))
}
