package ai.hawoncall.car

import android.os.SystemClock
import ai.hawoncall.core.ChildLiveSnapshot
import ai.hawoncall.core.LiveMeetingRoutePolicy
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable internal fun CarChildLocationPanel(vm: CarSession) {
    if(vm.isDropoff || !vm.linked) return
    var frozen by remember { mutableStateOf<ChildLiveSnapshot?>(null) }
    val fresh=vm.childFixFresh
    val live=vm.childLive
    val age=vm.childFixAgeSeconds()
    val currentSession=live?.session?.id
    LaunchedEffect(vm.canRouteToChild,currentSession,fresh) {
        if(!vm.canRouteToChild || frozen?.session?.id!=currentSession) frozen=null
    }
    Card(Modifier.fillMaxWidth().padding(horizontal=24.dp,vertical=12.dp)) {
        Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Text("아이 휴대폰 위치 · 만날 곳 참고",fontSize=21.sp,fontWeight=FontWeight.Bold)
            Text(when {
                vm.childLiveError.isNotBlank() -> vm.childLiveError
                fresh -> "최근 ${age ?: 0}초 전 · 정확도 약 ${live?.fix?.accuracyMeters?.toInt()}m · 아이 휴대폰 GPS"
                live?.session?.status=="AWAITING_CHILD" -> "아이 휴대폰 연결 대기 · 보호자 앱의 아이 위치 코드를 입력해 주세요"
                live?.session?.status=="WAITING_FOR_FIX" -> "아이 휴대폰의 위치 공유 시작을 기다려요"
                live?.session?.status=="STALE" || live?.fix!=null -> "최근 위치가 오래되어 목적지로 사용할 수 없어요"
                else -> "공유 위치 없음 · 보호자 앱에서 아이 위치 공유를 연결해 주세요"
            },fontSize=15.sp)
            if(fresh) live?.fix?.let {
                Text(String.format(Locale.US,"최근 위치  %.5f, %.5f",it.latitude,it.longitude),fontSize=14.sp)
            }
            if(vm.liveTargetObservedAt.isNotBlank()) Text("요청한 목적지: ${fixTime(vm.liveTargetObservedAt)}의 아이 위치 · 이후 이동은 자동 반영하지 않아요",fontSize=14.sp)
            if(vm.institutionTrackingSuspended) {
                Text("아이 위치 길찾기 · 기관 픽업 자동처리 일시중지",fontSize=16.sp,fontWeight=FontWeight.Bold)
                if(vm.parked) {
                    Text("기관 픽업을 재개하려면 순정 내비에서 원래 기관 목적지를 설정한 뒤 경로를 다시 확인해 주세요.",fontSize=13.sp)
                    OutlinedButton(onClick=vm::resumeInstitutionTracking,enabled=vm.canResumeInstitutionTracking,
                        modifier=Modifier.fillMaxWidth().heightIn(min=56.dp)) { Text("원래 기관 경로 확인 후 픽업 재개") }
                }
            }
            if(vm.liveRouteMessage.isNotBlank()) Text(vm.liveRouteMessage,fontSize=15.sp)
            if(vm.parked) {
                Button(onClick={ if(vm.canRouteToChild) frozen=vm.childLive },enabled=vm.canRouteToChild,
                    modifier=Modifier.fillMaxWidth().heightIn(min=60.dp)) { Text(if(vm.liveRouteBusy) "내비 결과 확인 중" else "아이 위치로 길찾기",fontSize=18.sp) }
                Text("공유 위치는 정차 허가·차량 도착·탑승 증거가 아니에요. 안전한 정차 장소와 실제 아이를 직접 확인해 주세요.",fontSize=13.sp)
            }
        }
    }
    val selected=frozen
    if(selected!=null && vm.canRouteToChild) {
        val stillFresh=LiveMeetingRoutePolicy.allowed(selected,live,vm.parked,!vm.isDropoff,vm.configurationVerified && !vm.recoveryRequired,SystemClock.elapsedRealtime())
        if(stillFresh) AlertDialog(onDismissRequest={frozen=null},title={Text("아이 위치로 목적지를 바꿀까요?")},
            text={Text("${fixTime(selected.fix?.observedAt.orEmpty())}에 확인된 아이 위치 한 지점으로 순정 내비 목적지를 변경해요. 정확도는 약 ${selected.fix?.accuracyMeters?.toInt()}m예요.\n\n진행 중인 기관 픽업의 자동 처리를 일시중지하며 위치 공유는 유지됩니다. 아이의 이동에 따라 자동으로 다시 탐색하지 않으며, 이 위치에서의 정차나 탑승을 허가하지 않습니다.",fontSize=18.sp,lineHeight=28.sp)},
            confirmButton={TextButton(onClick={ val confirmed=frozen; frozen=null; if(confirmed!=null && vm.canRouteToChild) vm.requestLiveMeetingDestination(confirmed) },modifier=Modifier.heightIn(min=60.dp)) { Text("확인한 아이 위치로 변경",fontSize=17.sp) }},
            dismissButton={TextButton(onClick={frozen=null},modifier=Modifier.heightIn(min=60.dp)) { Text("기존 경로 유지",fontSize=17.sp) }})
    }
}
private fun fixTime(raw: String)=runCatching { DateTimeFormatter.ofPattern("HH:mm:ss").withZone(ZoneId.systemDefault()).format(Instant.parse(raw)) }.getOrDefault("확인 시각")
