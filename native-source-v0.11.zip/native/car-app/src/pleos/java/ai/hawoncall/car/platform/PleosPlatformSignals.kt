package ai.hawoncall.car.platform

import ai.hawoncall.core.Gear
import ai.hawoncall.car.BuildConfig
import android.content.Context
import android.os.Handler
import android.os.Looper

/** All SDK callbacks enter the application on the main thread, and stop after close. */
class PleosPlatformSignals(context: Context, academy: Destination) : PlatformSignals {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var closed = false
    private var listener: SignalListener? = null
    private val emit: ((SignalListener) -> Unit) -> Unit = { action ->
        main.post { if (!closed) listener?.let(action) }
        Unit
    }
    private val vehicle = PleosVehicleAdapter(context, emit)
    private val aaos = AaosSafetyAdapter(context, emit)
    private val navigationDemo = BuildConfig.DEBUG && context
        .getSharedPreferences("car-settings", Context.MODE_PRIVATE)
        .getBoolean("navigationDemo", false)
    private val navigation = if (navigationDemo) null else PleosNavigationAdapter(context, academy, emit)
    private val simulatedNavigation = if (navigationDemo) NavigationOnlyDemo(academy, emit) else null
    private val location = PleosLocationAdapter(context, academy, emit)

    override fun connect(listener: SignalListener) {
        check(!closed) { "Platform adapter is closed" }
        check(this.listener == null) { "Already connected" }
        this.listener = object : SignalListener by listener {
            override fun onGear(gear: Gear) {
                simulatedNavigation?.onGear(gear)
                navigation?.onGear(gear)
                listener.onGear(gear)
            }
            override fun onUxRestricted(restricted: Boolean) {
                navigation?.onUxRestricted(restricted)
                simulatedNavigation?.onUxRestricted(restricted)
                listener.onUxRestricted(restricted)
            }
        }
        listener.onGear(Gear.UNKNOWN)
        listener.onUxRestricted(true)
        // Unknown capability must not be interpreted as confirmed absence of sensors.
        listener.onCapabilities(occupancy = true, belt = true)
        aaos.connect()
        vehicle.connect()
        if (navigationDemo) {
            listener.onStatus("내비만 모의 시연 · 문·착석·벨트·기어·위치는 실제 차량 신호")
            simulatedNavigation?.connect()
        } else navigation?.connect()
        location.connect()
    }

    override fun route(destination: Destination) {
        if (closed) return
        simulatedNavigation?.route(destination) ?: navigation?.route(destination)
    }

    override fun requestLiveMeetingDestination(frozen: ai.hawoncall.core.ChildLiveSnapshot,onResult: (LiveRouteResult)->Unit) {
        if(closed || navigationDemo || navigation==null) {
            onResult(LiveRouteResult(LiveRouteState.FAILED,"실제 내비 연결 상태를 확인해 주세요.")); return
        }
        navigation.requestLiveMeetingDestination(frozen,onResult)
    }
    override fun openNavigation() {
        if (closed) return
        if (navigationDemo) {
            emit { it.onStatus("내비만 모의 시연 중 · 실제 내비 화면을 열지 않습니다") }
        } else navigation?.openNavigation()
    }

    override fun pollNavigation() {
        if (closed) return
        navigation?.poll()
        location.poll()
    }

    override fun close() {
        if (closed) return
        closed = true
        main.removeCallbacksAndMessages(null)
        aaos.close()
        vehicle.close()
        navigation?.close()
        simulatedNavigation?.close()
        location.close()
        listener = null
    }
}
