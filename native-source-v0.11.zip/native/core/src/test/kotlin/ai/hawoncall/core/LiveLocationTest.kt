package ai.hawoncall.core

import kotlin.test.*
class LiveLocationTest {
    private val fix=ChildLiveFix(37.5665,126.978,12.0,"2026-10-26T01:00:00Z",1,2.0,"CHILD_PHONE_GPS")
    private val session=ChildSharingSession("session","SHARING","2026-10-26T01:30:00Z")
    @Test fun expiresWithMonotonicAge() {
        val s=ChildLiveSnapshot(session,fix,true,1000,java.time.Instant.parse("2026-10-26T01:00:00Z").toEpochMilli())
        assertTrue(s.usable(29_000)); assertFalse(s.usable(29_001)); assertFalse(s.usable(999))
    }
    @Test fun phonePositionCannotBecomeInstitutionArrivalEvidence() {
        assertFalse(ChildLiveSnapshot(session,fix.copy(source="UNKNOWN"),true,1000,java.time.Instant.parse("2026-10-26T01:00:00Z").toEpochMilli()).usable(1000))
        assertFalse(ChildLiveSnapshot(session,fix.copy(accuracyMeters=51.0),true,1000,java.time.Instant.parse("2026-10-26T01:00:00Z").toEpochMilli()).usable(1000))
        assertFalse(ChildLiveSnapshot(null,fix,true,1000,java.time.Instant.parse("2026-10-26T01:00:00Z").toEpochMilli()).usable(1000))
    }
    @Test fun manualRouteNeedsParkPickupFreshAuthorizationAndFrozenSession() {
        val now=java.time.Instant.parse("2026-10-26T01:00:00Z").toEpochMilli()
        val frozen=ChildLiveSnapshot(session,fix,true,1000,now)
        assertTrue(LiveMeetingRoutePolicy.allowed(frozen,frozen.copy(fix=fix.copy(sequence=2)),true,true,true,2000))
        assertFalse(LiveMeetingRoutePolicy.allowed(frozen,frozen,false,true,true,2000))
        assertFalse(LiveMeetingRoutePolicy.allowed(frozen,frozen,true,false,true,2000))
        assertFalse(LiveMeetingRoutePolicy.allowed(frozen,null,true,true,true,2000))
        assertFalse(LiveMeetingRoutePolicy.allowed(frozen,frozen.copy(session=session.copy(id="rotated")),true,true,true,2000))
        assertEquals(1L,frozen.fix?.sequence)
    }
    @Test fun realFixNeedsBothClocksAndNoMock() {
        fun ok(wall:Long=100_000, elapsed:Long=100_000_000_000,mock:Boolean=false)=PhoneFixPolicy.acceptable(37.56,126.97,10.0,wall,elapsed,100_000,100_000_000_000,mock)
        assertTrue(ok()); assertFalse(ok(wall=60_000)); assertFalse(ok(elapsed=60_000_000_000)); assertFalse(ok(mock=true))
    }
}

class PhoneUploadGateTest {
    @Test fun serialOrderThrottleAndStopDropFixes() {
        val gate=PhoneUploadGate()
        assertEquals(1L,gate.acquire(10_000,1000))
        assertNull(gate.acquire(11_000,5000)) // In-flight upload cannot be reordered.
        gate.release()
        assertNull(gate.acquire(10_000,5000)) // An already observed fix cannot be replayed.
        assertNull(gate.acquire(11_000,3999))
        assertEquals(2L,gate.acquire(11_000,4000))
        gate.release(); gate.close()
        assertNull(gate.acquire(12_000,8000))
    }
}
