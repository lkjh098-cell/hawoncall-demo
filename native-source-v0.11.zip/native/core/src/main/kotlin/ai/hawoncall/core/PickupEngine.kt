package ai.hawoncall.core

import java.util.UUID
import kotlin.math.ceil

fun interface Clock { fun nowMillis(): Long }

data class PickupPlan(
    val linkId: String,
    val childName: String,
    val academyName: String,
    val academyId: String = "academy",
    val weekday: Int = 1,
    /** Initial preparation duration D, before the extra 30-second calling margin. */
    val initialLeadSeconds: Long = 300,
    val institutionType: InstitutionType = InstitutionType.ACADEMY,
    val journeyType: JourneyType = JourneyType.PICKUP,
    val serviceArea: ServiceArea = ServiceArea.SEOUL,
    val pickupSpot: PickupSpot? = null,
) {
    init {
        require(linkId.isNotBlank())
        require(childName.isNotBlank())
        require(academyName.isNotBlank())
        require(academyId.isNotBlank())
        require(weekday in 1..7)
    }
}

enum class JourneyType { PICKUP, DROPOFF }
enum class InstitutionType(val label: String) {
    SCHOOL("학교"), KINDERGARTEN("유치원"), DAYCARE("어린이집"), ACADEMY("학원");
    fun journeyLabel(journey: JourneyType) = if (this == SCHOOL) {
        if (journey == JourneyType.PICKUP) "하교" else "등교"
    } else if (journey == JourneyType.PICKUP) "하원" else "등원"
}
enum class ServiceArea { SEOUL }

/** Informational authorized location. This never changes or proves arrival at an OEM route. */
data class PickupSpot(val id: String, val name: String, val latitude: Double, val longitude: Double) {
    init {
        require(id.isNotBlank() && name.isNotBlank())
        require(latitude.isFinite() && latitude in -90.0..90.0)
        require(longitude.isFinite() && longitude in -180.0..180.0)
    }
}

enum class PickupState { IDLE, PLANNED, EN_ROUTE, CALLED, APPROACHING, ARRIVED, BOARDING_DETECTED, BOARDED, DONE, CANCELLED, HANDED_OVER }
enum class Gear { PARK, DRIVE, REVERSE, NEUTRAL, UNKNOWN }
enum class RearSide { LEFT, RIGHT }
enum class EventType { ETA, CALL, ARRIVED, BOARDED, CANCEL, HANDED_OVER }
enum class RouteDestination { ACADEMY, NEXT }

sealed interface PickupEffect {
    data class ServerEvent(
        val type: EventType,
        val atMillis: Long,
        val etaMin: Int? = null,
        val reason: String? = null,
    ) : PickupEffect
    data class RequestRoute(val destination: RouteDestination) : PickupEffect
    data class Speak(val text: String) : PickupEffect
    data class StateChanged(val from: PickupState, val to: PickupState, val atMillis: Long) : PickupEffect
    data class LearningUpdated(
        val key: LearningKey,
        val previousSeconds: Long,
        val durationSeconds: Long,
        val waitSeconds: Long,
    ) : PickupEffect
    data class WaitingAlert(val waitSeconds: Long) : PickupEffect
}

data class PickupSnapshot(
    val state: PickupState,
    val etaSeconds: Long?,
    val arrivalAtMillis: Long?,
    val boardedAtMillis: Long?,
    val waitingSeconds: Long,
    val learnedDurationSeconds: Long,
    val callLeadSeconds: Long,
    val canConfirmBoarding: Boolean,
    val gear: Gear,
    val journeyType: JourneyType = JourneyType.PICKUP,
    val canConfirmHandoff: Boolean = false,
    val handedOverAtMillis: Long? = null,
)

/**
 * One engine represents one trip. Call it serially on its owning thread.
 * All callbacks are observations at Clock.nowMillis(); adapters must discard stale SDK callbacks.
 * No network, vehicle SDK, timer, or Android API is used here. Call tick() periodically.
 */
class PickupEngine(
    val plan: PickupPlan,
    private val clock: Clock,
    private val learning: LearningStore = InMemoryLearningStore(),
    private val sampleId: String = UUID.randomUUID().toString(),
) {
    var state: PickupState = PickupState.IDLE
        private set
    private var gear = Gear.UNKNOWN
    private var etaSeconds: Long? = null
    private var arrivalAt: Long? = null
    private var boardedAt: Long? = null
    private var handedOverAt: Long? = null
    private var lastEtaAt: Long? = null
    private var called = false
    private var waitingAlertSent = false
    private var occupancySupported = true
    private var beltSupported = true
    private var lastNow = Long.MIN_VALUE
    private var nearEvidenceAt: Long? = null
    private var parkedSince: Long? = null
    private var parkedMillis = 0L
    private var arrivalEventSent = false
    private var approachSpoken = false
    private var learned = false
    private val effects = mutableListOf<PickupEffect>()
    private val learningKey = LearningKey(plan.academyId, plan.linkId, plan.weekday, plan.journeyType)
    private val doors = RearSide.entries.associateWith { DoorEvidence() }

    companion object {
        const val APPROACH_RADIUS_METERS = 150.0
        const val PARKED_RADIUS_METERS = 100.0
        const val NEAR_EVIDENCE_MAX_AGE_MILLIS = 30_000L
    }

    private val activeStates = setOf(PickupState.PLANNED, PickupState.EN_ROUTE,
        PickupState.CALLED, PickupState.APPROACHING, PickupState.ARRIVED, PickupState.BOARDING_DETECTED)
    private val parkedStates = setOf(PickupState.ARRIVED, PickupState.BOARDING_DETECTED)

    private class DoorEvidence {
        var open: Boolean? = null
        var occupied: Boolean? = null
        var buckled: Boolean? = null
        var openedAt: Long? = null
        var closedAt: Long? = null
        var occupancyEdgeAt: Long? = null
        var beltEdgeAt: Long? = null
        fun clearAttempt() {
            openedAt = null
            closedAt = null
            occupancyEdgeAt = null
            beltEdgeAt = null
        }
    }

    private var institutionNavigationSuspended=false
    /** Advisory phone routing neither cancels the trip nor inherits any vehicle-arrival lease. */
    fun suspendForAdvisoryNavigation() {
        institutionNavigationSuspended=true
        nearEvidenceAt=null; etaSeconds=null
        pauseParkedWait(now())
        doors.values.forEach { it.clearAttempt() }
        if(state in parkedStates) transition(PickupState.APPROACHING)
    }
    /** Host must separately validate the immutable original institution route before resuming. */
    fun resumeInstitutionNavigation() { institutionNavigationSuspended=false; nearEvidenceAt=null; doors.values.forEach { it.clearAttempt() } }

    private fun now(): Long = clock.nowMillis().coerceAtLeast(lastNow).also { lastNow = it }
    private fun duration() = learning.durationSeconds(learningKey, plan.initialLeadSeconds)
    val snapshot: PickupSnapshot
        get() {
            val at = now()
            return PickupSnapshot(state, etaSeconds, arrivalAt, boardedAt,
                waitingSeconds(at), duration(), duration() + 30,
                plan.journeyType == JourneyType.PICKUP && canConfirm(at), gear,
                plan.journeyType, plan.journeyType == JourneyType.DROPOFF && canConfirm(at), handedOverAt)
        }

    fun drainEffects(): List<PickupEffect> = effects.toList().also { effects.clear() }

    fun start() {
        if (state != PickupState.IDLE) return
        transition(PickupState.PLANNED)
        if (gear == Gear.DRIVE) beginDriving()
    }

    private fun beginDriving() {
        if (institutionNavigationSuspended || state != PickupState.PLANNED) return
        transition(PickupState.EN_ROUTE)
        etaSeconds?.let { maybeCall(it) }
    }

    fun updateEta(seconds: Long) {
        if (institutionNavigationSuspended || seconds < 0 || state !in activeStates) return
        etaSeconds = seconds
        // ETA from an active route also establishes that navigation has started.
        beginDriving()
        val at = now()
        // The server's parked arrival remains authoritative if the car moves again locally.
        // Keep the UI ETA current without queuing a post-arrival ETA ahead of boarding.
        if (!arrivalEventSent && (lastEtaAt == null || at - lastEtaAt!! >= 60_000)) {
            effects += PickupEffect.ServerEvent(EventType.ETA, at,
                ceil(seconds / 60.0).toLong().coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            lastEtaAt = at
        }
        maybeCall(seconds)
    }

    private fun maybeCall(seconds: Long) {
        if (!called && state == PickupState.EN_ROUTE && seconds <= duration() + 30) call()
    }

    private fun call() {
        if (called) return
        called = true
        if (state in setOf(PickupState.PLANNED, PickupState.EN_ROUTE)) transition(PickupState.CALLED)
        effects += PickupEffect.ServerEvent(EventType.CALL, now())
    }

    /** Compatibility alias for an approach observation; it cannot establish a parked arrival. */
    fun arrive() = proximityEntered()

    fun proximityEntered() {
        if (institutionNavigationSuspended) return
        if (state !in activeStates || state in parkedStates) return
        if (!called) call()
        if (state != PickupState.APPROACHING) transition(PickupState.APPROACHING)
        if (!approachSpoken) {
            approachSpoken = true
            effects += PickupEffect.Speak("${plan.institutionType.label} 근처예요. 안전한 곳에 주차해주세요")
        }
    }

    /** An explicit OEM navigation arrival is near evidence, never proof that the car is parked. */
    fun destinationArrived() {
        if (institutionNavigationSuspended) return
        if (state !in activeStates) return
        nearEvidenceAt = now()
        proximityEntered()
        enterParkedArrival()
    }

    fun locationDistanceUpdated(meters: Double) {
        if (institutionNavigationSuspended) return
        if (!meters.isFinite() || meters < 0 || state !in activeStates) return
        val at = now()
        nearEvidenceAt = if (meters <= PARKED_RADIUS_METERS) at else null
        if (meters > PARKED_RADIUS_METERS && state in parkedStates) leaveParkedArrival(at)
        if (meters <= APPROACH_RADIUS_METERS) proximityEntered()
        enterParkedArrival()
    }

    private fun enterParkedArrival() {
        val at = now()
        if (institutionNavigationSuspended || state !in activeStates || state in parkedStates || gear != Gear.PARK || !hasFreshNearbyEvidence(at)) return
        if (!called) call()
        if (arrivalAt == null) arrivalAt = at
        parkedSince = at
        doors.values.forEach { it.clearAttempt() }
        transition(PickupState.ARRIVED)
        if (!arrivalEventSent) {
            arrivalEventSent = true
            effects += PickupEffect.ServerEvent(EventType.ARRIVED, at)
        }
    }

    private fun leaveParkedArrival(at: Long) {
        pauseParkedWait(at)
        doors.values.forEach { it.clearAttempt() }
        if (state in parkedStates) transition(PickupState.APPROACHING)
    }

    private fun pauseParkedWait(at: Long) {
        parkedSince?.let { parkedMillis += (at - it).coerceAtLeast(0) }
        parkedSince = null
    }

    fun destinationChanged(isAcademy: Boolean) {
        if (isAcademy) {
            if (state == PickupState.IDLE) start()
        } else if (state in activeStates) cancel("destination_changed")
    }

    fun gearChanged(value: Gear) {
        if (gear == value) return
        val at = now()
        gear = value
        if (value != Gear.PARK) {
            if (state in parkedStates) leaveParkedArrival(at)
            doors.values.forEach { it.clearAttempt() }
        }
        if (state == PickupState.BOARDED && value == Gear.DRIVE) {
            transition(PickupState.DONE)
        } else if (value == Gear.DRIVE) beginDriving()
        if (value == Gear.PARK) enterParkedArrival()
    }

    private fun hasFreshNearbyEvidence(at: Long): Boolean =
        nearEvidenceAt?.let { at - it in 0L..NEAR_EVIDENCE_MAX_AGE_MILLIS } == true

    fun doorChanged(side: RearSide, open: Boolean) {
        val door = doors.getValue(side)
        if (door.open == open) return
        val previous = door.open
        door.open = open
        if (state !in parkedStates || gear != Gear.PARK) return
        val at = now()
        if (open) {
            if (state == PickupState.BOARDING_DETECTED) invalidateBoardingCandidate()
            if (door.closedAt != null) door.clearAttempt()
            door.closedAt = null
            door.openedAt = at
        } else if (previous == true) {
            val opened = door.openedAt
            door.openedAt = null
            door.closedAt = if (opened != null && at - opened >= 1_000) at else null
        }
        evaluateBoarding(at)
    }

    fun occupancyChanged(side: RearSide, occupied: Boolean) {
        val door = doors.getValue(side)
        val previous = door.occupied
        door.occupied = occupied
        if (!occupied) {
            door.occupancyEdgeAt = null
            if (state == PickupState.BOARDING_DETECTED) invalidateBoardingCandidate()
        }
        if (state in parkedStates && gear == Gear.PARK && occupancySupported && previous == false && occupied) {
            door.occupancyEdgeAt = now()
            evaluateBoarding(now())
        }
    }

    fun beltChanged(side: RearSide, buckled: Boolean) {
        val door = doors.getValue(side)
        val previous = door.buckled
        door.buckled = buckled
        if (!buckled) door.beltEdgeAt = null
        if (state in parkedStates && gear == Gear.PARK && beltSupported && previous == false && buckled) {
            door.beltEdgeAt = now()
            evaluateBoarding(now())
        }
    }

    fun setCapabilities(occupancy: Boolean, belt: Boolean) {
        occupancySupported = occupancy
        beltSupported = belt
        // A capability refresh cannot turn an old sensor observation into fresh evidence.
        if (state == PickupState.BOARDING_DETECTED) invalidateBoardingCandidate()
        doors.values.forEach {
            if (!occupancy) it.occupancyEdgeAt = null
            if (!belt) it.beltEdgeAt = null
        }
    }

    private fun validDoor(door: DoorEvidence, at: Long): Boolean {
        val closed = door.closedAt ?: return false
        return door.open == false && at - closed >= 1_000 && at - closed <= 60_000
    }

    private fun canConfirm(at: Long) = !institutionNavigationSuspended && state in parkedStates && gear == Gear.PARK && hasFreshNearbyEvidence(at)

    private fun invalidateBoardingCandidate() {
        doors.values.forEach { it.clearAttempt() }
        if (state == PickupState.BOARDING_DETECTED) transition(PickupState.ARRIVED)
    }

    fun confirmBoarding() {
        if (plan.journeyType == JourneyType.PICKUP && canConfirm(now())) boarded()
    }

    private fun evaluateBoarding(at: Long) {
        if(institutionNavigationSuspended) return
        // A door, seat or belt observation never establishes entry into an institution.
        if (plan.journeyType != JourneyType.PICKUP) return
        if (state !in parkedStates || gear != Gear.PARK) return
        val qualifies = doors.values.any { door ->
            val closed = door.closedAt
            closed != null && validDoor(door, at) &&
                listOfNotNull(if (occupancySupported) door.occupancyEdgeAt else null,
                    if (beltSupported) door.beltEdgeAt else null).any { edge ->
                    edge >= closed - 60_000 && edge <= closed + 60_000
                }
        }
        if (qualifies && state != PickupState.BOARDING_DETECTED) transition(PickupState.BOARDING_DETECTED)
        if (!qualifies && state == PickupState.BOARDING_DETECTED) transition(PickupState.ARRIVED)
    }

    /** Explicit guardian action only. PARK and fresh bound-destination evidence are still required. */
    fun confirmHandoff() {
        if (plan.journeyType != JourneyType.DROPOFF || !canConfirm(now())) return
        handedOverAt = now()
        pauseParkedWait(handedOverAt!!)
        transition(PickupState.HANDED_OVER)
        effects += PickupEffect.ServerEvent(EventType.HANDED_OVER, handedOverAt!!)
        effects += PickupEffect.Speak("보호자가 안전 인계를 확인했어요")
        // Pickup preparation learning must not be trained from dropoff dwell.
    }

    private fun boarded() {
        if (!canConfirm(now())) return
        boardedAt = now()
        pauseParkedWait(boardedAt!!)
        transition(PickupState.BOARDED)
        effects += PickupEffect.ServerEvent(EventType.BOARDED, now())
        effects += PickupEffect.Speak("${plan.childName}아, 오늘도 수고했어")
        if (!learned) {
            learned = true
            val wait = waitingSeconds(boardedAt!!)
            val previous = duration()
            val updated = learning.record(learningKey, wait, plan.initialLeadSeconds, sampleId)
            effects += PickupEffect.LearningUpdated(learningKey, previous, updated, wait)
        }
    }

    fun completeDeparture() {
        if (state == PickupState.BOARDED && gear == Gear.DRIVE) transition(PickupState.DONE)
    }

    fun cancel(reason: String) {
        if (state !in activeStates) return
        pauseParkedWait(now())
        transition(PickupState.CANCELLED)
        doors.values.forEach { it.clearAttempt() }
        effects += PickupEffect.ServerEvent(EventType.CANCEL, now(), reason = reason.take(200))
    }

    fun tick() {
        if(institutionNavigationSuspended) return
        val at = now()
        evaluateBoarding(at)
        if (state in parkedStates && !waitingAlertSent && waitingSeconds(at) >= 300) {
            waitingAlertSent = true
            effects += PickupEffect.WaitingAlert(waitingSeconds(at))
            effects += PickupEffect.Speak("${plan.institutionType.label} 앞에서 5분 이상 기다리고 있어요")
        }
    }

    private fun transition(next: PickupState) {
        val previous = state
        state = next
        effects += PickupEffect.StateChanged(previous, next, now())
    }

    private fun waitingSeconds(at: Long): Long =
        (parkedMillis + (parkedSince?.let { (at - it).coerceAtLeast(0) } ?: 0)) / 1_000
}
