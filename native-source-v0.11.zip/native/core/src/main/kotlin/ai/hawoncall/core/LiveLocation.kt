package ai.hawoncall.core

import org.json.JSONObject
import java.time.Instant

/** Advisory phone fix. It cannot establish vehicle arrival or permission to stop. */
data class ChildLiveFix(val latitude: Double, val longitude: Double, val accuracyMeters: Double,
    val observedAt: String, val sequence: Long, val ageSeconds: Double, val source: String)
data class ChildSharingSession(val id: String, val status: String, val expiresAt: String)
data class ChildLiveSnapshot(val session: ChildSharingSession?, val fix: ChildLiveFix?, val fresh: Boolean,
    val receivedMonotonicMillis: Long, val receivedWallMillis: Long = System.currentTimeMillis()) {
    fun ageMillis(nowMonotonicMillis: Long): Long? = fix?.let {
        if(nowMonotonicMillis < receivedMonotonicMillis) null
        else (it.ageSeconds * 1000).toLong() + nowMonotonicMillis - receivedMonotonicMillis
    }
    fun usable(nowMonotonicMillis: Long): Boolean {
        val currentSession=session ?: return false
        val currentFix=fix ?: return false
        val sessionAlive=runCatching {
            Instant.parse(currentSession.expiresAt).toEpochMilli()-receivedWallMillis > nowMonotonicMillis-receivedMonotonicMillis
        }.getOrDefault(false)
        return fresh && sessionAlive && currentSession.status=="SHARING" &&
            currentFix.sequence>0 && currentFix.ageSeconds.isFinite() && currentFix.ageSeconds in 0.0..30.0 &&
            currentFix.source=="CHILD_PHONE_GPS" && currentFix.latitude.isFinite() && currentFix.longitude.isFinite() &&
            currentFix.latitude in -90.0..90.0 && currentFix.longitude in -180.0..180.0 &&
            currentFix.accuracyMeters.isFinite() && currentFix.accuracyMeters>0 && currentFix.accuracyMeters<=50 &&
            ageMillis(nowMonotonicMillis)?.let { it in 0..30_000 }==true
    }
}
object ChildLiveJson {
    fun snapshot(o: JSONObject, receivedMonotonicMillis: Long): ChildLiveSnapshot {
        require(!o.optBoolean("permissionInferenceAllowed",true) && !o.optBoolean("automaticRouteChangeAllowed",true))
        val session=o.optJSONObject("session")?.let {
            ChildSharingSession(it.getString("id"),it.getString("status"),it.getString("expiresAt").also(Instant::parse))
        }
        val fresh=o.optBoolean("fresh",false)
        val fix=if(!fresh) null else o.optJSONObject("location")?.let {
            ChildLiveFix(it.getDouble("latitude"),it.getDouble("longitude"),it.getDouble("accuracyMeters"),
                it.getString("observedAt").also(Instant::parse),it.getLong("sequence"),it.getDouble("ageSeconds"),it.getString("source"))
        }
        return ChildLiveSnapshot(session,fix,fresh,receivedMonotonicMillis).also {
            require(!fresh || it.usable(receivedMonotonicMillis)) { "아이 위치 응답을 확인할 수 없습니다." }
        }
    }
}

/** Both clocks refer to the actual fix. Never relabel an old cached fix as current. */
object PhoneFixPolicy {
    fun acceptable(latitude: Double, longitude: Double, accuracyMeters: Double, observedAtMillis: Long,
        fixElapsedNanos: Long, nowMillis: Long, nowElapsedNanos: Long, mock: Boolean): Boolean =
        !mock && latitude.isFinite() && longitude.isFinite() && latitude in -90.0..90.0 && longitude in -180.0..180.0 &&
        accuracyMeters.isFinite() && accuracyMeters > 0 && accuracyMeters <= 50 &&
        nowMillis-observedAtMillis in -5_000..30_000 && fixElapsedNanos > 0 &&
        nowElapsedNanos-fixElapsedNanos in 0..30_000_000_000L
}

/** Explicit advisory destination gate; no transition or arrival API is exposed here. */
object LiveMeetingRoutePolicy {
    fun allowed(frozen: ChildLiveSnapshot?, authenticated: ChildLiveSnapshot?, parked: Boolean,
        pickup: Boolean, authorized: Boolean, now: Long): Boolean {
        if(frozen==null || authenticated==null || !parked || !pickup || !authorized) return false
        return frozen.usable(now) && authenticated.usable(now) &&
            frozen.session?.id==authenticated.session?.id &&
            (authenticated.fix?.sequence ?: 0)>=(frozen.fix?.sequence ?: 0)
    }
}

/** Serial upload admission stores no fix, only counters. Busy/old/throttled fixes are dropped. */
class PhoneUploadGate {
    private var busy=false
    private var closed=false
    private var lastAttempt: Long?=null
    private var lastObserved=0L
    private var sequence=0L
    @Synchronized fun acquire(observedAtMillis: Long,elapsedMillis: Long): Long? {
        val previous=lastAttempt
        if(closed || busy || observedAtMillis<=lastObserved || previous!=null && elapsedMillis-previous<3000) return null
        busy=true; lastAttempt=elapsedMillis; lastObserved=observedAtMillis
        return ++sequence
    }
    @Synchronized fun release() { busy=false }
    @Synchronized fun close() { closed=true; busy=false }
}
