package ai.hawoncall.guardian

import android.os.SystemClock
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable internal fun GuardianChildLocationPanel(state: GuardianUiState,onCreate:(Boolean)->Unit,onRevoke:()->Unit) {
    val session=state.session ?: return
    if(session.link.journeyType!=JourneyType.PICKUP) return
    var consent by remember(session.link.id) { mutableStateOf(false) }
    val live=state.childLive
    // Reading the UI clock recomposes age even if the last successful snapshot never changes.
    val uiClock=state.now
    val now=SystemClock.elapsedRealtime()
    val usable=live?.usable(now)==true && !state.needsReconnect
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Text("아이 휴대폰 실시간 위치",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
            Text("아이 휴대폰에 ‘하원콜 아이 위치’ 앱을 설치하고 아래 코드를 직접 입력하세요. 아이가 공유를 시작하면 보호자와 연결 차량에서 최근 위치를 확인해요.")
            Text(when {
                state.childLiveError!=null -> state.childLiveError
                usable -> "공유 중 · 최근 위치 ${live?.ageMillis(now)?.div(1000)}초 전 · 정확도 약 ${live?.fix?.accuracyMeters?.toInt()}m"
                live?.session?.status=="AWAITING_CHILD" -> "아이 휴대폰 연결 대기"
                live?.session?.status=="WAITING_FOR_FIX" -> "아이 휴대폰의 실제 위치 공유 시작을 기다려요"
                live?.session?.status=="STALE" -> "위치가 오래되어 현재 위치를 표시하지 않아요"
                else -> "최근 공유 위치 없음"
            })
            val pair=state.childPair
            if(pair!=null) {
                val remaining=((pair.expiresAt-uiClock)/1000).coerceAtLeast(0)
                Text(if(remaining>0) pair.code.chunked(4).joinToString("  ") else "아이 위치 코드 만료",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
                Text("아이 위치 전용 · 한 번 사용 · ${remaining/60}분 ${remaining%60}초 남음")
            }
            Row {
                Checkbox(consent,{consent=it},enabled=!state.childSharingBusy)
                Text("보호자로서 아이와 공유 범위를 확인했으며, 아이의 최근 위치를 보호자와 연결 차량에 최대 30분 공유하는 데 동의해요.",modifier=Modifier.padding(top=10.dp))
            }
            Button(onClick={onCreate(consent)},enabled=consent && !state.childSharingBusy && !state.needsReconnect,modifier=Modifier.fillMaxWidth()) { Text(if(state.childSharingBusy) "처리 중" else "아이 위치 연결 코드 발급") }
            OutlinedButton(onClick=onRevoke,enabled=!state.childSharingBusy && !state.needsReconnect,modifier=Modifier.fillMaxWidth()) { Text("아이 위치 공유 해제") }
            Text("아이 앱은 공유 중 알림과 중지 버튼을 표시해요. 위치는 30초 이내·정확도 50m 이내일 때만 참고하며, 주정차 허가·차량 도착·탑승 확인에 사용하지 않아요.",style=MaterialTheme.typography.bodySmall)
        }
    }
}
