package ai.hawoncall.guardian

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

internal data class GuardianUiState(
    val childLive: ai.hawoncall.core.ChildLiveSnapshot? = null,
    val childPair: GuardianPairing? = null,
    val childSharingBusy: Boolean = false,
    val childLiveError: String? = null,
    val operations: ai.hawoncall.core.OperationSnapshot? = null,
    val operationsDate: String = ai.hawoncall.core.BriefingPolicy.serviceDate(),
    val operationsError: String? = null,
    val operationsBusy: Boolean = false,
    val operationsNotice: String? = null,
    val operationsFetchedAt: Long = 0,
    val operationsReceivedMonotonic: Long = 0,
    val restoring: Boolean = true,
    val session: GuardianSession? = null,
    val pairing: GuardianPairing? = null,
    val busy: Boolean = false,
    val refreshing: Boolean = false,
    val error: String? = null,
    val cacheWarning: String? = null,
    val needsReconnect: Boolean = false,
    val refreshFailed: Boolean = true,
    val spots: GuardianSpotCatalog? = null,
    val spotsLoading: Boolean = false,
    val spotError: String? = null,
    val spotQuery: String = "",
    val selectingSpot: Boolean = false,
    val roadSpot: GuardianPickupSpot? = null,
    val roads: GuardianRoadContext? = null,
    val roadsLoading: Boolean = false,
    val roadError: String? = null,
    val now: Long = System.currentTimeMillis()
)

internal class GuardianViewModel(private val store: GuardianSessionStore,private val allowLocal: Boolean) : ViewModel() {
    private val api=GuardianApi(allowLocal)
    private val mutable=MutableStateFlow(GuardianUiState())
    val state=mutable.asStateFlow()
    private val storage=Mutex()
    @Volatile private var generation=0L
    @Volatile private var persistedSnapshot: GuardianSession?=null
    private var childLiveJob: Job?=null
    private var childAction: Job?=null
    private var foreground=false
    private var pollJob: Job?=null
    private var clockJob: Job?=null
    private var action: Job?=null
    private var spotAction: Job?=null
    private var roadAction: Job?=null
    private var roadGeneration=0L
    private var operationJob: Job?=null
    private var pendingIssue: Pair<String,String>?=null
    init {
        viewModelScope.launch {
            try {
                val restored=withContext(Dispatchers.IO) { storage.withLock { store.load() } }
                restored?.let { GuardianServerPolicy.validate(it.serverUrl,allowLocal) }
                persistedSnapshot=restored
                mutable.update { it.copy(restoring=false,session=restored) }
            } catch(e: Exception) {
                if(e is CancellationException) throw e
                mutable.update { it.copy(restoring=false,error="저장된 연결을 복원하지 못했습니다. 연결 정보를 초기화한 뒤 다시 연결하세요.") }
            }
            startPolling()
        }
    }
    fun setForeground(active: Boolean) {
        foreground=active
        if(active) {
            if(clockJob?.isActive!=true) clockJob=viewModelScope.launch {
                while(isActive) { mutable.update { it.copy(now=System.currentTimeMillis()) }; delay(1000) }
            }
            startPolling()
        } else { pollJob?.cancel(); pollJob=null; clockJob?.cancel(); clockJob=null; childLiveJob?.cancel(); childLiveJob=null; mutable.update { it.copy(childLive=null) } }
    }
    private fun startPolling() {
        startChildLivePolling()
        if(!foreground || mutable.value.restoring || mutable.value.session==null || mutable.value.needsReconnect || mutable.value.selectingSpot || pollJob?.isActive==true) return
        pollJob=viewModelScope.launch {
            while(isActive) { refresh(); if(mutable.value.needsReconnect) break; delay(3000) }
        }
    }
    private suspend fun persist(s: GuardianSession,version: Long) = withContext(Dispatchers.IO) {
        storage.withLock {
            if(version==generation) {
                store.save(s)
                if(version==generation) persistedSnapshot=s
            }
        }
    }
    private suspend fun refresh() {
        val s=mutable.value.session ?: return
        val version=generation
        mutable.update { it.copy(refreshing=true) }
        try {
            val fresh=api.refresh(s)
            loadOperations()
            if(version!=generation) return
            // Network freshness must not wait for the encrypted cache or inherit its failures.
            mutable.update { it.copy(session=fresh,error=null,needsReconnect=false,refreshFailed=false,refreshing=false) }
            if(requiresSnapshotWrite(persistedSnapshot,fresh)) {
                try {
                    persist(fresh,version)
                    if(version==generation) mutable.update { it.copy(cacheWarning=null) }
                } catch(e: Exception) {
                    if(e is CancellationException) throw e
                    if(version==generation) mutable.update { it.copy(cacheWarning="새 소식은 표시하고 있어요. 기기에 기록을 저장하지 못해 앱을 다시 열면 이전 기록이 보일 수 있어요.") }
                }
            }
        } catch(e: Exception) {
            if(e is CancellationException) throw e
            if(version==generation) mutable.update { it.copy(refreshFailed=true,error=message(e),needsReconnect=e is GuardianApiException && e.code==401,
                pairing=if(e is GuardianApiException && e.code==401) null else it.pairing) }
        } finally { if(version==generation) mutable.update { it.copy(refreshing=false) } }
    }
    fun retry() { pollJob?.cancel(); pollJob=null; mutable.update { it.copy(needsReconnect=false) }; startPolling() }
    fun register(server: String,r: GuardianRegistration,consent: Boolean) {
        if(mutable.value.busy || mutable.value.restoring) return
        val error=runCatching {
            GuardianServerPolicy.validate(server,allowLocal)
            require(r.academyCode.matches(Regex("[A-Z0-9_-]{4,24}"))) { "기관 코드를 확인하세요. (4~24자)" }
            require(r.childName.isNotBlank() && r.childName.length<=30 && !r.childName.any { it<' ' || it=='<' || it=='>' }) { "아이 호칭을 1~30자로 입력하세요." }
            require(r.weekday.isNotEmpty() && r.weekday.all { it in 1..7 }) { "이용 요일을 선택하세요." }
            require(r.pickupTime.matches(Regex("([01]\\d|2[0-3]):[0-5]\\d"))) { "예정 시각을 16:30처럼 입력하세요." }
            require(r.serviceArea=="SEOUL") { "현재 서울에서만 이용할 수 있습니다." }
            require(consent) { "법정대리인 동의가 필요합니다." }
        }.exceptionOrNull()
        if(error!=null) { mutable.update { it.copy(error=error.message) }; return }
        val version=generation
        mutable.update { it.copy(busy=true,error=null) }
        action=viewModelScope.launch {
            try {
                val session=api.register(server,r)
                persist(session,version)
                if(version==generation) mutable.update { it.copy(session=session,busy=false,error=null) }
                startPolling()
            } catch(e: Exception) {
                if(e is CancellationException) throw e
                if(version==generation) mutable.update { it.copy(busy=false,error=message(e)) }
            }
        }
    }
    fun loadPickupSpots(query: String = "") {
        val session=mutable.value.session ?: return
        if(mutable.value.spotsLoading || mutable.value.selectingSpot || mutable.value.needsReconnect) return
        val version=generation
        mutable.update { it.copy(spotsLoading=true,spotError=null,spotQuery=query.trim().take(80)) }
        spotAction=viewModelScope.launch {
            try {
                val catalog=api.pickupSpots(session,query.trim().take(80))
                if(version==generation) mutable.update { it.copy(spots=catalog,spotsLoading=false) }
            } catch(e: Exception) {
                if(e is CancellationException) throw e
                if(version==generation && e is GuardianApiException && e.code==401) { pollJob?.cancel(); pollJob=null }
                if(version==generation) mutable.update { it.copy(spotsLoading=false,spotError=message(e),
                    spots=null,needsReconnect=e is GuardianApiException && e.code==401 || it.needsReconnect,
                    pairing=if(e is GuardianApiException && e.code==401) null else it.pairing) }
            }
        }
    }
    fun selectPickupSpot(spotId: String) {
        val session=mutable.value.session ?: return
        val state=mutable.value
        if(state.selectingSpot || state.spotsLoading || state.needsReconnect || state.spots?.selectionAllowed!=true ||
            state.spots.spots.none { it.id==spotId && it.selectable }) return
        val version=generation
        pollJob?.cancel(); pollJob=null
        mutable.update { it.copy(selectingSpot=true,spotError=null,refreshing=false) }
        spotAction=viewModelScope.launch {
            try {
                val selected=api.selectPickupSpot(session,spotId)
                // A concurrent status refresh must not lose its newest trip snapshot.
                val current=mutable.value.session ?: return@launch
                val fresh=current.copy(link=selected.link)
                persist(fresh,version)
                if(version==generation) mutable.update { it.copy(session=fresh,selectingSpot=false) }
                loadPickupSpots(mutable.value.spotQuery)
            } catch(e: Exception) {
                if(e is CancellationException) throw e
                if(version==generation) mutable.update { it.copy(selectingSpot=false,spotError=message(e),
                    needsReconnect=e is GuardianApiException && e.code==401 || it.needsReconnect,
                    pairing=if(e is GuardianApiException && e.code==401) null else it.pairing) }
            } finally { if(version==generation) startPolling() }
        }
    }
    fun showRoadContext(spot: GuardianPickupSpot) {
        val session=mutable.value.session ?: return
        if(mutable.value.needsReconnect) return
        val version=generation
        val roadVersion=++roadGeneration
        roadAction?.cancel()
        mutable.update { it.copy(roadSpot=spot,roads=null,roadsLoading=true,roadError=null) }
        roadAction=viewModelScope.launch {
            try {
                val roads=api.roadContext(session,spot)
                if(version==generation && roadVersion==roadGeneration) mutable.update { it.copy(roads=roads,roadsLoading=false) }
            } catch(e: Exception) {
                if(e is CancellationException) throw e
                if(version==generation && roadVersion==roadGeneration) {
                    if(e is GuardianApiException && e.code==401) { pollJob?.cancel(); pollJob=null }
                    mutable.update { it.copy(roadsLoading=false,roadError=message(e),
                        needsReconnect=e is GuardianApiException && e.code==401 || it.needsReconnect,
                        pairing=if(e is GuardianApiException && e.code==401) null else it.pairing) }
                }
            }
        }
    }

    fun loadOperations(date: String = mutable.value.operationsDate) {
        val session=mutable.value.session ?: return
        if(mutable.value.needsReconnect) return
        if(runCatching { java.time.LocalDate.parse(date) }.isFailure) {
            mutable.update { it.copy(operationsError="날짜를 YYYY-MM-DD로 입력하세요.") }; return
        }
        if(date!=mutable.value.operationsDate) mutable.update { it.copy(operationsDate=date,operations=null,operationsNotice=null) }
        if(operationJob?.isActive==true) return
        val version=generation
        operationJob=viewModelScope.launch {
            try {
                val data=api.operations(session,date)
                if(version==generation && date==mutable.value.operationsDate) mutable.update { it.copy(operations=data,operationsError=null,operationsFetchedAt=System.currentTimeMillis(),operationsReceivedMonotonic=android.os.SystemClock.elapsedRealtime()) }
            } catch(e: Exception) {
                if(e is CancellationException) throw e
                if(version==generation) mutable.update { it.copy(operationsError=message(e),needsReconnect=it.needsReconnect || e is GuardianApiException && e.code==401) }
            }
        }
    }
    fun saveDayPlan(plan: ai.hawoncall.core.DayPlan) {
        val session=mutable.value.session ?: return
        if(mutable.value.operationsBusy || mutable.value.needsReconnect) return
        val validation=runCatching { plan.validate() }.exceptionOrNull()
        if(validation!=null) { mutable.update { it.copy(operationsError=validation.message) }; return }
        val version=generation
        mutable.update { it.copy(operationsBusy=true,operationsError=null,operationsNotice=null) }
        viewModelScope.launch {
            try {
                api.saveDayPlan(session,plan)
                if(version==generation) { mutable.update { it.copy(operationsNotice="보호자 일정을 저장했어요.") }; loadOperations(plan.serviceDate) }
            } catch(e: Exception) {
                if(e is CancellationException) throw e
                if(version==generation) mutable.update { it.copy(operationsError=message(e),needsReconnect=it.needsReconnect || e is GuardianApiException && e.code==401) }
            } finally { if(version==generation) mutable.update { it.copy(operationsBusy=false) } }
        }
    }
    fun requestIssue(kind: String,message: String) {
        val session=mutable.value.session ?: return
        val tripId=mutable.value.operations?.tripId ?: return
        if(mutable.value.operationsBusy || mutable.value.needsReconnect) return
        val fingerprint="$tripId|$kind|$message"
        val requestId=pendingIssue?.takeIf { it.first==fingerprint }?.second ?: java.util.UUID.randomUUID().toString().also { pendingIssue=fingerprint to it }
        val version=generation
        mutable.update { it.copy(operationsBusy=true,operationsError=null,operationsNotice=null) }
        viewModelScope.launch {
            try {
                api.issue(session,tripId,requestId,kind,message)
                if(version==generation) { pendingIssue=null; mutable.update { it.copy(operationsNotice="기관에 요청을 전송했어요. 기관의 응답을 기다려 주세요.") }; loadOperations() }
            } catch(e: Exception) {
                if(e is CancellationException) throw e
                if(version==generation) mutable.update { it.copy(operationsError=message(e),needsReconnect=it.needsReconnect || e is GuardianApiException && e.code==401) }
            } finally { if(version==generation) mutable.update { it.copy(operationsBusy=false) } }
        }
    }
    fun createPairing() {
        val s=mutable.value.session ?: return
        if(mutable.value.busy || mutable.value.needsReconnect) return
        val version=generation
        mutable.update { it.copy(busy=true,error=null,pairing=null) }
        action=viewModelScope.launch {
            try {
                val pair=api.pairing(s)
                if(version==generation) mutable.update { it.copy(busy=false,pairing=pair,now=System.currentTimeMillis()) }
            } catch(e: Exception) {
                if(e is CancellationException) throw e
                if(version==generation) mutable.update { it.copy(busy=false,error=message(e),needsReconnect=e is GuardianApiException && e.code==401) }
            }
        }
    }
    private fun startChildLivePolling() {
        if(!foreground || mutable.value.restoring || mutable.value.session==null || mutable.value.needsReconnect || childLiveJob?.isActive==true) return
        val version=generation
        childLiveJob=viewModelScope.launch {
            while(isActive && version==generation && !mutable.value.needsReconnect) {
                val session=mutable.value.session ?: break
                try {
                    val live=api.childLive(session)
                    if(version==generation) mutable.update { it.copy(childLive=live,childLiveError=null,childPair=if(live.session?.status=="AWAITING_CHILD") it.childPair else null) }
                } catch(e: Exception) {
                    if(e is CancellationException) throw e
                    if(version==generation) mutable.update { it.copy(childLive=null,childLiveError="아이 위치를 확인하지 못했어요. 마지막 위치를 현재 위치로 사용하지 않습니다.",needsReconnect=it.needsReconnect || e is GuardianApiException && e.code==401) }
                }
                delay(2000)
            }
        }
    }
    fun createChildSharing(consent: Boolean) {
        val session=mutable.value.session ?: return
        if(!consent || session.link.journeyType!=JourneyType.PICKUP || mutable.value.childSharingBusy || mutable.value.needsReconnect) return
        val version=generation
        childLiveJob?.cancel(); childLiveJob=null
        mutable.update { it.copy(childSharingBusy=true,childPair=null,childLive=null,childLiveError=null) }
        childAction=viewModelScope.launch {
            try {
                val pair=api.createChildSharing(session)
                if(version==generation) mutable.update { it.copy(childPair=pair) }
            } catch(e: Exception) {
                if(e is CancellationException) throw e
                if(version==generation) mutable.update { it.copy(childLiveError=message(e),needsReconnect=it.needsReconnect || e is GuardianApiException && e.code==401) }
            } finally { if(version==generation) { mutable.update { it.copy(childSharingBusy=false) }; startChildLivePolling() } }
        }
    }
    fun revokeChildSharing() {
        val session=mutable.value.session ?: return
        if(mutable.value.childSharingBusy || mutable.value.needsReconnect) return
        val version=generation
        childLiveJob?.cancel(); childLiveJob=null
        mutable.update { it.copy(childSharingBusy=true,childLive=null,childPair=null,childLiveError=null) }
        childAction=viewModelScope.launch {
            try { api.revokeChildSharing(session) }
            catch(e: Exception) {
                if(e is CancellationException) throw e
                if(version==generation) mutable.update { it.copy(childLiveError="서버에서 공유 해제를 확인하지 못했어요. 아이 휴대폰의 공유 중지도 눌러 주세요.",needsReconnect=it.needsReconnect || e is GuardianApiException && e.code==401) }
            } finally {
                if(version==generation) { mutable.update { it.copy(childSharingBusy=false) }; startChildLivePolling() }
            }
        }
    }
    fun reset() {
        generation++
        childLiveJob?.cancel(); childLiveJob=null; childAction?.cancel()
        operationJob?.cancel(); pendingIssue=null
        action?.cancel(); spotAction?.cancel(); roadAction?.cancel(); roadGeneration++; pollJob?.cancel(); pollJob=null
        mutable.value=GuardianUiState(restoring=false,busy=true)
        action=viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { storage.withLock { store.clear(); persistedSnapshot=null } }
                mutable.update { it.copy(busy=false) }
            } catch(e: Exception) {
                if(e is CancellationException) throw e
                mutable.update { it.copy(busy=false,error="기기에서 연결 정보를 지우지 못했습니다. 다시 초기화하세요.") }
            }
        }
    }
    private fun message(e: Exception): String = when(e) {
        is GuardianApiException -> e.message ?: "연결 상태를 확인하세요."
        is IllegalArgumentException -> e.message ?: "입력을 확인하세요."
        else -> "서버에 연결하지 못했습니다. 인터넷과 서버 주소를 확인한 뒤 다시 시도하세요."
    }
}
