import test from 'node:test';
import assert from 'node:assert/strict';
import { createShellState, reduceShell, SHELL_APPS } from './pleos-shell.mjs';
import { createInitialState, view } from './model.mjs';
import { REAL_ROUTE } from './route-data.mjs';
const apply = (state, ...actions) => actions.reduce(reduceShell, state);
test('every shell route can open, invalid routes cannot displace the current app', () => {
  for (const app of SHELL_APPS) {
    const state = reduceShell(createShellState(), { type: 'OPEN', app });
    assert.equal(state.app, app);
    assert.deepEqual(reduceShell(state, { type: 'OPEN', app: 'https://external.invalid' }), state);
  }
});
test('library and climate toggle back to their caller; nested app back returns through library', () => {
  const initial = createShellState();
  const library = apply(initial, { type: 'OPEN', app: 'hawon' }, { type: 'OPEN', app: 'library' });
  assert.equal(reduceShell(library, { type: 'OPEN', app: 'library' }).app, 'hawon');
  const media = reduceShell(library, { type: 'OPEN', app: 'media' });
  assert.equal(reduceShell(media, { type: 'BACK' }).app, 'library');
  const climate = reduceShell(media, { type: 'OPEN', app: 'climate' });
  assert.equal(reduceShell(climate, { type: 'OPEN', app: 'climate' }).app, 'media');
});
test('mock climate stays bounded, sync applies both ways, independent zones survive app changes', () => {
  let s = apply(createShellState(), { type: 'TEMP', side: 'driver', value: 100 }, { type: 'FAN', value: -8 });
  assert.equal(s.driver, 30); assert.equal(s.passenger, 30); assert.equal(s.fan, 0); assert.equal(s.auto, false);
  s = apply(s, { type: 'TOGGLE', key: 'sync' }, { type: 'TEMP', side: 'passenger', value: 19.5 }, { type: 'OPEN', app: 'phone' }, { type: 'OPEN', app: 'climate' });
  assert.equal(s.driver, 30); assert.equal(s.passenger, 19.5);
  assert.deepEqual(reduceShell(s, { type: 'TEMP', side: 'driver', value: NaN }), s);
  assert.equal(reduceShell(s, { type: 'TEMP', side: 'wrong', value: 18 }).wrong, undefined);
});
test('all seat levels cycle back off and media selection persists without affecting trip state', () => {
  const trip = createInitialState({ now: Date.parse('2026-10-26T00:00:00Z'), route: REAL_ROUTE });
  const before = JSON.stringify(trip);
  let s = createShellState();
  for (let i = 0; i < 4; i++) s = reduceShell(s, { type: 'SEAT', key: 'driverSeat' });
  assert.equal(s.driverSeat, 0);
  s = apply(s, { type: 'TRACK', step: -1 }, { type: 'TOGGLE', key: 'playing' }, { type: 'OPEN', app: 'navigation' }, { type: 'OPEN', app: 'media' });
  assert.equal(s.track, 2); assert.equal(s.playing, true);
  assert.equal(JSON.stringify(trip), before); assert.equal(view(trip).confirmed, false);
  assert.equal('progress' in s, false); assert.equal('gear' in s, false);
});
test('phone accepts only keypad characters, bounds input, and previews locally', () => {
  let s = createShellState();
  for (const digit of '01012345678') s = reduceShell(s, { type: 'DIGIT', digit });
  s = reduceShell(s, { type: 'DIGIT', digit: 'tel:01000000000' });
  assert.equal(s.digits, '01012345678');
  s = apply(s, { type: 'ERASE' }, { type: 'PHONE_PREVIEW' });
  assert.equal(s.phonePreview, '0101234567 · 번호 미리보기');
  for (let i = 0; i < 50; i++) s = reduceShell(s, { type: 'DIGIT', digit: '9' });
  assert.equal(s.digits.length, 20);
  assert.equal('call' in s, false);
});
