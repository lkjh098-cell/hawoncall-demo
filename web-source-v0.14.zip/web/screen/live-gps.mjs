import {pointInBoundary} from './seoul-boundary.mjs';
// v11 live location is deliberately isolated from the persistent demo domains.
export const LIVE_CHANNEL='hawoncall.live-gps.v11';
export const FIX_TTL=30000;
export const SESSION_TTL=1800000;
export function validFix(f,now=Date.now()) {return !!f&&['demo','gps'].includes(f.kind)&&Number.isFinite(f.lat)&&Number.isFinite(f.lon)&&Math.abs(f.lat)<=90&&Math.abs(f.lon)<=180&&Number.isFinite(f.accuracy)&&f.accuracy>0&&f.accuracy<=50&&Number.isFinite(f.observedAt)&&f.observedAt<=now+2000&&now-f.observedAt<=FIX_TTL;}
export function inMapScope(f){return !!f&&pointInBoundary([f.lon,f.lat]);}
export function usableFix(session,now=Date.now()){return !!session&&session.expiresAt>now&&validFix(session.fix,now)&&inMapScope(session.fix);}
export function acceptLive(current,packet,now=Date.now()){
 if(!packet||packet.version!==11||packet.domain!=='live-meeting'||typeof packet.owner!=='string'||typeof packet.sessionId!=='string'||!Number.isFinite(packet.expiresAt)||packet.expiresAt<=now||packet.expiresAt>now+SESSION_TTL+2000)return current;
 if(current&&current.expiresAt>now&&(current.owner!==packet.owner||current.sessionId!==packet.sessionId))return current;
 if(packet.stopped)return null;
 if(!validFix(packet.fix,now)||packet.fix.observedAt<(current?.fix?.observedAt||0))return current;
 return {owner:packet.owner,sessionId:packet.sessionId,expiresAt:packet.expiresAt,fix:{lat:packet.fix.lat,lon:packet.fix.lon,accuracy:packet.fix.accuracy,observedAt:packet.fix.observedAt,kind:packet.fix.kind}};
}
export function freezeTarget(session,gear,now=Date.now()) {return gear==='P'&&usableFix(session,now)?Object.freeze({...session.fix,sessionId:session.sessionId,expiresAt:session.expiresAt}):null;}
export function mayAdopt(target,current,gear,now=Date.now()){return gear==='P'&&!!target&&usableFix(current,now)&&target.sessionId===current.sessionId&&target.expiresAt>now&&validFix(target,now);}
export function parseRoadResponse(value){const r=value?.routes?.[0];if(value?.code!=='Ok'||r?.geometry?.type!=='LineString'||r.geometry.coordinates.length<2||!r.geometry.coordinates.every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite))||!Number.isFinite(r.distance)||r.distance<=0||!Number.isFinite(r.duration)||r.duration<=0)return null;return {coordinates:r.geometry.coordinates,totalMeters:r.distance,durationSeconds:r.duration};}
export function httpsBackend(value){try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.search&&!u.hash?u.origin+u.pathname.replace(/\/$/,''):null;}catch{return null;}}
