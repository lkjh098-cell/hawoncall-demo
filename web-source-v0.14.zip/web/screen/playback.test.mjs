import test from 'node:test';
import assert from 'node:assert/strict';
import {createInitialState,reduce,view} from './model.mjs';
import {REAL_ROUTE} from './route-data.mjs';
import {createDriveLoop,mayRepeatDrive,validPlaybackRate} from './drive-controls.mjs';
test('1x playback distance matches real road duration and presentation rates stay optional',()=>{
  for(const rate of [1,3,6]){let s=createInitialState({now:1000,route:REAL_ROUTE,playbackRate:rate});s=reduce(s,{type:'PLAY',now:1000});s=reduce(s,{type:'TICK',now:2000,dtMs:1000});assert.ok(Math.abs(s.progress-rate/REAL_ROUTE.durationSeconds)<1e-9);assert.equal(s.gear,'D');assert.equal(s.confirmed,false);}
  assert.equal(validPlaybackRate(10),false);
});
test('changing playback speed preserves position and cannot create arrival or confirmation',()=>{
  let s=createInitialState({now:1,route:REAL_ROUTE,playbackRate:1});s=reduce(s,{type:'PLAY',now:1});s=reduce(s,{type:'TICK',now:1001,dtMs:1000});const p=s.progress;
  s=reduce(s,{type:'PLAYBACK_RATE',rate:6,now:1001});assert.equal(s.progress,p);assert.equal(s.playbackRate,6);assert.equal(view(s).arrival,false);assert.equal(s.confirmed,false);
  s=reduce(s,{type:'RESET',now:1001});assert.equal(s.playbackRate,6);
});
test('continuous drive repeats from D approach only and cannot replay P or completed handoff',()=>{
  const base={near:true,gear:'D',playing:false,confirmed:false,arrival:false,routeMismatch:false,isFresh:true};let current=base,scheduled,restarts=0,cancelled=0;
  const loop=createDriveLoop({getJourney:()=>current,restart:()=>restarts++,schedule:fn=>{scheduled=fn;return 4;},cancel:()=>cancelled++});
  loop.observe(base);scheduled();assert.equal(restarts,1);
  for(const extra of [{gear:'P',arrival:true},{confirmed:true},{isFresh:false},{routeMismatch:true}])assert.equal(mayRepeatDrive({...base,...extra}),false);
  loop.observe(base);current={...base,gear:'P',arrival:true};scheduled();assert.equal(restarts,1);
  loop.observe(base);loop.interrupt();assert.ok(cancelled>0);loop.dispose();
});
