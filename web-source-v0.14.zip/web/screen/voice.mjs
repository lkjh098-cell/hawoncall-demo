// Platform browser TTS only; no AI/provider request, audio-focus or music-duck claim.
export function createBriefPlayer({engine=globalThis.speechSynthesis,Utterance=globalThis.SpeechSynthesisUtterance,onChange=()=>{}}={}) {
 let token=0, timer, utterance, status='대기',active=false,pending=false;
 const emit=message=>{status=message;onChange({status,active});};
 function stop(reason='안내를 멈췄어요'){token++;clearTimeout(timer);active=false;pending=false;utterance=null;try{engine?.cancel();}catch{}emit(reason);}
 function play(text,{onStart=()=>{}}={}) {
  if(!engine||!Utterance){emit('이 브라우저에서 음성 엔진을 사용할 수 없어요. 아래 안내문을 확인하세요.');return false;}
  stop('음성 준비 중');pending=true;const own=token;let started=false;utterance=new Utterance(text);utterance.lang='ko-KR';utterance.rate=1;
  const voices=engine.getVoices?.()||[];const voice=voices.find(v=>v.lang?.startsWith('ko')&&v.localService)||voices.find(v=>v.lang?.startsWith('ko'));
  if(voice)utterance.voice=voice;
  utterance.onstart=()=>{if(own!==token)return;clearTimeout(timer);started=true;pending=false;active=true;onStart();emit(`브라우저 음성 재생 중${voice?.localService?' · 한국어 기기 음성':''}`);};
  utterance.onend=()=>{if(own!==token)return;clearTimeout(timer);pending=false;active=false;utterance=null;emit(started?'브라우저 음성 안내 완료':'음성 시작을 확인하지 못했어요.');};
  utterance.onerror=e=>{if(own!==token)return;clearTimeout(timer);pending=false;active=false;utterance=null;emit(`음성 사용 불가 · ${e.error||'엔진 오류'} · 안내문을 확인하세요.`);};
  try{engine.speak(utterance);emit('브라우저 음성 시작 대기');timer=setTimeout(()=>{if(own===token&&!started)stop('음성 시작을 확인하지 못했어요. 안내문을 확인하세요.');},5000);return true;}catch{stop('음성 엔진 오류 · 안내문을 확인하세요.');return false;}
 }
 return {play,stop,get active(){return active;},get pending(){return pending;},get status(){return status;}};
}
