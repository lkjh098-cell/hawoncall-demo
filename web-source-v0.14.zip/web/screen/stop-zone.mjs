/** Presentation scenarios are explicit assumptions, never a road-regulation database. */
export function stopZoneNotice(journey, {scenario='prohibited', meetingPreview=false}={}) {
  if (!journey?.near || !journey.isFresh || journey.routeMismatch || journey.departed || meetingPreview) return null;
  const kind=['prohibited','allowed','unknown'].includes(scenario)?scenario:'unknown';
  const copy={
    prohibited:['주정차 금지구역이에요','이 지점에 정차하지 말고, 허용된 승하차 장소를 확인해 주세요.','금지 구역 가정','⊘'],
    allowed:['주정차 가능구역이에요','허용 구역·시간을 확인하고, 정차한 뒤 P로 전환해 주세요.','가능 구역 가정','P'],
    unknown:['주정차 가능 여부를 확인해 주세요','현장 표지와 운영 시간을 확인한 뒤 승하차 장소를 정해 주세요.','구역 정보 없음','!'],
  }[kind];
  const detail=journey.arrival&&kind==='allowed'?'정차 상태를 확인했어요. 아이의 탑승·인계는 보호자가 직접 확인해 주세요.':journey.arrival&&kind==='prohibited'?'P로 전환해도 정차 허용으로 바뀌지 않아요. 허용된 지점을 확인해 주세요.':copy[1];
  return {kind,title:copy[0],detail,scenario:copy[2],symbol:copy[3],phase:journey.arrival?'도착지 안내 · P 정차':'도착지 근처 · D 접근',basis:'시연 시나리오 · 실제 도로 규제 미확인',actualPermission:'unknown'};
}

export function mountStopZone({getJourney,hasMeetingPreview=()=>false,guardianOnly=false}={}) {
  if(guardianOnly)return {render(){},getScenario:()=> 'unknown'};
  const nav=document.querySelector('.navigation'),shell=document.querySelector('#vehicleView');
  const notice=document.createElement('section');notice.id='stopZoneNotice';notice.className='stop-zone-notice';notice.hidden=true;notice.setAttribute('role','status');notice.setAttribute('aria-label','도착지 주정차 안내');
  const icon=document.createElement('b');icon.className='stop-zone-symbol';icon.setAttribute('aria-hidden','true');
  const body=document.createElement('div');body.className='stop-zone-copy';
  const phase=document.createElement('span');phase.className='stop-zone-phase';
  const title=document.createElement('h2');title.id='stopZoneTitle';
  const detail=document.createElement('p');const basis=document.createElement('small');basis.className='stop-zone-basis';
  body.append(phase,title,detail,basis);notice.append(icon,body);nav.append(notice);
  const control=document.createElement('section');control.className='stop-zone-control';control.setAttribute('aria-label','도착지 주정차 시나리오');
  control.innerHTML='<label for="stopZoneScenario">도착지 주정차 안내 <small>가상 시나리오</small></label><select id="stopZoneScenario"><option value="prohibited">금지구역 가정</option><option value="allowed">가능구역 가정</option><option value="unknown">정보 없음 · 확인 필요</option></select><p>도착지 150m 이내에서 안내해요. 실제 도로의 규제 판정은 아직 연결되지 않았어요.</p>';
  document.querySelector('#simulationDrawer').append(control);
  const selector=control.querySelector('select');
  let signature='';
  function render(journey=getJourney()){
    const v=stopZoneNotice(journey,{scenario:selector.value,meetingPreview:hasMeetingPreview()});
    shell.classList.toggle('has-stop-notice',!!v);notice.hidden=!v;
    if(!v){signature='';return;}
    const next=JSON.stringify(v);if(signature===next)return;signature=next;
    notice.dataset.kind=v.kind;icon.textContent=v.symbol;phase.textContent=`${v.phase} · ${v.scenario}`;title.textContent=v.title;detail.textContent=v.detail;basis.textContent=v.basis;
  }
  selector.onchange=()=>render();
  return {render,getScenario:()=>selector.value,setScenario:value=>{selector.value=['prohibited','allowed','unknown'].includes(value)?value:'unknown';render();}};
}
