import test from 'node:test';
import assert from 'node:assert/strict';
import {drivingMotionSnapshot, drivingLaneDash, drivingTrafficPose, drivingRoadForProgress, drivingRoadPoint, drivingRoadGeometry} from './pleos-shell.mjs';
import {REAL_ROUTE} from './route-data.mjs';
import {pointAlongRoute, navigationPoseForProgress} from './real-map.mjs';

const trip = {gear:'D', playing:true, speedKph:36, progress:.25, playbackRate:1, route:{totalMeters:2400}};
test('visual clock follows route distance and interpolates the real playback interval', () => {
  assert.equal(drivingMotionSnapshot(trip).travel, 600);
  assert.equal(drivingMotionSnapshot(trip, 300).travel, 603);
  assert.equal(drivingMotionSnapshot({...trip, playbackRate:3}, 300).travel, 609);
  assert.equal(drivingMotionSnapshot({...trip, playbackRate:6}, 300).travel, 618);
  // A suspended tab cannot cause an unbounded leap while its state is stale.
  assert.equal(drivingMotionSnapshot(trip, 50_000).travel, 603.3);
});
test('pause with a retained speedometer reading, P, and arrival all freeze the scene', () => {
  for (const patch of [{playing:false}, {gear:'P'}, {near:true}, {arrival:true}, {confirmed:true}, {speedKph:0}, {routeMismatch:true}]) {
    const v = {...trip, ...patch};
    assert.equal(drivingMotionSnapshot(v, 300).active, false);
    assert.equal(drivingMotionSnapshot(v, 300).travel, drivingMotionSnapshot(v).travel);
  }
});
test('road marks travel toward the viewer and grow with perspective', () => {
  for (const side of [-1,1]) {
    const before = drivingLaneDash(0, 4, side), after = drivingLaneDash(7, 4, side);
    assert.ok(after[1][1] > before[1][1], 'mark must flow down from horizon');
    assert.ok(after[1][1] - after[0][1] > before[1][1] - before[0][1], 'fixed road length grows toward viewer');
    assert.ok(Math.abs(after[1][0]-206) > Math.abs(before[1][0]-206), 'mark follows widening lane perspective');
    assert.deepEqual(drivingLaneDash(224,4,side), before, 'wrapping preserves the evenly spaced road');
  }
});
test('adjacent vehicles move relatively along their lanes and remain finite over repeated journeys', () => {
  for (const index of [0,1]) {
    const start = drivingTrafficPose(0,index), later = drivingTrafficPose(20,index);
    assert.ok(later.y > start.y); assert.ok(later.scale > start.scale);
    assert.ok(index ? later.x > start.x : later.x < start.x);
    for (let travel=0; travel<=2400; travel+=.7) {
      const p = drivingTrafficPose(travel,index);
      assert.ok(Object.values(p).every(Number.isFinite));
      assert.ok(p.opacity >= 0 && p.opacity <= 1);
      assert.ok(p.y >=110 && p.y <=580);
    }
  }
});

const metersRoute = points => points.map(([east, north]) => [127 + east / (111195 * Math.cos(37 * Math.PI / 180)), 37 + north / 111195]);
test('geographic right and left turns bend the whole vehicle-local road in the recorded direction', () => {
  const right = metersRoute([[0,0], [0,70], [150,70]]), left = metersRoute([[0,0], [0,70], [-150,70]]);
  const r = drivingRoadForProgress(right, 0), l = drivingRoadForProgress(left, 0);
  assert.ok(drivingRoadPoint(r, 140)[0] > 260);
  assert.ok(drivingRoadPoint(l, 140)[0] < 152);
  assert.deepEqual(drivingRoadPoint(r, 0), [206, 580], 'road is anchored underneath vehicle');
  for (const road of [r,l]) {
    const shape = drivingRoadGeometry(road);
    assert.ok(Object.values(shape).every(path => !/NaN|Infinity/.test(path)));
    assert.notEqual(shape.surface, drivingRoadGeometry(null).surface);
    assert.notEqual(shape.edges, drivingRoadGeometry(null).edges);
    for (const side of [-1,1]) {
      const straight = drivingLaneDash(0,10,side), bent = drivingLaneDash(0,10,side,road);
      const near = 140, shift = drivingRoadPoint(road, near)[0] - 206;
      assert.ok(Math.abs((bent[1][0] - straight[1][0]) - shift) < 1e-8);
    }
    const trafficTravel = (28 - 140) / .17;
    const straightCar = drivingTrafficPose(trafficTravel,0), bentCar = drivingTrafficPose(trafficTravel,0,road);
    assert.ok(Math.abs((bentCar.x - straightCar.x) - (drivingRoadPoint(road,140)[0] - 206)) < 1e-8);
  }
  const after = drivingRoadForProgress(right, .6);
  assert.ok(Math.abs(drivingRoadPoint(after, 100)[0] - 206) < .1, 'completed turn becomes a straight road relative to new heading');
});
test('an actual S route changes lateral direction without a scripted oscillation', () => {
  const route = metersRoute([[0,0],[0,40],[45,40],[45,75],[-45,75],[-45,180]]);
  const road = drivingRoadForProgress(route, 0);
  assert.ok(drivingRoadPoint(road,90)[0] > 230);
  assert.ok(drivingRoadPoint(road,220)[0] < 180);
  for (let progress=0; progress<=1; progress+=.01) {
    const r = drivingRoadForProgress(route,progress);
    for (let meters=0; meters<=240; meters+=4) {
      const [x,y] = drivingRoadPoint(r,meters), halfWidth=23+183/(1+meters/18);
      // Near corners may carry the shoulder beyond the cropped illustration, but
      // the road center and all preview lane markings stay within its viewport.
      assert.ok(x>98 && x<314 && y>=110 && y<=580);
      assert.ok(Number.isFinite(halfWidth));
    }
  }
});
test('recorded Tehran-ro right turn matches the map bearing before, during, and after maneuver', () => {
  const before=drivingRoadForProgress(REAL_ROUTE.coordinates,.30);
  assert.ok(drivingRoadPoint(before,80)[0]>260, 'right turn is visible before the car reaches the corner');
  const during=drivingRoadForProgress(REAL_ROUTE.coordinates,.31);
  assert.equal(during.heading,navigationPoseForProgress(REAL_ROUTE.coordinates,.31).heading);
  const after=drivingRoadForProgress(REAL_ROUTE.coordinates,.33);
  assert.ok(Math.abs(drivingRoadPoint(after,80)[0]-206)<2, 'new Samsung-ro heading straightens the preview');
  const turn=REAL_ROUTE.steps.find(s=>s.maneuver?.type==='turn');
  assert.equal(turn.maneuver.modifier,'right');
  assert.ok(pointAlongRoute(REAL_ROUTE.coordinates,.30).segmentIndex < pointAlongRoute(REAL_ROUTE.coordinates,.33).segmentIndex);
});

test('SVG bridge replaces static lane strokes, animates each frame, and cancels immediately on pause', async () => {
  const {updatePleosShell} = await import('./pleos-shell.mjs');
  class Node {
    constructor(tag) { this.tagName=tag; this.children=[]; this.attrs={}; this.dataset={}; this.namespaceURI='http://www.w3.org/2000/svg'; this.classList={toggle(){}}; }
    append(n) { n.parent=this; this.children.push(n); }
    setAttribute(k,v) { this.attrs[k]=v; }
    replaceWith(n) { n.parent=this.parent; this.parent.children.splice(this.parent.children.indexOf(this),1,n); }
    querySelector(selector) { return selector==='#egoCar'?ego:selector==='[stroke-dasharray]'?dash:selector==='.driving-scene'?scene:null; }
  }
  const scene=new Node('svg'), face=new Node('path'), edges=new Node('path'), dash=new Node('path'), near=new Node('path'), left=new Node('g'), right=new Node('g'), ego=new Node('g'), shell=new Node('section');
  for (const n of [face,edges,dash,near,left,right,ego]) scene.append(n);
  const routeTrip={...trip,progress:.30,route:REAL_ROUTE,motionCoordinates:REAL_ROUTE.coordinates};
  const frames=new Map(); let frameId=0;
  const saved={document:globalThis.document,requestAnimationFrame:globalThis.requestAnimationFrame,cancelAnimationFrame:globalThis.cancelAnimationFrame};
  globalThis.document={hidden:false,getElementById:id=>id==='vehicleView'?shell:null,createElementNS:(_,tag)=>new Node(tag)};
  globalThis.requestAnimationFrame=callback=>{frames.set(++frameId,callback);return frameId;};
  globalThis.cancelAnimationFrame=id=>frames.delete(id);
  try {
    const at=performance.now(); updatePleosShell(routeTrip);
    assert.equal(scene.children.includes(dash),false);
    const lane=scene.children.find(n=>n.id==='drivingLaneFlow'), startMark=lane.children[4].attrs.points, startCar=left.attrs.transform, startRoad=face.attrs.d;
    assert.equal(scene.children.filter(n=>n.id==='drivingRoadSurface').length,1);
    assert.equal(ego.attrs.transform,'translate(206 402)');
    assert.notEqual(edges.attrs.d,drivingRoadGeometry(null).edges);
    assert.equal(lane.children.length,32); assert.equal(frames.size,1);
    const callback=frames.values().next().value; frames.clear(); callback(at+200);
    assert.notEqual(lane.children[4].attrs.points,startMark); assert.notEqual(left.attrs.transform,startCar);
    assert.notEqual(face.attrs.d,startRoad,'road bend follows interpolated authoritative route progress');
    assert.equal(frames.size,1);
    updatePleosShell({...routeTrip,progress:.301,playing:false});
    const pausedCar=left.attrs.transform, pausedRoad=face.attrs.d, pausedMark=lane.children[4].attrs.points;
    assert.equal(scene.dataset.motion,'paused'); assert.equal(frames.size,0);
    updatePleosShell({...routeTrip,progress:.301,playing:false});
    assert.equal(left.attrs.transform,pausedCar); assert.equal(frames.size,0);
    assert.equal(face.attrs.d,pausedRoad); assert.equal(lane.children[4].attrs.points,pausedMark);
    updatePleosShell({...routeTrip,progress:.301,gear:'P'});
    assert.equal(face.attrs.d,pausedRoad); assert.equal(left.attrs.transform,pausedCar); assert.equal(frames.size,0);
  } finally {
    for (const [key,value] of Object.entries(saved)) { if(value===undefined)delete globalThis[key];else globalThis[key]=value; }
  }
});
