import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState, reduce, view, scenarioPosition } from './model.mjs';

const initial = () => createInitialState({ now: 1_000 });
const step = (s, type, rest = {}) => reduce(s, { type, ...rest });
const arrived = () => step(step(initial(), 'APPROACH'), 'PARK');
const candidate = () => step(arrived(), 'SENSOR');

test('initial route and map geometry stay immutable through every manual step', () => {
  let s = initial();
  const route = s.route;
  assert.ok(Object.isFrozen(route));
  assert.ok(Object.isFrozen(route.points));
  for (const type of ['DRIVE', 'APPROACH', 'PARK', 'SENSOR', 'CONFIRM', 'DEPART', 'RESET']) {
    s = step(s, type);
    assert.equal(s.route, route);
  }
  assert.throws(() => { route.id = 'other'; }, TypeError);
});

test('reducers leave the previous state unchanged', () => {
  const before = initial();
  const after = step(before, 'DRIVE');
  assert.equal(before.gear, 'P');
  assert.equal(before.progress, 0);
  assert.equal(after.gear, 'D');
});

test('autonomous playback stops at 150m in D with no arrival or boarding', () => {
  let s = step(initial(), 'PLAY');
  for (let i = 1; i <= 30; i++) s = step(s, 'TICK', { now: 1_000 + i * 1_000, dtMs: 1_000 });
  const v = view(s);
  assert.equal(v.remainingMeters, 150);
  assert.equal(v.gear, 'D');
  assert.equal(v.speedKph, 0);
  assert.equal(v.playing, false);
  assert.equal(v.arrival, false);
  assert.equal(v.candidate, false);
  assert.equal(v.confirmed, false);
});

test('nearby vehicle in D cannot declare arrival or accept sensor/guardian confirmation', () => {
  let s = step(initial(), 'APPROACH');
  s = step(step(s, 'SENSOR'), 'CONFIRM');
  assert.equal(view(s).arrival, false);
  assert.equal(s.candidate, false);
  assert.equal(s.confirmed, false);
});

test('P far from destination is insufficient for arrival', () => {
  const v = view(step(initial(), 'PARK'));
  assert.equal(v.arrival, false);
  assert.equal(v.canConfirm, false);
});

test('fresh near P declares arrival without automatically confirming boarding', () => {
  const v = view(arrived());
  assert.equal(v.arrival, true);
  assert.equal(v.stage, 'arrived');
  assert.equal(v.confirmed, false);
  assert.equal(v.canConfirm, false);
});

test('sensor establishes candidate only and explicit guardian confirmation completes', () => {
  const s = candidate();
  assert.equal(view(s).canConfirm, true);
  assert.equal(s.confirmed, false);
  const confirmed = step(s, 'CONFIRM', { now: 2_000 });
  assert.equal(confirmed.confirmed, true);
  assert.equal(confirmed.confirmedAt, 2_000);
  assert.equal(confirmed.candidate, false);
  assert.equal(view(confirmed).canConfirm, false);
});

test('guardian confirmation requires a boarding candidate', () => {
  assert.equal(step(arrived(), 'CONFIRM').confirmed, false);
});

test('repeated guardian confirmation preserves its original timestamp', () => {
  const s = step(candidate(), 'CONFIRM', { now: 2_000 });
  const next = step(s, 'CONFIRM', { now: 3_000 });
  assert.equal(next.confirmedAt, 2_000);
  assert.equal(next.confirmed, true);
});

test('30 second freshness boundary expires and closes existing candidate', () => {
  const s = candidate();
  assert.equal(view(step(s, 'TICK', { now: 31_000 })).isFresh, true);
  const expired = step(s, 'TICK', { now: 31_001 });
  assert.equal(view(expired).stage, 'stale');
  assert.equal(view(expired).arrival, false);
  assert.equal(expired.candidate, false);
  assert.equal(step(expired, 'CONFIRM').confirmed, false);
});

test('leaving P invalidates candidate and a later P needs a new sensor event', () => {
  const s = step(candidate(), 'VEHICLE', { snapshot: { gear: 'D', speedKph: 0, timestamp: 1_000 } });
  assert.equal(s.candidate, false);
  const parked = step(s, 'VEHICLE', { snapshot: { gear: 'P', timestamp: 2_000 }, now: 2_000 });
  assert.equal(view(parked).arrival, true);
  assert.equal(step(parked, 'CONFIRM').confirmed, false);
});

test('changed external route invalidates pickup without replacing fixed route', () => {
  const s = candidate();
  const changed = step(s, 'NAVIGATION', { snapshot: { routeId: 'another-route', progress: 1, timestamp: 2_000 }, now: 2_000 });
  assert.equal(changed.route, s.route);
  assert.equal(changed.progress, s.progress);
  assert.equal(changed.confirmed, false);
  assert.equal(view(changed).stage, 'route-changed');
  assert.equal(view(step(changed, 'PARK')).canConfirm, false);
});

test('external snapshots update only observations, never guardian completion', () => {
  const s = step(initial(), 'NAVIGATION', { snapshot: { routeId: initial().route.id, remainingMeters: 30, timestamp: 2_000 }, now: 2_000 });
  const parked = step(s, 'VEHICLE', { snapshot: { gear: 'P', speedKph: 40, timestamp: 2_000 } });
  assert.equal(view(parked).arrival, true);
  assert.equal(parked.speedKph, 0);
  assert.equal(parked.confirmed, false);
  assert.equal(parked.candidate, false);
});

test('out-of-order external observations cannot overwrite a newer vehicle gear', () => {
  const s = step(candidate(), 'VEHICLE', { now: 3_000, snapshot: { gear: 'D', timestamp: 3_000 } });
  const old = step(s, 'VEHICLE', { snapshot: { gear: 'P', timestamp: 2_000 } });
  assert.equal(old.gear, 'D');
  assert.equal(old.vehicleAt, 3_000);
});

test('future or stale snapshot timestamp fails the freshness gate', () => {
  const stale = step(arrived(), 'NAVIGATION', { now: 50_000, snapshot: { remainingMeters: 10, timestamp: 1_000 } });
  assert.equal(view(stale).arrival, false);
  const future = step(arrived(), 'VEHICLE', { snapshot: { gear: 'P', timestamp: 99_000 } });
  assert.equal(view(future).isFresh, false);
});

test('departure retains a completed guardian record but closes arrival and candidate', () => {
  const s = step(step(candidate(), 'CONFIRM'), 'DEPART');
  assert.equal(view(s).stage, 'departed');
  assert.equal(view(s).arrival, false);
  assert.equal(view(s).canConfirm, false);
  assert.equal(s.confirmed, true);
});

test('map position clamps both bounds and route progress is always 0..1', () => {
  assert.deepEqual(scenarioPosition(-5), scenarioPosition(0));
  assert.deepEqual(scenarioPosition(5), scenarioPosition(1));
  let s = step(initial(), 'NAVIGATION', { snapshot: { progress: 9 } });
  assert.equal(s.progress, 1);
  s = step(s, 'NAVIGATION', { snapshot: { progress: -9 } });
  assert.equal(s.progress, 0);
});

test('reset preserves route identity and clears all session confirmation state', () => {
  const s = step(candidate(), 'CONFIRM');
  const reset = step(s, 'RESET', { now: 9_000 });
  assert.equal(reset.route, s.route);
  assert.equal(reset.confirmedAt, null);
  assert.equal(reset.confirmed, false);
  assert.equal(reset.candidate, false);
  assert.equal(reset.gear, 'P');
  assert.equal(reset.progress, 0);
});


test('display rounding never admits a vehicle farther than 100m', () => {
  const s = step(arrived(), 'NAVIGATION', { snapshot: { routeId: initial().route.id, remainingMeters: 100.1, timestamp: 1_000 } });
  assert.equal(view(s).remainingMeters, 100);
  assert.equal(view(s).near, true);
  assert.equal(view(s).arrival, false);
});

test('external navigation ETA is displayed without fabricating confirmation', () => {
  const s = step(initial(), 'NAVIGATION', { snapshot: { remainingMeters: 600, etaSeconds: 240, timestamp: 1_000 } });
  assert.equal(view(s).etaSeconds, 240);
  assert.equal(s.confirmed, false);
});


test('manual PARK rolls from approach to 35m; observed P at150m does not arrive', () => {
  const approach = step(initial(), 'APPROACH');
  const observedPark = step(approach, 'VEHICLE', { snapshot: { gear: 'P', timestamp: 1_000 } });
  assert.equal(view(observedPark).remainingMeters, 150);
  assert.equal(view(observedPark).arrival, false);
  const manualPark = step(approach, 'PARK');
  assert.equal(view(manualPark).remainingMeters, 35);
  assert.equal(view(manualPark).arrival, true);
});

test('unknown, R, N and missing gear all close the confirmation gate', () => {
  for (const gear of ['UNKNOWN', 'R', 'N', undefined]) {
    const s = step(candidate(), 'VEHICLE', { snapshot: { gear, timestamp: 1_000 } });
    assert.equal(s.gear, 'UNKNOWN');
    assert.equal(s.candidate, false);
    assert.equal(view(s).arrival, false);
    assert.equal(step(s, 'CONFIRM').confirmed, false);
  }
});

test('missing external timestamps never manufacture freshness', () => {
  const vehicle = step(candidate(), 'VEHICLE', { snapshot: { gear: 'P' } });
  assert.equal(view(vehicle).isFresh, false);
  assert.equal(vehicle.candidate, false);
  const nav = step(candidate(), 'NAVIGATION', { snapshot: { routeId: initial().route.id, remainingMeters: 35 } });
  assert.equal(view(nav).isFresh, false);
  assert.equal(nav.candidate, false);
});

test('missing route identity or position closes an externally observed arrival', () => {
  for (const snapshot of [{ remainingMeters: 35, timestamp: 1_000 }, { routeId: initial().route.id, timestamp: 1_000 }]) {
    const s = step(candidate(), 'NAVIGATION', { snapshot });
    assert.equal(view(s).arrival, false);
    assert.equal(s.candidate, false);
  }
});

test('confirmed guardian history survives route change and freshness expiry', () => {
  const confirmed = step(candidate(), 'CONFIRM', { now: 2_000 });
  const changed = step(confirmed, 'NAVIGATION', { now: 3_000, snapshot: { routeId: 'changed', progress: 1, timestamp: 3_000 } });
  const old = step(changed, 'TICK', { now: 90_000 });
  assert.equal(old.confirmed, true);
  assert.equal(old.confirmedAt, 2_000);
  assert.equal(view(old).stage, 'confirmed');
  assert.equal(view(old).arrival, false);
});


test('simulation HEARTBEAT preserves a parked candidate and refreshes only its timestamps', () => {
  const s = candidate();
  const beat = step(s, 'HEARTBEAT', { now: 40_000 });
  assert.equal(beat.navAt, 40_000);
  assert.equal(beat.vehicleAt, 40_000);
  assert.equal(view(beat).arrival, true);
  for (const key of ['progress', 'gear', 'speedKph', 'candidate', 'confirmed', 'confirmedAt', 'playing']) assert.equal(beat[key], s[key]);
});

test('HEARTBEAT never refreshes either observation in a mixed or external session', () => {
  const parked = candidate();
  const mixed = step(parked, 'VEHICLE', { snapshot: { gear: 'P', timestamp: 1_000 } });
  const external = step(mixed, 'NAVIGATION', { snapshot: { routeId: parked.route.id, remainingMeters: 35, timestamp: 1_000 } });
  for (const s of [mixed, external]) {
    const beat = step(s, 'HEARTBEAT', { now: 40_000 });
    assert.equal(beat.navAt, 1_000);
    assert.equal(beat.vehicleAt, 1_000);
    assert.equal(beat.candidate, s.candidate);
    assert.equal(beat.confirmed, s.confirmed);
    assert.equal(view(beat).arrival, false);
  }
});

test('HEARTBEAT cannot refresh a route mismatch even after simulation director inputs', () => {
  let s = step(candidate(), 'NAVIGATION', { snapshot: { routeId: 'changed', remainingMeters: 35, timestamp: 1_000 } });
  s = step(s, 'PARK', { now: 2_000 });
  assert.equal(s.navSource, 'simulation');
  assert.equal(s.vehicleSource, 'simulation');
  const beat = step(s, 'HEARTBEAT', { now: 40_000 });
  assert.equal(beat.navAt, 2_000);
  assert.equal(beat.vehicleAt, 2_000);
  assert.equal(view(beat).arrival, false);
});
