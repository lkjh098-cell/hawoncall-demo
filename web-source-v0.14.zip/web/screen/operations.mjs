// Synthetic, public v0.10 operations. Meeting guidance never grants parking permission.
export const READINESS_FRESH_MS = 5 * 60_000;
export const ISSUE_KINDS = Object.freeze({NO_STOP_SPACE:'정차 공간 없음',CHILD_DELAYED:'아이 준비 지연',ALTERNATE_POINT_REQUEST:'다른 장소 요청',CANCEL_REQUEST:'일정 취소 요청'});
const plain=(s,max)=>typeof s==='string'&&s.length<=max&&!/[<>\u0000-\u001f]/.test(s);
export function serviceDate(now=Date.now()) {return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);}
export function validDate(s){if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;const d=new Date(s+'T00:00:00Z');return Number.isFinite(+d)&&d.toISOString().slice(0,10)===s;}
export function validateDayPlan(p){return !!p&&validDate(p.serviceDate)&&p.source==='guardian-demo'&&Array.isArray(p.items)&&p.items.length<=8&&p.items.every(i=>i&&/^([01]\d|2[0-3]):[0-5]\d$/.test(i.time)&&plain(i.title,48)&&i.title.trim().length>0&&plain(i.note??'',80))&&plain(p.reminder??'',120);}
export function demoDayPlan(now=Date.now()){return {serviceDate:serviceDate(now),source:'guardian-demo',items:[{time:'17:30',title:'가상 도서관 방문',note:'책 반납'},{time:'18:30',title:'가상 가족 저녁',note:''}],reminder:'가상 준비물: 물병을 챙겨 주세요.'};}
export function meetingPoint(route){return {label:'대치동 만남 지점 · 가상 기관',entranceHint:'저장된 도로 경로의 끝 · 출입구 확인 필요',meetingNotes:'도로 경로 끝을 만남 안내로 사용한 시연입니다. 담당자에게 실제 출입구와 정차 가능 여부를 확인하세요.',coordinates:route.coordinates.at(-1),permission:'UNVERIFIED',permissionReason:'허용 근거·시간대 미확인 · 검증된 지점 0개',source:'저장된 OSRM 경로 끝 / 가상 기관 안내'};}
export function validateReadiness(r){return !!r&&['PREPARING','READY','DELAYED'].includes(r.status)&&Number.isFinite(r.declaredAt)&&typeof r.tripId==='string'&&(r.status==='READY'||(Number.isFinite(r.readyInMinutes)&&r.readyInMinutes>=0&&r.readyInMinutes<=120));}
export function readinessEstimate(r,journey,now=Date.now()){
 if(!r||r.tripId!==journey.tripId)return {available:false,reason:'기관 준비 정보 없음',status:'미수신'};
 const status={PREPARING:'준비 중',READY:'준비 완료',DELAYED:'준비 지연'}[r.status]||'미확인';
 if(!validateReadiness(r)||now<r.declaredAt)return {available:false,reason:'기관 선언 시간·형식 미확인',status};
 if(now-r.declaredAt>READINESS_FRESH_MS)return {available:false,reason:'기관 선언 5분 경과 · 다시 확인 필요',status};
 if(!journey.isFresh||journey.routeMismatch||!Number.isFinite(journey.etaSeconds))return {available:false,reason:'신선한 차량 ETA 없음',status};
 const readySeconds=r.status==='READY'?0:Math.max(0,r.readyInMinutes*60-(now-r.declaredAt)/1000);
 return {available:true,status,readyMinutes:Math.ceil(readySeconds/60),etaMinutes:Math.ceil(journey.etaSeconds/60),waitMinutes:Math.ceil(Math.max(0,readySeconds-journey.etaSeconds)/60),ageSeconds:Math.floor((now-r.declaredAt)/1000),reason:'가상 차량 ETA + 기관 선언 · 실제 경과시간 반영'};
}
export function createIssue({id,kind,message='',tripId,actor,now=Date.now()}){if(!id||!ISSUE_KINDS[kind]||!['car','guardian'].includes(actor)||!plain(message,120)||typeof tripId!=='string')return null;return {id,kind,message,tripId,actor,createdAt:now,status:'OPEN',reply:'',respondedAt:null};}
export function validateIssue(i){return !!i&&typeof i.id==='string'&&i.id.length<=120&&ISSUE_KINDS[i.kind]&&['car','guardian'].includes(i.actor)&&typeof i.tripId==='string'&&plain(i.message,120)&&Number.isFinite(i.createdAt)&&['OPEN','ACKNOWLEDGED','RESOLVED','DECLINED'].includes(i.status)&&plain(i.reply,160);}
export function applyIssue(list,issue){if(!validateIssue(issue))return list;const old=list.find(i=>i.id===issue.id);if(old&&(old.tripId!==issue.tripId||old.kind!==issue.kind||old.createdAt!==issue.createdAt||old.actor!==issue.actor||old.message!==issue.message||((old.respondedAt??0)>=(issue.respondedAt??0))))return list;return [...list.filter(i=>i.id!==issue.id),issue];}
export function respondIssue(i,status,reply,now=Date.now()){if(!validateIssue(i)||!['ACKNOWLEDGED','RESOLVED','DECLINED'].includes(status)||!plain(reply,160)||!reply.trim())return null;return {...i,status,reply,respondedAt:Math.max(now,(i.respondedAt??0)+1)};}
export function buildBrief(plan,journey,{now=Date.now(),phase='outbound'}={}){
 if(!validateDayPlan(plan)||plan.serviceDate!==serviceDate(now))return {text:'오늘 날짜로 등록된 일정이 없어요.',items:[],available:false};
 if(phase==='after-pickup'&&(journey.mode!=='pickup'||!journey.confirmed))return {text:'보호자의 직접 탑승 확인 후 안내해요.',items:[],available:false};
 const hhmm=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Seoul',hour:'2-digit',minute:'2-digit',hour12:false}).format(now);
 const items=[...plan.items].filter(i=>i.time>=hhmm).sort((a,b)=>a.time.localeCompare(b.time)).slice(0,3);
 const intro=phase==='after-pickup'?'탑승 후 일정 안내입니다.':'오늘 다음 일정 안내입니다.';
 const detail=items.length?items.map(i=>`${i.time.replace(':','시 ')}분, ${i.title}.`).join(' '):'오늘 남은 일정은 없어요.';
 return {text:`${intro} ${detail}${plan.reminder?' 알림. '+plan.reminder:''}`.slice(0,380),items,available:!!(items.length||plan.reminder)};
}
export function briefKey(journey,phase){return `${journey.tripId}:${phase}`;}
export function mayAutoBrief(journey,phase,played){return !journey.routeMismatch&&!played.has(briefKey(journey,phase))&&(phase==='outbound'? !journey.confirmed :journey.mode==='pickup'&&journey.confirmed);}
