/** Real road geometry helpers. Coordinates are GeoJSON [longitude, latitude].
 * This module neither accesses the DOM nor requests routing until createRoadMap is called.
 */
const R = 6371008.8;
const radians = n => n * Math.PI / 180;
const clamp = n => Math.min(1, Math.max(0, Number.isFinite(n) ? n : 0));
const geometryCache = new WeakMap();
const guidanceCache = new WeakMap();
export function metersBetween(a, b) {
  const dl = radians(b[0] - a[0]), dp = radians(b[1] - a[1]);
  const h = Math.sin(dp / 2) ** 2 + Math.cos(radians(a[1])) * Math.cos(radians(b[1])) * Math.sin(dl / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(Math.min(1, h)));
}
function geometry(coordinates) {
  if (!Array.isArray(coordinates) || coordinates.length < 2) throw new TypeError('Route requires at least two geographic coordinates.');
  if (geometryCache.has(coordinates)) return geometryCache.get(coordinates);
  const distances = [0];
  for (let i = 1; i < coordinates.length; i++) distances.push(distances[i - 1] + metersBetween(coordinates[i - 1], coordinates[i]));
  const result = {distances, total: distances.at(-1)};
  geometryCache.set(coordinates, result);
  return result;
}
/** Distance-based interpolation, not equally timed jumps between geometry vertices. */
export function pointAlongRoute(coordinates, progress = 0) {
  const {distances, total} = geometry(coordinates), target = clamp(progress) * total;
  let lo = 0, hi = coordinates.length - 1;
  while (lo + 1 < hi) { const mid = (lo + hi) >> 1; if (distances[mid] <= target) lo = mid; else hi = mid; }
  const a = coordinates[lo], b = coordinates[hi], segment = distances[hi] - distances[lo];
  const t = segment ? Math.min(1, (target - distances[lo]) / segment) : 0;
  const lon = a[0] + (b[0] - a[0]) * t, lat = a[1] + (b[1] - a[1]) * t;
  const dlon = radians(b[0] - a[0]), p1 = radians(a[1]), p2 = radians(b[1]);
  const heading = (Math.atan2(Math.sin(dlon) * Math.cos(p2), Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dlon)) * 180 / Math.PI + 360) % 360;
  return {lat, lon, heading, distanceMeters: target, segmentIndex: lo};
}
/** A short geographic tangent softens road-vertex heading changes without moving
 * the vehicle off its recorded road. Both camera and marker use this same pose. */
export function navigationPoseForProgress(coordinates, progress = 0) {
  const p = pointAlongRoute(coordinates, progress), {total} = geometry(coordinates);
  const span = Math.min(12, total / 4) / (total || 1);
  const a = pointAlongRoute(coordinates, clamp(progress) - span);
  const b = pointAlongRoute(coordinates, clamp(progress) + span);
  return {...p, heading: pointAlongRoute([[a.lon, a.lat], [b.lon, b.lat]], .5).heading};
}
function projectOnRoute(coordinates, location, minimum = 0) {
  const {distances} = geometry(coordinates), cos = Math.cos(radians(location[1]));
  let best = {distance: Infinity, along: minimum};
  for (let i = 0; i < coordinates.length - 1; i++) {
    if (distances[i + 1] + 0.1 < minimum) continue;
    const a = coordinates[i], b = coordinates[i + 1];
    const ax = (a[0] - location[0]) * cos, ay = a[1] - location[1], dx = (b[0] - a[0]) * cos, dy = b[1] - a[1];
    const t = Math.max(0, Math.min(1, -(ax * dx + ay * dy) / (dx * dx + dy * dy || 1)));
    const along = distances[i] + (distances[i + 1] - distances[i]) * t;
    const d = (ax + dx * t) ** 2 + (ay + dy * t) ** 2;
    if (along + 0.1 >= minimum && d < best.distance) best = {distance: d, along};
  }
  return best.along;
}
function maneuvers(route) {
  if (guidanceCache.has(route)) return guidanceCache.get(route);
  let previous = 0;
  const result = (route.steps || []).filter(s => Array.isArray(s.maneuver?.location)).map(step => {
    previous = projectOnRoute(route.coordinates, step.maneuver.location, previous);
    return {...step, along: previous};
  });
  guidanceCache.set(route, result);return result;
}
export function guidanceForProgress(route, progress = 0) {
  const {total} = geometry(route.coordinates), traveled = clamp(progress) * total;
  const steps = maneuvers(route), nextIndex = steps.findIndex(step => step.maneuver.type !== 'depart' && step.along > traveled + 1);
  const next = nextIndex < 0 ? steps.at(-1) : steps[nextIndex];
  const following = nextIndex < 0 ? null : steps[nextIndex + 1] || null;
  const scale = Number.isFinite(route.totalMeters) && total ? route.totalMeters / total : 1;
  const describe = s => s ? {road: s.name || s.ref || '이름 없는 도로', modifier: s.maneuver.modifier || 'straight', type: s.maneuver.type, distanceMeters: Math.max(0, (s.along - traveled) * scale)} : null;
  return {...(describe(next) || {road: route.destination, modifier: 'straight', type: 'arrive', distanceMeters: 0}), following: describe(following)};
}
// Positron style snapshot from https://tiles.openfreemap.org/styles/positron.
// Carto/Positron colors are adapted for the subdued navigation view. Vector
// footprints and heights come from OpenFreeMap/OpenMapTiles; no generated buildings.
const POSITRON_STYLE = {"version":8,"sources":{"ne2_shaded":{"maxzoom":6,"tileSize":256,"tiles":["https://tiles.openfreemap.org/natural_earth/ne2sr/{z}/{x}/{y}.png"],"type":"raster"},"openmaptiles":{"type":"vector","url":"https://tiles.openfreemap.org/planet"}},"sprite":"https://tiles.openfreemap.org/sprites/ofm_f384/ofm","glyphs":"https://tiles.openfreemap.org/fonts/{fontstack}/{range}.pbf","layers":[{"id":"background","type":"background","paint":{"background-color":"rgb(242,243,240)"}},{"id":"park","type":"fill","source":"openmaptiles","source-layer":"park","filter":["match",["geometry-type"],["MultiPolygon","Polygon"],true,false],"paint":{"fill-color":"rgb(230, 233, 229)"}},{"id":"water","type":"fill","source":"openmaptiles","source-layer":"water","filter":["all",["match",["geometry-type"],["MultiPolygon","Polygon"],true,false],["!=",["get","brunnel"],"tunnel"]],"paint":{"fill-antialias":true,"fill-color":"rgb(194, 200, 202)"}},{"id":"landcover_ice_shelf","type":"fill","source":"openmaptiles","source-layer":"landcover","maxzoom":8,"filter":["all",["match",["geometry-type"],["MultiPolygon","Polygon"],true,false],["==",["get","subclass"],"ice_shelf"]],"paint":{"fill-color":"hsl(0,0%,98%)","fill-opacity":0.7}},{"id":"landcover_glacier","type":"fill","source":"openmaptiles","source-layer":"landcover","maxzoom":8,"filter":["all",["match",["geometry-type"],["MultiPolygon","Polygon"],true,false],["==",["get","subclass"],"glacier"]],"paint":{"fill-color":"hsl(0,0%,98%)","fill-opacity":["interpolate",["linear"],["zoom"],0,1,8,0.5]}},{"id":"landuse_residential","type":"fill","source":"openmaptiles","source-layer":"landuse","maxzoom":16,"filter":["all",["match",["geometry-type"],["MultiPolygon","Polygon"],true,false],["==",["get","class"],"residential"]],"paint":{"fill-color":"rgb(234, 234, 230)","fill-opacity":["interpolate",["exponential",0.6],["zoom"],8,0.8,9,0.6]}},{"id":"landcover_wood","type":"fill","source":"openmaptiles","source-layer":"landcover","minzoom":10,"filter":["all",["match",["geometry-type"],["MultiPolygon","Polygon"],true,false],["==",["get","class"],"wood"]],"paint":{"fill-color":"rgb(220,224,220)","fill-opacity":["interpolate",["linear"],["zoom"],8,0,12,1]}},{"id":"waterway","type":"line","source":"openmaptiles","source-layer":"waterway","filter":["match",["geometry-type"],["LineString","MultiLineString"],true,false],"paint":{"line-color":"hsl(195,17%,78%)"}},{"id":"building","type":"fill","source":"openmaptiles","source-layer":"building","minzoom":12,"paint":{"fill-antialias":true,"fill-color":"rgb(234, 234, 229)","fill-outline-color":"rgb(219, 219, 218)"}},{"id":"tunnel_motorway_casing","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":6,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["all",["==",["get","brunnel"],"tunnel"],["==",["get","class"],"motorway"]]],"layout":{"line-cap":"butt","line-join":"miter"},"paint":{"line-color":"rgb(213, 213, 213)","line-opacity":1,"line-width":["interpolate",["exponential",1.4],["zoom"],5.8,0,6,3,20,40]}},{"id":"tunnel_motorway_inner","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":6,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["all",["==",["get","brunnel"],"tunnel"],["==",["get","class"],"motorway"]]],"layout":{"line-cap":"round","line-join":"round"},"paint":{"line-color":"rgb(234,234,234)","line-width":["interpolate",["exponential",1.4],["zoom"],4,2,6,1.3,20,30]}},{"id":"aeroway-taxiway","type":"line","source":"openmaptiles","source-layer":"aeroway","minzoom":12,"filter":["match",["get","class"],["taxiway"],true,false],"layout":{"line-cap":"round","line-join":"round"},"paint":{"line-color":"hsl(0,0%,88%)","line-opacity":1,"line-width":["interpolate",["exponential",1.55],["zoom"],13,1.8,20,20]}},{"id":"aeroway-runway-casing","type":"line","source":"openmaptiles","source-layer":"aeroway","minzoom":11,"filter":["match",["get","class"],["runway"],true,false],"layout":{"line-cap":"round","line-join":"round"},"paint":{"line-color":"hsl(0,0%,88%)","line-opacity":1,"line-width":["interpolate",["exponential",1.5],["zoom"],11,6,17,55]}},{"id":"aeroway-area","type":"fill","source":"openmaptiles","source-layer":"aeroway","minzoom":4,"filter":["all",["match",["geometry-type"],["MultiPolygon","Polygon"],true,false],["match",["get","class"],["runway","taxiway"],true,false]],"paint":{"fill-color":"rgba(255, 255, 255, 1)","fill-opacity":["interpolate",["linear"],["zoom"],13,0,14,1]}},{"id":"aeroway-runway","type":"line","source":"openmaptiles","source-layer":"aeroway","minzoom":11,"filter":["all",["match",["get","class"],["runway"],true,false],["match",["geometry-type"],["LineString","MultiLineString"],true,false]],"layout":{"line-cap":"round","line-join":"round"},"paint":{"line-color":"rgba(255, 255, 255, 1)","line-opacity":1,"line-width":["interpolate",["exponential",1.5],["zoom"],11,4,17,50]}},{"id":"road_area_pier","type":"fill","source":"openmaptiles","source-layer":"transportation","filter":["all",["match",["geometry-type"],["MultiPolygon","Polygon"],true,false],["==",["get","class"],"pier"]],"paint":{"fill-antialias":true,"fill-color":"rgb(242,243,240)"}},{"id":"road_pier","type":"line","source":"openmaptiles","source-layer":"transportation","filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["match",["get","class"],["pier"],true,false]],"layout":{"line-cap":"round","line-join":"round"},"paint":{"line-color":"rgb(242,243,240)","line-width":["interpolate",["exponential",1.2],["zoom"],15,1,17,4]}},{"id":"highway_path","type":"line","source":"openmaptiles","source-layer":"transportation","filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["==",["get","class"],"path"]],"layout":{"line-cap":"round","line-join":"round"},"paint":{"line-color":"rgb(234, 234, 234)","line-opacity":0.9,"line-width":["interpolate",["exponential",1.2],["zoom"],13,1,20,10]}},{"id":"highway_minor","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":8,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["match",["get","class"],["minor","service","track"],true,false]],"layout":{"line-cap":"round","line-join":"round"},"paint":{"line-color":"hsl(0,0%,88%)","line-opacity":0.9,"line-width":["interpolate",["exponential",1.55],["zoom"],13,1.8,20,20]}},{"id":"highway_major_casing","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":11,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["match",["get","class"],["primary","secondary","tertiary","trunk"],true,false]],"layout":{"line-cap":"butt","line-join":"miter"},"paint":{"line-color":"rgb(213, 213, 213)","line-dasharray":[12,0],"line-width":["interpolate",["exponential",1.3],["zoom"],10,3,20,23]}},{"id":"highway_major_inner","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":11,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["match",["get","class"],["primary","secondary","tertiary","trunk"],true,false]],"layout":{"line-cap":"round","line-join":"round"},"paint":{"line-color":"#fff","line-width":["interpolate",["exponential",1.3],["zoom"],10,2,20,20]}},{"id":"highway_major_subtle","type":"line","source":"openmaptiles","source-layer":"transportation","maxzoom":11,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["match",["get","class"],["primary","secondary","tertiary","trunk"],true,false]],"layout":{"line-cap":"round","line-join":"round"},"paint":{"line-color":"hsla(0,0%,85%,0.69)","line-width":2}},{"id":"highway_motorway_casing","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":6,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["all",["match",["get","brunnel"],["bridge","tunnel"],false,true],["==",["get","class"],"motorway"]]],"layout":{"line-cap":"butt","line-join":"miter"},"paint":{"line-color":"rgb(213, 213, 213)","line-dasharray":[2,0],"line-opacity":1,"line-width":["interpolate",["exponential",1.4],["zoom"],5.8,0,6,3,20,40]}},{"id":"highway_motorway_inner","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":6,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["all",["match",["get","brunnel"],["bridge","tunnel"],false,true],["==",["get","class"],"motorway"]]],"layout":{"line-cap":"round","line-join":"round"},"paint":{"line-color":["interpolate",["linear"],["zoom"],5.8,"hsla(0,0%,85%,0.53)",6,"#fff"],"line-width":["interpolate",["exponential",1.4],["zoom"],4,2,6,1.3,20,30]}},{"id":"highway_motorway_subtle","type":"line","source":"openmaptiles","source-layer":"transportation","maxzoom":6,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["==",["get","class"],"motorway"]],"layout":{"line-cap":"round","line-join":"round"},"paint":{"line-color":"hsla(0,0%,85%,0.53)","line-width":["interpolate",["exponential",1.4],["zoom"],4,2,6,1.3]}},{"id":"railway_transit","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":16,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["all",["==",["get","class"],"transit"],["match",["get","brunnel"],["tunnel"],false,true]]],"layout":{"line-join":"round"},"paint":{"line-color":"#dddddd","line-width":3}},{"id":"railway_transit_dashline","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":16,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["all",["==",["get","class"],"transit"],["match",["get","brunnel"],["tunnel"],false,true]]],"layout":{"line-join":"round"},"paint":{"line-color":"#fafafa","line-dasharray":[3,3],"line-width":2}},{"id":"railway_service","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":16,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["all",["==",["get","class"],"rail"],["has","service"]]],"layout":{"line-join":"round"},"paint":{"line-color":"#dddddd","line-width":3}},{"id":"railway_service_dashline","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":16,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["==",["get","class"],"rail"],["has","service"]],"layout":{"line-join":"round"},"paint":{"line-color":"#fafafa","line-dasharray":[3,3],"line-width":2}},{"id":"railway","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":13,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["all",["!",["has","service"]],["==",["get","class"],"rail"]]],"layout":{"line-join":"round"},"paint":{"line-color":"#dddddd","line-width":["interpolate",["exponential",1.3],["zoom"],16,3,20,7]}},{"id":"railway_dashline","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":13,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["all",["!",["has","service"]],["==",["get","class"],"rail"]]],"layout":{"line-join":"round"},"paint":{"line-color":"#fafafa","line-dasharray":[3,3],"line-width":["interpolate",["exponential",1.3],["zoom"],16,2,20,6]}},{"id":"highway_motorway_bridge_casing","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":6,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["all",["==",["get","brunnel"],"bridge"],["==",["get","class"],"motorway"]]],"layout":{"line-cap":"butt","line-join":"miter"},"paint":{"line-color":"rgb(213, 213, 213)","line-dasharray":[2,0],"line-opacity":1,"line-width":["interpolate",["exponential",1.4],["zoom"],5.8,0,6,5,20,45]}},{"id":"highway_motorway_bridge_inner","type":"line","source":"openmaptiles","source-layer":"transportation","minzoom":6,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["all",["==",["get","brunnel"],"bridge"],["==",["get","class"],"motorway"]]],"layout":{"line-cap":"round","line-join":"round"},"paint":{"line-color":["interpolate",["linear"],["zoom"],5.8,"hsla(0,0%,85%,0.53)",6,"#fff"],"line-width":["interpolate",["exponential",1.4],["zoom"],4,2,6,1.3,20,30]}},{"id":"boundary_3","type":"line","source":"openmaptiles","source-layer":"boundary","minzoom":8,"filter":["all",["==",["typeof",["get","admin_level"]],"number"],[">=",["get","admin_level"],3],["<=",["get","admin_level"],6],["!=",["get","maritime"],1],["!=",["get","disputed"],1],["!",["has","claimed_by"]]],"paint":{"line-color":"hsl(0,0%,70%)","line-dasharray":[1,1],"line-width":["interpolate",["linear",1],["zoom"],7,1,11,2]}},{"id":"boundary_2","type":"line","source":"openmaptiles","source-layer":"boundary","filter":["all",["==",["get","admin_level"],2],["!=",["get","maritime"],1],["!=",["get","disputed"],1],["!",["has","claimed_by"]]],"layout":{"line-cap":"round","line-join":"round"},"paint":{"line-color":"hsl(0,0%,70%)","line-opacity":["interpolate",["linear"],["zoom"],0,0.4,4,1],"line-width":["interpolate",["linear"],["zoom"],3,1,5,1.2,12,3]}},{"id":"boundary_disputed","type":"line","source":"openmaptiles","source-layer":"boundary","filter":["all",["!=",["get","maritime"],1],["==",["get","disputed"],1]],"paint":{"line-color":"hsl(0,0%,70%)","line-dasharray":[1,2],"line-width":["interpolate",["linear"],["zoom"],3,1,5,1.2,12,3]}},{"id":"waterway_line_label","type":"symbol","source":"openmaptiles","source-layer":"waterway","minzoom":10,"filter":["match",["geometry-type"],["LineString","MultiLineString"],true,false],"layout":{"symbol-placement":"line","symbol-spacing":350,"text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"]," ",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Italic"],"text-letter-spacing":0.2,"text-max-width":5,"text-size":14},"paint":{"text-color":"hsl(0,0%,66%)","text-halo-color":"rgba(255,255,255,0.7)","text-halo-width":1.5}},{"id":"water_name_point_label","type":"symbol","source":"openmaptiles","source-layer":"water_name","filter":["match",["geometry-type"],["MultiPoint","Point"],true,false],"layout":{"text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"],"\n",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Italic"],"text-letter-spacing":0.2,"text-max-width":5,"text-size":["interpolate",["linear"],["zoom"],0,10,8,14]},"paint":{"text-color":"#495e91","text-halo-color":"rgba(255,255,255,0.7)","text-halo-width":1.5}},{"id":"water_name_line_label","type":"symbol","source":"openmaptiles","source-layer":"water_name","filter":["match",["geometry-type"],["LineString","MultiLineString"],true,false],"layout":{"symbol-placement":"line","symbol-spacing":350,"text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"]," ",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Italic"],"text-letter-spacing":0.2,"text-max-width":5,"text-size":14},"paint":{"text-color":"#495e91","text-halo-color":"rgba(255,255,255,0.7)","text-halo-width":1.5}},{"id":"highway-name-path","type":"symbol","source":"openmaptiles","source-layer":"transportation_name","minzoom":15.5,"filter":["==",["get","class"],"path"],"layout":{"symbol-placement":"line","text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"]," ",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Regular"],"text-rotation-alignment":"map","text-size":["interpolate",["linear"],["zoom"],13,12,14,13]},"paint":{"text-color":"hsl(30,0%,62%)","text-halo-color":"#f8f4f0","text-halo-width":0.5}},{"id":"highway-name-minor","type":"symbol","source":"openmaptiles","source-layer":"transportation_name","minzoom":15,"filter":["all",["match",["geometry-type"],["LineString","MultiLineString"],true,false],["match",["get","class"],["minor","service","track"],true,false]],"layout":{"symbol-placement":"line","text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"]," ",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Regular"],"text-rotation-alignment":"map","text-size":["interpolate",["linear"],["zoom"],13,12,14,13]},"paint":{"text-color":"#666","text-halo-blur":0.5,"text-halo-width":1}},{"id":"highway-name-major","type":"symbol","source":"openmaptiles","source-layer":"transportation_name","minzoom":12.2,"filter":["match",["get","class"],["primary","secondary","tertiary","trunk"],true,false],"layout":{"symbol-placement":"line","text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"]," ",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Regular"],"text-rotation-alignment":"map","text-size":["interpolate",["linear"],["zoom"],13,12,14,13]},"paint":{"text-color":"#666","text-halo-blur":0.5,"text-halo-width":1}},{"id":"highway-shield-non-us","type":"symbol","source":"openmaptiles","source-layer":"transportation_name","minzoom":11,"filter":["all",["<=",["get","ref_length"],6],["match",["geometry-type"],["LineString","MultiLineString"],true,false],["match",["get","network"],["us-highway","us-interstate","us-state"],false,true]],"layout":{"icon-image":["concat","road_",["get","ref_length"]],"icon-rotation-alignment":"viewport","icon-size":1,"symbol-placement":["step",["zoom"],"point",11,"line"],"symbol-spacing":200,"text-field":["to-string",["get","ref"]],"text-font":["Noto Sans Regular"],"text-rotation-alignment":"viewport","text-size":10}},{"id":"highway-shield-us-interstate","type":"symbol","source":"openmaptiles","source-layer":"transportation_name","minzoom":11,"filter":["all",["<=",["get","ref_length"],6],["match",["geometry-type"],["LineString","MultiLineString"],true,false],["match",["get","network"],["us-interstate"],true,false]],"layout":{"icon-image":["concat",["get","network"],"_",["get","ref_length"]],"icon-rotation-alignment":"viewport","icon-size":1,"symbol-placement":["step",["zoom"],"point",7,"line",8,"line"],"symbol-spacing":200,"text-field":["to-string",["get","ref"]],"text-font":["Noto Sans Regular"],"text-rotation-alignment":"viewport","text-size":10}},{"id":"road_shield_us","type":"symbol","source":"openmaptiles","source-layer":"transportation_name","minzoom":12,"filter":["all",["<=",["get","ref_length"],6],["match",["geometry-type"],["LineString","MultiLineString"],true,false],["match",["get","network"],["us-highway","us-state"],true,false]],"layout":{"icon-image":["concat",["get","network"],"_",["get","ref_length"]],"icon-rotation-alignment":"viewport","icon-size":1,"symbol-placement":["step",["zoom"],"point",11,"line"],"symbol-spacing":200,"text-field":["to-string",["get","ref"]],"text-font":["Noto Sans Regular"],"text-rotation-alignment":"viewport","text-size":10}},{"id":"airport","type":"symbol","source":"openmaptiles","source-layer":"aerodrome_label","minzoom":11,"filter":["all",["has","iata"]],"layout":{"icon-image":"airport_11","icon-size":1,"text-anchor":"top","text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"],"\n",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Regular"],"text-max-width":9,"text-offset":[0,0.6],"text-optional":true,"text-padding":2,"text-size":12},"paint":{"text-color":"#666","text-halo-blur":0.5,"text-halo-color":"#ffffff","text-halo-width":1}},{"id":"label_other","type":"symbol","source":"openmaptiles","source-layer":"place","minzoom":8,"filter":["match",["get","class"],["city","continent","country","state","town","village"],false,true],"layout":{"text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"],"\n",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Italic"],"text-letter-spacing":0.1,"text-max-width":9,"text-size":["interpolate",["linear"],["zoom"],8,9,12,10],"text-transform":"uppercase"},"paint":{"text-color":"#333","text-halo-blur":1,"text-halo-color":"#fff","text-halo-width":1}},{"id":"label_village","type":"symbol","source":"openmaptiles","source-layer":"place","minzoom":9,"filter":["==",["get","class"],"village"],"layout":{"icon-allow-overlap":true,"icon-image":["step",["zoom"],"circle_11_black",10,""],"icon-optional":false,"icon-size":0.2,"text-anchor":"bottom","text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"],"\n",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Regular"],"text-max-width":8,"text-size":["interpolate",["exponential",1.2],["zoom"],7,10,11,12]},"paint":{"text-color":"#000","text-halo-blur":1,"text-halo-color":"#fff","text-halo-width":1}},{"id":"label_town","type":"symbol","source":"openmaptiles","source-layer":"place","minzoom":6,"filter":["==",["get","class"],"town"],"layout":{"icon-allow-overlap":true,"icon-image":["step",["zoom"],"circle_11_black",10,""],"icon-optional":false,"icon-size":0.2,"text-anchor":"bottom","text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"],"\n",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Regular"],"text-max-width":8,"text-size":["interpolate",["exponential",1.2],["zoom"],7,12,11,14]},"paint":{"text-color":"#000","text-halo-blur":1,"text-halo-color":"#fff","text-halo-width":1}},{"id":"label_state","type":"symbol","source":"openmaptiles","source-layer":"place","minzoom":5,"maxzoom":8,"filter":["==",["get","class"],"state"],"layout":{"text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"],"\n",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Italic"],"text-letter-spacing":0.2,"text-max-width":9,"text-size":["interpolate",["linear"],["zoom"],5,10,8,14],"text-transform":"uppercase"},"paint":{"text-color":"#333","text-halo-blur":1,"text-halo-color":"#fff","text-halo-width":1}},{"id":"label_city","type":"symbol","source":"openmaptiles","source-layer":"place","minzoom":3,"filter":["all",["==",["get","class"],"city"],["!=",["get","capital"],2]],"layout":{"icon-allow-overlap":true,"icon-image":["step",["zoom"],"circle_11_black",9,""],"icon-optional":false,"icon-size":0.4,"text-anchor":"bottom","text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"],"\n",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Regular"],"text-max-width":8,"text-offset":[0,-0.1],"text-size":["interpolate",["exponential",1.2],["zoom"],4,11,7,13,11,18]},"paint":{"text-color":"#000","text-halo-blur":1,"text-halo-color":"#fff","text-halo-width":1}},{"id":"label_city_capital","type":"symbol","source":"openmaptiles","source-layer":"place","minzoom":3,"filter":["all",["==",["get","class"],"city"],["==",["get","capital"],2]],"layout":{"icon-allow-overlap":true,"icon-image":["step",["zoom"],"circle_11_black",9,""],"icon-optional":false,"icon-size":0.5,"text-anchor":"bottom","text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"],"\n",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Bold"],"text-max-width":8,"text-offset":[0,-0.2],"text-size":["interpolate",["exponential",1.2],["zoom"],4,12,7,14,11,20]},"paint":{"text-color":"#000","text-halo-blur":1,"text-halo-color":"#fff","text-halo-width":1}},{"id":"label_country_3","type":"symbol","source":"openmaptiles","source-layer":"place","minzoom":2,"maxzoom":9,"filter":["all",["==",["get","class"],"country"],[">=",["get","rank"],3]],"layout":{"text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"],"\n",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Bold"],"text-max-width":6.25,"text-size":["interpolate",["linear"],["zoom"],3,9,7,17]},"paint":{"text-color":"#000","text-halo-blur":1,"text-halo-color":"#fff","text-halo-width":1}},{"id":"label_country_2","type":"symbol","source":"openmaptiles","source-layer":"place","maxzoom":9,"filter":["all",["==",["get","class"],"country"],["==",["get","rank"],2]],"layout":{"text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"],"\n",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Bold"],"text-max-width":6.25,"text-size":["interpolate",["linear"],["zoom"],2,9,5,17]},"paint":{"text-color":"#000","text-halo-blur":1,"text-halo-color":"#fff","text-halo-width":1}},{"id":"label_country_1","type":"symbol","source":"openmaptiles","source-layer":"place","maxzoom":9,"filter":["all",["==",["get","class"],"country"],["==",["get","rank"],1]],"layout":{"text-field":["case",["has","name:nonlatin"],["concat",["get","name:latin"],"\n",["get","name:nonlatin"]],["coalesce",["get","name_en"],["get","name"]]],"text-font":["Noto Sans Bold"],"text-max-width":6.25,"text-size":["interpolate",["linear"],["zoom"],1,9,4,17]},"paint":{"text-color":"#000","text-halo-blur":1,"text-halo-color":"#fff","text-halo-width":1}}]};
export function navigationMapStyle(night = false, perspective = true) {
  const style = JSON.parse(JSON.stringify(POSITRON_STYLE));
  style.name = '하원콜 · neutral navigation';
  style.sources.openmaptiles.attribution = '<a href="https://openfreemap.org/" target="_blank" rel="noopener">OpenFreeMap</a> · <a href="https://github.com/openmaptiles/positron-gl-style" target="_blank" rel="noopener">Positron · CARTO</a> · © <a href="https://openmaptiles.org/" target="_blank" rel="noopener">OpenMapTiles</a> · © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>';
  const colors = night ? {ground:'#222831',park:'#314238',water:'#344955',road:'#626d7d',edge:'#77818d',building:'#46515e',outline:'#626b77',text:'#e2e7ec',halo:'#222831'} : {ground:'#f4f6f8',park:'#c8e6d2',water:'#d5e9f2',road:'#b5bdcc',edge:'#cbd1db',building:'#e3e6eb',outline:'#cdd2db',text:'#697382',halo:'#ffffff'};
  style.layers = style.layers.filter(layer => !/shield|airport|railway|boundary|highway-name-path/.test(layer.id));
  for (const layer of style.layers) {
    layer.paint ||= {};
    if (layer.type === 'background') layer.paint['background-color'] = colors.ground;
    if (layer.id === 'park' || layer.id === 'landcover_wood') layer.paint['fill-color'] = colors.park;
    if (layer.id === 'landuse_residential' || layer.id === 'road_area_pier') layer.paint['fill-color'] = colors.ground;
    if (layer.id === 'water') layer.paint['fill-color'] = colors.water;
    if (layer.id === 'building') {
      layer.paint['fill-color'] = colors.building;
      layer.paint['fill-outline-color'] = colors.outline;
    }
    if (layer.type === 'line' && layer['source-layer'] === 'transportation') {
      layer.paint['line-color'] = /casing/.test(layer.id) ? colors.edge : colors.road;
    }
    if (layer.type === 'symbol') {
      layer.layout ||= {};
      layer.layout['text-field'] = ['coalesce',['get','name:ko'],['get','name:nonlatin'],['get','name'],['get','name:latin']];
      layer.layout['text-font'] = ['Noto Sans Regular'];
      layer.layout['text-transform'] = 'none';
      layer.layout['text-padding'] = 12;
      layer.paint['text-color'] = colors.text;
      layer.paint['text-halo-color'] = colors.halo;
      layer.paint['text-halo-width'] = 1.7;
      if (layer.id === 'highway-name-minor') {layer.minzoom=17;layer.layout['symbol-spacing']=500;}
      if (layer.id === 'highway-name-major') {layer.layout['text-size']=14;layer.layout['symbol-spacing']=340;}
      if (layer['source-layer'] === 'place') {layer.maxzoom=Math.min(layer.maxzoom || 18,16);}
    }
  }
  const before = style.layers.findIndex(l => l.type === 'symbol');
  style.layers.splice(before < 0 ? style.layers.length : before,0,{
    id:'navigation-buildings-3d',type:'fill-extrusion',source:'openmaptiles','source-layer':'building',minzoom:14,
    layout:{visibility:perspective?'visible':'none'},
    paint:{'fill-extrusion-color':colors.building,'fill-extrusion-height':['coalesce',['get','render_height'],['get','height'],0],'fill-extrusion-base':['coalesce',['get','render_min_height'],['get','min_height'],0],'fill-extrusion-opacity':.94,'fill-extrusion-vertical-gradient':true}
  });
  return style;
}
const positionSVG = '<svg viewBox="0 0 50 50" width="50" height="50" aria-hidden="true"><circle cx="25" cy="25" r="22" fill="white" stroke="#168acb" stroke-width="3"/><path d="m25 10 12 27-12-7-12 7Z" fill="#078fd1" stroke="#fff" stroke-width="1.2" stroke-linejoin="round"/></svg>';
const routeFeature = coordinates => ({type:'Feature',properties:{},geometry:{type:'LineString',coordinates}});
/** Vendored MapLibre renders public OpenFreeMap tiles. GPS overlays are transient; routing is requested only by the separate explicit confirmation flow. */
export function createRoadMap(container, {route, statusElement, onFollowChange, maplibre = globalThis.maplibregl} = {}) {
  const status = (message, error = false) => {if (!statusElement) return;statusElement.textContent=message;statusElement.hidden=!message;statusElement.classList.toggle('is-error',error);};
  const unavailable = () => ({setLiveTarget(){},setMeetingRoute(){},focusLiveTarget(){},setProgress(){},fit(){},zoomIn(){},zoomOut(){},follow(){},isFollowing:()=>false,setNight(){},setPerspective(){},resize(){},setDestination(){},destroy(){}});
  if (!maplibre) {status('지도 엔진을 불러오지 못했어요 · 페이지를 새로 열어주세요',true);return unavailable();}
  let map;
  const initial = navigationPoseForProgress(route.coordinates,0);
  try {
    map = new maplibre.Map({container,style:navigationMapStyle(),center:[initial.lon,initial.lat],zoom:16.8,pitch:50,bearing:initial.heading,attributionControl:false,scrollZoom:false,dragRotate:false,touchPitch:false,maxPitch:60,fadeDuration:0,renderWorldCopies:false});
  } catch (error) {status('3D 지도를 사용할 수 없어요 · 브라우저의 그래픽 가속을 확인해주세요',true);return unavailable();}
  map.addControl(new maplibre.AttributionControl({compact:false}),'bottom-right');
  const doc = container.ownerDocument || document;
  const positionEl=doc.createElement('div');positionEl.className='real-position-marker';positionEl.innerHTML=positionSVG;positionEl.style.cssText='width:50px;height:50px;filter:drop-shadow(0 2px 2px #52667b45);';positionEl.setAttribute('aria-label','시연 차량 현재 위치');
  const marker=new maplibre.Marker({element:positionEl,rotationAlignment:'map',pitchAlignment:'viewport',subpixelPositioning:true}).setLngLat(route.coordinates[0]).setRotation(initial.heading).addTo(map);
  const destinationEl=doc.createElement('div');destinationEl.className='real-destination-marker';destinationEl.style.cssText='display:grid;justify-items:center;gap:5px;';
  const label=doc.createElement('span');label.className='real-destination-label';label.textContent=route.destination;label.style.cssText='white-space:nowrap;background:white;padding:7px 10px;border-radius:10px;color:#43515f;box-shadow:0 2px 7px #1c345b20;font:600 13px sans-serif;';
  const pin=doc.createElement('span');pin.textContent='h';pin.style.cssText='display:grid;place-items:center;background:#328fdf;color:white;width:29px;height:29px;border:3px solid white;border-radius:50%;font:bold 19px sans-serif;box-shadow:0 2px 6px #1c345b30;';destinationEl.append(label,pin);
  const destination=new maplibre.Marker({element:destinationEl,anchor:'bottom',offset:[0,14]}).setLngLat(route.coordinates.at(-1)).addTo(map);
  let liveMarker=null,liveFix=null,meetingRoute=null;
  const emptyFeatures=()=>({type:"FeatureCollection",features:[]});
  const liveCircle=f=>{if(!f)return emptyFeatures();const points=Array.from({length:65},(_,i)=>{const a=i/64*Math.PI*2;return [f.lon+Math.cos(a)*f.accuracy/(111320*Math.cos(f.lat*Math.PI/180)),f.lat+Math.sin(a)*f.accuracy/111320];});return {type:"Feature",properties:{},geometry:{type:"Polygon",coordinates:[points]}};};
  let progress=0,tracking=true,perspective=true,night=false,disposed=false,hadResourceError=false,followZoom=16.8;
  const zeroPadding = {top:0,bottom:0,left:0,right:0};
  const changeTracking = enabled => {
    enabled = Boolean(enabled);
    if (tracking === enabled) return;
    tracking = enabled;
    onFollowChange?.(tracking);
  };
  status('실제 벡터 지도를 불러오는 중…');
  const timeout=setTimeout(()=>{if(!disposed&&!map.isSourceLoaded('openmaptiles'))status('배경 지도 연결을 확인해주세요 · 인터넷 연결이 필요해요',true);},12000);
  const camera = () => {
    if (disposed || !tracking || container.clientWidth < 2 || container.clientHeight < 2) return;
    const p = navigationPoseForProgress(route.coordinates, progress);
    // A padded optical center is a persistent, exact navigation anchor. Repeated
    // easeTo/offset animations compete with gestures and zoom animations; direct
    // camera updates keep the marker and road transform in the same render frame.
    map.jumpTo({center:[p.lon,p.lat],bearing:perspective?p.heading:0,pitch:perspective?50:0,
      zoom:followZoom,padding:{...zeroPadding,top:container.clientHeight*.44}});
  };
  const resize = () => {
    if (disposed || container.clientWidth < 2 || container.clientHeight < 2) return;
    map.resize();
    camera();
  };
  const remainingCoordinates = () => {const p=pointAlongRoute(route.coordinates,progress);return [[p.lon,p.lat],...route.coordinates.slice(p.segmentIndex+1)];};
  const installRoute = () => {
    if(disposed || map.getSource('navigation-route'))return;
    map.addSource('navigation-route',{type:'geojson',data:routeFeature(route.coordinates)});
    map.addSource('navigation-remaining',{type:'geojson',data:routeFeature(remainingCoordinates())});
    map.addLayer({id:'navigation-route-casing',type:'line',source:'navigation-route',layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#fff','line-width':12,'line-opacity':.98}});
    map.addLayer({id:'navigation-route-traveled',type:'line',source:'navigation-route',layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#92adc7','line-width':7}});
    map.addLayer({id:'navigation-route-active',type:'line',source:'navigation-remaining',layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#168ddd','line-width':7}});
    map.addSource('child-accuracy',{type:'geojson',data:liveCircle(liveFix)});
    map.addLayer({id:'child-accuracy-fill',type:'fill',source:'child-accuracy',paint:{'fill-color':'#08a88a','fill-opacity':.18}});
    map.addLayer({id:'child-accuracy-outline',type:'line',source:'child-accuracy',paint:{'line-color':'#049c81','line-width':2}});
    map.addSource('meeting-road',{type:'geojson',data:meetingRoute?routeFeature(meetingRoute.coordinates):emptyFeatures()});
    map.addLayer({id:'meeting-road-line',type:'line',source:'meeting-road',layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#08a88a','line-width':8}});
    if(tracking)camera();
  };
  map.on('style.load',installRoute);
  map.on('error',event=>{hadResourceError=true;status(event.error?.message?.includes('WebGL')?'3D 지도 표시가 중단됐어요 · 브라우저를 새로 열어주세요':'지도 연결이 불안정해요 · 일부 도로·지명이 표시되지 않을 수 있어요',true);});
  map.on('sourcedata',event=>{if(event.sourceId==='openmaptiles'&&event.isSourceLoaded){clearTimeout(timeout);if(!hadResourceError&&globalThis.navigator?.onLine!==false)status('');}});
  map.on('idle',()=>{if(!hadResourceError&&globalThis.navigator?.onLine!==false&&map.isSourceLoaded('openmaptiles')&&map.areTilesLoaded())status('');});
  map.on('dragstart',()=>{changeTracking(false);map.stop();});
  // Touch zoom/rotation and keyboard panning are also explicit manual views.
  map.on('movestart',event=>{if(event.originalEvent){changeTracking(false);}});
  map.getCanvas().addEventListener('webglcontextlost',()=>status('3D 지도 표시가 중단됐어요 · 브라우저를 새로 열어주세요',true));
  const offline=()=>status('오프라인 상태예요 · 배경 지도를 불러올 수 없어요',true);
  globalThis.addEventListener?.('offline',offline);
  if(globalThis.navigator?.onLine===false)offline();
  const fit=()=>{changeTracking(false);const bounds=new maplibre.LngLatBounds(route.coordinates[0],route.coordinates[0]);for(const p of route.coordinates)bounds.extend(p);map.fitBounds(bounds,{padding:{top:100,bottom:120,left:75,right:75},maxZoom:15.6,pitch:0,bearing:0,duration:0});};
  const setProgress=value=>{
    if(disposed)return;
    progress=clamp(value);
    const p=navigationPoseForProgress(route.coordinates,progress);
    marker.setLngLat([p.lon,p.lat]).setRotation(p.heading);
    map.getSource('navigation-remaining')?.setData(routeFeature(remainingCoordinates()));
    camera();
  };
  const setLiveTarget=f=>{liveFix=f;if(!f){liveMarker?.remove();liveMarker=null;}else{if(!liveMarker){const e=doc.createElement('div');e.className='child-map-marker';e.innerHTML='<b>아이</b><span>만남 위치</span>';liveMarker=new maplibre.Marker({element:e,anchor:'bottom'}).setLngLat([f.lon,f.lat]).addTo(map);}liveMarker.setLngLat([f.lon,f.lat]);}map.getSource('child-accuracy')?.setData(liveCircle(f));};
  const setMeetingRoute=r=>{meetingRoute=r;map.getSource('meeting-road')?.setData(r?routeFeature(r.coordinates):emptyFeatures());if(r){changeTracking(false);const b=new maplibre.LngLatBounds(r.coordinates[0],r.coordinates[0]);r.coordinates.forEach(p=>b.extend(p));map.fitBounds(b,{padding:90,maxZoom:16,pitch:40,duration:400});}};
  const visibilityChanged = () => {if(!doc.hidden)resize();};
  doc.addEventListener?.('visibilitychange',visibilityChanged);
  const Observer = doc.defaultView?.ResizeObserver || globalThis.ResizeObserver;
  const observer = Observer ? new Observer(resize) : null;
  observer?.observe(container);
  camera();
  return {
    setLiveTarget,setMeetingRoute,
    focusLiveTarget:()=>{if(liveFix){changeTracking(false);map.easeTo({center:[liveFix.lon,liveFix.lat],padding:zeroPadding,zoom:17,pitch:40,duration:450});}},
    setProgress,fit,isFollowing:()=>tracking,
    zoomIn:()=>{if(tracking){followZoom=Math.min(20,followZoom+1);camera();}else map.zoomIn({duration:0});},
    zoomOut:()=>{if(tracking){followZoom=Math.max(13,followZoom-1);camera();}else map.zoomOut({duration:0});},
    follow:enabled=>{changeTracking(enabled);if(tracking){map.stop();resize();}},
    setNight:enabled=>{if(night===enabled)return;night=enabled;map.setStyle(navigationMapStyle(night,perspective));},
    setPerspective:enabled=>{perspective=enabled;map.getLayer('navigation-buildings-3d')&&map.setLayoutProperty('navigation-buildings-3d','visibility',enabled?'visible':'none');if(tracking)camera();else map.easeTo({pitch:enabled?50:0,bearing:enabled?map.getBearing():0,duration:350});},
    resize,setDestination:name=>{label.textContent=name;},
    destroy:()=>{disposed=true;clearTimeout(timeout);observer?.disconnect();doc.removeEventListener?.('visibilitychange',visibilityChanged);globalThis.removeEventListener?.('offline',offline);liveMarker?.remove();destination.remove();marker.remove();map.remove();}
  };
}
