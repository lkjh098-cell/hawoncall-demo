// Public demonstration points, not user location. Cached road-routing result; no live traffic.
export const REAL_ROUTE = Object.freeze({
  "id": "osrm-seoul-daechi-20261025",
  "name": "선릉역 인근 → 대치동 픽업 지점",
  "destination": "대치동 픽업 지점(시연)",
  "totalMeters": 2149.6,
  "durationSeconds": 146.6,
  "coordinates": [
    [
      127.049657,
      37.504591
    ],
    [
      127.050874,
      37.504957
    ],
    [
      127.051978,
      37.505299
    ],
    [
      127.052874,
      37.505566
    ],
    [
      127.053019,
      37.505609
    ],
    [
      127.055136,
      37.506262
    ],
    [
      127.056376,
      37.506638
    ],
    [
      127.056661,
      37.506723
    ],
    [
      127.056715,
      37.506618
    ],
    [
      127.057241,
      37.505588
    ],
    [
      127.05732,
      37.505433
    ],
    [
      127.057673,
      37.504794
    ],
    [
      127.058243,
      37.503749
    ],
    [
      127.058307,
      37.503624
    ],
    [
      127.058496,
      37.503255
    ],
    [
      127.058586,
      37.503076
    ],
    [
      127.058755,
      37.502768
    ],
    [
      127.058899,
      37.502525
    ],
    [
      127.059133,
      37.50208
    ],
    [
      127.059489,
      37.50142
    ],
    [
      127.05951,
      37.50138
    ],
    [
      127.059534,
      37.501335
    ],
    [
      127.059561,
      37.501285
    ],
    [
      127.05958,
      37.501249
    ],
    [
      127.060155,
      37.500178
    ],
    [
      127.060467,
      37.499597
    ],
    [
      127.060786,
      37.498972
    ],
    [
      127.060811,
      37.498923
    ],
    [
      127.060833,
      37.498878
    ],
    [
      127.060849,
      37.49885
    ],
    [
      127.06087,
      37.498809
    ],
    [
      127.061136,
      37.498315
    ],
    [
      127.061386,
      37.49785
    ],
    [
      127.061759,
      37.497165
    ],
    [
      127.061812,
      37.497016
    ],
    [
      127.062452,
      37.495842
    ],
    [
      127.062497,
      37.495744
    ],
    [
      127.062978,
      37.494842
    ],
    [
      127.06308,
      37.494651
    ],
    [
      127.063143,
      37.494521
    ],
    [
      127.062978,
      37.494462
    ]
  ],
  "steps": [
    {
      "intersections": [
        {
          "out": 0,
          "entry": [
            true
          ],
          "bearings": [
            69
          ],
          "location": [
            127.049657,
            37.504591
          ]
        },
        {
          "out": 0,
          "in": 2,
          "entry": [
            true,
            true,
            false
          ],
          "bearings": [
            75,
            165,
            255
          ],
          "location": [
            127.050874,
            37.504957
          ]
        },
        {
          "out": 0,
          "in": 2,
          "entry": [
            true,
            true,
            false
          ],
          "bearings": [
            75,
            150,
            255
          ],
          "location": [
            127.053019,
            37.505609
          ]
        },
        {
          "out": 0,
          "in": 2,
          "entry": [
            true,
            true,
            false
          ],
          "bearings": [
            75,
            150,
            255
          ],
          "location": [
            127.055136,
            37.506262
          ]
        }
      ],
      "driving_side": "right",
      "maneuver": {
        "bearing_after": 69,
        "bearing_before": 0,
        "location": [
          127.049657,
          37.504591
        ],
        "modifier": "right",
        "type": "depart"
      },
      "geometry": {
        "coordinates": [
          [
            127.049657,
            37.504591
          ],
          [
            127.050874,
            37.504957
          ],
          [
            127.051978,
            37.505299
          ],
          [
            127.052874,
            37.505566
          ],
          [
            127.053019,
            37.505609
          ],
          [
            127.055136,
            37.506262
          ],
          [
            127.056376,
            37.506638
          ],
          [
            127.056661,
            37.506723
          ]
        ],
        "type": "LineString"
      },
      "ref": "90",
      "name": "테헤란로",
      "mode": "driving",
      "weight": 38.8,
      "duration": 38.8,
      "distance": 662.8
    },
    {
      "intersections": [
        {
          "out": 1,
          "in": 2,
          "entry": [
            true,
            true,
            false,
            false
          ],
          "bearings": [
            60,
            165,
            255,
            330
          ],
          "location": [
            127.056661,
            37.506723
          ]
        },
        {
          "out": 1,
          "in": 3,
          "entry": [
            true,
            true,
            true,
            false
          ],
          "bearings": [
            75,
            150,
            240,
            345
          ],
          "location": [
            127.05732,
            37.505433
          ]
        },
        {
          "out": 0,
          "in": 2,
          "entry": [
            true,
            true,
            false
          ],
          "bearings": [
            150,
            240,
            330
          ],
          "location": [
            127.057673,
            37.504794
          ]
        },
        {
          "out": 0,
          "in": 2,
          "entry": [
            true,
            true,
            false
          ],
          "bearings": [
            165,
            255,
            330
          ],
          "location": [
            127.058243,
            37.503749
          ]
        },
        {
          "out": 1,
          "in": 3,
          "entry": [
            true,
            true,
            true,
            false
          ],
          "bearings": [
            60,
            150,
            255,
            345
          ],
          "location": [
            127.058586,
            37.503076
          ]
        },
        {
          "out": 0,
          "in": 2,
          "entry": [
            true,
            true,
            false
          ],
          "bearings": [
            150,
            240,
            330
          ],
          "location": [
            127.058899,
            37.502525
          ]
        },
        {
          "out": 1,
          "in": 2,
          "entry": [
            true,
            true,
            false
          ],
          "bearings": [
            75,
            150,
            330
          ],
          "location": [
            127.059489,
            37.50142
          ]
        },
        {
          "out": 1,
          "in": 3,
          "entry": [
            true,
            true,
            true,
            false
          ],
          "bearings": [
            60,
            150,
            255,
            330
          ],
          "location": [
            127.059534,
            37.501335
          ]
        },
        {
          "out": 1,
          "in": 2,
          "entry": [
            true,
            true,
            false
          ],
          "bearings": [
            60,
            150,
            330
          ],
          "location": [
            127.05958,
            37.501249
          ]
        },
        {
          "out": 0,
          "in": 2,
          "entry": [
            true,
            true,
            false
          ],
          "bearings": [
            150,
            240,
            330
          ],
          "location": [
            127.060155,
            37.500178
          ]
        },
        {
          "out": 0,
          "in": 2,
          "entry": [
            true,
            false,
            false
          ],
          "bearings": [
            165,
            255,
            330
          ],
          "location": [
            127.060467,
            37.499597
          ]
        },
        {
          "out": 1,
          "in": 3,
          "entry": [
            true,
            true,
            true,
            false
          ],
          "bearings": [
            60,
            150,
            255,
            345
          ],
          "location": [
            127.060833,
            37.498878
          ]
        },
        {
          "out": 0,
          "in": 2,
          "entry": [
            true,
            true,
            false
          ],
          "bearings": [
            150,
            255,
            330
          ],
          "location": [
            127.061136,
            37.498315
          ]
        },
        {
          "out": 1,
          "in": 3,
          "entry": [
            true,
            true,
            true,
            false
          ],
          "bearings": [
            75,
            165,
            210,
            330
          ],
          "location": [
            127.061759,
            37.497165
          ]
        }
      ],
      "driving_side": "right",
      "geometry": {
        "coordinates": [
          [
            127.056661,
            37.506723
          ],
          [
            127.056715,
            37.506618
          ],
          [
            127.057241,
            37.505588
          ],
          [
            127.05732,
            37.505433
          ],
          [
            127.057673,
            37.504794
          ],
          [
            127.058243,
            37.503749
          ],
          [
            127.058307,
            37.503624
          ],
          [
            127.058496,
            37.503255
          ],
          [
            127.058586,
            37.503076
          ],
          [
            127.058755,
            37.502768
          ],
          [
            127.058899,
            37.502525
          ],
          [
            127.059133,
            37.50208
          ],
          [
            127.059489,
            37.50142
          ],
          [
            127.05951,
            37.50138
          ],
          [
            127.059534,
            37.501335
          ],
          [
            127.059561,
            37.501285
          ],
          [
            127.05958,
            37.501249
          ],
          [
            127.060155,
            37.500178
          ],
          [
            127.060467,
            37.499597
          ],
          [
            127.060786,
            37.498972
          ],
          [
            127.060811,
            37.498923
          ],
          [
            127.060833,
            37.498878
          ],
          [
            127.060849,
            37.49885
          ],
          [
            127.06087,
            37.498809
          ],
          [
            127.061136,
            37.498315
          ],
          [
            127.061386,
            37.49785
          ],
          [
            127.061759,
            37.497165
          ],
          [
            127.061812,
            37.497016
          ],
          [
            127.062452,
            37.495842
          ],
          [
            127.062497,
            37.495744
          ],
          [
            127.062978,
            37.494842
          ],
          [
            127.06308,
            37.494651
          ],
          [
            127.063143,
            37.494521
          ]
        ],
        "type": "LineString"
      },
      "maneuver": {
        "bearing_after": 157,
        "bearing_before": 68,
        "location": [
          127.056661,
          37.506723
        ],
        "modifier": "right",
        "type": "turn"
      },
      "name": "삼성로",
      "mode": "driving",
      "weight": 106.9,
      "duration": 106.9,
      "distance": 1470.8
    },
    {
      "intersections": [
        {
          "out": 2,
          "in": 3,
          "entry": [
            false,
            true,
            true,
            false
          ],
          "bearings": [
            75,
            150,
            240,
            330
          ],
          "location": [
            127.063143,
            37.494521
          ]
        }
      ],
      "driving_side": "right",
      "maneuver": {
        "bearing_after": 243,
        "bearing_before": 156,
        "location": [
          127.063143,
          37.494521
        ],
        "modifier": "right",
        "type": "turn"
      },
      "geometry": {
        "coordinates": [
          [
            127.063143,
            37.494521
          ],
          [
            127.062978,
            37.494462
          ]
        ],
        "type": "LineString"
      },
      "ref": "92",
      "name": "남부순환로",
      "mode": "driving",
      "weight": 0.9,
      "duration": 0.9,
      "distance": 16
    },
    {
      "intersections": [
        {
          "in": 0,
          "entry": [
            true
          ],
          "bearings": [
            66
          ],
          "location": [
            127.062978,
            37.494462
          ]
        }
      ],
      "driving_side": "right",
      "maneuver": {
        "bearing_after": 0,
        "bearing_before": 246,
        "location": [
          127.062978,
          37.494462
        ],
        "modifier": "right",
        "type": "arrive"
      },
      "geometry": {
        "coordinates": [
          [
            127.062978,
            37.494462
          ],
          [
            127.062978,
            37.494462
          ]
        ],
        "type": "LineString"
      },
      "ref": "92",
      "name": "남부순환로",
      "mode": "driving",
      "weight": 0,
      "duration": 0,
      "distance": 0
    }
  ],
  "source": "OSRM driving route / OpenStreetMap road data",
  "sourceUrl": "https://router.project-osrm.org/route/v1/driving/127.0497,37.5045;127.0629,37.4946?overview=full&geometries=geojson&steps=true",
  "fetchedOn": "2026-10-25",
  "traffic": "not-live",
  "waypoints": [
    {
      "hint": "8pjvgf___38NAAAATgAAABEAAAAAAAAA6WjIQcX75ULa__lBAAAAAA0AAABOAAAAEQAAAAAAAAC9bwAAuZ-SB09GPALkn5IH9EU8AgIAXwQAAAAA",
      "location": [
        127.049657,
        37.504591
      ],
      "name": "테헤란로",
      "distance": 10.79143345
    },
    {
      "hint": "y87vgf___38JAAAACwAAAAAAAAAgAAAAifJ_QW6-X0AAAAAAp6ZnQgkAAAALAAAAAAAAACAAAAC9bwAAwtOSB74ePAJ005IHSB88AgAAXw8AAAAA",
      "location": [
        127.062978,
        37.494462
      ],
      "name": "남부순환로",
      "distance": 16.7984286
    }
  ]
});
for (const coordinate of REAL_ROUTE.coordinates) Object.freeze(coordinate);
Object.freeze(REAL_ROUTE.coordinates);
