// Only public, fabricated demo state is persisted. No route coordinates or user data.
export const DEMO_STORAGE_KEY = 'hawoncall.browser-demo.v14';
const scalarKeys=['playbackRate','tripId','tripGeneration','progress','gear','speedKph','now','navAt','vehicleAt','playing','candidate','confirmed','confirmedAt','departed','mode','institution'];
export function packDemoState(state, source, revision=Date.now()) {
 const snapshot=Object.fromEntries(scalarKeys.map(k=>[k,state[k]]));
 return {version:14,actor:'car',domain:'journey',source,revision,snapshot};
}
export function restoreDemoState(packet, initial) {
 if(!packet||packet.version!==14||packet.actor!=='car'||packet.domain!=='journey'||typeof packet.source!=='string'||!Number.isFinite(packet.revision)||!packet.snapshot)return null;
 const s=packet.snapshot;
 if(![1,3,6].includes(s.playbackRate))return null;
 if(!Number.isInteger(s.tripGeneration)||s.tripGeneration<0)return null;
 if(typeof s.tripId!=='string'||s.tripId.length>100)return null;
 if(!['pickup','dropoff'].includes(s.mode)||!['school','kindergarten','daycare','academy'].includes(s.institution)||!['D','P'].includes(s.gear))return null;
 if(!Number.isFinite(s.progress)||s.progress<0||s.progress>1||!Number.isFinite(s.speedKph)||s.speedKph<0||s.speedKph>200)return null;
 if(!['now','navAt','vehicleAt'].every(k=>Number.isFinite(s[k])&&s[k]>=0))return null;
 if(!['playing','candidate','confirmed','departed'].every(k=>typeof s[k]==='boolean'))return null;
 if(s.confirmed&&(!Number.isFinite(s.confirmedAt)||s.confirmedAt<0))return null;
 return {...initial,...Object.fromEntries(scalarKeys.map(k=>[k,s[k]])),route:initial.route,notice:''};
}

// Independent keys for guardian plan, institution declarations and each request.
// No operations writer ever stores or merges a journey snapshot.
export function domainStorageKey(domain,id=''){return `${DEMO_STORAGE_KEY}.${domain}${id?'.'+id:''}`;}
export function packDomain(domain,value,source,revision=Date.now(),actor='guardian'){if(!['dayplan','institution','issue'].includes(domain)||!['guardian','institution','car'].includes(actor))return null;if(domain==='dayplan'&&actor!=='guardian'||domain==='institution'&&actor!=='institution')return null;return {version:14,domain,actor,value,source,revision};}
export function validDomainPacket(p){return !!p&&p.version===14&&['dayplan','institution','issue'].includes(p.domain)&&typeof p.source==='string'&&Number.isFinite(p.revision)&&!!p.value&&(p.domain==='dayplan'?p.actor==='guardian':p.domain==='institution'?p.actor==='institution':['guardian','car','institution'].includes(p.actor));}
