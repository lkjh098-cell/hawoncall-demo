import test from 'node:test';
import assert from 'node:assert/strict';
import {stopZoneNotice} from './stop-zone.mjs';
const near={near:true,isFresh:true,gear:'D',arrival:false,routeMismatch:false,departed:false};
test('arrival-zone scenarios show both requested messages without claiming actual permission',()=>{
 for(const [scenario,title] of [['prohibited','주정차 금지구역이에요'],['allowed','주정차 가능구역이에요'],['unknown','주정차 가능 여부를 확인해 주세요']]){
  const result=stopZoneNotice(near,{scenario});assert.equal(result.title,title);assert.equal(result.actualPermission,'unknown');assert.match(result.basis,/시연.*미확인/);assert.match(result.phase,/D 접근/);
 }
 assert.match(stopZoneNotice({...near,gear:'P',arrival:true},{scenario:'allowed'}).phase,/P 정차/);
});
test('no institution zone notice before approach, on stale or changed route, after leaving, or at child GPS route preview',()=>{
 for(const patch of [{near:false},{isFresh:false},{routeMismatch:true},{departed:true}])assert.equal(stopZoneNotice({...near,...patch}),null);
 assert.equal(stopZoneNotice(near,{scenario:'allowed',meetingPreview:true}),null);
 assert.equal(stopZoneNotice(near,{scenario:'untrusted'}).kind,'unknown');
});
