import test from 'node:test';
import assert from 'node:assert/strict';
import {SHOWCASE_STEPS,SHOWCASE_FEATURES,createShowcaseState,reduceShowcase,getShowcaseCoverage,mountShowcase} from './showcase.mjs';

test('every chapter has an immutable scene action and covers only declared features',()=>{
  assert.equal(SHOWCASE_STEPS.length,9);
  assert.equal(new Set(SHOWCASE_STEPS.map(s=>s.id)).size,SHOWCASE_STEPS.length);
  assert.ok(Object.isFrozen(SHOWCASE_STEPS));assert.ok(Object.isFrozen(SHOWCASE_FEATURES));
  const ids=new Set(SHOWCASE_FEATURES.map(f=>f.id));
  for(const s of SHOWCASE_STEPS){assert.ok(Object.isFrozen(s));assert.ok(Object.isFrozen(s.features));assert.equal(s.actionRef,s.sceneId);for(const id of s.features)assert.ok(ids.has(id));}
  for(const f of SHOWCASE_FEATURES)assert.ok(SHOWCASE_STEPS.find(s=>s.sceneId===f.sceneId)?.features.includes(f.id));
});

test('selecting a chapter never marks its features opened or confirms boarding',()=>{
  let s=createShowcaseState();s=reduceShowcase(s,{type:'SELECT',index:5});
  const coverage=getShowcaseCoverage(s);
  assert.equal(s.index,5);assert.equal(coverage.opened,0);assert.equal(coverage.manualConfirmationObserved,false);
  assert.equal(coverage.items.some(f=>f.manualObserved),false);
});

test('opening a scene counts it once and leaves manual actions uncompleted',()=>{
  const original=createShowcaseState();let s=reduceShowcase(original,{type:'SCENE_OPENED',sceneId:'boarding'});
  s=reduceShowcase(s,{type:'SCENE_OPENED',sceneId:'boarding'});
  assert.deepEqual(original.openedSceneIds,[]);assert.deepEqual(s.openedSceneIds,['boarding']);
  const coverage=getShowcaseCoverage(s,{gear:'P',candidate:true,arrival:true});
  assert.equal(coverage.opened,2);assert.equal(coverage.manualConfirmationObserved,false);
  assert.equal(coverage.items.find(f=>f.id==='guardian-confirmation').manualObserved,false);
});

test('manual confirmation evidence comes only from actual journey state',()=>{
  const s=createShowcaseState(),yes=getShowcaseCoverage(s,{confirmed:true}),no=getShowcaseCoverage(s,{confirmed:'true'});
  assert.equal(yes.opened,0);assert.equal(yes.manualConfirmationObserved,true);
  assert.equal(yes.items.filter(f=>f.manualObserved).length,1);assert.equal(no.manualConfirmationObserved,false);
  assert.equal('confirmed' in s,false);assert.equal('consent' in s,false);
});

test('invalid navigation and fake completion events do not change presentation state',()=>{
  const s=createShowcaseState();
  for(const action of [{type:'SELECT',index:-1},{type:'SELECT',index:9},{type:'SELECT',index:1.5},{type:'SCENE_OPENED',sceneId:'confirm'},{type:'CONFIRM'},{type:'GPS_ALLOW'},{type:'DESTINATION_CONSENT'}])assert.equal(reduceShowcase(s,action),s);
});

test('full coverage means screens opened, while safeguards remain unconfirmed',()=>{
  const state=SHOWCASE_STEPS.reduce((s,step)=>reduceShowcase(s,{type:'SCENE_OPENED',sceneId:step.sceneId}),createShowcaseState());
  const coverage=getShowcaseCoverage(state,{confirmed:false});
  assert.equal(coverage.opened,SHOWCASE_FEATURES.length);assert.equal(coverage.manualConfirmationObserved,false);
  assert.ok(coverage.items.every(f=>f.opened));assert.ok(coverage.items.every(f=>!f.manualObserved));
});

test('guardian-only or server imports install no presentation and call no scenes',()=>{
  let count=0;const api=mountShowcase({guardianOnly:true,onScene:()=>count++});
  api.open();api.render({confirmed:true});api.close();api.destroy();assert.equal(count,0);
  assert.deepEqual(api.getState(),createShowcaseState());
});
