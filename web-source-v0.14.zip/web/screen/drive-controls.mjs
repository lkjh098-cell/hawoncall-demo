/** Playback controls operate on fabricated journey events only. */
export function validPlaybackRate(rate) { return [1,3,6].includes(Number(rate)); }
export function mayRepeatDrive(v) {
  return !!v && v.near && v.gear==='D' && !v.playing && !v.confirmed && !v.arrival && !v.routeMismatch && v.isFresh;
}
export function createDriveLoop({getJourney,restart,schedule=setTimeout,cancel=clearTimeout,onWaiting=()=>{}}) {
  let enabled=true, timer=null;
  const stop=()=>{if(timer!==null)cancel(timer);timer=null;onWaiting(false);};
  return {
    setEnabled(value){enabled=!!value;if(!enabled)stop();},
    observe(v){if(!enabled||!mayRepeatDrive(v)){stop();return;}if(timer===null){onWaiting(true);timer=schedule(()=>{timer=null;onWaiting(false);if(enabled&&mayRepeatDrive(getJourney()))restart();},5000);}},
    interrupt(){stop();},
    dispose(){enabled=false;stop();},
  };
}
export function mountDriveControls({getJourney,play,pause,reset,setRate,openNavigation,guardianOnly=false}={}) {
  if(guardianOnly)return {render(){},onTransition(){},dispose(){}};
  const toolbar=document.querySelector('.demo-toolbar');
  const host=document.createElement('div');host.className='drive-playback';host.setAttribute('aria-label','가상 주행 재생');
  host.innerHTML='<button id="drivePlayback" class="drive-start" type="button">▶ 주행 시작</button><label class="drive-rate-label">재생 속도<select id="driveRate" aria-label="주행 재생 속도"><option value="1">1× 실제 시간</option><option value="3">3× 빠르게</option><option value="6">6× 발표용</option></select></label><label class="drive-loop"><input id="driveLoop" type="checkbox" checked>반복</label><button id="driveReset" class="drive-restart" aria-label="주행 처음부터" type="button">↺</button><span id="drivePlaybackHint" role="status"></span>';
  toolbar.prepend(host);
  const button=host.querySelector('#drivePlayback'),rate=host.querySelector('#driveRate'),loopBox=host.querySelector('#driveLoop'),hint=host.querySelector('#drivePlaybackHint');
  let waiting=false,manual=false;
  const restart=()=>{openNavigation?.();reset();play();};
  const loop=createDriveLoop({getJourney,restart:()=>{reset();play();},onWaiting:v=>{waiting=v;}});
  button.onclick=()=>{manual=false;loop.setEnabled(loopBox.checked);const v=getJourney();if(v.playing){loop.interrupt();pause();}else if(v.near||v.confirmed||v.departed||v.routeMismatch)restart();else{openNavigation?.();play();}};
  rate.value=String(getJourney().playbackRate||1);rate.onchange=()=>{const value=Number(rate.value);if(validPlaybackRate(value))setRate(value);};
  loopBox.onchange=()=>{manual=false;loop.setEnabled(loopBox.checked);};
  host.querySelector('#driveReset').onclick=()=>{manual=true;loop.interrupt();reset();};
  const visibility=()=>{if(document.hidden){manual=true;loop.interrupt();if(getJourney().playing)pause();}};
  document.addEventListener('visibilitychange',visibility);
  return {
    setRepeat(value){loopBox.checked=!!value;manual=false;loop.setEnabled(loopBox.checked);},
    render(v){
      if(!manual)loop.observe(v);
      button.textContent=v.playing?'Ⅱ 주행 일시 정지':v.near||v.confirmed||v.departed?'▶ 다시 주행':'▶ 주행 시작';
      button.setAttribute('aria-pressed',String(v.playing));
      if(document.activeElement!==rate)rate.value=String(v.playbackRate||1);
      hint.textContent=waiting?'D 근접 · 5초 후 다시 출발':v.playing?`${v.playbackRate||1}× · 실제 도로 위 가상 주행`:v.arrival?'P 정차 · 보호자 확인은 직접 진행':v.near?'D 근접 · P 주차는 직접 선택':'주행 시작을 누르면 지도와 차량이 움직여요.';
    },
    onTransition(type){if(['PAUSE','PARK','SENSOR','CONFIRM','DEPART','DRIVE','APPROACH','SCENARIO','RESET','NAVIGATION','VEHICLE'].includes(type)){loop.interrupt();if(!['RESET','SCENARIO'].includes(type))manual=true;}if(type==='PLAY')manual=false;},
    dispose(){loop.dispose();document.removeEventListener('visibilitychange',visibility);host.remove();},
  };
}
