/** Employee presentation rail. Opening a scene never implies a completed user action. */
const freezeDeep = value => {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    Object.values(value).forEach(freezeDeep);
    Object.freeze(value);
  }
  return value;
};

export const SHOWCASE_FEATURES = freezeDeep([
  {id:'route-retained',label:'기존 내비 경로 유지',sceneId:'start'},
  {id:'eta',label:'도착 예정 시간',sceneId:'start'},
  {id:'guardian-view',label:'보호자 화면',sceneId:'guardian'},
  {id:'guardian-plan',label:'보호자 일정 작성',sceneId:'guardian'},
  {id:'gps-sharing',label:'아이 위치 공유',sceneId:'child'},
  {id:'gps-quality',label:'위치 시각·정확도 확인',sceneId:'child'},
  {id:'destination-consent',label:'P에서 목적지 변경 동의',sceneId:'meeting'},
  {id:'stop-zone',label:'금지·가능구역 가정 시연',sceneId:'approach'},
  {id:'drive-park',label:'D 근접과 P 정차 구분',sceneId:'approach'},
  {id:'sensor-candidate',label:'탑승 신호는 후보로 표시',sceneId:'boarding'},
  {id:'guardian-confirmation',label:'보호자 직접 확인',sceneId:'boarding',manualAction:'guardian-confirmation'},
  {id:'voice-brief',label:'오늘 일정 음성 안내',sceneId:'briefing'},
  {id:'media',label:'차량 미디어 화면',sceneId:'briefing'},
  {id:'readiness',label:'ETA와 기관 준비 비교',sceneId:'operations'},
  {id:'issue-request',label:'장소·지연·취소 요청',sceneId:'operations'},
  {id:'institution-types',label:'학교·유치원·어린이집·학원',sceneId:'operations'},
  {id:'ecosystem',label:'차량 앱 라이브러리',sceneId:'apps'},
]);

export const SHOWCASE_STEPS = freezeDeep([
  {id:'start',sceneId:'start',actionRef:'start',title:'아이를 만나러 가는 길',takeaway:'아이 위치와 도착 시간을, 한 화면에서.',description:'기존 경로는 유지하면서 움직이는 가상 아이 위치와 차량의 도착 예정 시간을 함께 보세요.',features:['route-retained','eta'],instruction:'직접 볼 것 · 지도 위 이동과 도착 예정 시간',guard:'차량 위치·기어·기관 알림은 가상 시연 상태입니다.'},
  {id:'guardian',sceneId:'guardian',actionRef:'guardian',title:'보호자는 오늘을 준비',takeaway:'보호자의 일정이 차량 안 안내로 이어집니다.',description:'모바일 형태의 보호자 화면에서 오늘 일정과 준비물을 작성할 수 있습니다.',features:['guardian-view','guardian-plan'],instruction:'직접 할 것 · 오늘 일정 편집 후 저장',guard:'현재 반영 범위는 같은 브라우저의 시연 화면입니다. 실제 기관·휴대폰 서버 연결은 없습니다.'},
  {id:'child',sceneId:'child',actionRef:'child',title:'아이와 만날 위치 확인',takeaway:'공유 위치도 시각과 정확도를 함께 봅니다.',description:'아이 화면에서 공유를 직접 시작하고 차량에서 확인하는 흐름입니다. 이 장면은 권한을 요청하지 않습니다.',features:['gps-sharing','gps-quality'],instruction:'직접 볼 것 · 동의·위치 공유 시작·중지 방식',guard:'위치 권한과 공유는 사용자 선택입니다. 오래되거나 부정확한 위치를 도착 근거로 삼지 않습니다.'},
  {id:'meeting',sceneId:'meeting',actionRef:'meeting',title:'목적지 변경은 P에서',takeaway:'공유받은 위치가 내비 목적지를 바로 바꾸지는 않습니다.',description:'차량을 P 상태로 두고 위치를 검토한 뒤 목적지 변경에 직접 동의하는 화면을 보세요.',features:['destination-consent'],instruction:'직접 할 것 · 위치 미리보기 후 변경 여부 선택',guard:'기존 경로는 직접 동의 전까지 유지됩니다. 동의한 목적지는 고정된 좌표이며 아이가 움직여도 자동 변경되지 않습니다.'},
  {id:'approach',sceneId:'approach',actionRef:'approach',title:'가까워도, 도착은 아직',takeaway:'D 근접·P 정차·정차 가능 여부를 나눠 봅니다.',description:'아이 위치 미리보기를 끝내고 기관 경로의 가상 도착 절차로 돌아갑니다. 금지·가능구역 조건을 바꿔 보세요.',features:['stop-zone','drive-park'],instruction:'직접 볼 것 · D 근접 표시와 정차구역 조건 전환',guard:'구역은 가정한 시연입니다. P 기어가 주정차 허용을 증명하지 않으며 실제 표지·시간대 확인이 필요합니다.'},
  {id:'boarding',sceneId:'boarding',actionRef:'boarding',title:'마지막 확인은 보호자',takeaway:'문·좌석 신호만으로 탑승을 확정하지 않습니다.',description:'P와 가상 탑승 신호를 살펴본 뒤 차량 화면의 보호자 확인 버튼을 직접 눌러 보세요.',features:['sensor-candidate','guardian-confirmation'],instruction:'직접 할 것 · 차량 화면에서 보호자 확인',guard:'장면을 넘겨도 보호자 확인은 자동 실행되지 않습니다. 등원 인계 확인도 기관 입실을 증명하지 않습니다.'},
  {id:'briefing',sceneId:'briefing',actionRef:'briefing',title:'만난 뒤, 다음 일정까지',takeaway:'오늘의 다음 약속을 짧은 음성으로 확인합니다.',description:'미디어 화면에서 오늘 일정 안내를 열어 안내문과 브라우저 음성을 체험해 보세요.',features:['voice-brief','media'],instruction:'직접 할 것 · 안내문 확인 후 한 번 듣기',guard:'음성 사용은 직접 선택합니다. 브라우저 음성이며 다른 앱 음악의 음량을 실제 제어하지 않습니다.'},
  {id:'operations',sceneId:'operations',actionRef:'operations',title:'기다림과 변수에도 대응',takeaway:'준비 지연·정차 공간 부족을 요청과 응답으로 남깁니다.',description:'하원콜 상세와 시연 조작에서 기관 준비 선언, 문제 요청, 네 종류 기관을 살펴보세요.',features:['readiness','issue-request','institution-types'],instruction:'직접 할 것 · 준비 상태·문제 알림·시연 기관 선택',guard:'기관 응답은 가상입니다. 요청만으로 경로·일정이 변경되지 않으며 준비 완료는 탑승 완료가 아닙니다.'},
  {id:'apps',sceneId:'apps',actionRef:'apps',title:'차량 경험 안으로 연결',takeaway:'하원콜에서 내비·미디어·차량 앱으로 오갈 수 있습니다.',description:'앱 라이브러리를 열어 기존 화면과 하원콜이 이어지는 구성을 확인해 보세요.',features:['ecosystem'],instruction:'직접 볼 것 · 앱 열기와 이전 화면으로 돌아가기',guard:'앱 셸은 웹에서 재현한 구성입니다. MyHyundai·Pleos 계정이나 차량 서비스에 실제 연결되지 않습니다.'},
]);

export function createShowcaseState() { return {index:0,openedSceneIds:[]}; }
export function reduceShowcase(state, action) {
  if (!state || !Array.isArray(state.openedSceneIds)) return createShowcaseState();
  if (action?.type === 'SELECT' && Number.isInteger(action.index) && action.index >= 0 && action.index < SHOWCASE_STEPS.length) return {...state,index:action.index};
  if (action?.type === 'SCENE_OPENED' && SHOWCASE_STEPS.some(s=>s.sceneId===action.sceneId)) return {...state,openedSceneIds:[...new Set([...state.openedSceneIds,action.sceneId])]};
  return state;
}
/** `opened` counts navigation only; a manual action is observed separately from journey state. */
export function getShowcaseCoverage(state, journey = {}) {
  const opened = new Set(state?.openedSceneIds || []);
  const items = SHOWCASE_FEATURES.map(feature=>({...feature,opened:opened.has(feature.sceneId),manualObserved:feature.manualAction==='guardian-confirmation' && journey?.confirmed===true}));
  return {items,opened:items.filter(f=>f.opened).length,total:items.length,manualConfirmationObserved:journey?.confirmed===true};
}
const esc = value => String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

export function mountShowcase({onScene,getJourney=()=>({}),guardianOnly=false}={}) {
  const noop={render(){},open(){},close(){},destroy(){},getState:createShowcaseState};
  if (guardianOnly || typeof document==='undefined') return noop;
  const toolbar=document.querySelector('.demo-toolbar');
  if (!toolbar) return noop;
  let state=createShowcaseState(),isOpen=false,pending=false,generation=0,lastJourney={};
  const toggle=document.createElement('button');
  toggle.type='button';toggle.className='showcase-toggle';toggle.textContent='직원용 시연';
  toggle.setAttribute('aria-controls','employeeShowcase');toggle.setAttribute('aria-expanded','false');
  (toolbar.querySelector('.toolbar-actions')||toolbar).prepend(toggle);
  const panel=document.createElement('aside');
  panel.id='employeeShowcase';panel.className='showcase-panel';panel.hidden=true;panel.setAttribute('aria-label','직원용 하원 경험 시연');
  panel.innerHTML=`<header class="showcase-header"><div><span class="showcase-kicker">HAWONCALL · FAMILY PICKUP EXPERIENCE</span><h2>아이와 만나는 순간까지, 차 안에서 이어집니다.</h2></div><button type="button" class="showcase-close" aria-label="직원용 시연 닫기">×</button></header><div class="showcase-layout"><nav class="showcase-chapters" aria-label="시연 장면">${SHOWCASE_STEPS.map((s,i)=>`<button type="button" data-showcase-index="${i}"><span>${String(i+1).padStart(2,'0')}</span>${s.title}<i aria-hidden="true"></i></button>`).join('')}</nav><section class="showcase-story" aria-labelledby="showcaseTakeaway"><div class="showcase-position"></div><h3 id="showcaseTakeaway"></h3><p class="showcase-description"></p><div class="showcase-chips"></div><p class="showcase-instruction"></p><div class="showcase-actions"><button type="button" class="showcase-primary" data-showcase-open>장면 열기 <span aria-hidden="true">↗</span></button><button type="button" data-showcase-prev>이전</button><button type="button" data-showcase-next>다음 장면 →</button></div><p class="showcase-feedback" role="status" aria-live="polite"></p></section><section class="showcase-proof" aria-label="시연 확인 사항"><span class="showcase-proof-label">이 장면에서 확인할 원칙</span><p class="showcase-guard"></p><div class="showcase-manual-state"></div><p class="showcase-proof-foot">화면 열기와 동의·탑승 확인은 별개입니다.</p></section></div><footer class="showcase-footer"><details class="showcase-coverage"><summary><strong>둘러본 기능 <span data-showcase-count>0 / ${SHOWCASE_FEATURES.length}</span></strong><span>기능 목록</span></summary><ul>${SHOWCASE_FEATURES.map(f=>`<li data-showcase-feature="${f.id}"><i aria-hidden="true">○</i>${f.label}<small>아직 안 열었어요</small></li>`).join('')}</ul><p>표시는 해당 장면을 열었다는 뜻입니다. 권한 허용·저장·요청·확인 성공을 뜻하지 않습니다.</p></details><details class="showcase-scope"><summary><strong>구현 범위</strong><span>웹에서 체험 · 네이티브 소스 준비 · 실차 검증 전</span></summary><div><p><b>웹에서 체험</b> 화면 전환, 가상 주행·차량 신호·기관 응답, 일정 입력, 요청 흐름, 사용자 선택에 따른 브라우저 위치·음성. 왼쪽 도로는 경로에 따른 시각화이며 주변 차량은 가상입니다. 실차 적용 구상은 순정 시스템 주행 뷰를 유지하는 하원콜 앱 창 연동입니다.</p><p><b>네이티브 소스 준비</b> v0.11 차량·보호자·아이 앱 및 서버 소스와 빌드 자료가 있습니다. 실제 기어·좌석·도어 신호, 내비·오디오와의 실기 연결은 검증 전입니다. 양산 서비스·MyHyundai 계정 연동은 없습니다. 아이 GPS로 변경한 목적지의 후속 탑승 절차는 별도 보완이 필요합니다.</p><p><b>실차 검증 전</b> 주행 중 사용성, 통신·권한·신호 예외, 실제 정차 규제와 운영 협의. 시간 절감·안전 개선의 실측 성과는 제시하지 않습니다.</p></div></details></footer>`;
  toolbar.insertAdjacentElement('afterend',panel);
  const find=s=>panel.querySelector(s);
  const status=find('.showcase-feedback');
  function paintEvidence(journey) {
    const coverage=getShowcaseCoverage(state,journey);
    find('[data-showcase-count]').textContent=`${coverage.opened} / ${coverage.total}`;
    for (const f of coverage.items) {
      const li=find(`[data-showcase-feature="${f.id}"]`);
      li.classList.toggle('is-opened',f.opened);li.querySelector('i').textContent=f.opened?'✓':'○';
      li.querySelector('small').textContent=f.opened?'장면을 열었어요':'아직 안 열었어요';
    }
    const manual=find('.showcase-manual-state');
    manual.textContent=journey?.confirmed===true?'현재 운행 · 보호자 확인 기록 있음':'현재 운행 · 보호자 직접 확인 전';
    manual.classList.toggle('is-confirmed',journey?.confirmed===true);
  }
  function paintStep() {
    const step=SHOWCASE_STEPS[state.index];
    find('.showcase-position').textContent=`${String(state.index+1).padStart(2,'0')} / ${String(SHOWCASE_STEPS.length).padStart(2,'0')}  ·  ${step.title}`;
    find('h3').textContent=step.takeaway;find('.showcase-description').textContent=step.description;
    find('.showcase-chips').innerHTML=step.features.map(id=>`<span>${esc(SHOWCASE_FEATURES.find(f=>f.id===id).label)}</span>`).join('');
    find('.showcase-instruction').textContent=step.instruction;find('.showcase-guard').textContent=step.guard;
    find('[data-showcase-prev]').disabled=state.index===0||pending;
    find('[data-showcase-next]').disabled=state.index===SHOWCASE_STEPS.length-1||pending;
    find('[data-showcase-open]').disabled=pending;
    panel.querySelectorAll('[data-showcase-index]').forEach((button,i)=>{
      const current=i===state.index;button.setAttribute('aria-current',current?'step':'false');
      button.classList.toggle('is-current',current);button.classList.toggle('is-opened',state.openedSceneIds.includes(SHOWCASE_STEPS[i].sceneId));
      button.disabled=pending;
    });
    paintEvidence(lastJourney);
  }
  async function openScene(index) {
    if(pending || typeof onScene!=='function') {if(typeof onScene!=='function')status.textContent='장면 연결을 확인해 주세요.';return;}
    state=reduceShowcase(state,{type:'SELECT',index});
    const step=SHOWCASE_STEPS[state.index],token=++generation;
    pending=true;status.textContent='장면을 여는 중…';paintStep();
    try {
      const result=await onScene(step.sceneId,{stepId:step.id,source:'showcase'});
      if(token!==generation)return;
      if(result===false) {status.textContent='장면을 열지 못했어요. 화면 상태를 확인한 뒤 다시 시도해 주세요.';return;}
      state=reduceShowcase(state,{type:'SCENE_OPENED',sceneId:step.sceneId});
      status.textContent='장면을 열었어요. 화면의 직접 조작을 이어가세요.';
    } catch {
      if(token===generation)status.textContent='장면을 열지 못했어요. 다시 시도해 주세요.';
    } finally {if(token===generation){pending=false;lastJourney=getJourney()||{};paintStep();}}
  }
  function open(){isOpen=true;panel.hidden=false;toggle.setAttribute('aria-expanded','true');lastJourney=getJourney()||{};paintStep();}
  function close(){isOpen=false;panel.hidden=true;toggle.setAttribute('aria-expanded','false');}
  toggle.onclick=()=>isOpen?close():open();
  find('.showcase-close').onclick=()=>{close();toggle.focus();};
  find('[data-showcase-open]').onclick=()=>openScene(state.index);
  find('[data-showcase-prev]').onclick=()=>openScene(Math.max(0,state.index-1));
  find('[data-showcase-next]').onclick=()=>openScene(Math.min(SHOWCASE_STEPS.length-1,state.index+1));
  panel.querySelectorAll('[data-showcase-index]').forEach(button=>button.onclick=()=>openScene(Number(button.dataset.showcaseIndex)));
  paintStep();
  return {render(v){lastJourney=v||getJourney()||{};if(isOpen)paintEvidence(lastJourney);},open,close,destroy(){generation++;panel.remove();toggle.remove();},getState(){return {...state,openedSceneIds:[...state.openedSceneIds]};}};
}
