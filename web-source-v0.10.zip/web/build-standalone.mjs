import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {Script} from 'node:vm';
const base=new URL('./',import.meta.url),read=name=>readFile(new URL('screen/'+name,base),'utf8');
const [html,css,maplibreCss,maplibreJs,data,model,map,sync,app,shell,operations,voice,operationsUI]=await Promise.all(['index.html','cockpit.css','vendor/maplibre-gl.css','vendor/maplibre-gl.js','route-data.mjs','model.mjs','real-map.mjs','sync.mjs','cockpit.js','pleos-shell.mjs','operations.mjs','voice.mjs','operations-ui.mjs'].map(name=>name==='pleos-shell.mjs'?read(name).catch(error=>{if(error.code==='ENOENT')return '';throw error;}):read(name)));
const strip=s=>s.replace(/^import[^\n]*\n/gm,'').replace(/^export /gm,'');
const wrap=s=>{const names=[...s.matchAll(/^export (?:function|const|let|class) (\w+)/gm)].map(m=>m[1]);return `const {${names.join(',')}} = (()=>{\n${strip(s)}\nreturn {${names.join(',')}};})();`;};
const code=[wrap(data),wrap(model),wrap(map),wrap(sync),wrap(operations),wrap(voice),wrap(operationsUI),...(shell?[wrap(shell)]:[]),'(()=>{'+strip(app)+'})();'].join('\n');new Script(code,{filename:'hawoncall-browser-v10.js'});
// MapLibre's UMD distribution contains its worker implementation and creates a
// Blob URL at runtime. Both CSS and UMD JS are embedded for a one-file upload.
const safeScript=s=>s.replace(/<\/script/gi,'<\\/script').replace(/\n\/\/# sourceMappingURL=.*(?=\n|$)/g,'');
const licenses=await Promise.all(['vendor/MAPLIBRE-LICENSE.txt','vendor/OPENFREEMAP-STYLES-LICENSE.md','vendor/POSITRON-LICENSE.md'].map(read));
const output=html.replace('<script type="module" src="./pleos-shell.mjs"></script>','').replace(/<link rel="stylesheet" href="\.\/vendor\/(?:leaflet|maplibre-gl)\.css">/,()=>'<style>'+maplibreCss+'</style>').replace('<link rel="stylesheet" href="./cockpit.css">',()=>'<style>'+css+'</style>').replace(/<script src="\.\/vendor\/(?:leaflet|maplibre-gl)\.js"><\/script>/,()=>'<script>'+safeScript(maplibreJs)+'</script>').replace('<script type="module" src="./cockpit.js"></script>',()=>'<script type="module">\n'+safeScript(code)+'\n</script>').replace('</body>',()=>'<\!-- Third-party licenses retained for this single-file distribution.\n'+licenses.join('\n\n').replace(/-->/g,'—>')+'\n--></body>');
if(/<(?:script|link)[^>]+(?:src|href)="\.\//.test(output))throw new Error('Standalone output still references a local file.');
await mkdir(new URL('dist/',base),{recursive:true});await writeFile(new URL('dist/index.html',base),output);await writeFile(new URL('실제지도_차량시연.html',base),output);console.log(`Built dist/index.html (${Buffer.byteLength(output)} bytes)`);
