# 하원콜 서버 0.10 · 만남 안내 / 기관 준비 / 예외 대응 / 보호자 일정

Express + WebSocket + SQLite로 동작하는 서버입니다. 외부 클라우드·문자·전화 서비스 없이 로컬 실행하며, 포함된 서울 도로·주차 참고 데이터를 제공합니다. 기관 목록, 보호자 등록, 차량 상태 전달을 같은 API로 연결합니다. 아래 기존 웹 안내는 학원 픽업 중심이며 v0.7의 학교·유치원·어린이집과 양방향 UI는 네이티브 앱에서 확인합니다.

## 실행

Node.js **22.13 이상**이 필요합니다. `node:sqlite` 내장 모듈을 사용해 별도 네이티브 SQLite 빌드가 필요하지 않습니다. 개발 지시서의 Node 20 / better-sqlite3 조합 대신 이 구성을 선택했습니다. 검증 환경은 macOS, **Node 26.7.0**입니다.

```sh
npm ci
npm run bootstrap
npm start
```

`bootstrap`을 호출하면 실재하지 않는 시연 학원 `HAWON01`, 학교 `SEOULSCH`, 유치원 `SEOULKID`, 어린이집 `SEOULDAY`를 생성합니다. 실행 결과에 무작위 관리자 비밀번호가 한 번 표시됩니다. 이미 존재하면 비밀번호를 바꾸지 않습니다. 비밀번호를 직접 정하려면 최초 생성 시 `ACADEMY_PASSWORD='12자-이상-고유한-비밀번호' npm run bootstrap`을 사용하세요. 학원 기본 계정은 `ACADEMY_CODE`, `ACADEMY_NAME`, `INSTITUTION_TYPE`도 설정할 수 있습니다. 원문 비밀번호는 DB에 저장하지 않습니다.

- 홈: <http://127.0.0.1:3000/>
- 학원 화면: <http://127.0.0.1:3000/academy/HAWON01>
- 보호자 등록: <http://127.0.0.1:3000/setup>
- **모든 차량 신호가 가상인 웹 시뮬레이터**: <http://127.0.0.1:3000/demo>

학원 화면에 로그인한 뒤 새 창에서 보호자 등록 → 토큰 보관 → 웹 시뮬레이터의 ‘전체 흐름’을 실행하세요. ‘학원에 하원 호출’이 보이면 학원 화면에서 ‘내려보냄’을 누르세요. 가상 차량 화면에도 확인 상태가 전달됩니다. 이 웹 시연은 Android 앱이나 Pleos 차량 신호의 실기 검증을 대신하지 않습니다.

Android Emulator가 접근할 때는 `HOST=0.0.0.0 npm start`로 실행하고 차량 앱에 `http://10.0.2.2:3000`을 입력하세요. 다른 기기에서는 맥의 같은 네트워크 주소를 사용합니다. 기본 바인딩은 `127.0.0.1`이며 이 로컬 서버를 인터넷에 공개하는 설정은 포함하지 않습니다. 실제 배포에는 HTTPS/WSS가 필요합니다.

## 설정과 데이터

환경 변수는 실행하는 셸에서 설정합니다. `.env.example`은 예시이며 `.env`를 자동으로 읽지 않습니다.

- `PORT`: 기본 3000
- `HOST`: 기본 127.0.0.1
- `DATABASE_PATH`: 기본 `./data/hawoncall.sqlite`
- `ACADEMY_CODE` / `ACADEMY_NAME` / `ACADEMY_PASSWORD`: 최초 계정 생성에만 사용

비밀번호는 무작위 salt + scrypt 해시, 차량 토큰과 학원 세션은 SHA-256 해시로 저장합니다. 차량 토큰은 연결 생성 시 한 번 발급하는 256비트 난수입니다. 학원 세션은 12시간 뒤 만료됩니다. 브라우저 인증 정보는 현재 탭의 sessionStorage만 사용합니다. 자동 공개 관리자 계정, 하드코딩 비밀번호, 위치 수집은 없습니다.

픽업과 이벤트 로그는 생성 후 90일이 지나면 시작 시·매시간 삭제합니다. 아이 호칭·일정·보호자 동의 시각 및 연결 정보는 연결 사용을 위해 유지됩니다. 이 로컬 버전의 연결 해제·개인정보 삭제는 운영자가 서버 중지 후 DB에서 해당 연결과 관련 픽업을 지워 처리해야 합니다. 학원 목록은 최근 90일 안의 최대 200건을 조회합니다.

## API 계약

모든 오류는 `{ "error": "...", "message": "한국어 설명" }` 형식이며 설정 불일치 등의 기계 판별 사유에는 선택적 `code`가 붙습니다. 차량 생성 설정 불일치의 409 코드는 `LINK_CONFIGURATION_CHANGED`입니다. 인증 헤더는 `Authorization: Bearer <token>`입니다. 입력의 알 수 없는 필드는 거절합니다. 특히 위치 좌표는 저장하거나 학원에 전달하지 않습니다.

- `POST /api/academy/session` `{code,password}` → `{token,expiresAt,academy:{id,code,name}}`
- `DELETE /api/academy/session` 학원 인증 → 204
- `POST /api/links` `{academyCode,childName,weekday:[1,2,3,4,5],pickupTime:"21:50",baseLeadSeconds:300,guardianConsent:true}` → `{link,carToken}`
- `GET /api/car/config` 차량 인증 → `{link}`
- `POST /api/trips` 차량 인증 `{linkId,clientTripId}` → `{trip}`. 동일 clientTripId는 같은 픽업 반환. 연결별 동시 진행 픽업은 1건.
- `GET /api/trips/:id` 차량 인증 → `{trip}`
- `POST /api/trips/:id/events` 차량 인증 `{eventId,type,at,etaMin?,confirmation?}` → `{trip}`
- `GET /api/academy/trips` 학원 인증 → `{trips}`
- `POST /api/trips/:id/released` 학원 인증, 빈 JSON 객체 → `{trip}`
- `GET /api/health` → 연결 상태·보관 정책

link 필드: `id, childName, academyName, academyCode, weekday, pickupTime, baseLeadSeconds, guardianConsent`. 요일은 월요일 1 ~ 일요일 7, 준비 시간은 60~1200초입니다. 학원 좌표·POI 연결은 차량 내부에서 설정합니다. 순정 내비 경로와 다음 목적지는 앱이 변경하지 않습니다.

trip 필드: `id, linkId, clientTripId, childName, academyName, status, etaMin, createdAt, updatedAt, calledAt, arrivedAt, boardedAt, cancelledAt, releasedAt, confirmation`. 초기 상태는 `PLANNED`, 이후 `EN_ROUTE`, `CALLED`, `ARRIVED`, `BOARDED`(PICKUP), `HANDED_OVER`(DROPOFF) 또는 `CANCELLED`입니다. `DONE`은 차량 내 상태이며 서버에서는 방향별 완료 상태로 종료합니다.

이벤트 종류는 `ETA | CALL | ARRIVED | BOARDED | HANDED_OVER | CANCEL`. `at`은 UTC ISO 문자열입니다. ETA는 0~1440의 정수 분만 허용합니다. eventId는 픽업별 유일한 1~100자 영숫자·대시·밑줄입니다. 같은 eventId와 같은 내용의 재시도는 현재 trip과 `idempotent:true`를 반환합니다. 같은 ID의 내용 변경은 409입니다. 이미 종료된 픽업에는 새 이벤트를 적용하지 않습니다. ARRIVED가 먼저 오면 호출 시각도 설정하고, 나중의 CALL은 ARRIVED를 이전 상태로 돌리지 않습니다. 탑승·인계는 ARRIVED에서만 허용합니다. 학원 내려보냄은 CALLED/ARRIVED에서 허용하며 재시도해도 최초 확인 시각을 유지합니다.

WebSocket은 `/ws/academy/:code`, `/ws/car/:tripId`에 연결한 직후 첫 메시지로 `{type:"AUTH",token:"..."}`을 보내야 합니다. URL에 토큰을 넣지 않습니다. 성공 시 즉시 초기 스냅샷을 받으며 변경 시 학원에는 `{type:"TRIPS",trips}`, 차량에는 `{type:"TRIP",trip}`이 옵니다. 인증 전 5초 timeout, 4KB 메시지 제한, 동일 origin 브라우저 검사, 느린 소비자 제한, ping/pong가 적용됩니다. 네이티브 클라이언트는 Origin을 생략할 수 있습니다. 웹은 연결 단절 시 재연결하고 10초 간격 REST polling을 병행합니다.

## 검증

```sh
npm test
```

`node:test` + supertest + ws로 REST 정상 흐름, 동의·입력 검증, 인증과 학원/차량 간 접근 격리, 중복 이벤트/픽업 재시도, 종료 상태 보호, 빠른 도착, 내려보냄, WebSocket 초기/갱신·인증 timeout, 위치/비밀 미전달, 90일 삭제, SQLite 재시작 지속성을 검사합니다. 웹 브라우저에서 실제 화면과 흐름을 별도로 확인해야 합니다.


## 0.3 인계 확인 계약

차량의 접근(APPROACHING)과 센서 후보(BOARDING_DETECTED)는 차량 내 상태입니다. 서버 ARRIVED는 기어 P와 최근 근접 위치를 함께 확인한 최초 도착 기록이며, 이후에도 현재 차량의 P 상태가 계속 유지된다고 보장하는 실시간 신호가 아닙니다. 기어 P는 합법·안전한 정차 장소의 증명이 아니므로 보호자가 안전한 주차 여부를 확인합니다.

BOARDED 이벤트는 `confirmation: "GUARDIAN"`가 필수이며, 서버는 이 필드를 차량 UI에서 명시 확인했다는 기록으로 저장합니다. 보호자 신원이나 아이 본인을 서버가 독립적으로 식별·인증했다는 의미는 아닙니다. 기존 BOARDED 데이터의 확인 필드는 null로 유지합니다. 웹 자동 시연은 센서 감지에서 멈추며 별도 보호자 확인을 눌러야 완료합니다.

## v0.7 서울 등하원 범위와 승하차 참고 지점

서비스 설정 범위는 `SEOUL`이다. 이것은 기존 기관의 실제 주소를 확인했다는 뜻이 아니다. 운영자가 등록한 기관 유형은 `SCHOOL`, `KINDERGARTEN`, `DAYCARE`, `ACADEMY`이며 기존 기관/연결은 `ACADEMY`, `PICKUP`으로 이전된다. 기존 `academyCode`, `academyName`, `pickupTime` 필드는 호환성을 유지한다. 링크 응답에는 `institutionType`, `institutionCode`, `institutionName`, `journeyType`, `serviceArea`, `isDemoInstitution`, `pickupSpot`이 추가된다. bootstrap이 만드는 기관은 실재 기관이 아닌 시연용이며 응답에 명시한다. 기관 코드와 입력 유형이 일치해야 한다.

보호자 등록은 `institutionType`(생략하면 코드에 등록된 유형), `journeyType`(`PICKUP` 또는 `DROPOFF`, 기본 `PICKUP`), `serviceArea`(기본 `SEOUL`)를 받는다. 서울 외 서비스 값은 거절한다. 차량의 `POST /api/trips`에는 위 세 값을 선택적으로 보내 저장된 설정과의 일치를 검사할 수 있다. trip의 `journeyType`은 생성 시 고정된다. 이후 링크 설정이 바뀌어도 해당 trip의 방향은 바뀌지 않는다. `BOARDED`는 하원 픽업, `HANDED_OVER`는 등원 인계에만 허용하며 둘 다 선행 `ARRIVED`와 `confirmation: "GUARDIAN"`이 필요하다. 두 완료 상태와 `CANCELLED`는 종료 상태다. 등원 완료에는 `handedOverAt`이 반환된다.

### 참고 지점 조회·선택

- `GET /api/guardian/pickup-spots`는 보호자 bearer로 서울 참고 목록을 조회한다. 선택적으로 `?lat=37.5&lon=127.0`을 함께 보낼 수 있다. `q`(80자 이하)는 전체 원자료의 지점 이름·주소를 검색하고 결과를 최대 200개로 제한한다. 응답 `total/truncated`는 검색 전체 건수·잘림 여부다. 좌표는 서울 서비스 경계 안에 있어야 하며 거리순 조회에만 사용하고 저장하지 않는다. 목록 조회는 선택 지점이나 내비게이션 경로를 바꾸지 않는다.
- 응답은 `{ serviceArea, spots, selectionAllowed, recommendedSpotId, recommendationBasis }`이다. spot에는 `id`, `name`, `latitude`, `longitude`, `state`, `eligible`, `reason`, `permissionExpiresAt`, `maxDwellSeconds`, `waitSampleCount`, `estimatedWaitSeconds`, `sourceId`, `sourceName`, `sourceUrl`, `address`가 있다. 좌표 조회 시 `distanceMeters`가 추가된다.
- `POST /api/guardian/pickup-spot`의 본문은 `{ "spotId": "..." }`만 받는다. 확인된 현재 허가가 유효하고 방향·기관 유형·승용차 범위와 일치하는 지점만 선택한다. 불명 ID는 404, 미확인·차단·만료·범위 불일치는 409다. 성공 응답은 `{ link }`이다.
- 보호자·차량 config의 `link.pickupSpot`은 현재도 자격이 유효할 때만 반환한다. 만료·차단된 선택은 `null`로 닫힌다. 클라이언트도 이미 수신한 `permissionExpiresAt`을 확인해야 한다. 이 값은 전체 허가 만료와 현재 일일 시간 창의 끝 중 빠른 시각이다.
- `GET /api/guardian/road-context?lat=&lon=`는 동일한 서울 좌표 검증 후 반경 2km, 최대 500개의 실제 도로 선형 참고자료를 반환한다. 응답의 `featureCollection`은 GeoJSON이며 `truncated`로 잘림을 표시한다. 좌표 생략 시 빈 목록과 `requiresCoordinates: true`다. 도로 선형은 주행 경로·정차 허가를 뜻하지 않는다.

- `GET /api/guardian/protection-facilities?q=`는 보호자 인증으로 어린이보호구역 지정 시설의 이름·주소·자치구를 검색한다. 최대 100개와 `total/truncated/source`를 반환한다. `protectionAreaGeometryAvailable: false`, `completeHazardMap: false`를 명시하며 주소 목록으로 도로 규제 경계·승하차 허가를 추론하지 않는다.

### 운영자 허가 자료와 학습 제한

`server/data/seoul-reference.geojson`은 string `id`, Point geometry, `properties.name/sourceId/sourceName/sourceUrl/address`를 가진 FeatureCollection이다. `seoul-boundary.geojson`은 출처를 명시한 서울 서비스 경계 Polygon 또는 MultiPolygon(Feature/FeatureCollection도 지원)이다. 경계가 없으면 자격은 열리지 않는다. 제공된 공식 도로·주차·보호구역 자료는 **문맥 참고자료**이며 해당 자료만으로 승하차 허가가 성립하지 않는다. reference 속성의 `VERIFIED` 표시는 승인으로 취급하지 않는다. 보호자는 허가나 상태를 자체 승인할 수 없다.

실제 운영 전에 별도의 운영자 관리 `spot-permissions.json`에 `{ "permissions": [...] }`를 구축해야 한다. 각 기록은 `id`, `spotId`, `state: "VERIFIED"`, `authorityName`, `permissionDocumentRef`, `operatorAuditorId`, `auditDocumentRef`, `auditedAt`, `roadRestrictionsReviewed: true`, `safeAccessReviewed: true`, `schoolZoneRestrictionsReviewed: true`, `signRulesReviewed: true`, `calendarDates: ["YYYY-MM-DD"]`, `allowedWeekdaysKST: [1,2,3,4,5]`(월=1, 일=7), `timeWindowsKST: [{"start":"08:00","end":"09:00"}]`, `maxDwellSeconds`(1~3600 정수), `validFrom`, `validUntil`, `serviceArea: "SEOUL"`, `journeyTypes`, `vehicleTypes: ["PASSENGER_CAR"]`, `institutionTypes`를 요구한다. `calendarDates`에는 공휴일·휴교일·임시 규제를 검토한 실제 감사 대상 날짜만 명시한다. 한국 시간 요일과 시간 창도 모두 일치해야 한다(`end: "24:00"` 허용, 자정 넘는 창은 날짜별로 나눔). `validFrom/validUntil`은 실제 허용 시간의 연속 구간이어야 한다. 시간대별 제한이 있으면 각 허용 구간으로 발급해야 하며 종일 허가로 넓혀 적지 않는다. 운영자 문서의 진위와 권한은 파일 반영 전에 별도 감사해야 한다. 공개 HTTP 승인 API는 없다. 배포 자료에는 검증된 실제 허가 지점을 가장한 테스트 fixture를 넣지 않는다. 허가 자료를 교체하면 서버를 재시작해야 한다.

대기시간 학습은 현재 허가가 있는 선택 지점을 trip 생성 때 고정한 뒤 실제 지점 도착과 완료 양쪽에 위치 관측 증거가 있을 때만 실행한다. `ARRIVED`, `BOARDED`, `HANDED_OVER`는 선택적 `arrivalSpotEvidence: {spotId, observedAt, distanceMeters, accuracyMeters?, source: "PLEOS_FUSED_LOCATION", parkedWaitSeconds?}`를 받는다. 점유 위치 좌표 자체는 전송·저장하지 않는다. 관측은 서버 수신 시 30초 이내(미래 시계 오차 최대 5초), 같은 고정 지점에서 30m 이내, 정확도 값이 있으면 20m 이내여야 한다. point ID·허가 증거·참고 좌표 형상을 모두 비교한다. 이는 인증된 차량 앱의 실제 위치 어댑터를 신뢰하는 경계이며 서버가 GPS를 암호학적으로 증명하는 것은 아니다.

일반 기관 목적지의 `ARRIVED`만으로는 지점 학습을 하지 않는다. 나중에 별도의 유효한 지점 관측 `ARRIVED`가 오면 그 서버 수신 시각부터 지점 체류 구간을 연다. 완료도 현재 위치 증거와 명시 보호자 확인이 모두 있어야 학습한다. 앱은 실제 위치가 선택 지점 근처이고 P 상태인 구간의 `parkedWaitSeconds` 정수를 완료 증거에 제공한다. 서버는 지점 도착~완료 수신 간격과 P 체류 시간이 모두 0~`maxDwellSeconds`(최대 3600초)인지, P 체류가 수신 간격보다 30초 이상 길지 않은지 확인한다. 원격 서버는 기어 연속성을 직접 관측하지 않으므로 실제 차량 어댑터의 P·위치 신선도 통합 검증이 필요하다. 선택 지점과 OEM 목적지는 서로 다를 수 있으며 지점 선택이 내비 경로를 바꾸지 않는다.

오프라인 대기열에서 관측이 만료되거나 현재 지점·허가와 맞지 않으면 구조가 유효한 도착·완료 이벤트는 수용하고 `arrivalEvidenceAccepted: false`로 학습만 배제한다. 좌표 등 금지된 키를 포함하거나 출처·자료형이 잘못된 증거는 거절한다. 이로써 만료된 부가 관측 때문에 안전한 여정 완료 대기열이 막히지 않는다. 허가가 변경·만료되면 학습하지 않는다. `trip_id` 유일 키로 반복 전송은 한 번만 반영한다. 취소·ETA·방문 횟수·임의 평점은 학습하지 않는다.

같은 지점·방향·기관 유형·동일 허가 증거·한국 시간 요일·시간대(1시간)의 완료 표본이 5건 이상일 때만 P 체류 평균을 표시한다. 조회 좌표를 함께 보낸 경우에만 그 좌표에서 1km 이내이고 같은 문맥의 표본이 5건 이상인 현재 유효한 지점들을 평균 P 체류시간이 짧은 순서, 이어 거리순으로 배치한다. 이 지점들에만 `recommendationRank`(1부터)와 `recommendationConfidence: "LIMITED_OBSERVATIONS"`를 붙이고 1위를 `recommendedSpotId`로 제시한다. 먼 지점·미확인·차단·만료 지점·5건 미만 지점은 학습 추천에 올리지 않는다. 좌표가 없으면 평균 관측값은 보여도 추천 순위·개인화 추천은 반환하지 않는다. 이는 관측된 체류시간의 비교이며 안전성·적법성 점수가 아니다. 추천 시에도 현재 허가를 다시 검사하고 지점 선택·경로 변경은 자동 실행하지 않는다. 표본은 trip과 함께 90일 뒤 삭제된다. 현재 보호자 UI는 조회 좌표를 기본 전송하지 않으므로 위치를 반영한 추천은 향후 기관 좌표 연결에서 사용할 API 기능이다. 자료 출처와 기준일은 `server/data/sources.json`을 확인한다. 배포 기본 자료에는 운영자가 현장·허가를 확인한 지점이 없으므로 선택 가능 지점·실제 학습 표본은 0건이다.


## v0.10 운영 API · 실제 로컬 저장

기존 v0.7 API와 인증은 그대로 동작한다. 추가 기능도 실제 SQLite에 저장하며 공개 브라우저의 정적 시연과 저장소를 공유하지 않는다. `SCHOOL | KINDERGARTEN | DAYCARE | ACADEMY`, 연결·등하원별 고정된 `PICKUP | DROPOFF` 방향, 현재 승하차 허가 검사와 명시적인 차량 보호자 완료 확인을 유지한다. 기본 데이터의 검증된 승하차 지점은 **0개**다.

### 보호자 일정과 음성 선호

- `GET /api/guardian/day-plan?serviceDate=YYYY-MM-DD` → `{dayPlan}`. 날짜 생략 시 서울 날짜다.
- `PUT /api/guardian/day-plan` → `{dayPlan}`. 보호자 토큰이 속한 연결의 해당 날짜를 교체한다. 차량·기관 토큰으로 작성할 수 없다.

```json
{
  "serviceDate": "2026-10-26",
  "items": [{"time":"18:30","title":"저녁","note":"물 챙기기"}],
  "reminder": "가방 확인",
  "voicePreferences": {"enabled":false,"outbound":true,"afterBoarding":true}
}
```

날짜는 실제 달력 날짜이며 서울 오늘 기준 앞뒤 90일 이내다. 일정은 0~8개, 시각 `HH:mm`, 제목 1~60자, 메모 0~160자, 알림 0~200자다. 모든 문구는 일반 한 줄 텍스트이고 꺾쇠·제어 문자는 거절한다. `note`, `reminder`는 생략하면 빈 문자열, `voicePreferences`를 생략하면 위 기본값이다. 음성 선호 객체를 보내면 세 불리언을 모두 보내야 한다. 알려지지 않은 필드는 거절한다. 응답에는 정규화한 필드와 `source:"GUARDIAN"`, `updatedAt`이 추가된다. 저장 전에는 `items:[]`, 빈 알림, 기본 음성 선호, `updatedAt:null`이다. 같은 기관의 다른 보호자에게 공개하지 않는다. 외부 캘린더 연동이나 계정 연결 기능은 없다.

음성 재생은 차량의 선택 기능이다. 일정 저장 성공은 음성 재생 성공을 뜻하지 않는다. 일정 최대 3개와 알림만 간단히 읽고 출발 전 1회, PICKUP의 명시적인 탑승 완료 뒤 1회만 안내한다. DROPOFF의 인계 완료를 귀가 시작으로 간주하지 않는다. 네이티브 음성 엔진·오디오 포커스 사용 가능 여부는 차량 앱에서 확인한다.

### 보호자·차량 운영 조회

`GET /api/guardian/operations`, `GET /api/car/operations`는 각 토큰의 같은 연결만 조회한다. 선택 검색 조건은 `serviceDate`와 `tripId`다. `tripId` 생략 시 같은 연결에서 가장 최근 생성한 등하원, 하나도 없으면 `tripId:null`이다. 다른 연결의 `tripId`는 404다.

```json
{
  "tripId":"tr_example", "journeyType":"PICKUP", "institutionType":"SCHOOL",
  "meetingPoint":{
    "label":"정문", "entranceHint":"오른쪽 출입구", "meetingNotes":"보행 통로를 비워 주세요",
    "referenceSpotId":null, "referenceSpot":null,
    "permission":{"eligible":false,"state":"UNVERIFIED","reason":"NO_REFERENCE_SPOT","permissionExpiresAt":null,"maxDwellSeconds":null},
    "source":"INSTITUTION", "updatedAt":"2026-10-26T08:00:00.000Z",
    "permissionCheckedAt":"2026-10-26T08:01:00.000Z", "guidanceIsPermission":false
  },
  "readiness":{
    "status":"PREPARING", "readyAt":"2026-10-26T08:08:00.000Z", "updatedAt":"2026-10-26T08:00:00.000Z",
    "source":"INSTITUTION", "fresh":true,"expiresAt":"2026-10-26T08:15:00.000Z","releasedAt":null
  },
  "timing":{
    "etaMin":3,"etaAt":"2026-10-26T08:00:00.000Z","etaReceivedAt":"2026-10-26T08:00:00.000Z",
    "etaFresh":true,"estimatedArrivalAt":"2026-10-26T08:03:00.000Z","estimatedWaitMinutes":5,
    "reason":"KNOWN","etaSource":"VEHICLE_EVENT","etaExpiresAt":"2026-10-26T08:02:00.000Z",
    "etaTtlSeconds":120,"readinessTtlSeconds":900
  },
  "issues":[], "dayPlan":{"serviceDate":"2026-10-26","items":[],"reminder":"","voicePreferences":{"enabled":false,"outbound":true,"afterBoarding":true},"source":"GUARDIAN","updatedAt":null},
  "serverTime":"2026-10-26T08:01:00.000Z"
}
```

기관 만남 안내 미입력 시 문자열은 비우고 `source:"UNSET"`, `updatedAt:null`이다. 기관 준비 미입력은 `status:"UNKNOWN"`, 시각 `null`, `source:"UNSET"`, `fresh:false`다. 준비 상태는 기관이 입력한 선언이며 물리적으로 내려보냈다는 증거가 아니다. `releasedAt`은 기존 실제 내려보냄 이벤트를 별도로 유지한다.

차량 ETA의 **관측 시각과 서버 수신 시각 둘 다** 120초 미만일 때 최신이다. 서버가 실제 수용한 ETA의 두 시각을 별도 열에 보관하므로 늦게 도착한 구형 ETA가 최신성을 갱신하지 않는다. ARRIVED 상태에서는 기존 최초 도착 관측·수신 시각의 ETA 0을 사용한다. 기관 준비 입력은 900초 미만이면 최신이다. 미래 관측·입력 시각은 최신으로 인정하지 않는다. 예전 DB에서 관측·수신 시각을 확인할 수 없는 ETA는 미확인으로 남긴다.

두 출처가 모두 최신이고 기관 `readyAt`이 있어야 대기 시간을 계산한다. `max(0,ceil((readyAt-max(serverNow,observedEtaArrivalAt))/분))`이며 현재 서버 시각을 사용한다. 결과는 기관 선언과 차량 관측을 비교한 추정이며 실시간 학습 예측으로 표시하지 않는다. `reason`은 `KNOWN | MISSING_ETA | STALE_ETA | MISSING_READINESS | STALE_READINESS | TRIP_TERMINAL`이고 미확인·오래됨·종료 상태는 `estimatedWaitMinutes:null`이다. ETA·준비 시각 자체는 오래되었더라도 출처와 최신성 표식과 함께 응답할 수 있다. 순정 내비 경로를 변경하거나 대기 시간을 채우는 우회를 하지 않는다.

### 기관 작성과 예외 대응

기관 웹 `/academy/:code`에서 기존 목록과 내려보냄을 유지하면서 ‘기관 만남 안내 설정’, 등하원별 ‘준비·예외 대응’을 사용할 수 있다. 별도 클라우드 계정은 필요 없다.

- `GET /api/academy/meeting-point` → `{meetingPoint}`. 기관 단독 미리보기의 허가 방향은 PICKUP이다. 보호자·차량 조회는 실제 해당 등하원의 고정 방향으로 허가를 재검사한다.
- `PUT /api/academy/meeting-point` `{label,entranceHint,meetingNotes?,referenceSpotId?}` → `{meetingPoint}`. label 1~80자, entranceHint 1~160자, meetingNotes 0~240자, referenceSpotId는 존재하는 공공 참고 지점 또는 null이다. 미검증 참고 지점도 안내에 첨부할 수 있으나 허가로 승격되지 않는다. `permission`은 기존 증빙 레지스트리를 현재 날짜·시각·기관·차량·방향에 맞춰 재검사한 결과다. 링크 선택 지점과 등하원 스냅샷을 바꾸지 않는다.
- `GET /api/academy/trips/:id/operations` → `{tripId,journeyType,readiness,timing,issues,serverTime}`. 소속 기관의 등하원만 읽을 수 있으며 보호자의 개인 dayPlan은 제외한다.
- `PUT /api/academy/trips/:id/readiness` `{status:"PREPARING"|"READY"|"DELAYED",readyInMinutes?}` → `{tripId,readiness,timing,issues}`. 준비 시간은 0~120 정수 분, 생략 시 예상 시각 미확인이다. READY는 지금 준비 완료이며 시간 생략 또는 0만 허용한다. 종료된 등하원은 409다. 탑승·인계·내려보냄 상태를 자동 변경하지 않는다.
- `POST /api/guardian/trips/:id/issues`, `POST /api/car/trips/:id/issues` `{requestId,kind,message?,spotId?}` → 생성 201 `{issue,idempotent:false}`. `kind`는 `NO_STOP_SPACE | CHILD_DELAYED | ALTERNATE_POINT_REQUEST | CANCEL_REQUEST | RUNNING_LATE`, message는 0~240자다. 요청 ID는 1~100자 영숫자·대시·밑줄이다. spotId는 대체 지점 요청에만 허용하며 **현재 실제 방향·차량에 유효한 기존 허가**가 있어야 한다. 지점 없이 기관에 대안을 문의할 수 있다. 기본 데이터의 미검증 지점을 제안하거나 선택하지 않는다.
- `PUT /api/academy/trips/:id/issues/:issueId` `{requestId,status:"ACKNOWLEDGED"|"RESOLVED"|"DECLINED",reply?}` → `{issue,idempotent:false}`. reply 0~240자. 소속 기관만 회신 가능하다. OPEN/ACKNOWLEDGED에서 대응할 수 있고 RESOLVED/DECLINED 뒤 새 회신은 409다.

issue 필드는 `id,tripId,requestId,actor,kind,message,spotId,status,reply,createdAt,updatedAt`이다. 최초 상태 OPEN, 회신 전 reply는 null이다. 요청 중복 키는 **trip + actor(GUARDIAN/CAR) + requestId**, 기관 회신 중복 키는 **issue + requestId**다. 동일 키·동일 정규화 내용 재시도는 200과 현재 issue, `idempotent:true`; 내용이 달라지면 409다. 종료 이후에도 이미 수용된 동일 요청·회신 재시도는 재적용 없이 확인 가능하다. 새 요청·회신은 종료 이후 거절한다. 요청 접수·기관 응답은 차량 경로·링크 선택 지점·완료·취소 상태를 바꾸지 않는다. 등하원별 요청 50개, 요청별 기관 회신 기록 20개로 제한한다.

### 저장과 확인 범위

기존 DB는 `openStore`에서 새 표와 ETA 관측·수신 열을 자동 추가한다. 기존 링크의 기관·방향 기본값과 이전 미확인 BOARDED 처리는 바꾸지 않는다. SQLite 외래 키로 90일 지난 등하원 삭제 시 준비·요청·기관 회신이 함께 삭제된다. 서울 날짜가 90일 지난 보호자 일정도 정리한다. 연결·기관 설정은 기존 보관 정책을 따른다. 만남 안내와 개인 일정을 외부로 전송하는 기능은 없다.

`npm test`는 기존 72개와 v0.10 운영 10개, 총 82개를 검사한다. 새 검사는 날짜·일정 한도·엄격한 입력, 기관/보호자/차량 역할 및 같은 기관의 다른 보호자 격리, 허가 0개 기본값, 출처·최신성·지연 ETA, 기관 준비와 내려보냄 분리, 요청·응답 멱등성 및 종료 후 재시도, SQLite 재시작 지속성과 정리를 포함한다. 실제 차량·기관 운영·음성 재생 성공을 뜻하는 검사는 아니다.
