import { opaque } from './store.js';

const terminal = new Set(['BOARDED','HANDED_OVER','CANCELLED']);
const issueKinds = ['NO_STOP_SPACE','CHILD_DELAYED','ALTERNATE_POINT_REQUEST','CANCEL_REQUEST','RUNNING_LATE'];
const defaults = {enabled:false,outbound:true,afterBoarding:true};
const etaTtl = 120000, readinessTtl = 900000;
const fail = (status,message) => { throw Object.assign(new Error(message),{status}); };
const exact = (value,keys) => {
  if(!value || Array.isArray(value) || typeof value!=='object' || Object.keys(value).some(k=>!keys.includes(k))) fail(400,'허용되지 않은 입력입니다.');
};
const plain = (value,max,required=false) => typeof value==='string' && value.length<=max && (!required || !!value.trim()) && !/[<>\u0000-\u001f\u007f]/u.test(value);
const requestId = value => typeof value==='string' && /^[A-Za-z0-9_-]{1,100}$/.test(value);
const kstDate = (now=Date.now()) => new Date(now+9*3600000).toISOString().slice(0,10);
const iso = value => new Date(value).toISOString();
const fresh = (at,now,ttl) => Number.isFinite(Date.parse(at)) && Date.parse(at)<=now && now-Date.parse(at)<ttl;
function serviceDate(value) {
  if(typeof value!=='string' || !/^\d{4}-\d\d-\d\d$/.test(value) || !Number.isFinite(Date.parse(value)) || iso(Date.parse(value)).slice(0,10)!==value) fail(400,'일정 날짜를 YYYY-MM-DD로 입력하세요.');
  const days=(Date.parse(value)-Date.parse(kstDate()))/86400000;
  if(days < -90 || days > 90) fail(400,'오늘 기준 앞뒤 90일의 일정을 입력하세요.');
  return value;
}
const issueDto = row => ({id:row.id,tripId:row.trip_id,requestId:row.request_id,actor:row.actor,kind:row.kind,message:row.message,spotId:row.spot_id,status:row.status,reply:row.reply,createdAt:row.created_at,updatedAt:row.updated_at});

export function registerOperations({app,db,spots,guardianAuth,carAuth,academyAuth,limited,tripById,ownedTrip,broadcast}) {
  const ownedAcademyTrip = req => { const t=tripById(req.params.id);if(!t || t.academy_id!==req.academy.id) fail(404,'등하원 기록을 찾을 수 없습니다.');return t; };
  const dayPlan = (link,date) => {
    const row=db.prepare('SELECT * FROM guardian_day_plans WHERE link_id=? AND service_date=?').get(link.id,date);
    return {serviceDate:date,items:row?JSON.parse(row.items):[],reminder:row?.reminder??'',voicePreferences:row?JSON.parse(row.voice_preferences):{...defaults},source:'GUARDIAN',updatedAt:row?.updated_at??null};
  };
  const queryDate = (req,keys=['serviceDate']) => { if(Object.keys(req.query).some(k=>!keys.includes(k))) fail(400,'허용되지 않은 검색 조건입니다.');return serviceDate(req.query.serviceDate??kstDate()); };
  const meeting = (link,now=Date.now()) => {
    const row=db.prepare('SELECT * FROM institution_meeting_points WHERE academy_id=?').get(link.academy_id);
    const ref=row?.reference_spot_id?spots.detail(row.reference_spot_id,link,now):null;
    const check=ref?spots.eligibility(ref.id,link,now):{eligible:false,state:'UNVERIFIED',reason:'NO_REFERENCE_SPOT'};
    return {label:row?.label??'',entranceHint:row?.entrance_hint??'',meetingNotes:row?.meeting_notes??'',referenceSpotId:row?.reference_spot_id??null,referenceSpot:ref,
      permission:{eligible:check.eligible,state:check.state,reason:check.reason??'CURRENT_PERMISSION',permissionExpiresAt:check.permissionExpiresAt??null,maxDwellSeconds:check.evidence?.maxDwellSeconds??null},
      source:row?'INSTITUTION':'UNSET',updatedAt:row?.updated_at??null,permissionCheckedAt:iso(now),guidanceIsPermission:false};
  };
  const tripOperations = (t,now=Date.now()) => {
    const row=t?db.prepare('SELECT * FROM trip_readiness WHERE trip_id=?').get(t.id):null;
    const readiness={status:row?.status??'UNKNOWN',readyAt:row?.ready_at??null,updatedAt:row?.updated_at??null,source:row?'INSTITUTION':'UNSET',fresh:!!row&&fresh(row.updated_at,now,readinessTtl),expiresAt:row?iso(Date.parse(row.updated_at)+readinessTtl):null,releasedAt:t?.released_at??null};
    let eta=null;
    if(t?.status==='ARRIVED') eta={at:t.arrived_at,received_at:t.arrival_received_at,etaMin:0};
    else if(t?.eta_observed_at && t?.eta_received_at) eta={at:t.eta_observed_at,received_at:t.eta_received_at,etaMin:t.eta_min};
    const etaFresh=!!eta && fresh(eta.at,now,etaTtl) && fresh(eta.received_at,now,etaTtl);
    const arrival=eta?Date.parse(eta.at)+eta.etaMin*60000:null;
    const reason=t&&terminal.has(t.status)?'TRIP_TERMINAL':!eta?'MISSING_ETA':!etaFresh?'STALE_ETA':!row||row.ready_at===null?'MISSING_READINESS':!readiness.fresh?'STALE_READINESS':'KNOWN';
    return {readiness,timing:{etaMin:eta?.etaMin??null,etaAt:eta?.at??null,etaReceivedAt:eta?.received_at??null,etaFresh,estimatedArrivalAt:arrival===null?null:iso(arrival),estimatedWaitMinutes:reason==='KNOWN'?Math.max(0,Math.ceil((Date.parse(row.ready_at)-Math.max(now,arrival))/60000)):null,reason,etaSource:eta?'VEHICLE_EVENT':'UNSET',etaExpiresAt:eta?iso(Math.min(Date.parse(eta.at),Date.parse(eta.received_at))+etaTtl):null,etaTtlSeconds:etaTtl/1000,readinessTtlSeconds:readinessTtl/1000},issues:t?db.prepare('SELECT * FROM trip_issues WHERE trip_id=? ORDER BY created_at,id').all(t.id).map(issueDto):[]};
  };
  app.get('/api/guardian/day-plan',guardianAuth,(req,res)=>res.json({dayPlan:dayPlan(req.link,queryDate(req))}));
  app.put('/api/guardian/day-plan',guardianAuth,limited('day-plan',100),(req,res)=>{
    exact(req.body,['serviceDate','items','reminder','voicePreferences']);
    const date=serviceDate(req.body.serviceDate),{items,reminder='',voicePreferences={...defaults}}=req.body;
    if(!Array.isArray(items)||items.length>8||!plain(reminder,200)) fail(400,'일정은 최대 8개, 알림은 200자까지 입력하세요.');
    const normalized=items.map(item=>{exact(item,['time','title','note']);if(typeof item.time!=='string'||!/^([01]\d|2[0-3]):[0-5]\d$/.test(item.time)||!plain(item.title,60,true)||!plain(item.note??'',160))fail(400,'일정 시각과 제목·메모를 확인하세요.');return {time:item.time,title:item.title.trim(),note:(item.note??'').trim()};});
    exact(voicePreferences,['enabled','outbound','afterBoarding']);
    if(['enabled','outbound','afterBoarding'].some(k=>typeof voicePreferences[k]!=='boolean')) fail(400,'음성 설정은 켜짐·꺼짐으로 입력하세요.');
    db.prepare('INSERT INTO guardian_day_plans VALUES(?,?,?,?,?,?) ON CONFLICT(link_id,service_date) DO UPDATE SET items=excluded.items,reminder=excluded.reminder,voice_preferences=excluded.voice_preferences,updated_at=excluded.updated_at').run(req.link.id,date,JSON.stringify(normalized),reminder.trim(),JSON.stringify(voicePreferences),iso(Date.now()));
    res.json({dayPlan:dayPlan(req.link,date)});
  });
  for(const [actor,auth] of [['guardian',guardianAuth],['car',carAuth]]) {
    app.get(`/api/${actor}/operations`,auth,(req,res)=>{
      const date=queryDate(req,['serviceDate','tripId']);
      let t;
      if(req.query.tripId!==undefined) {if(!requestId(req.query.tripId))fail(400,'등하원 식별자를 확인하세요.');t=tripById(req.query.tripId);if(!t||t.link_id!==req.link.id)fail(404,'등하원 기록을 찾을 수 없습니다.');}
      else t=db.prepare('SELECT id FROM trips WHERE link_id=? ORDER BY created_at DESC,rowid DESC LIMIT 1').get(req.link.id);
      if(t)t=tripById(t.id);
      const now=Date.now(),link={...req.link,journey_type:t?.journey_type??req.link.journey_type};
      res.json({tripId:t?.id??null,journeyType:link.journey_type,institutionType:req.link.institution_type,meetingPoint:meeting(link,now),...tripOperations(t,now),dayPlan:dayPlan(req.link,date),serverTime:iso(now)});
    });
    app.post(`/api/${actor}/trips/:id/issues`,auth,limited('issues',100),(req,res)=>{
      exact(req.body,['requestId','kind','message','spotId']);
      const {requestId:id,kind,message='',spotId=null}=req.body;
      if(!requestId(id)||!issueKinds.includes(kind)||!plain(message,240)||spotId!==null&&!plain(spotId,160,true))fail(400,'요청 종류와 내용을 확인하세요.');
      if(spotId!==null && kind!=='ALTERNATE_POINT_REQUEST') fail(400,'대체 지점 요청에만 참고 지점을 첨부하세요.');
      const t=ownedTrip(req),role=actor.toUpperCase(),payload=JSON.stringify({kind,message:message.trim(),spotId});
      const previous=db.prepare('SELECT * FROM trip_issues WHERE trip_id=? AND actor=? AND request_id=?').get(t.id,role,id);
      if(previous){if(previous.payload!==payload)fail(409,'같은 요청 ID에 다른 내용을 사용할 수 없습니다.');return res.json({issue:issueDto(previous),idempotent:true});}
      if(terminal.has(t.status))fail(409,'종료된 등하원에 새 요청을 보낼 수 없습니다.');
      if(spotId!==null && !spots.eligibility(spotId,{...req.link,journey_type:t.journey_type}).eligible)fail(409,'현재 방향·차량에 유효한 허가가 있는 지점만 제안할 수 있습니다.');
      if(db.prepare('SELECT count(*) n FROM trip_issues WHERE trip_id=?').get(t.id).n>=50)fail(409,'등하원별 요청은 50개까지 보관합니다.');
      const issueId=`is_${opaque().slice(0,20)}`,now=iso(Date.now());
      db.prepare("INSERT INTO trip_issues VALUES(?,?,?,?,?,?,?,?,'OPEN',NULL,?,?)").run(issueId,t.id,role,id,payload,kind,message.trim(),spotId,now,now);
      broadcast(t);res.status(201).json({issue:issueDto(db.prepare('SELECT * FROM trip_issues WHERE id=?').get(issueId)),idempotent:false});
    });
  }
  app.get('/api/academy/meeting-point',academyAuth,(req,res)=>res.json({meetingPoint:meeting({academy_id:req.academy.id,institution_type:req.academy.institution_type,journey_type:'PICKUP',service_area:req.academy.service_area})}));
  app.put('/api/academy/meeting-point',academyAuth,limited('meeting-point',100),(req,res)=>{
    exact(req.body,['label','entranceHint','meetingNotes','referenceSpotId']);
    const {label,entranceHint,meetingNotes='',referenceSpotId=null}=req.body;
    if(!plain(label,80,true)||!plain(entranceHint,160,true)||!plain(meetingNotes,240)||referenceSpotId!==null&&!plain(referenceSpotId,160,true))fail(400,'만남 장소와 출입구 안내를 확인하세요.');
    const link={academy_id:req.academy.id,institution_type:req.academy.institution_type,journey_type:'PICKUP',service_area:req.academy.service_area};
    if(referenceSpotId!==null&&!spots.detail(referenceSpotId,link))fail(404,'참고 지점을 찾을 수 없습니다.');
    db.prepare('INSERT INTO institution_meeting_points VALUES(?,?,?,?,?,?) ON CONFLICT(academy_id) DO UPDATE SET label=excluded.label,entrance_hint=excluded.entrance_hint,meeting_notes=excluded.meeting_notes,reference_spot_id=excluded.reference_spot_id,updated_at=excluded.updated_at').run(req.academy.id,label.trim(),entranceHint.trim(),meetingNotes.trim(),referenceSpotId,iso(Date.now()));
    res.json({meetingPoint:meeting(link)});
  });
  app.get('/api/academy/trips/:id/operations',academyAuth,(req,res)=>{const t=ownedAcademyTrip(req);res.json({tripId:t.id,journeyType:t.journey_type,...tripOperations(t),serverTime:iso(Date.now())});});
  app.put('/api/academy/trips/:id/readiness',academyAuth,limited('readiness',200),(req,res)=>{
    exact(req.body,['status','readyInMinutes']);const {status,readyInMinutes}=req.body;
    if(!['PREPARING','READY','DELAYED'].includes(status)||readyInMinutes!==undefined&&(!Number.isInteger(readyInMinutes)||readyInMinutes<0||readyInMinutes>120)||status==='READY'&&readyInMinutes!==undefined&&readyInMinutes!==0)fail(400,'준비 상태와 0~120분의 준비 시간을 확인하세요.');
    const t=ownedAcademyTrip(req);if(terminal.has(t.status))fail(409,'종료된 등하원은 변경할 수 없습니다.');
    const now=Date.now(),readyAt=status==='READY'?iso(now):readyInMinutes===undefined?null:iso(now+readyInMinutes*60000);
    db.prepare('INSERT INTO trip_readiness VALUES(?,?,?,?) ON CONFLICT(trip_id) DO UPDATE SET status=excluded.status,ready_at=excluded.ready_at,updated_at=excluded.updated_at').run(t.id,status,readyAt,iso(now));
    broadcast(t);res.json({tripId:t.id,...tripOperations(t,now)});
  });
  app.put('/api/academy/trips/:id/issues/:issueId',academyAuth,limited('issue-response',200),(req,res)=>{
    exact(req.body,['requestId','status','reply']);const {requestId:id,status,reply=''}=req.body;
    if(!requestId(id)||!['ACKNOWLEDGED','RESOLVED','DECLINED'].includes(status)||!plain(reply,240))fail(400,'응답 상태와 내용을 확인하세요.');
    const t=ownedAcademyTrip(req),issue=db.prepare('SELECT * FROM trip_issues WHERE id=? AND trip_id=?').get(req.params.issueId,t.id);
    if(!issue)fail(404,'요청을 찾을 수 없습니다.');
    const payload=JSON.stringify({status,reply:reply.trim()}),previous=db.prepare('SELECT * FROM issue_responses WHERE issue_id=? AND request_id=?').get(issue.id,id);
    if(previous){if(previous.payload!==payload)fail(409,'같은 응답 ID에 다른 내용을 사용할 수 없습니다.');return res.json({issue:issueDto(issue),idempotent:true});}
    if(terminal.has(t.status)||['RESOLVED','DECLINED'].includes(issue.status))fail(409,'종료된 등하원이나 처리된 요청은 변경할 수 없습니다.');
    if(db.prepare('SELECT count(*) n FROM issue_responses WHERE issue_id=?').get(issue.id).n>=20)fail(409,'요청별 응답은 20개까지 보관합니다.');
    const now=iso(Date.now());
    db.exec('BEGIN IMMEDIATE');try{db.prepare('INSERT INTO issue_responses VALUES(?,?,?,?)').run(issue.id,id,payload,now);db.prepare('UPDATE trip_issues SET status=?,reply=?,updated_at=? WHERE id=?').run(status,reply.trim(),now,issue.id);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
    broadcast(t);res.json({issue:issueDto(db.prepare('SELECT * FROM trip_issues WHERE id=?').get(issue.id)),idempotent:false});
  });
}
