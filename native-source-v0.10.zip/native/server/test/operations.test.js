import { test } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import { mkdtempSync,rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApplication } from '../src/app.js';
import { createAcademy,openStore,prune } from '../src/store.js';

const auth=token=>({Authorization:`Bearer ${token}`});
const today=()=>new Date(Date.now()+9*3600000).toISOString().slice(0,10);
const password='operations-private-password';
const plan=()=>({serviceDate:today(),items:[{time:'18:30',title:'저녁',note:'물 챙기기'}],reminder:'가방 확인',voicePreferences:{enabled:true,outbound:true,afterBoarding:false}});
async function fixture(t,path=':memory:') {
  const ctx=createApplication({databasePath:path,rateLimit:false});
  await new Promise((resolve,reject)=>{ctx.server.once('error',reject);ctx.server.listen(0,'127.0.0.1',resolve);});
  t.after(()=>ctx.close());
  for(const code of ['OPS01','OPS02'])createAcademy(ctx.db,{code,name:code,password,institutionType:'SCHOOL'});
  const login=async code=>(await request(ctx.app).post('/api/academy/session').send({code,password}).expect(200)).body.token;
  const register=async code=>(await request(ctx.app).post('/api/guardian/links').send({academyCode:code,childName:'호칭',weekday:[1],pickupTime:'17:00',guardianConsent:true,institutionType:'SCHOOL'}).expect(201)).body;
  const a=await register('OPS01'),b=await register('OPS01'),c=await register('OPS02');
  const code=(await request(ctx.app).post('/api/guardian/pairing').set(auth(a.guardianToken)).send({}).expect(200)).body.code;
  const car=(await request(ctx.app).post('/api/car/pairing').send({code}).expect(200)).body.carToken;
  const trip=(await request(ctx.app).post('/api/trips').set(auth(car)).send({linkId:a.link.id,clientTripId:'trip-one'}).expect(201)).body.trip;
  return {ctx,a,b,c,car,trip,academy:await login('OPS01'),other:await login('OPS02')};
}
const send=(f,type,extra={})=>request(f.ctx.app).post(`/api/trips/${f.trip.id}/events`).set(auth(f.car)).send({eventId:crypto.randomUUID(),type,at:new Date().toISOString(),...extra});
const ops=f=>request(f.ctx.app).get('/api/car/operations').set(auth(f.car));
const putPlan=(f,p=plan(),token=f.a.guardianToken)=>request(f.ctx.app).put('/api/guardian/day-plan').set(auth(token)).send(p);
const issue=(f,p,actor='guardian',token=actor==='guardian'?f.a.guardianToken:f.car)=>request(f.ctx.app).post(`/api/${actor}/trips/${f.trip.id}/issues`).set(auth(token)).send(p);
const readiness=(f,p,token=f.academy)=>request(f.ctx.app).put(`/api/academy/trips/${f.trip.id}/readiness`).set(auth(token)).send(p);
const respond=(f,id,p,token=f.academy)=>request(f.ctx.app).put(`/api/academy/trips/${f.trip.id}/issues/${id}`).set(auth(token)).send(p);

test('operations defaults are explicit missing data and cannot fabricate permission or ETA',async t=>{
  const f=await fixture(t),r=(await ops(f).expect(200)).body;
  assert.equal(r.tripId,f.trip.id);assert.equal(r.meetingPoint.permission.eligible,false);assert.equal(r.meetingPoint.permission.reason,'NO_REFERENCE_SPOT');assert.equal(r.readiness.source,'UNSET');assert.equal(r.readiness.fresh,false);assert.equal(r.timing.reason,'MISSING_ETA');assert.equal(r.timing.estimatedWaitMinutes,null);assert.equal(r.dayPlan.voicePreferences.enabled,false);assert.equal(r.dayPlan.updatedAt,null);
  assert.equal((await request(f.ctx.app).get('/api/guardian/operations').set(auth(f.b.guardianToken)).expect(200)).body.tripId,null);
});

test('day plan strict bounds, real calendar date and own-link/role isolation',async t=>{
  const f=await fixture(t);await putPlan(f).expect(200);
  const r=(await ops(f).expect(200)).body;assert.equal(r.dayPlan.items[0].title,'저녁');assert.equal(r.dayPlan.voicePreferences.afterBoarding,false);
  assert.deepEqual((await request(f.ctx.app).get('/api/guardian/day-plan').set(auth(f.b.guardianToken)).expect(200)).body.dayPlan.items,[]);
  for(const token of [f.car,f.academy])await putPlan(f,plan(),token).expect(401);
  await request(f.ctx.app).put('/api/car/day-plan').set(auth(f.car)).send(plan()).expect(404);
  for(const p of [{...plan(),items:Array(9).fill(plan().items[0])},{...plan(),serviceDate:'2026-02-31'},{...plan(),serviceDate:'2099-01-01'},{...plan(),latitude:37},{...plan(),items:[{time:'24:00',title:'일정'}]},{...plan(),items:[{time:'19:00',title:'<script>'}]},{...plan(),items:[{time:'19:00',title:'일정',linkId:f.b.link.id}]},{...plan(),voicePreferences:{enabled:true,outbound:true,afterBoarding:'false'}},{...plan(),reminder:'x'.repeat(201)},{...plan(),items:null}])await putPlan(f,p).expect(400);
  await request(f.ctx.app).get('/api/guardian/day-plan?serviceDate=x&linkId=x').set(auth(f.a.guardianToken)).expect(400);
});

test('institution meeting guidance is tenant scoped and does not self-approve reference permission',async t=>{
  const f=await fixture(t),p={label:'정문',entranceHint:'오른쪽 출입구',meetingNotes:'보행 통로를 비워 주세요'};
  await request(f.ctx.app).put('/api/academy/meeting-point').set(auth(f.academy)).send(p).expect(200);
  const r=(await ops(f).expect(200)).body;assert.equal(r.meetingPoint.label,'정문');assert.equal(r.meetingPoint.guidanceIsPermission,false);assert.equal(r.meetingPoint.permission.eligible,false);
  assert.equal((await request(f.ctx.app).get('/api/academy/meeting-point').set(auth(f.other)).expect(200)).body.meetingPoint.source,'UNSET');
  await request(f.ctx.app).put('/api/academy/meeting-point').set(auth(f.car)).send(p).expect(401);
  for(const delta of [{latitude:37},{label:'<b>'},{referenceSpotId:'unknown'}])await request(f.ctx.app).put('/api/academy/meeting-point').set(auth(f.academy)).send({...p,...delta}).expect(delta.referenceSpotId?404:400);
  const catalog=(await request(f.ctx.app).get('/api/guardian/pickup-spots').set(auth(f.a.guardianToken)).expect(200)).body;
  assert(catalog.spots.length>0);const referenceSpotId=catalog.spots[0].id;
  const m=(await request(f.ctx.app).put('/api/academy/meeting-point').set(auth(f.academy)).send({...p,referenceSpotId}).expect(200)).body.meetingPoint;
  assert.equal(m.permission.eligible,false);assert(m.referenceSpot);assert.equal(f.ctx.db.prepare('SELECT selected_spot_id FROM links WHERE id=?').get(f.a.link.id).selected_spot_id,null);
});

test('fresh declared readiness and observed ETA compute wait without release or trip transition',async t=>{
  const f=await fixture(t);await send(f,'ETA',{etaMin:3}).expect(200);await send(f,'CALL').expect(200);
  await readiness(f,{status:'PREPARING',readyInMinutes:8}).expect(200);
  const r=(await ops(f).expect(200)).body;assert.equal(r.timing.reason,'KNOWN');assert(r.timing.estimatedWaitMinutes>=5&&r.timing.estimatedWaitMinutes<=6); // publication may follow ETA by less than a minute
  assert.equal(r.readiness.status,'PREPARING');assert.equal(r.readiness.source,'INSTITUTION');assert.equal(r.readiness.releasedAt,null);assert.equal(r.timing.etaSource,'VEHICLE_EVENT');
  const dbTrip=f.ctx.db.prepare('SELECT * FROM trips WHERE id=?').get(f.trip.id);assert.equal(dbTrip.status,'CALLED');assert.equal(dbTrip.boarding_confirmation,null);
  await readiness(f,{status:'READY'}).expect(200);assert.equal((await ops(f).expect(200)).body.timing.estimatedWaitMinutes,0);
});

test('stale, future and missing readiness/ETA fail closed; late queued ETA cannot refresh',async t=>{
  const f=await fixture(t);await readiness(f,{status:'DELAYED'}).expect(200);await send(f,'ETA',{etaMin:3}).expect(200);
  assert.equal((await ops(f).expect(200)).body.timing.reason,'MISSING_READINESS');
  await readiness(f,{status:'PREPARING',readyInMinutes:5}).expect(200);
  f.ctx.db.prepare('UPDATE trip_readiness SET updated_at=? WHERE trip_id=?').run(new Date(Date.now()-900001).toISOString(),f.trip.id);
  assert.equal((await ops(f).expect(200)).body.timing.reason,'STALE_READINESS');
  await readiness(f,{status:'READY'}).expect(200);
  f.ctx.db.prepare('UPDATE trips SET eta_observed_at=? WHERE id=?').run(new Date(Date.now()-120001).toISOString(),f.trip.id);
  const before=f.ctx.db.prepare('SELECT eta_observed_at FROM trips WHERE id=?').get(f.trip.id).eta_observed_at;
  await send(f,'ETA',{etaMin:8,at:new Date(Date.now()-180000).toISOString()}).expect(200);
  assert.equal(f.ctx.db.prepare('SELECT eta_observed_at FROM trips WHERE id=?').get(f.trip.id).eta_observed_at,before);
  const r=(await ops(f).expect(200)).body;assert.equal(r.timing.reason,'STALE_ETA');assert.equal(r.timing.estimatedWaitMinutes,null);assert.equal(r.timing.etaFresh,false);
  await send(f,'ETA',{etaMin:1,at:new Date(Date.now()+60000).toISOString()}).expect(200);assert.equal((await ops(f).expect(200)).body.timing.etaFresh,false);
});

test('readiness scopes own institution, strict schema, active trip and separates release',async t=>{
  const f=await fixture(t);await readiness(f,{status:'READY'},f.other).expect(404);await readiness(f,{status:'READY'},f.a.guardianToken).expect(401);
  for(const p of [{status:'BOARDED'},{status:'READY',readyInMinutes:3},{status:'DELAYED',readyInMinutes:121},{status:'PREPARING',readyInMinutes:1.5},{status:'READY',latitude:3}])await readiness(f,p).expect(400);
  await send(f,'ARRIVED').expect(200);await request(f.ctx.app).post(`/api/trips/${f.trip.id}/released`).set(auth(f.academy)).send({}).expect(200);
  await readiness(f,{status:'READY'}).expect(200);assert((await ops(f).expect(200)).body.readiness.releasedAt);
  await send(f,'BOARDED',{confirmation:'GUARDIAN'}).expect(200);await readiness(f,{status:'READY'}).expect(409);assert.equal((await ops(f).expect(200)).body.timing.reason,'TRIP_TERMINAL');
});

test('issue requests isolate actor/link identities, reject unsafe point and never cancel/reroute',async t=>{
  const f=await fixture(t),p={requestId:'request-one',kind:'CANCEL_REQUEST',message:'오늘 취소 요청'};
  const one=(await issue(f,p).expect(201)).body.issue;assert.equal(one.actor,'GUARDIAN');assert.equal(one.status,'OPEN');
  assert.equal((await issue(f,p).expect(200)).body.idempotent,true);await issue(f,{...p,message:'다른 내용'}).expect(409);
  const two=(await issue(f,p,'car').expect(201)).body.issue;assert.notEqual(one.id,two.id);assert.equal(two.actor,'CAR');
  await issue(f,p,'guardian',f.b.guardianToken).expect(404);await issue(f,p,'guardian',f.car).expect(401);
  for(const p of [{requestId:'bad',kind:'BOARDED'},{requestId:'bad',kind:'RUNNING_LATE',message:'<x>'},{requestId:'bad',kind:'RUNNING_LATE',latitude:37},{requestId:'bad',kind:'RUNNING_LATE',spotId:'x'}])await issue(f,p).expect(400);
  await issue(f,{requestId:'point',kind:'ALTERNATE_POINT_REQUEST',spotId:'unknown'}).expect(409);
  const catalog=(await request(f.ctx.app).get('/api/guardian/pickup-spots').set(auth(f.a.guardianToken)).expect(200)).body;
  await issue(f,{requestId:'reference',kind:'ALTERNATE_POINT_REQUEST',spotId:catalog.spots[0].id}).expect(409);
  await issue(f,{requestId:'ask',kind:'ALTERNATE_POINT_REQUEST'}).expect(201);
  const row=f.ctx.db.prepare('SELECT * FROM trips WHERE id=?').get(f.trip.id);assert.equal(row.status,'PLANNED');assert.equal(row.pickup_spot_snapshot,null);
  await request(f.ctx.app).get(`/api/car/operations?tripId=${f.trip.id}`).set(auth(f.a.guardianToken)).expect(401);
  await request(f.ctx.app).get(`/api/guardian/operations?tripId=${f.trip.id}`).set(auth(f.b.guardianToken)).expect(404);
});

test('institution response state and terminal idempotent retries preserve action without completing trip',async t=>{
  const f=await fixture(t),p={requestId:'request',kind:'NO_STOP_SPACE'},i=(await issue(f,p,'car').expect(201)).body.issue;
  const ack={requestId:'reply-one',status:'ACKNOWLEDGED',reply:'확인 중'};
  await respond(f,i.id,ack,f.other).expect(404);await respond(f,i.id,ack,f.car).expect(401);
  await respond(f,i.id,{...ack,status:'BOARDED'}).expect(400);
  await respond(f,i.id,ack).expect(200);assert.equal((await respond(f,i.id,ack).expect(200)).body.idempotent,true);
  await respond(f,i.id,{...ack,reply:'변경'}).expect(409);
  const resolved={requestId:'reply-two',status:'RESOLVED',reply:'안내 확인'};await respond(f,i.id,resolved).expect(200);await respond(f,i.id,{requestId:'reply-three',status:'ACKNOWLEDGED'}).expect(409);
  assert.equal(f.ctx.db.prepare('SELECT status FROM trips WHERE id=?').get(f.trip.id).status,'PLANNED');
  await send(f,'CANCEL').expect(200);
  assert.equal((await respond(f,i.id,resolved).expect(200)).body.idempotent,true);assert.equal((await issue(f,p,'car').expect(200)).body.idempotent,true);
  await issue(f,{...p,requestId:'new'},'car').expect(409);await respond(f,i.id,{requestId:'late',status:'DECLINED'}).expect(409);
});

test('institution operations omit guardian private plan and foreign request rows',async t=>{
  const f=await fixture(t);await putPlan(f).expect(200);await issue(f,{requestId:'one',kind:'CHILD_DELAYED'}).expect(201);
  const r=(await request(f.ctx.app).get(`/api/academy/trips/${f.trip.id}/operations`).set(auth(f.academy)).expect(200)).body;assert.equal(r.issues.length,1);assert(!('dayPlan' in r));
  await request(f.ctx.app).get(`/api/academy/trips/${f.trip.id}/operations`).set(auth(f.other)).expect(404);
  const json=JSON.stringify((await ops(f).expect(200)).body);for(const secret of ['guardianToken','carToken','token_hash','password'])assert(!json.includes(secret));
});

test('operations persist after DB reopen and prune trip children plus old day plans',async t=>{
  const directory=mkdtempSync(join(tmpdir(),'hawon-operations-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));
  const path=join(directory,'data.sqlite'),f=await fixture(t,path);await putPlan(f).expect(200);await readiness(f,{status:'READY'}).expect(200);
  const i=(await issue(f,{requestId:'persist',kind:'RUNNING_LATE'}).expect(201)).body.issue;await respond(f,i.id,{requestId:'persist-response',status:'ACKNOWLEDGED'}).expect(200);
  const db=openStore(path);assert.equal(db.prepare('SELECT status FROM trip_readiness WHERE trip_id=?').get(f.trip.id).status,'READY');assert.equal(db.prepare('SELECT count(*) n FROM guardian_day_plans').get().n,1);assert.equal(db.prepare('SELECT count(*) n FROM issue_responses').get().n,1);
  db.prepare('UPDATE trips SET created_at=? WHERE id=?').run(new Date(Date.now()-91*86400000).toISOString(),f.trip.id);db.prepare("UPDATE guardian_day_plans SET service_date='2000-01-01'").run();prune(db);
  for(const table of ['trip_readiness','trip_issues','issue_responses','guardian_day_plans'])assert.equal(db.prepare(`SELECT count(*) n FROM ${table}`).get().n,0);db.close();
});
