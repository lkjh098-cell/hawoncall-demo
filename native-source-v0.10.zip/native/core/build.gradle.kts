plugins { kotlin("jvm") }
kotlin { jvmToolchain(17) }
dependencies { testImplementation(kotlin("test-junit")) }
tasks.test { testLogging { events("passed", "skipped", "failed") } }
dependencies { compileOnly("org.json:json:20240303"); testImplementation("org.json:json:20240303") }
