package ai.hawoncall.core

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Guardian-authored daily content. It never configures a route or confirms a child. */
data class DayItem(val time: String, val title: String, val note: String = "")
data class VoicePreferences(val enabled: Boolean = false, val outbound: Boolean = true, val afterBoarding: Boolean = true)
data class DayPlan(val serviceDate: String, val items: List<DayItem> = emptyList(), val reminder: String = "",
    val voicePreferences: VoicePreferences = VoicePreferences(), val source: String = "GUARDIAN", val updatedAt: String? = null) {
    fun validate() {
        require(runCatching { LocalDate.parse(serviceDate).toString()==serviceDate }.getOrDefault(false)) { "날짜를 YYYY-MM-DD로 입력하세요." }
        require(items.size<=8) { "일정은 최대 8개입니다." }
        fun plain(value: String, max: Int) = value.length<=max && value.none { it<' ' || it=='\u007f' || it=='<' || it=='>' }
        require(plain(reminder,200)) { "준비물 메모는 줄바꿈 없이 200자까지 입력하세요." }
        items.forEach {
            require(it.time.matches(Regex("([01]\\d|2[0-3]):[0-5]\\d"))) { "일정 시각은 HH:mm 형식입니다." }
            require(it.title.isNotBlank() && plain(it.title,60) && plain(it.note,160)) { "일정 제목은 1~60자, 메모는 160자까지입니다." }
        }
    }
}
object BriefingPolicy {
    fun serviceDate(now: Instant = Instant.now()): String = now.atZone(ZoneId.of("Asia/Seoul")).toLocalDate().toString()
    /** No replay on data polling, previous dates, stale receives, or dropoff handoff. */
    fun text(plan: DayPlan, phase: String, journey: JourneyType, explicitlyBoarded: Boolean,
        receivedAgeMillis: Long, now: Instant = Instant.now()): String? {
        if(runCatching { plan.validate() }.isFailure || plan.source!="GUARDIAN" || plan.updatedAt==null || plan.serviceDate!=serviceDate(now) || receivedAgeMillis !in 0..120_000 || !plan.voicePreferences.enabled) return null
        if(phase=="OUTBOUND" && !plan.voicePreferences.outbound) return null
        if(phase=="AFTER_BOARDING" && (!plan.voicePreferences.afterBoarding || journey!=JourneyType.PICKUP || !explicitlyBoarded)) return null
        if(phase !in setOf("OUTBOUND","AFTER_BOARDING")) return null
        val localTime=now.atZone(ZoneId.of("Asia/Seoul")).toLocalTime().toString().take(5)
        val items=plan.items.filter { phase!="AFTER_BOARDING" || it.time>=localTime }.sortedBy { it.time }.take(3).joinToString(". ") { "${it.time} ${it.title.take(60)}" }
        val reminder=plan.reminder.take(200).takeIf { it.isNotBlank() }?.let { "준비물과 당부. $it" }.orEmpty()
        if(items.isBlank() && reminder.isBlank()) return null
        return listOf(if(phase=="OUTBOUND") "보호자가 작성한 오늘 일정입니다" else "탑승 확인 후 오늘 일정입니다",items,reminder).filter { it.isNotBlank() }.joinToString(". ")
    }
    fun onceKey(identity: String, tripId: String, date: String, phase: String) = "$identity|$tripId|$date|$phase"
}
