package ai.hawoncall.core

import org.json.JSONArray
import org.json.JSONObject

/** Missing fields stay unknown; permission is never inferred from meeting guidance. */
data class OperationIssue(val id: String, val kind: String, val status: String, val message: String, val reply: String?)
data class OperationSnapshot(val tripId: String?, val journeyType: String, val meetingLabel: String,
    val entranceHint: String, val meetingNotes: String, val permissionEligible: Boolean, val permissionReason: String,
    val meetingSource: String, val meetingUpdatedAt: String?, val readinessStatus: String, val readyAt: String?,
    val readinessFresh: Boolean, val readinessUpdatedAt: String?, val releasedAt: String?, val etaMin: Int?,
    val etaFresh: Boolean, val estimatedWaitMinutes: Int?, val timingReason: String,
    val issues: List<OperationIssue>, val dayPlan: DayPlan, val serverTime: String?,
    val permissionExpiresAt: String? = null, val readinessExpiresAt: String? = null, val etaExpiresAt: String? = null,
    val referenceSpotId: String? = null, val referenceSpotName: String? = null) {
    fun permissionCurrent(age: Long) = permissionEligible && OperationFreshness.current(permissionExpiresAt,serverTime,age)
    fun readinessCurrent(age: Long) = readinessFresh && OperationFreshness.current(readinessExpiresAt,serverTime,age)
    fun etaCurrent(age: Long) = etaFresh && OperationFreshness.current(etaExpiresAt,serverTime,age)
    fun timingCurrent(age: Long) = timingReason=="KNOWN" && readinessCurrent(age) && etaCurrent(age)
}
/** Advance trusted server time by receive-relative monotonic age; never extend the source TTL. */
object OperationFreshness {
    fun current(expiresAt: String?, serverTime: String?, receivedAgeMillis: Long): Boolean =
        receivedAgeMillis in 0..120_000 && runCatching {
            java.time.Instant.parse(serverTime).plusMillis(receivedAgeMillis).isBefore(java.time.Instant.parse(expiresAt))
        }.getOrDefault(false)
}
object OperationsJson {
    private fun string(o: JSONObject, key: String): String? = if(!o.has(key) || o.isNull(key)) null else o.optString(key)
    fun dayPlan(o: JSONObject): DayPlan {
        val items=o.optJSONArray("items") ?: JSONArray()
        val voice=o.optJSONObject("voicePreferences") ?: JSONObject()
        return DayPlan(o.getString("serviceDate"),(0 until items.length()).map { i -> items.getJSONObject(i).let {
            DayItem(it.getString("time"),it.getString("title"),string(it,"note").orEmpty())
        } },string(o,"reminder").orEmpty(),VoicePreferences(voice.optBoolean("enabled",false),voice.optBoolean("outbound",true),voice.optBoolean("afterBoarding",true)),o.optString("source","GUARDIAN"),string(o,"updatedAt")).also { it.validate() }
    }
    fun encode(plan: DayPlan): JSONObject {
        plan.validate()
        return JSONObject().put("serviceDate",plan.serviceDate).put("items",JSONArray().also { a -> plan.items.forEach { a.put(JSONObject().put("time",it.time).put("title",it.title).put("note",it.note)) } })
            .put("reminder",plan.reminder).put("voicePreferences",JSONObject().put("enabled",plan.voicePreferences.enabled).put("outbound",plan.voicePreferences.outbound).put("afterBoarding",plan.voicePreferences.afterBoarding))
    }
    fun snapshot(o: JSONObject): OperationSnapshot {
        val meeting=o.optJSONObject("meetingPoint") ?: JSONObject(); val permission=meeting.optJSONObject("permission") ?: JSONObject()
        val readiness=o.optJSONObject("readiness") ?: JSONObject(); val timing=o.optJSONObject("timing") ?: JSONObject()
        val issues=o.optJSONArray("issues") ?: JSONArray()
        return OperationSnapshot(string(o,"tripId"),o.optString("journeyType",""),string(meeting,"label").orEmpty(),string(meeting,"entranceHint").orEmpty(),string(meeting,"meetingNotes").orEmpty(),
            permission.optBoolean("eligible",false),permission.optString("reason","UNKNOWN"),meeting.optString("source","UNSET"),string(meeting,"updatedAt"),readiness.optString("status","UNKNOWN"),string(readiness,"readyAt"),readiness.optBoolean("fresh",false),string(readiness,"updatedAt"),string(readiness,"releasedAt"),
            if(timing.has("etaMin") && !timing.isNull("etaMin")) timing.getInt("etaMin") else null,timing.optBoolean("etaFresh",false),
            if(timing.has("estimatedWaitMinutes") && !timing.isNull("estimatedWaitMinutes")) timing.getInt("estimatedWaitMinutes") else null,timing.optString("reason","UNKNOWN"),
            (0 until issues.length()).map { i -> issues.getJSONObject(i).let { OperationIssue(it.getString("id"),it.getString("kind"),it.getString("status"),string(it,"message").orEmpty(),string(it,"reply")) } },dayPlan(o.getJSONObject("dayPlan")),string(o,"serverTime"),string(permission,"permissionExpiresAt"),string(readiness,"expiresAt"),string(timing,"etaExpiresAt"),string(meeting,"referenceSpotId"),meeting.optJSONObject("referenceSpot")?.let { string(it,"name") })
    }
}
