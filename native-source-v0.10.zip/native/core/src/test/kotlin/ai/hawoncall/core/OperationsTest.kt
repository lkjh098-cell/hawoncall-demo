package ai.hawoncall.core
import kotlin.test.*
import java.time.Instant
import org.json.JSONObject
class OperationsTest {
    private val now=Instant.parse("2026-10-25T15:01:00Z")
    private val plan=DayPlan("2026-10-26",(1..8).map { DayItem("${(it+9).toString().padStart(2,'0')}:00","일정$it") },"물통",VoicePreferences(true),updatedAt="2026-10-25T15:00:00Z")
    @Test fun kstDateAndMaximumThree() {
        assertEquals("2026-10-26",BriefingPolicy.serviceDate(now))
        val text=BriefingPolicy.text(plan,"OUTBOUND",JourneyType.PICKUP,false,0,now)!!
        assertTrue(text.contains("일정3")); assertFalse(text.contains("일정4")); assertTrue(text.contains("물통"))
    }
    @Test fun staleOtherDateAndMissingOptInAreSilent() {
        assertNull(BriefingPolicy.text(plan,"OUTBOUND",JourneyType.PICKUP,false,120001,now))
        assertNull(BriefingPolicy.text(plan.copy(serviceDate="2026-10-25"),"OUTBOUND",JourneyType.PICKUP,false,0,now))
        assertNull(BriefingPolicy.text(plan.copy(voicePreferences=VoicePreferences(false)),"OUTBOUND",JourneyType.PICKUP,false,0,now))
    }
    @Test fun explicitPickupBoardingOnly() {
        assertNull(BriefingPolicy.text(plan,"AFTER_BOARDING",JourneyType.DROPOFF,true,0,now))
        assertNull(BriefingPolicy.text(plan,"AFTER_BOARDING",JourneyType.PICKUP,false,0,now))
        assertNotNull(BriefingPolicy.text(plan,"AFTER_BOARDING",JourneyType.PICKUP,true,0,now))
        assertNotEquals(BriefingPolicy.onceKey("a","t","d","OUTBOUND"),BriefingPolicy.onceKey("b","t","d","OUTBOUND"))
    }
    @Test fun guardianDtoRoundTripPreservesPreferencesAndNoAuthority() {
        val encoded=OperationsJson.encode(plan).put("updatedAt",plan.updatedAt)
        assertEquals(plan,OperationsJson.dayPlan(encoded))
        assertFalse(encoded.has("confirmation")); assertFalse(encoded.has("token"))
        assertFailsWith<IllegalArgumentException> { plan.copy(items=plan.items+DayItem("20:00","9번째")).validate() }
        assertFailsWith<IllegalArgumentException> { plan.copy(reminder="<html>").validate() }
    }
    @Test fun afterBoardingReadsUpcomingAndReminder() {
        val midday=Instant.parse("2026-10-26T04:00:00Z")
        val text=BriefingPolicy.text(plan,"AFTER_BOARDING",JourneyType.PICKUP,true,0,midday)!!
        assertFalse(text.contains("일정1")); assertFalse(text.contains("일정3"))
        assertTrue(text.contains("일정4")); assertTrue(text.contains("일정6")); assertFalse(text.contains("일정7")); assertTrue(text.contains("물통"))
    }
    @Test fun sourceExpiryNeverExtendsByHttpReceiveAge() {
        val server="2026-10-26T04:00:00Z"
        val expiry="2026-10-26T04:00:01Z"
        assertTrue(OperationFreshness.current(expiry,server,999))
        assertFalse(OperationFreshness.current(expiry,server,1000))
        assertFalse(OperationFreshness.current(expiry,server,-1))
        assertFalse(OperationFreshness.current(null,server,0))
        assertFalse(OperationFreshness.current(expiry,null,0))
        assertFalse(OperationFreshness.current("2026-10-26T05:00:00Z",server,120001))
        assertFailsWith<IllegalArgumentException> { plan.copy(reminder="bad\u007f").validate() }
    }
    @Test fun nullMeetingPermissionRemainsUnknown() {
        val dto=JSONObject().put("dayPlan",OperationsJson.encode(plan)).put("meetingPoint",JSONObject())
        val parsed=OperationsJson.snapshot(dto)
        assertFalse(parsed.permissionEligible); assertNull(parsed.tripId); assertNull(parsed.estimatedWaitMinutes)
        assertEquals("UNSET",parsed.meetingSource); assertFalse(parsed.readinessFresh)
    }
}
