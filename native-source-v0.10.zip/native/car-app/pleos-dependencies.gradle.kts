dependencies {
    add("pleosImplementation", "ai.pleos.playground:TextToSpeech:3.3.1")
    add("pleosImplementation", "ai.pleos.playground:Vehicle:2.3.2")
    add("pleosImplementation", "ai.pleos.playground:NaviHelper:3.0.5")
    add("pleosImplementation", "ai.pleos.playground:FusedLocation:1.1.3")
}
