package ai.hawoncall.car.voice
import android.content.Context
import ai.pleos.playground.tts.TextToSpeech
import ai.pleos.playground.tts.constant.Mode
import ai.pleos.playground.tts.constant.ErrorType
import ai.pleos.playground.tts.listener.EventListener
import ai.pleos.playground.tts.listener.OnInitializeListener
import java.util.Locale
fun createBriefingVoice(context: Context,report: (String)->Unit): BriefingVoice = PleosOnDeviceVoice(context,report)
private class PleosOnDeviceVoice(context: Context,report: (String)->Unit): FocusBriefingVoice(context,report) {
    private val engine=TextToSpeech(context.applicationContext,Mode.ON_DEVICE)
    private val events=object: EventListener {
        override fun onReady() { if(released) return; ready=true; report("Pleos 온디바이스 음성 준비됨") }
        override fun onStart() { report("Pleos 브리핑 재생 중") }
        override fun onUpdatedRms(rms: Double) = Unit
        override fun onDone() { done("브리핑 재생 완료") }
        override fun onStop() { done("브리핑 중지됨") }
        override fun onError(errorType: ErrorType) { done("Pleos 음성 오류: $errorType · 화면으로 확인하세요.") }
    }
    init {
        runCatching { engine.initialize(object: OnInitializeListener {
            override fun onSuccess() {
                if(released) return
                runCatching { engine.addEventListener(events); engine.setLocale(Locale.KOREAN); engine.setAudioAttributes(attributes); ready=true; report("Pleos 온디바이스 음성 준비됨") }
                    .onFailure { ready=false; report("Pleos 음성 설정 실패 · 권한과 차량 서비스를 확인하세요.") }
            }
            override fun onFailure(errorType: ErrorType) { ready=false; report("Pleos 음성 초기화 실패: $errorType") }
        }) }.onFailure { report("Pleos 음성 서비스를 사용할 수 없습니다. 권한·실차 환경을 확인하세요.") }
    }
    override fun play(text: String) { engine.speak(text,true) }
    override fun halt() { engine.stop() }
    override fun release() { released=true; stop(); ready=false; runCatching { engine.removeEventListener(events); engine.release() } }
}
