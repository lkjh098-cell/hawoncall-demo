package ai.hawoncall.car.voice
import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
fun createBriefingVoice(context: Context,report: (String)->Unit): BriefingVoice = AndroidDemoVoice(context,report)
private class AndroidDemoVoice(context: Context,report: (String)->Unit): FocusBriefingVoice(context,report) {
    private var engine: TextToSpeech?=null
    init {
        engine=TextToSpeech(context.applicationContext) { status -> main.post {
            if(released) return@post
            val language=engine?.setLanguage(Locale.KOREAN)
            ready=status==TextToSpeech.SUCCESS && language!=null && language>=0
            engine?.setAudioAttributes(attributes)
            report(if(ready) "Android 시연 음성 준비됨" else "Android 음성 엔진·한국어 데이터 없음 · 화면으로 확인하세요.")
        } }
        engine?.setOnUtteranceProgressListener(object: UtteranceProgressListener() {
            override fun onStart(id: String?) { report("Android 시연 브리핑 재생 중") }
            override fun onDone(id: String?) { done("브리핑 재생 완료") }
            @Deprecated("Android callback") override fun onError(id: String?) { done("음성 재생 실패 · 화면으로 확인하세요.") }
        })
    }
    override fun play(text: String) { check(engine?.speak(text,TextToSpeech.QUEUE_FLUSH,null,"day-plan")==TextToSpeech.SUCCESS) }
    override fun halt() { engine?.stop() }
    override fun release() { released=true; stop(); ready=false; engine?.shutdown(); engine=null }
}
