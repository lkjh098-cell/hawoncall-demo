package ai.hawoncall.car.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Handler
import android.os.Looper

interface BriefingVoice { fun speak(text: String): Boolean; fun stop(); fun release() }
/** Ordinary notification speech: never request navigation or safety priority. */
abstract class FocusBriefingVoice(context: Context,protected val report: (String)->Unit): BriefingVoice {
    protected val main=Handler(Looper.getMainLooper())
    protected val attributes=AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
    private val audio=context.getSystemService(AudioManager::class.java)
    private val request=AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        .setAudioAttributes(attributes).setWillPauseWhenDucked(true)
        .setOnAudioFocusChangeListener({ focus -> if(focus!=AudioManager.AUDIOFOCUS_GAIN) { stop(); report("다른 차량 소리로 브리핑을 중지했어요. 자동 재생하지 않습니다.") } },main).build()
    @Volatile protected var ready=false
    @Volatile protected var released=false
    protected abstract fun play(text: String)
    protected abstract fun halt()
    protected fun done(message: String) { audio.abandonAudioFocusRequest(request); report(message) }
    override fun speak(text: String): Boolean {
        if(!ready || released) { report("음성 엔진을 사용할 수 없습니다. 화면의 일정을 확인하세요."); return false }
        if(audio.requestAudioFocus(request)!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED) { report("차량 오디오 사용을 기다려 주세요. 브리핑은 자동 재시도하지 않습니다."); return false }
        return runCatching { play(text); report("음성 재생 요청 · 시작 응답 대기"); true }.getOrElse { done("음성 요청 실패 · 화면의 일정을 확인하세요."); false }
    }
    override fun stop() { runCatching { halt() }; done("브리핑 중지됨") }
}
