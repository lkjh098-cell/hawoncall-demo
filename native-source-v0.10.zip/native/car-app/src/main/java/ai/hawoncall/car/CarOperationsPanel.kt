package ai.hawoncall.car

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable internal fun CarOperationsPanel(vm: CarSession) {
    if(!vm.linked) return
    val data=vm.operations
    // Moving view only summarizes. No forms, setup, voice buttons, or modal survive leaving PARK.
    if(!vm.parked) {
        Text("${data?.meetingLabel?.ifBlank { "만날 장소 미확인" } ?: "만날 장소 수신 대기"} · 기관 ${if(data?.readinessCurrent(vm.operationsAgeMillis)==true) readinessTitle(data.readinessStatus) else "준비 최신 정보 대기"}",modifier=Modifier.padding(horizontal=22.dp,vertical=4.dp),color=Muted)
        return
    }
    Column(Modifier.fillMaxWidth().padding(22.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("만날 장소 · 기관 안내",style=MaterialTheme.typography.titleLarge)
        Text(data?.meetingLabel?.ifBlank { "안내 미등록" } ?: "기관 안내 수신 대기")
        data?.let {
            Text(listOf(it.entranceHint,it.meetingNotes).filter { value-> value.isNotBlank() }.joinToString(" · "))
            Text("기관 안내 · ${it.meetingUpdatedAt ?: "시각 미확인"}")
            it.referenceSpotId?.let { id -> Text("공개자료 참조: ${it.referenceSpotName ?: id} · 안내와 정차 허용은 별도입니다.") }
            it.permissionExpiresAt?.let { expiry -> Text("이용 조건 확인 유효 시각 $expiry") }
            Text(if(it.permissionCurrent(vm.operationsAgeMillis)) "참조 장소의 현재 이용 조건 확인됨" else "현장·운영 확인 필요 (${it.permissionReason})")
            Text("기관 준비 ${readinessTitle(it.readinessStatus)} · ${if(it.readinessCurrent(vm.operationsAgeMillis)) "기관이 알린 최신 정보" else "최신 여부 확인 필요"}")
            Text("ETA ${if(it.etaCurrent(vm.operationsAgeMillis)) it.etaMin?.let { value-> "${value}분" } ?: "미확인" else "미확인"} · 예상 현장 대기 ${if(it.timingCurrent(vm.operationsAgeMillis)) it.estimatedWaitMinutes?.let { value-> "${value}분" } ?: "미확인" else "미확인"}")
            Text("준비 완료는 내려보내기·탑승·입실 확인과 다릅니다.")
            it.releasedAt?.let { time -> Text("기관 내려보내기 기록 $time") }
            it.issues.takeLast(5).forEach { issue -> Text("${issueTitle(issue.kind)} · ${issue.status}${issue.reply?.let { reply -> " · 기관: $reply" }.orEmpty()}") }
            Text("${it.dayPlan.serviceDate} 보호자 일정",style=MaterialTheme.typography.titleMedium)
            it.dayPlan.items.take(8).forEach { item->Text("${item.time} ${item.title}${item.note.takeIf { value->value.isNotBlank() }?.let { note->" · $note" }.orEmpty()}") }
            if(it.dayPlan.items.isEmpty()) Text("등록한 일정이 없습니다.")
            if(it.dayPlan.reminder.isNotBlank()) Text("준비물·당부: ${it.dayPlan.reminder}")
        }
        OutlinedButton(onClick=vm::refreshOperations,enabled=!vm.recoveryRequired,modifier=Modifier.heightIn(min=56.dp)) { Text("안내 다시 확인") }
        Row { Switch(vm.voiceEnabled,vm::updateVoiceEnabled,enabled=!vm.recoveryRequired); Spacer(Modifier.width(10.dp)); Text("이 차량에서 일정 음성 사용") }
        Text("휴대폰의 날짜별 음성 동의가 함께 필요해요. 출발할 때와 하교·하원 탑승을 직접 확인한 뒤 한 번씩 안내합니다.")
        Text(vm.voiceStatus)
        Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick=vm::speakBriefing,enabled=vm.voiceEnabled && !vm.recoveryRequired,modifier=Modifier.heightIn(min=56.dp)) { Text("일정 읽기") }
            OutlinedButton(onClick=vm::stopBriefing,modifier=Modifier.heightIn(min=56.dp)) { Text("음성 중지") }
        }
        if(data?.tripId!=null) {
            var message by remember { mutableStateOf("") }
            Text("예외 상황 · 기관과 협의",style=MaterialTheme.typography.titleMedium)
            OutlinedTextField(message,{message=it.take(200).replace("\n"," ")},label={Text("요청 메모 (선택)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            listOf("NO_STOP_SPACE","CHILD_DELAYED","ALTERNATE_POINT_REQUEST","CANCEL_REQUEST").forEach { kind ->
                OutlinedButton(onClick={vm.requestIssue(kind,message)},enabled=!vm.operationsBusy && !vm.recoveryRequired && vm.operationsFresh,modifier=Modifier.fillMaxWidth().heightIn(min=56.dp)) { Text(issueTitle(kind)) }
            }
            Text("기관에 협의를 요청합니다. 현재 경로와 이동 상태는 자동 변경되지 않습니다.")
        }
        if(vm.operationsBusy) Text("요청 전송 중")
        if(vm.operationsNotice.isNotBlank()) Text(vm.operationsNotice)
        if(vm.operationsError.isNotBlank()) Text(vm.operationsError,color=MaterialTheme.colorScheme.error)
    }
}
private fun readinessTitle(value: String)=when(value) { "PREPARING"->"준비 중";"READY"->"준비 완료";"DELAYED"->"준비 지연";else->"미확인" }
private fun issueTitle(value: String)=when(value) { "NO_STOP_SPACE"->"정차 공간 없음";"CHILD_DELAYED"->"아이 준비 지연";"ALTERNATE_POINT_REQUEST"->"대체 장소 협의 요청";"CANCEL_REQUEST"->"취소 협의 요청";"RUNNING_LATE"->"보호자 지연";else->value }
