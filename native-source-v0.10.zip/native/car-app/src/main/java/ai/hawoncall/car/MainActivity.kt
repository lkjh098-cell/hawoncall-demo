package ai.hawoncall.car

import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.foundation.text.KeyboardOptions
import java.util.Locale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ai.hawoncall.car.platform.NavigationStatus
import ai.hawoncall.core.Gear
import ai.hawoncall.core.PickupState
import kotlin.math.ceil

class MainActivity : ComponentActivity() {
    private val model: CarViewModel by viewModels()
    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        // Recreate adapters after the OS permission result; settings are still protected by PARK + UX.
        if (result.values.any { !it }) model.session.onStatus("필수 권한이 허용되지 않았어요. 차량 연결을 확인하세요")
        else model.session.refreshPlatform()
    }
    private var permissionRequested = false
    private fun requestParkedPermissions() {
        if (!BuildConfig.SIMULATED_SIGNALS && model.session.parked && !permissionRequested) {
            permissionRequested = true;
            val declared = packageManager.getPackageInfo(packageName,PackageManager.GET_PERMISSIONS).requestedPermissions.orEmpty()
            val runtime = declared.filter { name ->
                runCatching { packageManager.getPermissionInfo(name,0).protectionLevel and android.content.pm.PermissionInfo.PROTECTION_MASK_BASE == android.content.pm.PermissionInfo.PROTECTION_DANGEROUS }.getOrDefault(false) && checkSelfPermission(name)!=PackageManager.PERMISSION_GRANTED
            }
            if (runtime.isNotEmpty()) permissions.launch(runtime.toTypedArray())
        }
    }
    override fun onStart() { super.onStart(); model.session.onUiVisible() }
    override fun onStop() { model.session.onUiHidden(); super.onStop() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LaunchedEffect(model.session.parked) { requestParkedPermissions() }
            MaterialTheme(colorScheme = darkColorScheme(primary = ActionBlue, onPrimary = Paper, secondary = StateGreen, background = Paper, surface = Navy, onSurface = MainText, onBackground = MainText, outline = Border)) {
                Surface(Modifier.fillMaxSize(), color = Paper) { CarScreen(model.session) }
            }
        }
    }
}

/** A compact native companion surface. The OEM navigation owns its map and route. */
internal data class CarCompanionUi(
    val parked: Boolean,
    val journeyLabel: String = "하원",
    val institutionLabel: String = "학원",
    val dropoff: Boolean = false,
    val pickupSpotContext: String = "",
    val linked: Boolean = false,
    val authorizationLost: Boolean = false,
    val recoveryAllowed: Boolean = false,
    val timetable: String = "",
    val state: PickupState = PickupState.IDLE,
    val childName: String = "",
    val academyName: String = "기관 연결을 기다리고 있어요",
    val navigationBadge: String = "내비 연결 확인 중",
    val status: String = "현재 내비와 픽업을 연결해요",
    val guidance: String = "순정 내비에서 기관을 목적지로 설정해 주세요",
    val eta: String = "—",
    val showEta: Boolean = false,
    val preparation: String = "연결 후 하원 준비 상태를 확인해요",
    val server: String = "서버 연결 전",
    val lockMessage: String = "",
    val active: Boolean = false,
    val canStart: Boolean = false,
    val canConfirm: Boolean = false,
    val canBindDestination: Boolean = false,
    val unmatchedDestinationName: String = "",
    val navigationActive: Boolean = false,
    val error: String = "",
    val settingsAllowed: Boolean = false,
    val simulated: Boolean = false,
)

@Composable private fun CarScreen(vm: CarSession) {
    if (vm.parked && vm.settingsVisible) { SettingsScreen(vm); return }
    val state = vm.snapshot?.state ?: PickupState.IDLE
    val boarded = state in setOf(PickupState.BOARDED, PickupState.DONE, PickupState.HANDED_OVER)
    var confirmationVisible by remember { mutableStateOf(false) }
    var recoveryConfirmationVisible by remember { mutableStateOf(false) }
    LaunchedEffect(vm.recoveryAllowed) { if (!vm.recoveryAllowed) recoveryConfirmationVisible=false }
    var bindingCandidate by remember { mutableStateOf<NavigationStatus?>(null) }
    var bindingAcademyName by remember { mutableStateOf("") }
    val canBindDestination = vm.canBindCurrentDestination && !vm.navigation.academyMatched && vm.navigation.destinationName.isNotBlank()
    val candidateStillCurrent = bindingCandidate?.sameDestinationAs(vm.navigation) == true && bindingAcademyName == vm.academyName
    LaunchedEffect(vm.parked, canBindDestination, candidateStillCurrent) {
        if (!vm.parked || !canBindDestination || !candidateStillCurrent) bindingCandidate = null
    }
    // Removing PARK or losing a prerequisite removes the modal immediately.
    LaunchedEffect(vm.parked, vm.guardianConfirmEnabled) {
        if (!vm.parked || !vm.guardianConfirmEnabled) confirmationVisible = false
    }
    val journey = vm.journeyLabel
    val institution = vm.institutionType.label
    val status = when (state) {
        PickupState.IDLE -> "서울 $journey 경로를 연결해요"
        PickupState.PLANNED, PickupState.EN_ROUTE -> "서울 $institution $journey 중이에요"
        PickupState.CALLED -> if (vm.pending > 0) "$journey 요청 전송 대기" else "$journey 요청을 보냈어요"
        PickupState.APPROACHING -> "$institution 근처예요"
        PickupState.ARRIVED -> "기어 P를 확인했어요"
        PickupState.BOARDING_DETECTED -> "뒷좌석 탑승 신호 감지"
        PickupState.BOARDED, PickupState.DONE -> "보호자 탑승 확인 완료"
        PickupState.HANDED_OVER -> "보호자 안전 인계 확인 완료"
        PickupState.CANCELLED -> "픽업 연결이 종료됐어요"
    }
    val guidance = when {
        vm.recoveryRequired -> "차량 연결이 갱신됐어요. P단 주차 후 다시 연결해 주세요"
        !vm.linked -> "휴대폰에서 발급한 연결 코드로 차량을 연결해 주세요"
        vm.parked && !vm.stopLocationFresh && state in setOf(PickupState.APPROACHING, PickupState.ARRIVED, PickupState.BOARDING_DETECTED) -> "위치 정보 갱신 기다림"
        state == PickupState.APPROACHING -> "안전한 픽업 위치에 주차해 주세요"
        state == PickupState.ARRIVED -> if (vm.isDropoff) "아이를 담당자에게 안전하게 인계한 후 직접 확인해 주세요" else "아이를 확인한 후 탑승을 완료해 주세요"
        state == PickupState.BOARDING_DETECTED -> "우리 아이인지 보호자가 확인해 주세요"
        state == PickupState.HANDED_OVER -> "안전 인계 확인을 기록했어요"
        boarded -> "안전벨트를 확인하고 출발해 주세요"
        vm.active -> "기존 내비 경로를 따라 이동해 주세요"
        !vm.navigation.active -> "순정 내비에서 $institution 목적지를 설정해 주세요"
        !vm.navigation.academyMatched -> "현재 내비 목적지를 픽업 장소로 등록해 주세요"
        else -> "현재 경로의 도착 예상 시간으로 $journey 준비해요"
    }
    val preparation = when {
        boarded -> if (vm.pending > 0) "보호자 확인 완료 · 서버 전송 대기" else if (vm.isDropoff) "보호자 안전 인계 확인 기록 전송됨" else "보호자 확인 완료 · 탑승 기록 전송됨"
        vm.releasedAt.isNotBlank() -> "$institution 내려보냄 확인 · ${formatTime(vm.releasedAt)}"
        state in setOf(PickupState.CALLED, PickupState.APPROACHING, PickupState.ARRIVED, PickupState.BOARDING_DETECTED) ->
            if (vm.pending > 0) "픽업 진행 기록 전송 대기 · 자동 재시도" else "$journey 요청 전송됨 · $institution 확인 대기"
        vm.active -> "도착 예상 시간에 맞춰 $journey 요청 예정"
        else -> "현재 내비 경로를 유지하며 픽업을 준비해요"
    }
    val etaSeconds = if (vm.navigation.verified) vm.navigation.remainingSeconds else null
    val ui = CarCompanionUi(
        parked = vm.parked, journeyLabel = journey, institutionLabel = institution, dropoff = vm.isDropoff,
        pickupSpotContext = vm.authorizedPickupSpot?.let { "${it.name} · ${"%.5f".format(Locale.US,it.latitude)}, ${"%.5f".format(Locale.US,it.longitude)}" }.orEmpty(), linked = vm.linked, authorizationLost = vm.recoveryRequired, recoveryAllowed = vm.recoveryAllowed, timetable = vm.timetable, state = state, childName = vm.childName, academyName = vm.academyName,
        navigationBadge = when {
            BuildConfig.SIMULATED_SIGNALS || vm.navigationDemo -> "모의 내비 신호"
            vm.navigation.connected && vm.navigation.verified -> "순정 내비 연결됨"
            vm.navigation.connected -> "내비 신호 확인 중"
            else -> "내비 연결 대기"
        },
        status = status, guidance = guidance,
        eta = etaSeconds?.let { "${ceil(it / 60.0).toInt().coerceAtLeast(1)}분" } ?: "—",
        showEta = !boarded && vm.navigation.active && state != PickupState.ARRIVED && state != PickupState.BOARDING_DETECTED,
        preparation = preparation,
        server = vm.connection + if (vm.pending > 0) " · ${vm.pending}건 전송 대기" else "",
        lockMessage = when {
            vm.gear == Gear.UNKNOWN -> "차량 정차 상태 확인 중"
            vm.gear == Gear.PARK && vm.restricted -> "차량 화면 조작 제한 중"
            !vm.parked -> "주행 중 · 조작은 P단 주차 후 가능해요"
            else -> "기어 P 확인"
        },
        active = vm.active,
        canStart = vm.linked && vm.configurationVerified && !vm.pairingBusy && !vm.pairingAwaitingPark && vm.navigation.active && vm.navigation.verified && vm.navigation.academyMatched && vm.pending == 0,
        canConfirm = vm.guardianConfirmEnabled,
        canBindDestination = canBindDestination,
        unmatchedDestinationName = if (vm.navigation.active && !vm.navigation.academyMatched) vm.navigation.destinationName else "",
        navigationActive = vm.navigation.active,
        error = vm.error, settingsAllowed = vm.settingsAllowed,
        simulated = BuildConfig.SIMULATED_SIGNALS || vm.navigationDemo,
    )
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = 1280.dp).fillMaxHeight().then(if (vm.parked) Modifier.verticalScroll(rememberScrollState()) else Modifier)) {
            CarCompanionContent(ui, onStart = vm::start, onRecover = { if (vm.recoveryAllowed) recoveryConfirmationVisible=true }, onConfirm = { if (vm.parked && vm.guardianConfirmEnabled) confirmationVisible = true }, onOpenNavigation = vm::openNavigation, onSettings = vm::showSettings, onBindDestination = { if (vm.parked && canBindDestination) { bindingAcademyName = vm.academyName; bindingCandidate = vm.navigation } })
            CarOperationsPanel(vm)
            if (vm.parked) {
                if (BuildConfig.DEBUG && BuildConfig.SIMULATED_SIGNALS) DemoTools(vm, state)
                Diagnostics(vm)
            }
        }
    }
    if (recoveryConfirmationVisible && vm.recoveryAllowed) {
        AlertDialog(onDismissRequest = { recoveryConfirmationVisible=false },
            title = { Text("차량을 다시 연결할까요?", fontWeight=FontWeight.Bold) },
            text = { Text("이전에 전송하지 못한 픽업 기록은 차량에 별도로 보관돼요. 새 연결로 다시 전송하지 않아요. 휴대폰의 새 코드로 차량을 연결해 주세요.", fontSize=19.sp, lineHeight=29.sp) },
            confirmButton = { TextButton(onClick = { recoveryConfirmationVisible=false; if (vm.recoveryAllowed) vm.recoverRevokedConnection() }, modifier=Modifier.heightIn(min=64.dp)) { Text("기록 보관 후 다시 연결", fontSize=17.sp) } },
            dismissButton = { TextButton(onClick = { recoveryConfirmationVisible=false }, modifier=Modifier.heightIn(min=64.dp)) { Text("취소", fontSize=17.sp) } })
    }
    if (bindingCandidate != null && vm.parked && canBindDestination && candidateStillCurrent) {
        val destination = checkNotNull(bindingCandidate)
        AlertDialog(
            onDismissRequest = { bindingCandidate = null },
            title = { Text("픽업 장소 등록", fontWeight = FontWeight.Bold) },
            text = { Text("안전하게 주차한 상태인가요?\n\n현재 순정 내비 목적지 ‘${destination.destinationName}’을 ${bindingAcademyName} 픽업 장소로 등록할까요?\n\n기존 경로는 바뀌지 않아요.", fontSize = 18.sp, lineHeight = 28.sp) },
            confirmButton = { TextButton(onClick = {
                val confirmed = bindingCandidate
                bindingCandidate = null
                if (vm.parked && vm.canBindCurrentDestination && !vm.navigation.academyMatched && bindingAcademyName == vm.academyName && confirmed?.sameDestinationAs(vm.navigation) == true) vm.bindCurrentDestination()
            }, modifier = Modifier.heightIn(min = 64.dp)) { Text("네, 이 장소로 등록", fontSize = 17.sp) } },
            dismissButton = { TextButton(onClick = { bindingCandidate = null }, modifier = Modifier.heightIn(min = 64.dp)) { Text("취소", fontSize = 17.sp) } },
        )
    }
    if (confirmationVisible && vm.parked && vm.guardianConfirmEnabled) {
        AlertDialog(
            onDismissRequest = { confirmationVisible = false },
            title = { Text(if (vm.isDropoff) "안전 인계 확인" else "아이 탑승 확인", fontWeight = FontWeight.Bold) },
            text = { Text(if (vm.isDropoff) "안전하게 주차했고, ${vm.childName} 아이를 기관의 담당자에게 안전하게 인계했나요? 차량 센서로 기관 입실을 확인하지 않아요." else "안전하게 주차했고, ${vm.childName} 아이가 맞고 안전하게 탑승했나요?", fontSize = 20.sp, lineHeight = 30.sp) },
            confirmButton = { TextButton(onClick = { confirmationVisible = false; if (vm.parked && vm.guardianConfirmEnabled) vm.confirm() }, modifier = Modifier.heightIn(min = 64.dp)) { Text(if (vm.isDropoff) "안전 인계 확인" else "네, 탑승을 확인했어요", fontSize = 17.sp) } },
            dismissButton = { TextButton(onClick = { confirmationVisible = false }, modifier = Modifier.heightIn(min = 64.dp)) { Text("취소", fontSize = 17.sp) } },
        )
    }
}

/** The app draws only its own responsive window. OEM navigation and system controls remain external. */
@Composable internal fun CarCompanionContent(
    ui: CarCompanionUi,
    onStart: () -> Unit = {},
    onRecover: () -> Unit = {},
    onConfirm: () -> Unit = {},
    onOpenNavigation: () -> Unit = {},
    onSettings: () -> Unit = {},
    onBindDestination: () -> Unit = {},
) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val wide = maxWidth >= 700.dp
        val inset = if (!ui.parked) 20.dp else if (wide) 30.dp else 22.dp
        Column(Modifier.fillMaxWidth().padding(inset), verticalArrangement = Arrangement.spacedBy(22.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(13.dp), verticalAlignment = Alignment.CenterVertically) {
                AppMark()
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("하원콜", color = MainText, fontWeight = FontWeight.Bold, fontSize = 29.sp)
                    Text("서울 · ${ui.institutionLabel} · ${ui.journeyLabel}", color = Muted, fontSize = 14.sp)
                }
                if (ui.parked && ui.settingsAllowed) OutlinedButton(onClick = onSettings, modifier = Modifier.heightIn(min = 64.dp), shape = RoundedCornerShape(18.dp)) { Text("연결 설정", fontSize = 16.sp) }
            }
            if (!ui.parked) {
                DrivingStatus(ui, wide)
                ConnectionFootnote(ui)
            } else if (wide) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1.3f)) { JourneyHero(ui, onStart, onConfirm, onOpenNavigation, onSettings, onBindDestination, onRecover) }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                        JourneyProgress(ui)
                        ConnectionFootnote(ui)
                    }
                }
            } else {
                JourneyHero(ui, onStart, onConfirm, onOpenNavigation, onSettings, onBindDestination, onRecover)
                if (ui.parked && ui.linked) JourneyProgress(ui)
                ConnectionFootnote(ui)
            }
        }
    }
}

@Composable private fun AppMark() {
    Canvas(Modifier.size(48.dp).background(BlueTint, RoundedCornerShape(15.dp)).padding(12.dp)) {
        val stroke = 2.5.dp.toPx()
        drawLine(ActionBlue, Offset(size.width * .24f, size.height * .18f), Offset(size.width * .24f, size.height * .78f), stroke)
        drawLine(ActionBlue, Offset(size.width * .24f, size.height * .78f), Offset(size.width * .80f, size.height * .78f), stroke)
        drawCircle(ActionBlue, size.width * .14f, Offset(size.width * .24f, size.height * .18f))
        drawCircle(ActionBlue, size.width * .14f, Offset(size.width * .80f, size.height * .78f), style = Stroke(stroke))
    }
}

/** Deliberately quiet while moving: no action, settings, map, or tappable journey step. */
@Composable private fun DrivingStatus(ui: CarCompanionUi, wide: Boolean) {
    DesignCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            InfoPill(ui.navigationBadge)
            if (wide && ui.linked) Text("${ui.childName} · ${ui.academyName}", color = Muted, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                if (!wide && ui.linked) Text("${ui.childName} · ${ui.academyName}", color = Muted, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (ui.linked) ui.status else "주차 후 차량을 연결해 주세요", color = MainText, fontSize = 30.sp, lineHeight = 41.sp, fontWeight = FontWeight.Bold)
                Text(ui.guidance, color = Muted, fontSize = 18.sp, lineHeight = 27.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (wide && ui.showEta) Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(ui.eta, color = ActionBlue, fontSize = 56.sp, fontWeight = FontWeight.Bold)
                Text("도착 예상", color = Muted, fontSize = 17.sp)
            }
        }
        if (!wide && ui.showEta) Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(ui.eta, color = ActionBlue, fontSize = 52.sp, fontWeight = FontWeight.Bold)
            Text("도착 예상", Modifier.padding(bottom = 8.dp), color = Muted, fontSize = 17.sp)
        }
        HorizontalDivider(color = Border)
        Text(ui.preparation, color = Muted, fontSize = 17.sp, lineHeight = 25.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable private fun JourneyHero(ui: CarCompanionUi, onStart: () -> Unit, onConfirm: () -> Unit, onOpenNavigation: () -> Unit, onSettings: () -> Unit, onBindDestination: () -> Unit, onRecover: () -> Unit) {
    val completed = ui.state in setOf(PickupState.BOARDED, PickupState.DONE, PickupState.HANDED_OVER)
    DesignCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InfoPill(if (!ui.linked) "차량 연결 준비" else ui.navigationBadge, if (completed) StateGreen else ActionBlue)
            Spacer(Modifier.weight(1f))
            if (ui.parked) Text("주차 중", color = Muted, fontSize = 14.sp)
        }
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            if (ui.linked) Text("${ui.childName} · ${ui.academyName}", color = Muted, fontSize = 19.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(if (ui.authorizationLost) "차량을 다시\n연결해 주세요" else if (!ui.linked) "휴대폰과 연결하면\n승하차 준비가 시작돼요" else ui.status, color = MainText, fontSize = if (ui.parked) 32.sp else 29.sp, lineHeight = if (ui.parked) 43.sp else 39.sp, fontWeight = FontWeight.Bold)
        }
        if (ui.showEta) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                Text(ui.eta, color = ActionBlue, fontSize = 58.sp, lineHeight = 64.sp, fontWeight = FontWeight.Bold)
                Text("도착 예상", Modifier.padding(bottom = 8.dp), color = Muted, fontSize = 18.sp)
            }
        }
        Text(ui.guidance, color = MainText, fontSize = 19.sp, lineHeight = 29.sp)
        if (ui.parked && ui.unmatchedDestinationName.isNotBlank()) Text("현재 목적지  ${ui.unmatchedDestinationName}", color = Muted, fontSize = 17.sp, lineHeight = 26.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        HorizontalDivider(color = Border)
        if (ui.parked) {
            if (ui.pickupSpotContext.isNotBlank()) {
                Text("허가된 승하차 지점", color = MainText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(ui.pickupSpotContext, color = Muted, fontSize = 16.sp, lineHeight = 24.sp)
                Text("기관이 등록한 유효한 허가 정보예요. 현재 순정 내비 목적지와 다를 수 있어요. 경로와 도착 판정은 현재 연결한 내비 목적지를 따라요.", color = Muted, fontSize = 15.sp, lineHeight = 23.sp)
            } else Text("확인된 허가 승하차 지점 정보가 없어요. 현장 표지와 기관 안내를 확인해 주세요.", color = Muted, fontSize = 15.sp, lineHeight = 23.sp)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (ui.timetable.isNotBlank()) ui.timetable else "현재 내비 경로를 그대로 유지해요", color = Muted, fontSize = 16.sp, lineHeight = 24.sp)
                if (!ui.linked) Text("휴대폰의 ‘차량 연결’에서 8자리 코드를 발급해 주세요.", color = Muted, fontSize = 16.sp, lineHeight = 25.sp)
            }
            when {
                ui.authorizationLost -> CompanionButton("차량 다시 연결", onRecover, ui.recoveryAllowed)
                !ui.linked -> CompanionButton("휴대폰으로 차량 연결", onSettings, ui.settingsAllowed)
                completed -> CompanionButton("순정 내비로 돌아가기", onOpenNavigation)
                ui.canConfirm -> CompanionButton(if (ui.dropoff) "안전 인계 확인" else "우리 아이 탑승 확인", onConfirm)
                !ui.active -> {
                    if (ui.canBindDestination) CompanionButton("이 목적지를 픽업 장소로 등록", onBindDestination)
                    else CompanionButton("현재 경로로 ${ui.journeyLabel} 시작", onStart, ui.canStart)
                    if (!ui.navigationActive) TextButton(onClick = onOpenNavigation, modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp)) { Text("순정 내비에서 목적지 설정", fontSize = 17.sp) }
                }
            }
        } else {
            Text(ui.preparation, color = Muted, fontSize = 17.sp, lineHeight = 26.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable private fun JourneyProgress(ui: CarCompanionUi) {
    val stage = when (ui.state) {
        PickupState.BOARDED, PickupState.DONE, PickupState.HANDED_OVER -> 3
        PickupState.ARRIVED, PickupState.BOARDING_DETECTED -> 2
        PickupState.CALLED, PickupState.APPROACHING -> 1
        else -> 0
    }
    DesignCard {
        Text("서울 ${ui.journeyLabel} 진행", color = MainText, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
        JourneyStep("01", "${ui.journeyLabel} 준비 요청", if (stage >= 1) "${ui.institutionLabel}에 ${ui.journeyLabel} 요청을 보냈어요" else "도착 시간에 맞춰 요청해요", stage >= 1, stage == 0)
        JourneyStep("02", "정차 상태 확인", if (stage >= 2) "P단과 가까운 위치를 확인했어요" else "허용된 승하차 장소에서 정차해 주세요", stage >= 2, stage == 1)
        JourneyStep("03", if (ui.dropoff) "보호자가 안전 인계 확인" else "보호자가 탑승 확인", if (stage == 3) "보호자 확인 완료" else if (ui.dropoff) "담당자에게 인계한 후 직접 확인해요" else "탑승 신호 후에도 직접 확인해요", stage == 3, stage == 2)
        HorizontalDivider(color = Border)
        Text(ui.preparation, color = Muted, fontSize = 16.sp, lineHeight = 25.sp)
    }
}

@Composable private fun JourneyStep(number: String, title: String, detail: String, done: Boolean, current: Boolean) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(if (done || current) BlueTint else Paper, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Text(if (done) "✓" else number, color = if (done || current) ActionBlue else Muted, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = if (done || current) MainText else Muted, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, color = Muted, fontSize = 15.sp, lineHeight = 23.sp)
        }
    }
}

@Composable private fun ConnectionFootnote(ui: CarCompanionUi) {
    Column(Modifier.padding(horizontal = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(ui.lockMessage, color = if (ui.parked) StateGreen else Muted, fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.Medium)
        if (ui.parked) Text(ui.server, color = Muted, fontSize = 14.sp, maxLines = 2)
        if (ui.simulated) Text("모의 시연 · 실제 차량 연동 아님", color = Muted, fontSize = 13.sp)
        if (ui.error.isNotBlank()) Text(ui.error, color = MaterialTheme.colorScheme.error, fontSize = 16.sp, lineHeight = 24.sp)
    }
}

@Composable private fun CompanionButton(label: String, onClick: () -> Unit, enabled: Boolean = true) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().heightIn(min = 68.dp), shape = RoundedCornerShape(18.dp), contentPadding = PaddingValues(horizontal = 18.dp, vertical = 17.dp)) {
        Text(label, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun ExpandableCard(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 12.dp)) {
        TextButton(onClick = { expanded = !expanded }, modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp), contentPadding = PaddingValues(horizontal = 4.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, Modifier.fillMaxWidth(), color = Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text(subtitle, Modifier.fillMaxWidth(), color = Muted, fontSize = 12.sp)
            }
            Text(if (expanded) "−" else "+", color = Muted, fontSize = 22.sp)
        }
        if (expanded) Column(Modifier.fillMaxWidth().background(Navy, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable private fun DemoTools(vm: CarSession, state: PickupState) {
    ExpandableCard("시연 도구", "주차 중에 모의 신호를 준비해요") {
        Text("기존 내비 → 픽업 연결 → 접근 중 D → P단 주차 → 뒷문 → 착석 → 보호자 확인. D단에서는 조작할 수 없어요.", color = Muted, fontSize = 14.sp, lineHeight = 22.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = vm::simulateExistingRoute, enabled = !vm.active, modifier = Modifier.heightIn(min = 64.dp)) { Text("기존 내비 설정") }
            OutlinedButton(onClick = vm::simulateNavigation, enabled = vm.active, modifier = Modifier.heightIn(min = 64.dp)) { Text("주행·접근·주차 시연") }
            OutlinedButton(onClick = vm::simulateDoor, enabled = state in setOf(PickupState.ARRIVED, PickupState.BOARDING_DETECTED), modifier = Modifier.heightIn(min = 64.dp)) { Text(if (vm.doorOpen) "뒷문 닫기" else "뒷문 열기") }
            OutlinedButton(onClick = vm::simulateOccupancy, enabled = state in setOf(PickupState.ARRIVED, PickupState.BOARDING_DETECTED) && vm.sensorsAvailable, modifier = Modifier.heightIn(min = 64.dp)) { Text(if (vm.occupied) "좌석 비우기" else "착석 신호") }
            OutlinedButton(onClick = vm::simulateRouteChange, enabled = vm.active, modifier = Modifier.heightIn(min = 64.dp)) { Text("내비 목적지 변경") }
            OutlinedButton(onClick = vm::simulateDeparture, enabled = state == PickupState.BOARDED, modifier = Modifier.heightIn(min = 64.dp)) { Text("D단 출발") }
            OutlinedButton(onClick = vm::simulateNoSensors, enabled = !vm.active, modifier = Modifier.heightIn(min = 64.dp)) { Text(if (vm.sensorsAvailable) "착석·벨트 지원" else "센서 미지원") }
        }
    }
}

@Composable private fun Diagnostics(vm: CarSession) {
    ExpandableCard("연결 상세", "차량·내비 신호와 기록") {
        Text(vm.platformStatus, color = Muted, fontSize = 13.sp, lineHeight = 21.sp)
        Text(vm.navigation.message, color = Muted, fontSize = 13.sp, lineHeight = 21.sp)
        if (vm.logs.isNotEmpty()) vm.logs.takeLast(5).reversed().forEach { Text(it, fontSize = 12.sp, color = Muted, lineHeight = 20.sp) }
        if (vm.active) TextButton(onClick = vm::cancel, modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp)) { Text("픽업 연결 취소", color = MaterialTheme.colorScheme.error) }
    }
}

@Composable private fun SettingsScreen(vm: CarSession) {
    var url by remember { mutableStateOf(vm.baseUrl) }
    var code by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = 920.dp).fillMaxHeight().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(22.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("휴대폰으로 차량 연결", Modifier.weight(1f), fontSize = 29.sp, fontWeight = FontWeight.Bold, color = MainText)
                TextButton(onClick = vm::hideSettings, enabled = !vm.pairingBusy, modifier = Modifier.heightIn(min = 64.dp)) { Text("돌아가기", fontSize = 17.sp) }
            }
            DesignCard {
                InfoPill("P단 주차 중에만 연결할 수 있어요")
                if (vm.pairingAwaitingPark) {
                    SectionHeading("차량 연결을 마무리해 주세요", "휴대폰의 연결 코드를 확인했어요. 안전하게 주차한 상태에서 연결을 완료해 주세요.")
                    if (vm.error.isNotBlank()) Text(vm.error, color = Muted, fontSize = 17.sp, lineHeight = 26.sp)
                    CompanionButton("이 차량에 연결 완료", vm::finishPendingPairing, vm.settingsAllowed && !vm.pairingBusy)
                } else {
                SectionHeading("휴대폰의 8자리 코드를 입력해 주세요", "휴대폰에서 아이와 기관을 등록하고 ‘차량 연결’을 눌러 주세요. 코드는 5분 동안 한 번 사용할 수 있어요.")
                SettingsField(url, { url = it }, "하원콜 서버 주소", !vm.pairingBusy)
                OutlinedTextField(code, { code = it.uppercase(Locale.ROOT).filter { c -> c.isLetterOrDigit() }.take(8) },
                    label = { Text("차량 연결 코드 8자리") }, placeholder = { Text("ABCD2345") },
                    textStyle = LocalTextStyle.current.copy(fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                    enabled = !vm.pairingBusy, modifier = Modifier.fillMaxWidth().heightIn(min = 76.dp), singleLine = true, shape = RoundedCornerShape(16.dp))
                Text("연결 후 순정 내비의 현재 목적지를 픽업 장소로 확인해요. 기존 경로는 유지돼요.", color = Muted, fontSize = 17.sp, lineHeight = 26.sp)
                if (vm.error.isNotBlank()) Text(vm.error, color = MaterialTheme.colorScheme.error, fontSize = 17.sp, lineHeight = 26.sp)
                CompanionButton(if (vm.pairingBusy) "안전하게 연결하는 중…" else "이 차량과 연결", { vm.pairWithMobile(url, code) }, vm.settingsAllowed && !vm.pairingBusy && code.length == 8 && url.isNotBlank())
                }
            }
            if (BuildConfig.DEBUG && !vm.pairingAwaitingPark) ManualConnectionSettings(vm, url)
        }
    }
}

/** Legacy credentials remain a debug-only recovery path; normal users pair by short-lived code. */
@Composable private fun ManualConnectionSettings(vm: CarSession, url: String) {
    var token by remember { mutableStateOf("") }
    var academyLat by remember { mutableStateOf(vm.saved("academyLat")) }
    var academyLon by remember { mutableStateOf(vm.saved("academyLon")) }
    ExpandableCard("개발자 연결 도구", "디버그 빌드 전용 · 수동 토큰과 좌표") {
        OutlinedTextField(token, { token = it }, label = { Text("차량 연결 토큰") }, modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp), singleLine = true, enabled = !vm.pairingBusy, shape = RoundedCornerShape(16.dp), visualTransformation = PasswordVisualTransformation())
        SettingsField(academyLat, { academyLat = it }, "기관 위도", !vm.pairingBusy)
        SettingsField(academyLon, { academyLon = it }, "기관 경도", !vm.pairingBusy)
        CompanionButton("수동 연결 저장", { vm.saveSettings(url, token, academyLat, academyLon, vm.nextName, vm.saved("nextLat"), vm.saved("nextLon")) }, !vm.pairingBusy && vm.settingsAllowed)
    }
}

@Composable private fun SettingsField(value: String, onChange: (String) -> Unit, label: String, enabled: Boolean = true) {
    OutlinedTextField(value, onChange, label = { Text(label) }, textStyle = LocalTextStyle.current.copy(fontSize = 19.sp), singleLine = true, enabled = enabled, modifier = Modifier.fillMaxWidth().heightIn(min = 68.dp), shape = RoundedCornerShape(16.dp))
}

/** ETA refreshes may continue; the reviewed destination identity must remain identical. */
private fun NavigationStatus.sameDestinationAs(other: NavigationStatus): Boolean =
    routeKey == other.routeKey && destinationName == other.destinationName &&
        destinationLatitude == other.destinationLatitude && destinationLongitude == other.destinationLongitude &&
        poiId == other.poiId && poiSubId == other.poiSubId && poiProvider == other.poiProvider

private fun formatTime(iso: String) = runCatching { java.time.Instant.parse(iso).atZone(java.time.ZoneId.systemDefault()).format(java.time.format.DateTimeFormatter.ofPattern("HH:mm")) }.getOrDefault(iso)

@Preview(name = "Driving companion", widthDp = 400, heightDp = 600)
@Composable private fun DrivingCompanionPreview() {
    MaterialTheme(colorScheme = darkColorScheme(primary = ActionBlue, onPrimary = Paper, surface = Navy, onSurface = MainText)) {
        Surface(color = Paper) { CarCompanionContent(CarCompanionUi(parked = false, linked = true, state = PickupState.CALLED, childName = "민준", academyName = "푸른나무학원", navigationBadge = "순정 내비 연결됨", status = "하원 요청을 보냈어요", guidance = "기존 내비 경로를 따라 이동해 주세요", eta = "4분", showEta = true, preparation = "하원 요청 전송됨 · 학원 확인 대기", server = "서버 연결됨", lockMessage = "주행 중 · 조작은 P단 주차 후 가능해요", active = true, navigationActive = true)) }
    }
}

@Preview(name = "Guardian confirmation ready", widthDp = 400, heightDp = 600)
@Composable private fun ParkedCompanionPreview() {
    MaterialTheme(colorScheme = darkColorScheme(primary = ActionBlue, onPrimary = Paper, surface = Navy, onSurface = MainText)) {
        Surface(color = Paper) { CarCompanionContent(CarCompanionUi(parked = true, linked = true, state = PickupState.BOARDING_DETECTED, childName = "민준", academyName = "푸른나무학원", navigationBadge = "순정 내비 연결됨", status = "뒷좌석 탑승 신호 감지", guidance = "우리 아이인지 보호자가 확인해 주세요", preparation = "학원 내려보냄 확인 · 16:02", server = "서버 연결됨", lockMessage = "기어 P 확인", active = true, canConfirm = true, navigationActive = true)) }
    }
}

@Preview(name = "Landscape companion app window", widthDp = 1000, heightDp = 650)
@Composable private fun LandscapeCompanionPreview() {
    MaterialTheme(colorScheme = darkColorScheme(primary = ActionBlue, onPrimary = Paper, surface = Navy, onSurface = MainText)) {
        Surface(color = Paper) { CarCompanionContent(CarCompanionUi(parked = true, linked = true, state = PickupState.APPROACHING, childName = "민준", academyName = "푸른나무학원", navigationBadge = "순정 내비 연결됨", status = "학원 근처예요", guidance = "안전한 픽업 위치에 주차해 주세요", eta = "1분", showEta = true, preparation = "학원 내려보냄 확인 · 16:02", server = "서버 연결됨", lockMessage = "기어 P 확인", active = true, navigationActive = true)) }
    }
}
