package ai.hawoncall.guardian

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ai.hawoncall.core.*

@Composable internal fun GuardianOperationsPanel(state: GuardianUiState,onLoad: (String)->Unit,onSave: (DayPlan)->Unit,onIssue: (String,String)->Unit) {
    val data=state.operations
    var date by rememberSaveable(state.session?.link?.id) { mutableStateOf(state.operationsDate) }
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("만날 장소와 기관 준비",style=MaterialTheme.typography.titleMedium)
        if(data==null) Text("기관 안내를 확인하고 있어요.")
        else {
            Text(data.meetingLabel.ifBlank { "만날 장소 안내 미등록" })
            Text(listOf(data.entranceHint,data.meetingNotes).filter { it.isNotBlank() }.joinToString(" · "))
            Text("기관 안내 · ${data.meetingUpdatedAt ?: "등록 시각 미확인"}")
            data.referenceSpotId?.let { id -> Text("공개자료 참조: ${data.referenceSpotName ?: id} · 안내와 정차 허용은 별도입니다.") }
            data.permissionExpiresAt?.let { expiry -> Text("이용 조건 확인 유효 시각 $expiry") }
            Text(if(data.permissionCurrent(if(state.operationsReceivedMonotonic>0) android.os.SystemClock.elapsedRealtime()-state.operationsReceivedMonotonic else Long.MAX_VALUE)) "참조 장소의 현재 이용 조건 확인됨" else "현장·운영 확인 필요 (${data.permissionReason})")
            val age=if(state.operationsReceivedMonotonic>0) android.os.SystemClock.elapsedRealtime()-state.operationsReceivedMonotonic else Long.MAX_VALUE
            Text("기관 준비: ${readinessLabel(data.readinessStatus)}${if(data.readinessCurrent(age)) "" else " · 최신 여부 확인 필요"}")
            Text("차량 ETA: ${if(data.etaCurrent(age)) data.etaMin?.let { "${it}분" } ?: "미확인" else "미확인"} · 예상 현장 대기: ${if(data.timingCurrent(age)) data.estimatedWaitMinutes?.let { "${it}분" } ?: "미확인" else "미확인"}")
            Text("준비 완료는 내려보내기·탑승·입실 확인이 아닙니다.")
            data.releasedAt?.let { Text("기관 내려보내기 기록: $it") }
            data.issues.takeLast(5).forEach { Text("${issueLabel(it.kind)} · ${it.status}${it.reply?.let { r -> " · 기관: $r" }.orEmpty()}") }
        }
        Text("오늘 일정 · 보호자 작성",style=MaterialTheme.typography.titleMedium)
        OutlinedTextField(date,{date=it.take(10)},label={Text("날짜 YYYY-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedButton(onClick={onLoad(date)},enabled=!state.operationsBusy && !state.needsReconnect) { Text("이 날짜 불러오기") }
        val plan=data?.dayPlan
        if(plan!=null) DayPlanEditor(plan,state.operationsBusy || state.needsReconnect,onSave)
        state.operationsError?.let { Text(it,color=MaterialTheme.colorScheme.error) }
        state.operationsNotice?.let { Text(it) }
        if(data?.tripId!=null) {
            Text("기관에 예외 상황 요청",style=MaterialTheme.typography.titleMedium)
            var message by rememberSaveable { mutableStateOf("") }
            OutlinedTextField(message,{message=it.take(200).replace("\n"," ")},label={Text("요청 메모 (선택)")},modifier=Modifier.fillMaxWidth())
            listOf("RUNNING_LATE","CHILD_DELAYED","ALTERNATE_POINT_REQUEST","CANCEL_REQUEST").forEach { kind ->
                OutlinedButton(onClick={onIssue(kind,message)},enabled=!state.operationsBusy && !state.needsReconnect,modifier=Modifier.fillMaxWidth()) { Text(issueLabel(kind)) }
            }
            Text("요청은 기관의 응답을 기다립니다. 차량 이동·경로·탑승 확인은 자동 변경되지 않습니다.")
        }
    } }
}
@Composable private fun DayPlanEditor(plan: DayPlan,disabled: Boolean,onSave: (DayPlan)->Unit) {
    var items by remember(plan.serviceDate,plan.updatedAt) { mutableStateOf(plan.items) }
    var reminder by remember(plan.serviceDate,plan.updatedAt) { mutableStateOf(plan.reminder) }
    var voice by remember(plan.serviceDate,plan.updatedAt) { mutableStateOf(plan.voicePreferences) }
    Text("${plan.serviceDate} · 최대 8개 · 차량 음성은 최대 3개와 준비물 메모")
    items.forEachIndexed { index,item ->
        Column(verticalArrangement=Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(item.time,{value->items=items.mapIndexed { i,v -> if(i==index) v.copy(time=value.take(5)) else v }},label={Text("${index+1}. 시각 HH:mm")},singleLine=true,enabled=!disabled,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(item.title,{value->items=items.mapIndexed { i,v -> if(i==index) v.copy(title=value.take(60)) else v }},label={Text("일정 제목")},singleLine=true,enabled=!disabled,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(item.note,{value->items=items.mapIndexed { i,v -> if(i==index) v.copy(note=value.take(160)) else v }},label={Text("일정 메모 (음성에서 생략)")},singleLine=true,enabled=!disabled,modifier=Modifier.fillMaxWidth())
            TextButton(onClick={items=items.filterIndexed { i,_ -> i!=index }},enabled=!disabled) { Text("일정 삭제") }
        }
    }
    OutlinedButton(onClick={items=items+DayItem("16:00","")},enabled=!disabled && items.size<8) { Text("일정 추가 (${items.size}/8)") }
    OutlinedTextField(reminder,{reminder=it.take(200)},label={Text("준비물·당부")},singleLine=true,enabled=!disabled,modifier=Modifier.fillMaxWidth())
    Row { Checkbox(voice.enabled,{voice=voice.copy(enabled=it)},enabled=!disabled); Text("차량 음성 브리핑 허용") }
    Row { Checkbox(voice.outbound,{voice=voice.copy(outbound=it)},enabled=!disabled); Text("기관으로 출발할 때 한 번") }
    Row { Checkbox(voice.afterBoarding,{voice=voice.copy(afterBoarding=it)},enabled=!disabled); Text("하교·하원에서 보호자 탑승 확인 후 한 번") }
    Button(onClick={onSave(plan.copy(items=items,reminder=reminder,voicePreferences=voice))},enabled=!disabled,modifier=Modifier.fillMaxWidth()) { Text(if(disabled) "처리 중" else "이 날짜 일정 저장") }
}
internal fun readinessLabel(value: String)=when(value) { "PREPARING"->"준비 중";"READY"->"준비 완료";"DELAYED"->"준비 지연";else->"미확인" }
internal fun issueLabel(value: String)=when(value) { "NO_STOP_SPACE"->"정차 공간 없음";"RUNNING_LATE"->"보호자 지연";"CHILD_DELAYED"->"아이 준비 지연";"ALTERNATE_POINT_REQUEST"->"대체 장소 협의 요청";"CANCEL_REQUEST"->"취소 협의 요청";else->value }
