package ai.hawoncall.guardian

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.time.Instant
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Host policy is explicit: a release host must pass false. No library BuildConfig shortcut. */
object GuardianServerPolicy {
    fun validate(raw: String, allowLocalDevelopment: Boolean): HttpUrl {
        val url = raw.trim().toHttpUrlOrNull() ?: throw IllegalArgumentException("서버 주소를 확인하세요.")
        require(url.username.isEmpty() && url.password.isEmpty() && url.query == null && url.fragment == null && url.encodedPath == "/") {
            "서버 주소에는 계정, 경로, 쿼리를 넣지 마세요."
        }
        require(url.isHttps || (allowLocalDevelopment && url.scheme == "http" && url.host in setOf("localhost", "127.0.0.1", "10.0.2.2"))) {
            "HTTPS 서버 주소가 필요합니다. 테스트 앱에서만 로컬 HTTP를 허용합니다."
        }
        return url
    }
}

enum class InstitutionType(val label: String) { SCHOOL("학교"), KINDERGARTEN("유치원"), DAYCARE("어린이집"), ACADEMY("학원") }
enum class JourneyType { PICKUP, DROPOFF }
internal fun journeyLabel(institution: InstitutionType, journey: JourneyType): String =
    if(institution==InstitutionType.SCHOOL) { if(journey==JourneyType.DROPOFF) "등교" else "하교" }
    else if(journey==JourneyType.DROPOFF) "등원" else "하원"

data class GuardianLink(val id: String, val childName: String, val academyName: String, val academyCode: String,
    val weekday: List<Int>, val pickupTime: String, val institutionType: InstitutionType = InstitutionType.ACADEMY,
    val journeyType: JourneyType = JourneyType.PICKUP, val serviceArea: String = "SEOUL", val pickupSpot: GuardianPickupSpot? = null) {
    val journeyLabel: String get() = journeyLabel(institutionType,journeyType)
}
data class GuardianTrip(val id: String, val status: String, val etaMin: Int?, val createdAt: String,
    val updatedAt: String, val calledAt: String?, val arrivedAt: String?, val boardedAt: String?,
    val releasedAt: String?, val confirmation: String?, val handedOverAt: String? = null, val journeyType: JourneyType = JourneyType.PICKUP)
data class GuardianSession(val serverUrl: String, val token: String, val link: GuardianLink,
    val latestTrip: GuardianTrip? = null, val fetchedAt: Long = 0L)
/** Fetch time is live UI state; unchanged trip snapshots do not need a new encrypted write. */
internal fun requiresSnapshotWrite(cached: GuardianSession?, fresh: GuardianSession): Boolean =
    cached==null || cached.serverUrl!=fresh.serverUrl || cached.token!=fresh.token ||
        cached.link!=fresh.link || cached.latestTrip!=fresh.latestTrip

data class GuardianPairing(val code: String, val expiresAt: Long)
data class GuardianRegistration(val academyCode: String, val childName: String, val weekday: List<Int>, val pickupTime: String,
    val institutionType: InstitutionType = InstitutionType.ACADEMY, val journeyType: JourneyType = JourneyType.PICKUP,
    val serviceArea: String = "SEOUL")
data class GuardianPickupSpot(val id: String, val name: String, val state: String, val eligible: Boolean,
    val reason: String?, val permissionExpiresAt: String?, val waitSampleCount: Int, val estimatedWaitSeconds: Int?,
    val sourceId: String?, val distanceMeters: Int? = null, val address: String? = null,
    val sourceName: String? = null, val sourceUrl: String? = null, val latitude: Double? = null, val longitude: Double? = null) {
    val selectable: Boolean get() = state=="VERIFIED" && eligible
}
data class GuardianSpotCatalog(val spots: List<GuardianPickupSpot>, val selectionAllowed: Boolean, val total: Int = spots.size, val truncated: Boolean = false)
data class GuardianRoadPoint(val longitude: Double,val latitude: Double)
data class GuardianRoadContext(val lines: List<List<GuardianRoadPoint>>,val radiusMeters: Int,val truncated: Boolean,
    val sourceName: String?,val sourceYear: String?,val sourceUrl: String?)

/** Implement with the host's agreed identity/session system when embedding. No car credentials belong here. */
interface GuardianSessionStore {
    fun load(): GuardianSession?
    fun save(session: GuardianSession)
    fun clear()
}

internal object GuardianJson {
    fun link(o: JSONObject) = GuardianLink(o.getString("id"), o.getString("childName"), o.getString("academyName"),
        o.getString("academyCode"), o.getJSONArray("weekday").let { a -> (0 until a.length()).map { a.getInt(it) } }, o.getString("pickupTime"),
        enumValueOf<InstitutionType>(o.optString("institutionType","ACADEMY")), enumValueOf<JourneyType>(o.optString("journeyType","PICKUP")),
        o.optString("serviceArea","SEOUL"), o.optJSONObject("pickupSpot")?.let(::spot)).also {
            require(it.serviceArea=="SEOUL") { "현재 서울의 기관 연결만 이용할 수 있습니다." }
        }
    private fun nullable(o: JSONObject, key: String): String? = if (!o.has(key) || o.isNull(key)) null else o.getString(key)
    fun trip(o: JSONObject) = GuardianTrip(o.getString("id"), o.getString("status"),
        if (o.isNull("etaMin")) null else o.getInt("etaMin").takeIf { it >= 0 },
        o.getString("createdAt"), o.getString("updatedAt"), nullable(o,"calledAt"), nullable(o,"arrivedAt"),
        nullable(o,"boardedAt"), nullable(o,"releasedAt"), nullable(o,"confirmation"), nullable(o,"handedOverAt"),
        enumValueOf<JourneyType>(o.optString("journeyType","PICKUP")))
    fun spot(o: JSONObject) = GuardianPickupSpot(o.getString("id"),o.getString("name"),o.getString("state"),
        o.optBoolean("eligible",false),nullable(o,"reason"),nullable(o,"permissionExpiresAt"),o.optInt("waitSampleCount",0),
        if(!o.has("estimatedWaitSeconds") || o.isNull("estimatedWaitSeconds")) null else o.getInt("estimatedWaitSeconds"),
        nullable(o,"sourceId"),if(!o.has("distanceMeters") || o.isNull("distanceMeters")) null else o.getInt("distanceMeters"),
        nullable(o,"address"),nullable(o,"sourceName"),nullable(o,"sourceUrl"),
        if(o.isNull("latitude")) null else o.optDouble("latitude").takeIf { it.isFinite() },
        if(o.isNull("longitude")) null else o.optDouble("longitude").takeIf { it.isFinite() })
    fun catalog(o: JSONObject): GuardianSpotCatalog {
        require(o.getString("serviceArea")=="SEOUL") { "서울 승하차 장소를 확인할 수 없습니다." }
        val spots=o.getJSONArray("spots")
        return GuardianSpotCatalog((0 until spots.length()).map { spot(spots.getJSONObject(it)) },o.optBoolean("selectionAllowed",false),o.optInt("total",spots.length()),o.optBoolean("truncated",false))
    }
    fun roads(o: JSONObject): GuardianRoadContext {
        require(o.getString("serviceArea")=="SEOUL" && !o.optBoolean("requiresCoordinates",true)) { "주변 도로를 확인할 수 없습니다." }
        val features=o.getJSONObject("featureCollection").getJSONArray("features")
        val lines=mutableListOf<List<GuardianRoadPoint>>()
        fun addLine(coordinates: JSONArray) {
            val points=(0 until coordinates.length()).mapNotNull { i ->
                val p=coordinates.optJSONArray(i) ?: return@mapNotNull null
                val lon=p.optDouble(0); val lat=p.optDouble(1)
                if(lon.isFinite() && lat.isFinite() && lon in -180.0..180.0 && lat in -90.0..90.0) GuardianRoadPoint(lon,lat) else null
            }
            if(points.size>=2) lines.add(points)
        }
        for(i in 0 until features.length()) {
            val geometry=features.getJSONObject(i).optJSONObject("geometry") ?: continue
            val coordinates=geometry.optJSONArray("coordinates") ?: continue
            when(geometry.optString("type")) {
                "LineString" -> addLine(coordinates)
                "MultiLineString" -> for(j in 0 until coordinates.length()) coordinates.optJSONArray(j)?.let(::addLine)
            }
        }
        val source=o.optJSONObject("source")
        return GuardianRoadContext(lines,o.optInt("radiusMeters",2000),o.optBoolean("truncated",false),
            source?.let { nullable(it,"name") ?: nullable(it,"title") ?: nullable(it,"provider") },
            source?.let { listOf("year","dataYear","referenceDate").firstNotNullOfOrNull { key -> if(!it.has(key) || it.isNull(key)) null else it.optString(key) } },
            source?.let { nullable(it,"url") ?: nullable(it,"sourceUrl") })
    }
    private fun encodeSpot(s: GuardianPickupSpot) = JSONObject().put("id",s.id).put("name",s.name).put("state",s.state)
        .put("eligible",s.eligible).put("reason",s.reason ?: JSONObject.NULL).put("permissionExpiresAt",s.permissionExpiresAt ?: JSONObject.NULL)
        .put("waitSampleCount",s.waitSampleCount).put("estimatedWaitSeconds",s.estimatedWaitSeconds ?: JSONObject.NULL)
        .put("sourceId",s.sourceId ?: JSONObject.NULL).put("distanceMeters",s.distanceMeters ?: JSONObject.NULL)
        .put("address",s.address ?: JSONObject.NULL).put("sourceName",s.sourceName ?: JSONObject.NULL).put("sourceUrl",s.sourceUrl ?: JSONObject.NULL)
        .put("latitude",s.latitude ?: JSONObject.NULL).put("longitude",s.longitude ?: JSONObject.NULL)
    fun latest(o: JSONObject): GuardianTrip? {
        val a = o.getJSONArray("trips")
        return (0 until a.length()).map { trip(a.getJSONObject(it)) }.maxByOrNull { Instant.parse(it.createdAt) }
    }
    fun registration(r: GuardianRegistration): JSONObject = JSONObject().put("academyCode",r.academyCode)
        .put("childName",r.childName).put("weekday",JSONArray(r.weekday)).put("pickupTime",r.pickupTime)
        .put("baseLeadSeconds",300).put("guardianConsent",true)
        .put("institutionType",r.institutionType.name).put("journeyType",r.journeyType.name).put("serviceArea",r.serviceArea)
    fun encode(s: GuardianSession): String {
        val l=s.link
        val out=JSONObject().put("serverUrl",s.serverUrl).put("token",s.token).put("fetchedAt",s.fetchedAt)
            .put("link",JSONObject().put("id",l.id).put("childName",l.childName).put("academyName",l.academyName)
                .put("academyCode",l.academyCode).put("weekday",JSONArray(l.weekday)).put("pickupTime",l.pickupTime)
                .put("institutionType",l.institutionType.name).put("journeyType",l.journeyType.name).put("serviceArea",l.serviceArea)
                .put("pickupSpot",l.pickupSpot?.let(::encodeSpot) ?: JSONObject.NULL))
        s.latestTrip?.let { t -> out.put("trip",JSONObject().put("id",t.id).put("status",t.status)
            .put("etaMin",t.etaMin ?: JSONObject.NULL).put("createdAt",t.createdAt).put("updatedAt",t.updatedAt)
            .put("calledAt",t.calledAt ?: JSONObject.NULL).put("arrivedAt",t.arrivedAt ?: JSONObject.NULL)
            .put("boardedAt",t.boardedAt ?: JSONObject.NULL).put("releasedAt",t.releasedAt ?: JSONObject.NULL)
            .put("confirmation",t.confirmation ?: JSONObject.NULL).put("handedOverAt",t.handedOverAt ?: JSONObject.NULL)
            .put("journeyType",t.journeyType.name)) }
        return out.toString()
    }
    fun decode(raw: String): GuardianSession = JSONObject(raw).let { o -> GuardianSession(o.getString("serverUrl"),
        o.getString("token"),link(o.getJSONObject("link")),o.optJSONObject("trip")?.let(::trip),o.optLong("fetchedAt",0L)) }
}

internal class GuardianApiException(val code: Int, message: String) : IOException(message)
internal class GuardianApi(private val allowLocalDevelopment: Boolean,
    private val client: OkHttpClient = OkHttpClient.Builder().followRedirects(false).followSslRedirects(false)
        .connectTimeout(8,TimeUnit.SECONDS).readTimeout(8,TimeUnit.SECONDS).callTimeout(12,TimeUnit.SECONDS).build()) {
    private suspend fun request(server: String, path: String, token: String? = null, body: JSONObject? = null, query: Map<String,String> = emptyMap(),maxBytes: Long = 262144, method: String = "POST"): JSONObject {
        val base=GuardianServerPolicy.validate(server,allowLocalDevelopment)
        val url=base.newBuilder().encodedPath(path).apply { query.forEach { (key,value) -> addQueryParameter(key,value) } }.build()
        val req=Request.Builder().url(url)
        if (token!=null) req.header("Authorization","Bearer $token")
        if (body!=null) req.method(method,body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
        val call=client.newCall(req.build())
        return suspendCancellableCoroutine { continuation ->
            continuation.invokeOnCancellation { call.cancel() }
            call.enqueue(object: Callback {
                override fun onFailure(call: Call, e: IOException) { if(continuation.isActive) continuation.resumeWithException(e) }
                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        try {
                            if ((it.body?.contentLength() ?: 0)>maxBytes) throw IOException("서버 응답이 너무 큽니다.")
                            val source=it.body?.source() ?: throw IOException("서버 응답이 비어 있습니다.")
                            source.request(maxBytes+1)
                            if(source.buffer.size>maxBytes) throw IOException("서버 응답이 너무 큽니다.")
                            val raw=source.readUtf8()
                            if(!it.isSuccessful) {
                                val message=runCatching { JSONObject(raw).optString("message") }.getOrNull()
                                throw GuardianApiException(it.code,message?.takeIf { m -> m.isNotBlank() } ?: "서버 연결을 확인하세요. (${it.code})")
                            }
                            val json=JSONObject(raw)
                            if(continuation.isActive) continuation.resume(json)
                        } catch(e: Exception) { if(continuation.isActive) continuation.resumeWithException(e) }
                    }
                }
            })
        }
    }
    suspend fun register(server: String,r: GuardianRegistration): GuardianSession {
        val o=request(server,"/api/guardian/links",body=GuardianJson.registration(r))
        val token=o.getString("guardianToken")
        require(token.matches(Regex("[A-Za-z0-9_-]{40,100}"))) { "보호자 인증 정보를 확인할 수 없습니다." }
        return GuardianSession(GuardianServerPolicy.validate(server,allowLocalDevelopment).toString(),token,GuardianJson.link(o.getJSONObject("link")))
    }
    suspend fun refresh(s: GuardianSession): GuardianSession {
        val link=GuardianJson.link(request(s.serverUrl,"/api/guardian/config",s.token).getJSONObject("link"))
        val trip=GuardianJson.latest(request(s.serverUrl,"/api/guardian/trips",s.token))
        return s.copy(link=link,latestTrip=trip,fetchedAt=System.currentTimeMillis())
    }
    suspend fun pickupSpots(s: GuardianSession,query: String = ""): GuardianSpotCatalog =
        GuardianJson.catalog(request(s.serverUrl,"/api/guardian/pickup-spots",s.token,query=if(query.isBlank()) emptyMap() else mapOf("q" to query),maxBytes=4_194_304))
    suspend fun roadContext(s: GuardianSession,spot: GuardianPickupSpot): GuardianRoadContext {
        val lat=spot.latitude ?: throw IllegalArgumentException("이 장소의 위치를 확인할 수 없습니다.")
        val lon=spot.longitude ?: throw IllegalArgumentException("이 장소의 위치를 확인할 수 없습니다.")
        return GuardianJson.roads(request(s.serverUrl,"/api/guardian/road-context",s.token,
            query=mapOf("lat" to lat.toString(),"lon" to lon.toString()),maxBytes=4_194_304))
    }
    suspend fun selectPickupSpot(s: GuardianSession,spotId: String): GuardianSession {
        val response=request(s.serverUrl,"/api/guardian/pickup-spot",s.token,JSONObject().put("spotId",spotId))
        return s.copy(link=GuardianJson.link(response.getJSONObject("link")))
    }
    suspend fun pairing(s: GuardianSession): GuardianPairing {
        val o=request(s.serverUrl,"/api/guardian/pairing",s.token,JSONObject())
        val code=o.getString("code")
        require(code.matches(Regex("[A-Z0-9]{8}"))) { "차량 연결 코드를 확인할 수 없습니다." }
        return GuardianPairing(code,Instant.parse(o.getString("expiresAt")).toEpochMilli())
    }
    suspend fun operations(s: GuardianSession,date: String): ai.hawoncall.core.OperationSnapshot =
        ai.hawoncall.core.OperationsJson.snapshot(request(s.serverUrl,"/api/guardian/operations",s.token,query=mapOf("serviceDate" to date)))
    suspend fun saveDayPlan(s: GuardianSession,plan: ai.hawoncall.core.DayPlan): ai.hawoncall.core.DayPlan =
        ai.hawoncall.core.OperationsJson.dayPlan(request(s.serverUrl,"/api/guardian/day-plan",s.token,ai.hawoncall.core.OperationsJson.encode(plan),method="PUT").getJSONObject("dayPlan"))
    suspend fun issue(s: GuardianSession,tripId: String,requestId: String,kind: String,message: String) {
        require(tripId.matches(Regex("[A-Za-z0-9_-]+")))
        request(s.serverUrl,"/api/guardian/trips/$tripId/issues",s.token,JSONObject().put("requestId",requestId).put("kind",kind).put("message",message))
    }

}
