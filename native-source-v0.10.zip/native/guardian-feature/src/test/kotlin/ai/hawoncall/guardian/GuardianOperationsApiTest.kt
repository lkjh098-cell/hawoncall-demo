package ai.hawoncall.guardian

import ai.hawoncall.core.*
import kotlinx.coroutines.runBlocking
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.MockResponse
import org.json.JSONObject
import org.junit.Test
import org.junit.Assert.*

class GuardianOperationsApiTest {
    private val link=GuardianLink("lk_1","하늘","하늘학원","SKY01",listOf(1),"16:00")
    @Test fun planPutAndExceptionPostUseOnlyScopedGuardianBearer()=runBlocking {
        val server=MockWebServer()
        try {
            server.start()
            val api=GuardianApi(true)
            val plan=DayPlan("2026-10-26",listOf(DayItem("17:00","수영","수건")),"물통",VoicePreferences(true,false,true))
            server.enqueue(MockResponse().setBody(JSONObject().put("dayPlan",OperationsJson.encode(plan).put("updatedAt","2026-10-26T00:00:00Z")).toString()))
            val session=GuardianSession(server.url("/").toString(),"guardian-session-only",link)
            val saved=api.saveDayPlan(session,plan)
            assertTrue(saved.voicePreferences.enabled); assertFalse(saved.voicePreferences.outbound)
            val put=server.takeRequest()
            assertEquals("PUT",put.method); assertEquals("/api/guardian/day-plan",put.path)
            assertEquals("Bearer guardian-session-only",put.getHeader("Authorization"))
            assertEquals("2026-10-26",JSONObject(put.body.readUtf8()).getString("serviceDate"))
            server.enqueue(MockResponse().setBody("{\"issue\":{\"id\":\"issue1\"}}"))
            api.issue(session,"tr_1","request-1","CANCEL_REQUEST","기관 확인 부탁드립니다")
            val post=server.takeRequest()
            assertEquals("POST",post.method); assertEquals("/api/guardian/trips/tr_1/issues",post.path)
            assertEquals("Bearer guardian-session-only",post.getHeader("Authorization"))
            val body=JSONObject(post.body.readUtf8())
            assertEquals("request-1",body.getString("requestId")); assertFalse(body.has("confirmation")); assertFalse(body.has("status"))
        } finally { server.shutdown() }
    }
    @Test fun serverFailureCannotBecomeSaveSuccess()=runBlocking {
        val server=MockWebServer()
        try {
            server.start(); server.enqueue(MockResponse().setResponseCode(503).setBody("{\"message\":\"offline\"}"))
            val session=GuardianSession(server.url("/").toString(),"g",link)
            try { GuardianApi(true).saveDayPlan(session,DayPlan("2026-10-26")); fail("503 must fail") }
            catch(error: GuardianApiException) { assertEquals(503,error.code) }
        } finally { server.shutdown() }
    }
}
