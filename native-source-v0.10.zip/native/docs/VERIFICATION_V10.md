# 0.10 검증 범위 · 2026-10-26

최종 소스로 차량 demo·Pleos APK, 보호자 APK, guardian-feature release AAR 빌드 성공. JDK17 / Gradle8.10.2 / Android35. Pleos 공식 TextToSpeech3.3.1 ON_DEVICE SDK API를 실제 의존성으로 컴파일했습니다.

자동 검사: core46, 차량30, 보호자18, 서버82 =176건 통과. 별도 브라우저67건 통과. Android 검사 실패·건너뜀0. 초기 빌드의 음성 setter JVM 충돌을 수정한 뒤 전체 빌드를 재실행했습니다.

추가 검사는 일정 입력 제한·직접 PICKUP 탑승 후 안내·DROPOFF 제외·한 번 안내 키·날짜·실제 만료 시각, 보호자 API 경로/인증·오류, 역할/기관/보호자 격리·예외 멱등성·종료 상태·ETA 관측시간을 포함합니다. HTTP를 새로 받았다는 이유로 이미 오래된 ETA나 허가의 수명을 늘리지 않습니다.

브라우저에서 보호자 일정/준비물 저장→차량 카드 반영, 기관 준비8분 vs ETA3분→대기5분, 보호자 취소 요청→기관 확인 회신을 확인했습니다. 회신 후 운행 상태는 유지됩니다. 브라우저 음성은 실제 시작 응답을 확인하지 못했으며 실패 상태와 안내문이 표시됨을 확인했습니다. 가짜 음성 엔진 콜백 검사는 실제 소리 출력 검증이 아닙니다.

실제 Pleos 차량 설치·주행·음성·OEM 오디오 포커스 공존은 미검증입니다. generic Android의 음성 엔진 유무도 기기별로 다릅니다. 출시 배포용 서명·차량 권한·설치·실기 검수와 HTTPS 서버가 필요합니다. 마이현대/외부 캘린더/음악 서비스 통합은 구현·승인된 결과가 아닙니다.

현재 현장·허가 검증 지점은0, 실제 학습 표본0입니다. 만남 안내와 반복 학습으로 허가가 생성되지 않습니다. 새 일정 API와 요청은 내비 경로·차량 운행 완료를 변경하지 않습니다.

공식 SDK·정책: https://document.pleos.ai/en/docs/pleos-only/connect-sdk-pleos/TextToSpeech/intro 및 https://document.pleos.ai/en/docs/pleos-only/vehicle-app-developer-guide/audio-focus-development-guide/audio-focus-development
