# v0.10 coordination contract

Goal: implement meeting point card, ETA vs institution readiness, pickup exceptions, and guardian-authored day-plan voice briefing across native server/car/guardian and static browser demo. Preserve v0.7 ownership/auth/permission gates, immutable trips, current OEM route, D/P distinction, explicit guardian completion. No fabricated verified real pickup points. Native UI/voice and backend agents may refine this contract together and update this file before final integration.

Proposed endpoints (agree exact payloads directly):

- Guardian GET/PUT `/api/guardian/day-plan`: serviceDate (KST YYYY-MM-DD), up to 8 schedule items `{time:HH:mm,title,note?}`, `reminder`, voice preferences. Same guardian link only. No external calendar/account integration.
- Guardian GET `/api/guardian/operations`, car GET `/api/car/operations`: `{meetingPoint,readiness,issues,dayPlan,tripId}` for own link/latest relevant trip. Distinguish source, timestamps, missing/stale values. Readiness is institution-declared, not algorithm proof.
- Guardian/car POST `/api/{guardian|car}/trips/:id/issues`: idempotent `{requestId,kind,message?,spotId?}`. Kinds NO_STOP_SPACE, CHILD_DELAYED, ALTERNATE_POINT_REQUEST, CANCEL_REQUEST, RUNNING_LATE. Guardian requests do not directly control/complete/cancel the vehicle trip or reroute. A proposed point must pass existing current permission eligibility before any selection; unverified request may ask institution to find an alternative without assigning a point.
- Institution PUT `/api/academy/meeting-point`: `{label,entranceHint,meetingNotes?,referenceSpotId?}`. This is meeting guidance, never self-issued legal permission. Derive eligible permission from existing evidence registry only.
- Institution PUT `/api/academy/trips/:id/readiness`: `{status:PREPARING|READY|DELAYED,readyInMinutes?}`. Existing released event retained; READY is preparation, not automatic boarding/institution entry.
- Institution responds to own trip issue with ACKNOWLEDGED/RESOLVED/DECLINED and short reply. Responses do not automatically modify OEM route or terminal state.

Meeting card: label, entranceHint, meetingNotes, public reference spot if any, current permission state/reason/window. Unknown remains unknown. Base data has zero verified points. Institution type and direction remain on current link/trip.

Readiness display: compare fresh vehicle ETA with fresh declared readyAt to estimate wait. If either missing/stale show unknown. Distinguish preparation done vs physically released. Do not claim live prediction from synthetic fixtures. Never modify route to consume time.

Day plan: explicit calendar date, guardian-authored source, bounded item count/text and plain text validation. Car short brief uses at most 3 items plus reminder, opt-in, once outbound and once after explicit PICKUP boarding; DROPOFF final handoff is not child-onboard return journey. No fabricated return route. Stop/respect audio focus loss; do not label schedule speech as safety/navigation to gain priority. Native Pleos TTS ON_DEVICE per current SDK docs; generic demo Android TTS fallback may have no engine. Expose unavailability instead of claiming audible success.

Browser: preserve v0.9 Pleos layout/map. Same-browser demo only. Guardian profile/forms may edit day plan, reminder and request exceptions; still cannot emit trip completion. Institution presenter simulation can publish readiness. Explicitly synthetic meeting fixtures remain unverified. Isolate new sync storage version to avoid older open tabs. No real child/personal data entry expected in public demo.

Native feature modules: guardian can edit own day plan and request; car only P can edit/issue reports or initiate voice setup. Driving view summarizes only. Network errors do not imply success. Idempotence and cross-user isolation must have meaningful tests. Backend agents update response examples and share with consumers early.


## Settled native backend contract (v0.10.0)

Backend implementation and full response examples: `server/README.md` section v0.10. Endpoint shapes sent to native_operations_v10 and acknowledged. Routes are the proposed routes above, with these concrete details:

- GET own operations accepts `serviceDate` and optional own `tripId`. Reply contains `{tripId,journeyType,institutionType,meetingPoint,readiness,timing,issues,dayPlan,serverTime}`. `timing.estimatedWaitMinutes` is nullable; `reason` is KNOWN/MISSING_ETA/STALE_ETA/MISSING_READINESS/STALE_READINESS/TRIP_TERMINAL. ETA expires after 120 seconds on both observed and server received time, readiness after 900 seconds. Dedicated accepted ETA columns prevent late events from refreshing it. ARRIVED uses initial arrival observation/receipt, and terminal operations never estimate wait.
- Day plan PUT is `{serviceDate,items:[{time,title,note?}],reminder?,voicePreferences?:{enabled,outbound,afterBoarding}}`; title60/note160/reminder200, max8, plain single-line text, actual KST calendar date within +/-90 days. GET/PUT replies `{dayPlan:{serviceDate,items,reminder,voicePreferences,source:"GUARDIAN",updatedAt}}`. Default voicePreferences `{enabled:false,outbound:true,afterBoarding:true}`. No saved plan has updatedAt null.
- Meeting point `{label,entranceHint,meetingNotes,referenceSpotId,referenceSpot,permission:{eligible,state,reason,permissionExpiresAt,maxDwellSeconds},source,updatedAt,permissionCheckedAt,guidanceIsPermission:false}`. permission reason is always a string. Guidance references may be unverified; current permission uses existing evidence, and guidance never changes selected spot or immutable trip snapshot.
- POST issue reply `{issue:{id,tripId,requestId,actor,kind,message,spotId,status,reply,createdAt,updatedAt},idempotent}`. Actor is GUARDIAN/CAR. New issue status OPEN. Same trip+actor+requestId replay is idempotent, changed body409. Optional spot only for ALTERNATE_POINT_REQUEST and must pass actual current eligibility. No spot can request institution assistance without assigning a point. Maximum50 issues/trip.
- Institution response exact route PUT `/api/academy/trips/:id/issues/:issueId` `{requestId,status:"ACKNOWLEDGED"|"RESOLVED"|"DECLINED",reply?}`. Same issue+requestId replay is idempotent, changed body409. New responses after RESOLVED/DECLINED or trip terminal are409, already accepted exact replay remains200. Maximum20 responses/issue.
- Institution GET `/api/academy/meeting-point`, GET `/api/academy/trips/:id/operations` for actual local web controls. Trip operations omits guardian private dayPlan. Institution web preserves existing list/release flow and adds meeting/readiness/response forms.
- Existing 72 tests plus10 operation integration tests passed (82 total); full rerun after institution UI/version/docs required by backend agent. All DB additions are automatic migrations; trip children cascade on90day prune and guardian schedules older than90 KST days prune separately.
